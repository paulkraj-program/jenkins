package com.deere.teamsite.common.constants;

public class TaskVariableConstants {

	public static final String DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";

	public static final String EDT = "America/New_York";

	public static final String PUBLISH_TIME = "PublishTime";

	public static final String DELETE_TIME = "DeleteTime";

	public static final String DEPLOY_DATE = "DeployDate";

	public static final String TIME_ZONE = "TimeZones";

	public static final String NEXT_TRANSITION = "nextTransition";

}
