package com.deere.teamsite.common.constants;


/**
 * The Class Constants.
 */
public class PopulateLookupConstants {
	// DataSource Variables

	/** The Constant LOOKUP_DCR_WA. */
	public static final String LOOKUP_DCR_WA = "/templatedata/deere/populate-tagger/data/";

	/** The Constant DCR_EXTENSION. */
	public static final String DCR_EXTENSION = "";

	/** The Constant LOOKUP_VALUE_CONTAINER. */
	public static final String LOOKUP_VALUE_CONTAINER = "lookup_container";

	/** The Constant LOOKUP_OPTION_LABEL. */
	public static final String LOOKUP_OPTION_LABEL = "lookup_display_name";

	/** The Constant LOOKUP_OPTION_VALUE. */
	public static final String LOOKUP_OPTION_VALUE = "lookup_option_value";
}
