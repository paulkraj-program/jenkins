package com.deere.teamsite.common.constants;

import java.util.regex.Pattern;

public class UiUtilsConstants {

	public static final String ERROR_MESSAGE = "Error while updating file,please contact system admin.";
	public static final String INVALID_FILETYPE_MESSAGE = "The file format is incompatible for Tagging. File - ";
	public static final String PROPERTIES_TITLE = "Properties Update";
	public static final String PAGE_TITLE = "title";
	public static final String MESSAGE = "message";
	public static final String EXT_ATTR_TITLE = "Title";
	public static final String EXT_ATTR_AUTHOR = "Author";
	public static final String EXT_ATTR_SUBJECT = "Subject";
	public static final String EXT_ATTR_KEYWORDS = "Keywords";
	public static final String EXT_ATTR_LOCALES = "Locales";
	public static final String CSCLIENT = "CSClient";
	public static final String EXT_MODIFIED_BY = "Modified By";
	public static final String[] BLANK_FILE = {};
	public static final String PROP_CSFACTORY = "com.interwoven.cssdk.factory.CSFactory";
	public static final String PROP_CSFACRORY_IMPL = "com.interwoven.cssdk.factory.CSJavaFactory";
	public static final String ENCODED_SPACE_PATTERN="%20";
	public static final String ASSETS_WA="/default/main/deere/Assets/WORKAREA/shared"; 
	public static final String IWMNT="/iwmnt";
	public static final Pattern LOCALE_PATTERN = Pattern.compile ("/deere/([^/]+)/([^/]+)");
	public static final String SLASH = "/";
	public static final String TEMP_FILE_EXT=".temp";
	
}
