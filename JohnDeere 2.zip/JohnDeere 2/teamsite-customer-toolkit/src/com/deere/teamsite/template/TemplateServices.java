package com.deere.teamsite.template;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.dom4j.*;
import com.interwoven.cssdk.filesys.*;
import com.deere.livesite.workflow.ReplacementPattern;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.transform.CSPTCompiler;
import com.interwoven.cssdk.transform.CSPTCompilerException;
import com.interwoven.cssdk.transform.OutputManager;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.livesite.dom4j.Dom4jUtils;
import com.interwoven.livesite.util.NodeHelper;
import com.interwoven.ui.formspub.TSTAsset;
import com.interwoven.ui.formspub.utils.TSTPathUtils;
import com.interwoven.ui.formspub.utils.TemplateManager;
import com.interwoven.ui.formspub.utils.TemplateManagerFactory;
import com.interwoven.ui.formspub.utils.XSLTPTCompiler;
import com.interwoven.ui.teamsite.tools.dependency.AssociationVersion;

/**
 * Provides common template services used within workflow and user interface
 * 
 * @author Klish Group, Inc
 * 
 */

public class TemplateServices {

	private static final transient Logger LOGGER = Logger.getLogger(TemplateServices.class);
	private static CSClient _client;
	private static Document mConfigXml = null;
	public static final String XPATH_PREFIX = "//";
	private static boolean _deleteBeforeGenerate = false;
	private static Pattern localePattern = Pattern.compile("(/[a-z][a-z]/[a-z][a-z]/)");

	/**
	 * Constructor to initialize TemplateServices
	 * @param client
	 * 			CSClient Object
	 * @param xmlFile
	 * 			Path to the generation configuration file
	 */
	public TemplateServices(CSClient client, String xmlFile, boolean deleteBeforeGenerate) {
		_client = client;
		_deleteBeforeGenerate = deleteBeforeGenerate;

		//Load the generation properties file.
		if (xmlFile != null) {
			LOGGER.debug("Loading Generate Properties File: " + xmlFile);
			mConfigXml = loadXMLFile(xmlFile);
		}
	}

	/***
	 * Check if the generate property files specified in the task 
	 * is valid. 
	 * 
	 * @return true or false.
	 * 
	 */
	public boolean isValidProperties() {
		if (mConfigXml != null) {
			return true;
		}
		return false;
	}

	/**
	 * Gets the list of dcrs to generate configured in templating.cfg.
	 * @param task
	 * @param attachedDCRList
	 *         List of DCRs Attached to workflow
	 * @return
	 * 			List of CSSimple File objects
	 * @throws CSException
	 */

	public List<CSSimpleFile> getFilesToGenerate(CSExternalTask task, List<CSSimpleFile> attachedDCRList) throws CSException {
		LOGGER.debug("Get Files to Generate");

		List<CSSimpleFile> generationList = new ArrayList<>();
		String[] ptList = null;

		TemplateManager tmplMgr = null;

		//Check each DCR attached to the task if it can generate files.
		for (CSSimpleFile dcr : attachedDCRList) {
			LOGGER.debug("DCR : " + dcr.getVPath().getPathNoServer().toString());
			try {
				TSTAsset asset = new TSTAsset(dcr);
				String category = asset.getTDT().getCategory();
				String dataType = asset.getTDT().getType();
				
				LOGGER.debug("TDT Category: " + category);
				LOGGER.debug("TDT DataType: " + dataType);

				tmplMgr = TemplateManagerFactory.templateManager(_client);
				ptList = tmplMgr.getPTs(category, dataType, dcr.getVPath().getArea());

				if (ptList != null) {
					for (String pt : ptList) {
						if (tmplMgr.doesPtExists(category, dataType, pt, dcr.getArea().getVPath())) {
							LOGGER.debug("PT: " + pt);
							generationList.add(dcr);
							break;
						} else {
							LOGGER.warn(pt + " presentation template does not exist in the presentation folder.");
						}
					}
				} else {
					LOGGER.warn("PTList was null");
				}
			} catch (Exception e) {
				LOGGER.error("Error getting files to generate.", e);
				throw new CSException(e);
			}
		}

		return generationList;
	}

	/**
	 * Provides a wrapper for the file generation using CSSDK
	 * 
	 * @param dcrFile
	 *            CSSimpleFile object for data content record
	 * @return operating system return code from the command execution
	 * @throws CSException 
	 */

	public CSVPath generateFile(CSSimpleFile dcrFile) throws CSException {

		LOGGER.debug("Generating Output For DCR : " + dcrFile.getVPath().getAreaRelativePath().toString());
		TSTAsset asset = new TSTAsset(dcrFile);
		TemplateManager templateManager = null;

		String[] ptList = null;
		try {
			templateManager = TemplateManagerFactory.templateManager(_client);

			//Category associated with the DCR
			String category = asset.getTDT().getCategory();
			//Data Type associated with the DCR
			String dataType = asset.getTDT().getType();

			//Get list of all the configured presentation templates for the category/datatype
			ptList = templateManager.getPTs(category, dataType, dcrFile.getVPath().getArea());

			if (ptList != null) {
				//Loop through all the configured presentation templates and generate
				for (String pt : ptList) {
					//Get the Output file path for the DCR.
					String outputVpath = getOutputFile(pt, dcrFile);

					if (!outputVpath.isEmpty()) {
						try {
							LOGGER.debug("Output File Path : " + outputVpath);
							CSFile outFile = _client.getFile(new CSVPath(outputVpath));
							if (outFile != null && outFile.getKind() != CSHole.KIND && _deleteBeforeGenerate) {
								LOGGER.debug("Deleting output file before generating : " + outFile.getVPath().getPathNoServer().toString());
								outFile.delete();
							}
							return generate(templateManager, dcrFile, pt, outputVpath);
						} catch (CSException cse) {
							throw new CSException();
						}
					}
				}
			} else {
				LOGGER.warn("No presentation templates configured for " + category + "/" + dataType);
			}

			return null;
		} catch (Exception ex) {
			LOGGER.error("An exception was thrown trying to acquire a TemplateManager object.", ex);
			throw new CSException(ex);
		}

	}

	private static CSVPath generate(TemplateManager templateManager, CSSimpleFile dcrFile, String pt, String outputVPath) throws CSException {

		LOGGER.debug("Out Put Path : " + outputVPath);
		LOGGER.debug("PT : " + pt);

		TSTAsset asset = new TSTAsset(dcrFile);

		CSVPath output = new CSVPath(outputVPath);
		CSPTCompiler compiler = null; 
		
		try {
			//compiler = templateManager.getPtcompiler (asset.getTDT ().getCategory (), asset.getTDT ().getType (), pt);
			compiler = new XSLTPTCompiler();
		} catch (Exception ex) {
			LOGGER.error("Failed to obtain TemplateManager instance or Template Compiler instance", ex);
			throw new CSException(ex);
		}

		String category = asset.getTDT().getCategory();
		String dataType = asset.getTDT().getType();

		compiler.setCSClient(_client);
		compiler.setDcr(asset.getDCRVPath().getPathNoServer());
		TSTPathUtils utils = TemplateManagerFactory.tstPathUtils();
		CSVPath ptPath = dcrFile.getVPath().getArea().getPathNoServer();
		ptPath = ptPath.concat(utils.getPathToPT(pt, category, dataType));

		compiler.setPt(ptPath);
		LOGGER.debug("Presentation path: " + ptPath.toString());

		CSVPath outputDir = output.getParentPath();
		compiler.setOutputDirectory(outputDir);
		LOGGER.debug("Output directory: " + outputDir.toString());

		checkOutputDirectory(outputDir);

		String fileName = output.getName();
		compiler.setOutputFileName(fileName);
		LOGGER.debug("Output filename: " + fileName);

		OutputManager outputManager = _client.getTransformOutputManager(0, _client.getWorkarea(dcrFile.getVPath().getArea(), false));
		LOGGER.debug("Obtained OutputManager from CSClient instance");

		try {
			compiler.compile(outputManager);
			LOGGER.info("Template compilation for file " + outputVPath + " successful");

			CSSimpleFile outputFile = (CSSimpleFile) _client.getFile(new CSVPath(outputVPath));
			try {
				outputFile.lock("");
			} catch (CSFileAlreadyLockedException lockedE) {

			} catch (CSObjectNotFoundException nfex) {
				LOGGER.error("Unable to lock generated file.", nfex);
				throw new CSException();
			} catch (CSException csex) {
				LOGGER.error("Error locking generated file.", csex);
				throw csex;
			}

			String dcrNameRelativeToDataDir = dcrFile.getName();
			String dataPathNoWorkarea = TemplateManagerFactory.tstPathUtils().getPathToDataDir(category, dataType);
			String dcrPathNoWorkarea = dcrFile.getVPath().getAreaRelativePath().toString();

			if ((dataPathNoWorkarea != null) && (dcrPathNoWorkarea != null)) {
				if ((dcrPathNoWorkarea.indexOf(dataPathNoWorkarea) == 0) && (dcrPathNoWorkarea.length() > dataPathNoWorkarea.length())) {
					int startIndex = dataPathNoWorkarea.length();
					if (!dataPathNoWorkarea.endsWith("/")) {
						startIndex++;
					}
					dcrNameRelativeToDataDir = dcrPathNoWorkarea.substring(startIndex);
				}
			}

			List<CSExtendedAttribute> eas = new ArrayList<CSExtendedAttribute>(3);
			eas.add(new CSExtendedAttribute("TeamSite/Templating/PrimaryDCR", dcrNameRelativeToDataDir));
			eas.add(new CSExtendedAttribute("TeamSite/Templating/PrimaryPT", pt));
			eas.add(new CSExtendedAttribute("TeamSite/Templating/PrimaryDocumentType", category + "/" + dataType));
			outputFile.setExtendedAttributes((CSExtendedAttribute[]) eas.toArray(new CSExtendedAttribute[3]));

			try {
				outputFile.deleteParentAssociations("pt-outputfile");
				outputFile.deleteParentAssociations("dcr-outputfile");
			} catch (CSException csex) {
				LOGGER.error("Couldn't remove the parent associations of " + outputFile.getVPath().toString(), csex);
				throw csex;
			}

			LOGGER.debug("Add association from " + dcrFile.getVPath().getPathNoServer() + " to " + outputFile.getVPath());

			try {
				CSAssociation[] associations = dcrFile.createChildAssociations(new CSAssociatable[] { outputFile }, "dcr-outputfile", true);
				if ((associations != null) && (associations.length == 0)) {
					LOGGER.warn("Couldn't add association between " + dcrFile.getVPath() + " and " + outputFile.getVPath());
				}
			} catch (CSException csex) {
				LOGGER.debug("Couldn't add association from " + dcrFile.getVPath().getPathNoServer() + " to " + outputFile.getVPath());
				throw csex;
			}

			CSSimpleFile ptFile = (CSSimpleFile) _client.getFile(ptPath);
			LOGGER.debug("Add association from " + ptFile.getVPath() + " to " + outputFile.getVPath().toString());

			try {
				CSAssociation[] associations = ptFile.createChildAssociations(new CSAssociatable[] { outputFile }, "pt-outputfile", true);
				if (associations.length == 0) {
					LOGGER.warn("Couldn't add association between " + ptFile.getVPath().toString() + " and " + outputFile.getVPath().toString());
				}
			} catch (CSException csex) {
				LOGGER.debug("Couldn't add association from " + ptFile.getVPath() + " to " + outputFile.getVPath());
				throw csex;
			}

			LOGGER.debug("execute: update association version for " + outputFile.getVPath().getPathNoServer());

			AssociationVersion.getInstance().setAssociationVersion(outputFile);

			return output;
		} catch (CSPTCompilerException csptce) {
			LOGGER.error("Template compilation failed", csptce);
			throw new CSException(csptce);
		}

	}

	/**
	 * Constructs the Output path for the category/datatype defined in the generation properties file.
	 * @param presentationTemplate
	 * 			Path to the presentation template to be generated
	 * @param dcrFile
	 * 			CSSimpleFile object for data capture record.
	 * @return
	 * 			Path to the output file. 
	 * @throws CSException
	 */
	private static String getOutputFile(String presentationTemplate, CSSimpleFile dcrFile) throws CSException {

		TemplateManager templateManager = null;
		TSTAsset asset = new TSTAsset(dcrFile);
		String outputPath, outputFileName, outputExtension;
		outputPath = outputFileName = outputExtension = "";

		try {
			templateManager = TemplateManagerFactory.templateManager(_client);

			String category = asset.getTDT().getCategory();
			String dataType = asset.getTDT().getType();
			String area = asset.getDCRVPath().getArea().getPathNoServer().toString();
			outputExtension = templateManager.getExtension(category, dataType, presentationTemplate);
			
			LOGGER.debug("Category is " + category);
			LOGGER.debug("DataType is " + dataType);
			LOGGER.debug("Presentation template name is " + presentationTemplate);
			LOGGER.debug("Area is " + area);
			LOGGER.debug("Output extension is " + outputExtension);
			
			Element root = mConfigXml.getRootElement();
			LOGGER.debug("Root is " + root==null ? "null" : root.asXML());

			//Read the 
			Element outputNode = (Element) mConfigXml.selectSingleNode("templating/category[@name='" + category + "']/data-type[@name='" + dataType + "']/presentation/template[@name='" + presentationTemplate + "']/output");

			if (outputNode != null) {
				String dataSourceType = getAttribute(outputNode, "dataSource", null);
				String fileName = getAttribute(outputNode, "fileName", "");
				String folderPath = getAttribute(outputNode, "folderPath", "");
				String useLocaleInPath = getAttribute(outputNode, "useLocaleInPath", "");
				
				//Add the locale in the path of the mapping json
				if(useLocaleInPath != null && useLocaleInPath.equalsIgnoreCase ("true")){
					String pathAfterLocale = getAttribute(outputNode, "pathAfterLocale", "");
					String workAreaPath = dcrFile.getArea ().getVPath ().toString ();
					Matcher m = localePattern.matcher (workAreaPath);
					if(m.find ()){
						LOGGER.debug ("Locale Path "+m.group());
						folderPath = !folderPath.isEmpty() ? "/" + folderPath + m.group(): "";
					}else
						folderPath = !folderPath.isEmpty() ? "/" + folderPath: "";
					
					folderPath = !pathAfterLocale.isEmpty () ? folderPath + pathAfterLocale: folderPath;
				}else
					folderPath = !folderPath.isEmpty() ? "/" + folderPath : "";

				Boolean useDcrRelativePath = getAttribute(outputNode, "useDCRRelativePath", "false").equalsIgnoreCase("true");
				String dcrRelativePath = (useDcrRelativePath) ? getDcrRelativePath(asset) : "";

				LOGGER.debug("DataSource : " + dataSourceType);
				LOGGER.debug("File Name: " + fileName);
				LOGGER.debug("Folder Path : " + folderPath);

				if (dataSourceType.equalsIgnoreCase("Xpath")) {
					outputFileName = getNodeValue(dcrFile, XPATH_PREFIX + fileName);
					outputFileName = !outputFileName.isEmpty() ? "/" + outputFileName : "";
				} else if (dataSourceType.equalsIgnoreCase("constant")) {
					outputFileName = "/" + fileName;
				} else if (dataSourceType.equalsIgnoreCase("filename")) {
					outputFileName = "/" + FilenameUtils.removeExtension(dcrFile.getVPath().getName().toString());
					//outputFileName = outputFileName.replaceAll("\\s+", "_");
					outputFileName = fileName + outputFileName;
				}

				if (outputFileName != null && !outputFileName.isEmpty()) {
					String areaRelativeFolderPath = folderPath + dcrRelativePath;

					LOGGER.debug("Loading File Patterns");
					List<ReplacementPattern> filenamePatterns = loadPatternSettings((Element) outputNode.selectSingleNode("filename-pattern"));
					LOGGER.debug("Loading Folder Patterns");
					List<ReplacementPattern> folderPatterns = loadPatternSettings((Element) outputNode.selectSingleNode("folder-pattern"));

					outputFileName = ReplacementPattern.applyPatterns(outputFileName, filenamePatterns);
					areaRelativeFolderPath = ReplacementPattern.applyPatterns(areaRelativeFolderPath, folderPatterns);

					outputPath = area + areaRelativeFolderPath + outputFileName + "." + outputExtension;
				} else {
					LOGGER.warn("Unable to get OutPut file name");
				}

			} else {
				LOGGER.warn("Presentation Template " + presentationTemplate + " not configured to generate.");
			}

		} catch (Exception e) {
			LOGGER.error("Failed to obtain TemplateManager instance or Template Compiler instance", e);
			throw new CSException(e);
		}

		return outputPath;
	}

	private static List<ReplacementPattern> loadPatternSettings(Element patternsNode) {
		List<ReplacementPattern> replacementPatterns = new ArrayList<ReplacementPattern>();
		if (patternsNode == null) {
			LOGGER.debug("Null patterns node");
			return replacementPatterns;
		}

		@SuppressWarnings("unchecked")
		List<Element> patternNodeList = patternsNode.elements();

		for (Element patternNode : patternNodeList) {
			if ("pattern".equals(patternNode.getName())) {

				String source = patternNode.attributeValue("pattern");
				String target = patternNode.attributeValue("replacement");

				replacementPatterns.add(new ReplacementPattern(source, target));
			}
		}

		if (replacementPatterns.isEmpty()) {
			LOGGER.debug("Loaded zero (0) Path Patterns");
		}

		return replacementPatterns;
	}

	private static String getAttribute(Element outputNode, String attributeName, String defaultValue) {
		return (outputNode.attributeValue(attributeName) != null) ? outputNode.attributeValue(attributeName) : defaultValue;
	}

	private static String getNodeValue(CSSimpleFile dcrFile, String xPath) throws CSException {
		String dcrXml = NodeHelper.readFileData(dcrFile);
		Document dcrDocument = Dom4jUtils.newDocument(dcrXml);
		Node nodeElement = dcrDocument.selectSingleNode(xPath);

		return (nodeElement != null && !nodeElement.getText().isEmpty()) ? nodeElement.getText() : "";
	}

	private static String getDcrRelativePath(TSTAsset asset) {
		Pattern pattern = Pattern.compile("^templatedata/[^\\/]+/[^\\/]+/data/(.*)$");
		Matcher m = pattern.matcher(asset.getDCRVPath().getAreaRelativePath().getParentPath().toString());

		return (m.matches()) ? "/" + m.group(1) : "";
	}

	private static Document loadXMLFile(String xmlFile) {
		Document document = null;

		File resourceFile = new File(xmlFile);
		String currentFolderLocation = System.getProperty("user.dir") + "/" + xmlFile;

		File currentResourceFile = new File(currentFolderLocation);

		if ((resourceFile != null && resourceFile.exists()) || (currentResourceFile != null && currentResourceFile.exists())) {
			FileInputStream fileInput;

			try {
				if ((resourceFile != null && resourceFile.exists())) {
					LOGGER.debug("Loading resource file from absolute location.");
					fileInput = new FileInputStream(resourceFile);
				} else {
					LOGGER.debug("Loading resource file from current folder.");
					fileInput = new FileInputStream(currentResourceFile);
				}

				document = Dom4jUtils.newDocument(fileInput);
			} catch (IOException ioex) {
				LOGGER.error("Error loading properties file : " + xmlFile);
			}

		} else {
			InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(xmlFile);
			if (input != null) {
				document = Dom4jUtils.newDocument(input);
			} else {
				LOGGER.error("Unable to load XMLfile from toolkit: " + xmlFile);
			}
		}

		return document;
	}

	private static void checkOutputDirectory(CSVPath outputPath) throws CSException {

		CSFile outputDir = _client.getFile(outputPath);

		if (outputDir == null || outputDir.getKind() == CSHole.KIND) {
			LOGGER.info("Directory doesn't exist, creating new");
			CSWorkarea area = _client.getWorkarea(new CSVPath(outputPath).getArea(), true);
			createParentDirectories(area, new CSAreaRelativePath(outputPath.getAreaRelativePath()));
		} else {
			LOGGER.debug("Directory already exists");
		}
	}

	public static void createParentDirectories(CSWorkarea area, CSAreaRelativePath path) throws CSException {
		CSAreaRelativePath parentPath = path.getParentPath();

		if (!parentPath.isEmpty()) {
			createParentDirectories(area, parentPath);
		}

		try {
			CSVPath vpath = new CSVPath(area.getVPath().toString() + "/" + path.toString());

			CSFile filesysEntry = _client.getFile(vpath);
			if (filesysEntry == null || filesysEntry.getKind() == CSHole.KIND) {
				LOGGER.debug("Path " + path.toString() + " does not exist, creating...");
				area.createDirectory(path);
			}

		} catch (CSException csex) {
			LOGGER.error("Failed creating parent directory: " + csex);
			throw csex;
		}
	}
}
