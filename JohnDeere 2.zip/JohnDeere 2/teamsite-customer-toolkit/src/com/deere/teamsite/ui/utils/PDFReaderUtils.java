package com.deere.teamsite.ui.utils;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.text.PDFTextStripper;
import org.owasp.esapi.ESAPI;

import com.deere.livesite.workflow.exception.CustomRuntimeException;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.deere.teamsite.common.constants.UiUtilsConstants;
import com.deere.teamsite.model.PDFInfo;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.ui.teamsite.g11n.blc.BranchConfigProviderIfc;



public class PDFReaderUtils {
	private static final  Logger LOGGER = Logger.getLogger(PDFReaderUtils.class);
	public static PDFInfo getPDFDocumentsInfo(String vpath) throws IOException {
		
	
			
			 CSVPath path=new CSVPath(vpath);
			 LOGGER.debug("File path :"+UiUtilsConstants.IWMNT+path.getPathNoServer().toString());
			 File pdfFile=new File(UiUtilsConstants.IWMNT+path.getPathNoServer().toString());
			 try (PDDocument document = PDDocument.load(pdfFile);)
	         { 
				 if (document.isEncrypted())
	             {
	            	 LOGGER.debug( "Error: Cannot add metadata to encrypted document." );
	            	 throw new CustomRuntimeException("Error: Cannot add metadata to encrypted document");
	             }  
			 PDDocumentInformation pdfDocInfo = document.getDocumentInformation();
			 PDFInfo pdfInfo=new PDFInfo();
			 String[] suggestions=getPDFInfoSugestion(document);
			 //Set Title and subject if present in document or get 1st and 2nd line of document and suggest on the field 
			 pdfInfo.setAuthor(pdfDocInfo.getAuthor());
			 //lines from file with more than 10,20 characters for title and subject respectively 
			 pdfInfo.setTitle(null!=pdfDocInfo.getTitle() && !pdfDocInfo.getTitle().trim().equals("") && pdfDocInfo.getTitle().length()>10?pdfDocInfo.getTitle():(!ArrayUtils.isEmpty(suggestions)?getSuggestion(suggestions,10):""));
			 pdfInfo.setSubject(null !=pdfDocInfo.getSubject() && !pdfDocInfo.getSubject().equals("") && pdfDocInfo.getTitle().length()>20?pdfDocInfo.getSubject():(!ArrayUtils.isEmpty(suggestions)?getSuggestion(suggestions,20):""));
			 pdfInfo.setKeywords(pdfDocInfo.getKeywords());
			 Map<String, String> customMetaData=new HashMap<String, String>();
			 customMetaData.put("Locales",pdfDocInfo.getCustomMetadataValue("Locales"));
			 pdfInfo.setCustomProperties(customMetaData);
			 LOGGER.debug("PDF Metadata are :"+ESAPI.encoder().encodeForHTML(pdfInfo.toString()));
			 
			 return pdfInfo;
		} catch (Exception e) {
			
			LOGGER.error("Error occured in getPDFDocumentsInfo for PDFReaderUtils",e);
			throw new CustomRuntimeException("Error while fetching file metadata");
		} 
		
	
	}

	/**
	 * Method to fetch valid string size for suggestion
	 * @param suggestions array of lines form file
	 * @param size number of line to for substring
	 * @return
	 */
	 public static String getSuggestion(String[] suggestions,int size) {
		 for(String text:suggestions) {
			 LOGGER.debug("Iterating suggestion :"+text +" size : "+text.length());
			 if(text.length()>=size) {
				 LOGGER.debug("Adding text :"+text);
				 return text;
			 }
		 }
		
		return null;
	}


	public static synchronized void  setPDFDocumentsInfo(String vpath,PDFInfo pdfInfo) throws IOException {
		 CSVPath path=new CSVPath(vpath);
		 LOGGER.debug("File path :"+path.getPathNoServer().toString());
		 File pdfFile=new File(UiUtilsConstants.IWMNT+path.getPathNoServer().toString());
		 File tempPDFfile=new File(UiUtilsConstants.IWMNT+path.getPathNoServer().toString()+UiUtilsConstants.TEMP_FILE_EXT);
		 LOGGER.debug("Copying file to "+UiUtilsConstants.IWMNT+path.getPathNoServer().toString()+UiUtilsConstants.TEMP_FILE_EXT);
		 Files.copy(pdfFile.toPath(), tempPDFfile.toPath());
		
		 try (PDDocument document = PDDocument.load(pdfFile);)
         {
             if (document.isEncrypted())
             {
            	 LOGGER.debug( "Error: Cannot add metadata to encrypted document." );
            	 throw new CustomRuntimeException("Error: Cannot add metadata to encrypted document");
             }       
     	               
            PDDocumentInformation info = document.getDocumentInformation();
                     
            if(isModifiableFile(document)) {
            	 
            LOGGER.debug("isModifiableFile true flag found");
            info.setTitle(pdfInfo.getTitle());
            info.setAuthor(pdfInfo.getAuthor());
            info.setSubject(pdfInfo.getSubject());
            info.setKeywords(pdfInfo.getKeywords());
			 Map<String, String> customMetaData=pdfInfo.getCustomProperties();
			
			 Set<String> customMetaDataKeyset=customMetaData.keySet();
			for (String key : customMetaDataKeyset) {
				LOGGER.debug("Custom metadata of the file :" + key + ":" + ESAPI.encoder().encodeForHTML(customMetaData.get(key)));
				info.setCustomMetadataValue(key, customMetaData.get(key));

			}
			
			 LOGGER.debug("document.getDocument().getCOSObject() :"+document.getDocument().getCOSObject().toString());
			 document.save(pdfFile);
			
			 
			 //Checking if the update didn't affected the pdf structure (Failed to load error on browser)
		
			 PDDocument.load(pdfFile);
			 LOGGER.debug("Loading success... Deleting temp file "+tempPDFfile.delete());
			
			 
             }
             else {
            	 LOGGER.debug("Skipping file from tagging as file may affect xhref object,may lead to corruption");
            	 throw new CustomRuntimeException("PDF content not accessible");
             }
			
         }
		 catch (Exception e) {
			 LOGGER.error("Error occured in setPDFDocumentsInfor for PDFReaderUtils",e);
				LOGGER.debug("File revert to before metadata update state");
				Files.copy(tempPDFfile.toPath(), pdfFile.toPath(),StandardCopyOption.REPLACE_EXISTING);
				LOGGER.debug("Deleting temp file "+tempPDFfile.delete());
				throw new CustomRuntimeException("Error while updating file metadata" +vpath);
			}
		
			 
        
	 
	}
	
	public static Set<SyndicationTarget> getTaggedLocaleList(Set<SyndicationTarget> targets,String taggedLocale){
		Set<SyndicationTarget> taggedTarget=new HashSet<SyndicationTarget>();
		if(taggedLocale!=null && !taggedLocale.equals("")) {
			String[] locales=taggedLocale.trim().split(",");
		for(String locale:locales) {
			LOGGER.debug("Checking locale :"+locale.replace("_", "-"));
			SyndicationTarget selectedTraget=SyndicationTarget.filterByLocale(targets, locale.replace("_", "-"));
			if(selectedTraget!=null) {
			taggedTarget.add(selectedTraget);
			}
		}
		LOGGER.debug("Tagged Targets are :"+taggedTarget.toString());
		}
		
		return taggedTarget;
	}
	
	public static void setExtendedAttribute(String vpath,PDFInfo info,CSClient client) {
		CSVPath path=new CSVPath(vpath);
		
		
		try {
			if(client==null) {
			client=getCSClient();
			}
			LOGGER.debug("Client  :"+client.getContext().getServerName());
			CSFile file=client.getFile(new CSVPath(path.getPathNoServer().toString()));
			LOGGER.debug("Current User   :"+client.getCurrentUser().getDisplayName());		
			LOGGER.debug("Process files   :"+file.getName());
			((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(UiUtilsConstants.EXT_ATTR_TITLE, info.getTitle()) });
			((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(UiUtilsConstants.EXT_ATTR_AUTHOR, info.getAuthor()) });
			((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(UiUtilsConstants.EXT_ATTR_SUBJECT, info.getSubject()) });
			((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(UiUtilsConstants.EXT_ATTR_KEYWORDS, info.getKeywords()) });
			((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(UiUtilsConstants.EXT_ATTR_LOCALES, info.getCustomProperties().get(UiUtilsConstants.EXT_ATTR_LOCALES)) });
			((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(UiUtilsConstants.EXT_MODIFIED_BY,client.getCurrentUser().getDisplayName()) });
		} catch (Exception e) {
			
			LOGGER.error("Error occured in setExtendedAttribute for PDFReaderUtils",e);
			throw new CustomRuntimeException("Unable to set extended attribute on file");
		}
		
		
	}
	
	
	public static String[] getPDFInfoSugestion(PDDocument document){
		
	    PDFTextStripper pdfStripper;
	    String[] lines =null;
		try {
			pdfStripper = new PDFTextStripper();
		//Read only first page
		
	   // pdfStripper.setStartPage(1);
	   // pdfStripper.setEndPage(1);
	    //load all lines into a string
	    String pages = pdfStripper.getText(document).trim();
	    LOGGER.debug("pages text after trim   :"+pages);
	    lines= pages.split("\r\n|\r|\n");
	   
		} catch (Exception e) {
			
			LOGGER.error("Error occured in getPDFInfoSuggestion for PDFReaderUtils",e);
			//throw new CustomRuntimeException("Unable to read files content ");
			return lines;
			
		}
		 return lines;
	}
	
	public static CSClient getCSClient() throws CSException {
		Properties properties = new Properties(System.getProperties());
		LOGGER.debug("Getting CSClient instance");
		
		if (properties.getProperty(UiUtilsConstants.PROP_CSFACTORY) == null) {
			properties.setProperty(UiUtilsConstants.PROP_CSFACTORY, UiUtilsConstants.PROP_CSFACRORY_IMPL);
		}
		
		CSFactory factory = CSFactory.getFactory(properties);
		return factory.getClientForCurrentUser(Locale.getDefault(), "teamsite", null);
	}
	

	public static String getMasterLocale(CSClient client, CSTask task) throws CSException {
		BranchConfigProviderIfc provider = com.interwoven.ui.teamsite.g11n.blc.BranchConfigProviderFactory.getProvider();
		LOGGER.debug("Getting Locale from branch");
		
		try {
			Locale masterLocale = provider.getMasterLocale(client, task.getArea().getBranch());
			LOGGER.debug("Master Locale: " + masterLocale);
			if(masterLocale!=null) {
				return masterLocale.toString();
			}
			else {
				 String branch=task.getArea().getBranch().getVPath().toString();
				 LOGGER.debug("Branch "+branch);
				 LOGGER.debug("Locale formed: " + getLocale(branch));
				 return getLocale(branch);
			}
		}
		
		catch(Exception ex){
			LOGGER.error("Unable to fetch locale");
		}
		
		return null;
	}
	
	/**
	 * Get locale from filepath
	 * @param filePath
	 * @return
	 */
	public static String getLocale(String filePath) {
		
			Matcher m = UiUtilsConstants.LOCALE_PATTERN.matcher(filePath);
			
			if (m.find ()) {
				LOGGER.debug("Patter Matched");
				return m.group (2) + "_" + m.group (1).toUpperCase();
			}
		
		return null;
	}
	

	
	public static ArrayList<String>  getExistingExtendedAttribute(String fileToUpdate,String extendedAttributeName,CSClient client) {
		ArrayList<String> existingExtendedAttrList=new ArrayList<String>();
		String existingExtendedAttrVal=null;
		try {
		
			CSVPath path=new CSVPath(UiUtilsConstants.IWMNT+fileToUpdate);
			CSFile file=client.getFile(path);
			if(file instanceof CSSimpleFile) {
				CSSimpleFile cssimpleFile=(CSSimpleFile) file;
			 existingExtendedAttrVal=cssimpleFile.getExtendedAttribute(extendedAttributeName).value;
			LOGGER.debug("Value fetched from file "+existingExtendedAttrVal);
			if (existingExtendedAttrVal!=null && !StringUtils.isBlank(existingExtendedAttrVal) ) {
				if(existingExtendedAttrVal.contains(",")) {
					//To tackle java.lang.UnsupportedOperationException for List.asArrayList
					existingExtendedAttrList=new ArrayList<String>(Arrays.asList(existingExtendedAttrVal.split(",")));
					LOGGER.debug("existingExtendedAttrList "+existingExtendedAttrList.toString());
					return existingExtendedAttrList;
				}
				else {
					existingExtendedAttrList.add(existingExtendedAttrVal);
					return existingExtendedAttrList;
				}
			}
			}
		} catch (Exception ex) {
			
			LOGGER.error("Error while fetching extended attribute of the file",ex);
		}
		return new ArrayList<String>();
	}
	
	/**
	 * Connvert comma seprat
	 * @param locales
	 * @return
	 */
	public static ArrayList<String>  getListOfTaggedLocales(String locales){
		ArrayList<String> existingLocalesList=new ArrayList<String>();
		if (locales!=null && !StringUtils.isBlank(locales) ) {
			if(locales.contains(",")) {
				//To tackle java.lang.UnsupportedOperationException for List.asArrayList
				existingLocalesList=new ArrayList<String>(Arrays.asList(locales.split(",")));
				LOGGER.debug("existingExtendedAttrList "+ESAPI.encoder().encodeForHTML(existingLocalesList.toString()));
				return existingLocalesList;
			}
			else {
				existingLocalesList.add(locales);
				return existingLocalesList;
			}
		}
		
		return  new ArrayList<String>();
	}
	
	
	/**
	 * Convert arraylist to comma seprated String
	 * @param extendedAttributes
	 * @return
	 */
	public  static String getTargetLocales(List<String> extendedAttributes) {
		StringBuilder targetLocalBuilder=new StringBuilder();
		for(String attr :extendedAttributes) {
		targetLocalBuilder.append(attr).append(",");
		}
		String targetLocales=targetLocalBuilder.toString();
		if(targetLocales.length()>0) {
			LOGGER.debug("Setting Attribute :"+ESAPI.encoder().encodeForHTML(targetLocales.substring(0, targetLocales.length()-1)));
			return targetLocales.substring(0, targetLocales.length()-1);
		}
		return null;
	}

	/**
	 * Check if sourceLocale is present in the list
	 * @param sourceLocale
	 * @param existingLocalList
	 * @return
	 */
	public static boolean isSourcePresent(String sourceLocale, List<String> existingLocalList) {
		for (String attr : existingLocalList) {
			if (sourceLocale.equalsIgnoreCase(attr)) {
				LOGGER.debug("Source Locale is present");
				return true;
			}
		}
		return false;
	}
	
	
	public static boolean isModifiableFile(PDDocument document) {
		PDFTextStripper pdfStripper;
	    String[] lines =null;
		try {
		pdfStripper = new PDFTextStripper();
		//Read only first page
			
	    pdfStripper.setStartPage(1);
	    pdfStripper.setEndPage(1);
	    //load all lines into a string
	    String pages = pdfStripper.getText(document);
	    lines= pages.split("\r\n|\r|\n");
	   if(lines!=null && lines.length>2) {
		   LOGGER.debug("File is valid returning true ");
		   for(String line:lines) {
			   LOGGER.debug("Line retuned form pdf "+line);
		   }
		   return true;  
	   }
		} catch (Exception e) {
			
			LOGGER.error("Error occured in isModifiableFile for PDFReaderUtils",e);
			 LOGGER.debug("Not a valid file for updating metadata");
			throw new CustomRuntimeException("Not a valid file for updating metadata");
			
			
		}
		return false;
		
	}

}
