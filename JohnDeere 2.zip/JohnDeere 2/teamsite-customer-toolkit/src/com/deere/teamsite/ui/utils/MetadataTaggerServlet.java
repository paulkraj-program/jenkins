package com.deere.teamsite.ui.utils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;

import com.deere.livesite.workflow.AbstractURLExternalTask;
import com.deere.teamsite.common.constants.UiUtilsConstants;
import com.deere.teamsite.model.PDFInfo;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSTransitionableTask;





public class MetadataTaggerServlet extends HttpServlet  {
	
	private static final long serialVersionUID = 1L;
	private static final transient Logger LOGGER = Logger.getLogger(MetadataTaggerServlet.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)   
	         throws ServletException, IOException {  
       int totalFiles=Integer.parseInt(request.getParameter("total_files"));
		CSTask task = (CSTask) request.getSession().getAttribute("task");
		CSClient client = (CSClient) request.getSession().getAttribute("client");
		CSTask nextTask=null;
		String file=null;
		try {
		for(int i=0;i<totalFiles;i++) {
		PDFInfo info=new PDFInfo();
		Map<String,String> customProperties=new HashMap<String, String>();
		file=request.getParameter("vpath_file_"+i);
		info.setTitle(request.getParameter("title_file_"+i)!=null?request.getParameter("title_file_"+i):"");
		info.setAuthor(request.getParameter("author_file_"+i)!=null?request.getParameter("author_file_"+i):"");
		info.setKeywords(request.getParameter("keywords_file_"+i)!=null?request.getParameter("keywords_file_"+i):"");
		info.setSubject(request.getParameter("subject_file_"+i)!=null?request.getParameter("subject_file_"+i):"");
		String localeFromTask=request.getParameter("locale")!=null?request.getParameter("locale"):"";
		LOGGER.debug("localeFromTask - "+ESAPI.encoder().encodeForHTML(localeFromTask));
		String[] locales=request.getParameterValues("locales_file_"+i);
		if(locales !=null && locales.length>0) {
		LOGGER.debug("Locales from request "+ESAPI.encoder().encodeForHTML(Arrays.toString(locales)));
		StringBuffer localeProp=new StringBuffer();
		if(locales!=null && locales.length>0) {
		for(String locale:locales) {
			if(locale!=null) {
			localeProp.append(locale.replace("-", "_")).append(",");
			}
		}
	
		
		customProperties.put(UiUtilsConstants.EXT_ATTR_LOCALES, localeProp.toString().substring(0, localeProp.length()-1));
		info.setCustomProperties(customProperties);
		}
		
		}
		else if( !localeFromTask.equals("") && localeFromTask!=null) {
			ArrayList<String> existingLocales=new ArrayList<String>();
			existingLocales=PDFReaderUtils.getListOfTaggedLocales(PDFReaderUtils.getPDFDocumentsInfo(file).getCustomProperties().get("Locales"));
			
			if(!existingLocales.isEmpty()) {
				if(!PDFReaderUtils.isSourcePresent(localeFromTask,existingLocales)) {
					LOGGER.debug("Locale - "+ESAPI.encoder().encodeForHTML(localeFromTask)+" already present");
					if(!localeFromTask.equals("null") && !localeFromTask.equals("") && localeFromTask!=null) {
					existingLocales.add(localeFromTask);
					}
				}
			}
			else {
				LOGGER.debug("Adding new locale "+ESAPI.encoder().encodeForHTML(localeFromTask));
				if(!localeFromTask.equals("null") && !localeFromTask.equals("") && localeFromTask!=null) {
				existingLocales.add(localeFromTask);
				}
			}
			LOGGER.debug("Locales to be updated "+ESAPI.encoder().encodeForHTML(existingLocales.toString()));
			customProperties.put(UiUtilsConstants.EXT_ATTR_LOCALES, PDFReaderUtils.getTargetLocales(existingLocales));
			info.setCustomProperties(customProperties);
			
		}
		
			
		LOGGER.debug("Updating file :"+ESAPI.encoder().encodeForHTML(file));
		PDFReaderUtils.setPDFDocumentsInfo(file, info);
		
		PDFReaderUtils.setExtendedAttribute(file, info,client);
		}
		
		if(task !=null) {
			LOGGER.debug("Task "+task.getName());
			//task.attachFiles((CSAreaRelativePath[]) request.getSession().getAttribute("attachFile"));
			nextTask = AbstractURLExternalTask.chooseSuccessTransition((CSTransitionableTask) task);
			if (nextTask != null && CSTask.CGI_TASK == nextTask.getKind ()) {
				String targetUrl = "/iw-cc/transitiontask?taskid=" + nextTask.getId() + "&vpath=&done_page=/iw-cc/ccpro/workflow/transition_handler.jsp?customer.done_page=/iw-cc/base/util/close_or_home.html&customer.full_redirect=true&taskid=" + task.getId();
				response.sendRedirect(response.encodeRedirectURL(targetUrl));
			}
		}
		else {
		//refresh the parent window
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();		
		String text = "<script language='javascript'>function refreshOpener(){window.opener.location.reload(true);window.close();}refreshOpener();</script>";
		out.println(text);
		out.close();
		}
		
		}
		catch(Exception e) {
			
			LOGGER.debug("Error occured during file updation "+ e + e.getMessage());
			request.setAttribute(UiUtilsConstants.MESSAGE, UiUtilsConstants.ERROR_MESSAGE+UiUtilsConstants.INVALID_FILETYPE_MESSAGE +file);
			request.setAttribute(UiUtilsConstants.PAGE_TITLE, UiUtilsConstants.PROPERTIES_TITLE);
			request.getRequestDispatcher("/customer/utils/alert_window.jsp").forward(request, response);
		}
		finally {
			try {
			if(task !=null) {
				LOGGER.debug("Task "+task.getName());
				//task.attachFiles((CSAreaRelativePath[]) request.getSession().getAttribute("attachFile"));
				nextTask = AbstractURLExternalTask.chooseSuccessTransition((CSTransitionableTask) task);
				if (nextTask != null && CSTask.CGI_TASK == nextTask.getKind ()) {
					String targetUrl = "/iw-cc/transitiontask?taskid=" + nextTask.getId() + "&vpath=&done_page=/iw-cc/ccpro/workflow/transition_handler.jsp?customer.done_page=/iw-cc/base/util/close_or_home.html&customer.full_redirect=true&taskid=" + task.getId();
					response.sendRedirect(response.encodeRedirectURL(targetUrl));
				}
			}
      request.getSession().removeAttribute("task");
			request.getSession().invalidate();
		}
		
		catch(Exception Ex) {
			LOGGER.debug("Unable to process workflow further "+Ex.getMessage());
			
		}
		
	
	}
	}


}
