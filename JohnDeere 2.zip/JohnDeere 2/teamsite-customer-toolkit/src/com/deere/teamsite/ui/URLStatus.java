package com.deere.teamsite.ui;

public class URLStatus {
	String url;
	int status;
	
	public URLStatus(String url, int status) {
		super();
		this.url = url;
		this.status = status;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	

}
