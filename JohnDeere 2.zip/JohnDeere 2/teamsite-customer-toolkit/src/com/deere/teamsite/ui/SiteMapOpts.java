package com.deere.teamsite.ui;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
//import org.apache.tomcat.util.threads.ThreadPoolExecutor;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.owasp.esapi.ESAPI;

import com.deere.teamsite.ui.utils.UiUtils;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.livesite.dom4j.Dom4jUtils;

public class SiteMapOpts {
	private static final Logger LOGGER = Logger.getLogger(SiteMapOpts.class.getName());
	public static final String HTML_DIR = "html/deere/";
	public static final String WEBSITE_DIR = "/website/";
	public static final String SITEMAP_XML = "sitemap.xml";
	// private static final String SECURE_PROTOCOL = "https://";
	private static final String DOMAIN_NAME_PATTERN = "(https://)*(([^/])+)";
	private static final String DEFAULT_PROPERTIES_FILE_PATH = "iw/config/johndeere/constants.properties";

	public StatusMsg clean(CSWorkarea workarea) {
		LOGGER.info("Came to execute sitemap cleanup for workarea :" + ESAPI.encoder().encodeForHTML(workarea.getVPath().getName().toString()));
		StatusMsg msg = null;
		if (null != workarea) {
			Properties siteProperties = UiUtils.readPropertiesFile(workarea, DEFAULT_PROPERTIES_FILE_PATH);
			if (null == siteProperties) {
				LOGGER.error("Unable to find site properties. exiting ...");
				return new StatusMsg("Unable to find site properties. Contact your admin team.", true);
			}
			String originalUrl = UiUtils.replaceRegex(siteProperties.getProperty("prodNode"), DOMAIN_NAME_PATTERN);
			LOGGER.info("Original URL :" + originalUrl);
			LOGGER.debug("Prod Node from constant property :" + originalUrl);
			CSFile sitemapCSFile = getSiteMapFile(workarea);
			if (null != sitemapCSFile) {
				InputStream siteInStream = UiUtils.getCSFileInputStream(sitemapCSFile);
				if (null != siteInStream) {
					List<String> urls = getSiteUrls(siteInStream);
					if (null != urls) {
						List<Future<URLStatus>> urlStatus = checkUrls(urls, originalUrl);
						Document sitemapDoc = Dom4jUtils.newDocument(UiUtils.getCSFileInputStream(sitemapCSFile));
						List<URLStatus> corrupts = new ArrayList<URLStatus>();
						for (Future<URLStatus> f : urlStatus) {
							try {
								if (f.isDone()) {
									URLStatus urlStat = f.get();
									if (urlStat.getStatus() != 200) {
										corrupts.add(urlStat);
										String xpathQuery = "//*[local-name() = 'url'][*[local-name() = 'loc']/text() = '"
												+ urlStat.getUrl() + "']";
										LOGGER.debug("Xpath Query :" + xpathQuery);
										List<Node> badNodes = sitemapDoc.selectNodes(xpathQuery);
										LOGGER.info("No of corrupted urls :" + badNodes.size());
										for (Node urlNode : badNodes) {
											LOGGER.info("Removed Node having url :" + urlNode.asXML());
											urlNode.detach();
											LOGGER.info("Removed :" + urlNode.asXML());
										}
									}
								}
								LOGGER.debug("All Status :" + f.get());
							} catch (Exception e) {
								msg = new StatusMsg(
										"Error occured while cleaning up the sitemap, kindly try again later.", true);
								LOGGER.error("Error occured while checking threads :" + e.getMessage(), e);
							}
						}
						if (corrupts.size() > 0) {
							msg = writeSitemapFile(workarea, sitemapDoc);
							msg.setStatus(corrupts);
						}else{
							msg = new StatusMsg("Sitemap doesn't contain any invalid URL.", false);
						}
					} else {
						msg = new StatusMsg(
								"Either sitemap file is corrupted or it doesn't have any link to check, kindly check",
								true);
						LOGGER.info("Either sitemap file is corrupted or it doesn't have any link to check");
					}
				} else {
					msg = new StatusMsg("Unable to get sitemap file filestream for this workarea, kindly check", true);
					LOGGER.info("Unable to get sitemap file filestream for this workarea");
				}
			} else {
				msg = new StatusMsg("Unable to find sitemap file for this workarea, kindly check", true);
				LOGGER.info("Unable to find sitemap file for this workarea");
			}
		} else {
			msg = new StatusMsg("You must be in a valid workarea to initiate cleanup.", true);
			LOGGER.info("Sitemap cleanup initiated from non workarea location.");
		}
		return msg;

	}

	private StatusMsg writeSitemapFile(CSWorkarea workarea, Document sitemapDoc) {
		CSFile sitemapCSFile = getSiteMapFile(workarea);
		StatusMsg sm = null;
		try {
			if (sitemapCSFile.isLocked()) {
				sm = new StatusMsg("Sitemap File is Locked by :" + sitemapCSFile.getLockCreator()
						+ ", kindly unlock the same and restart the cleanup activity.", true);
			} else {
				CSSimpleFile simFile = (CSSimpleFile) sitemapCSFile;
				InputStream dataStream = IOUtils.toInputStream(sitemapDoc.asXML(), "UTF-8");
				OutputStream outputStream = simFile.getOutputStream(true);
				long copiedBytes = IOUtils.copyLarge(dataStream, outputStream);
				LOGGER.debug("Copied Bytes :" + copiedBytes);
				IOUtils.closeQuietly(outputStream);
				if (sitemapCSFile.isLocked()) {
					sitemapCSFile.unlock();
				}
				sm = new StatusMsg("Sitemap Updated Successfully", false);
			}
		} catch (Exception e) {
			sm = new StatusMsg("Unable to update Sitemap file, kindly try again.", true);
			LOGGER.error("Error occured while writing sitemap file :" + e.getMessage(), e);
		}
		return sm;
	}

	public CSFile getSiteMapFile(CSWorkarea workarea) {
		CSFile csFile = null;
		if (null != workarea) {
			String workareaStr = workarea.getVPath().getPathNoServer().toString();
			String locale = UiUtils.getLocale(workareaStr);
			String sitemapFilePath = HTML_DIR + locale + WEBSITE_DIR + SITEMAP_XML;
			LOGGER.debug("Workarea :" + ESAPI.encoder().encodeForHTML(workarea.getVPath().getAreaName().toString()) + ", Sitemap Path :" + ESAPI.encoder().encodeForHTML(sitemapFilePath));
			System.out.println("Workarea :" + workarea + ", Sitemap Path :" + sitemapFilePath);
			csFile = UiUtils.getCSFile(workarea, sitemapFilePath);
		}
		return csFile;
	}

	private List<Future<URLStatus>> checkUrls(List<String> urls, String originalUrl) {
		ExecutorService executor = new ThreadPoolExecutor(100, 100, 0L, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<Runnable>());
		LOGGER.info("Iterating URLs in threads.. ");
		Iterator<String> urlIterator = urls.iterator();
		int noOfUrls = urls.size();
		int i = 0;
		try {
			List<Future<URLStatus>> futures = new ArrayList<>();
			while (urlIterator.hasNext()) {
				String url = urlIterator.next();
				LOGGER.debug("Executing :" + i + " out of " + noOfUrls + " --> " + url);
				Future<URLStatus> future = executor.submit(new Callable<URLStatus>() {
					@Override
					public URLStatus call() throws Exception {
						// TODO Auto-generated method stub
						LOGGER.debug(String.format("Executing to check status %s", Thread.currentThread().getName()));
						int status = UiUtils.getURLStatus(url, 1000, originalUrl);
						URLStatus urlStat = new URLStatus(url, status);
						return urlStat;
					}
				});
				futures.add(future);
				i++;
			}
			LOGGER.info("Completed iterating URLs in threads.. ");
			return futures;
		} catch (Exception e) {
			LOGGER.error("Exception Occured while checking sitemap urls.");
			return null;
		} finally {
			executor.shutdown();
		}
	}

	private List<String> getSiteUrls(InputStream is) {
		List<String> urls = null;
		try{
		Document doc = Dom4jUtils.newDocument(is);
		if (null != doc) {
			Element root = doc.getRootElement();
			Iterator<Element> elements = root.elementIterator("url");
			urls = new ArrayList<String>();
			while (elements.hasNext()) {
				Element urlEle = elements.next();
				Element loc = urlEle.element("loc");
				String locStr = loc.getText();
				urls.add(locStr);
			}
		}
		}catch(Exception e){
			LOGGER.error("Error Occured while parsing sitemap file :"+e.getMessage(),e);
			return null;
		}
		return urls;
	}

}
