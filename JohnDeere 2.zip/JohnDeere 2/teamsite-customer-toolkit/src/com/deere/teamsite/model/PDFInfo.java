package com.deere.teamsite.model;

import java.util.Map;
import java.util.Set;

public class PDFInfo {
	
	private String title;
	
	private  String author;
	private String  subject;
	private String keywords;
	private Map<String,String> customProperties;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public Map<String, String> getCustomProperties() {
		return customProperties;
	}
	public void setCustomProperties(Map<String, String> customProperties) {
		this.customProperties = customProperties;
	}
	
	@Override
	public String toString() {
		StringBuffer customMetaData=new StringBuffer();
		Set<String> customPropsKey=customProperties.keySet();
		for(String props:customPropsKey) {
			customMetaData.append(props).append(" : ").append(customProperties.get(props)).append(" ");
		}
		return "PDFInfo [title=" + title + ", author=" + author + ", subject=" + subject + ", keywords=" + keywords
				+ ", customProperties=" + customMetaData.toString() + "]";
	}

}
