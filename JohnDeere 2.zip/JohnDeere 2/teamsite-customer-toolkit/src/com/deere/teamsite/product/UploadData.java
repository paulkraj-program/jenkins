package com.deere.teamsite.product;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class UploadData {
	private static final Logger LOGGER = Logger.getLogger(UploadData.class);

    private static final String EXCEPTION = "Exception :";

	private UploadData() {
		throw new IllegalStateException("Utility class");
	}

	@SuppressWarnings("deprecation")
	public static Map<String, String> getCategoryHeaders(File s, int start) {

		
		File excelFile = s;
		Map<String, String> map = new LinkedHashMap<>();
		Map<String, String> mapModified = new LinkedHashMap<>();
		
		String[] characterString = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P",
				"Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI",
				"AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AU", "AV", "AW", "AX", "AY", "AZ" };

		if (excelFile.exists()) {
			try (
				FileInputStream fis = new FileInputStream(excelFile);
				XSSFWorkbook workBook = new XSSFWorkbook(fis);
				)
			{
				XSSFSheet sheet = workBook.getSheetAt(0);
				

				for (Row row : sheet) {

					if (row.getRowNum() == start) {
						for (Cell cell : row) {

							if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
								CellRangeAddress range = getMergedRegion(cell);
								if (range != null) {

									Cell mergeValue = sheet.getRow(range.getFirstRow()).getCell(range.getFirstColumn());

									map.put(range.formatAsString(),
											mergeValue.getStringCellValue().replaceAll("[\\n]", ""));

								}
							} else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {

								map.put(cell.getAddress().toString(),
										cell.getStringCellValue().replaceAll("[\\n]", ""));

							}
						}
					}

				}
				for (Map.Entry<String, String> entry : map.entrySet()) {

					if (entry.getKey().contains(":")) {

						String[] a = entry.getKey().split(":");

						String cellStartAddressForHeader = a[0].replaceAll("[0123456789]", "");

						String cellEndAddressForHeader = a[1].replaceAll("[0123456789]", "");
						int indexStartOf = ArrayUtils.indexOf(characterString, cellStartAddressForHeader);
						int indexEndOf = ArrayUtils.indexOf(characterString, cellEndAddressForHeader);

						for (int i = indexStartOf; i <= indexEndOf; i++) {
							mapModified.put(characterString[i], entry.getValue());

						}

					} else {

						String h = entry.getKey().replaceAll("[0123456789]", "");
						String g = entry.getValue();
						mapModified.put(h, g);
					}
				}
			} catch (Exception e) {

                LOGGER.error(EXCEPTION, e);

				
			} 
		}

		return mapModified;

	}

	public static void buildProductsTable(Properties prop, File excelFile, String pd)  {

		LOGGER.debug("<<<<<<<<<<<<<<<<<<<  Executing buildProductsTable  >>>>>>>>>>>>");
		
		
		if (excelFile.exists()) {
			
			
			
			
			String queryCheck = "SELECT * from " + pd + " WHERE model = ?";
			try (
				Connection dbConnection = MySqlConnect.getConnection(prop);	
				Statement stmt = (Statement) dbConnection.createStatement();
				PreparedStatement st = (PreparedStatement) dbConnection.prepareStatement(queryCheck);
				FileInputStream fisProducts = new FileInputStream(excelFile);
				XSSFWorkbook productWorkBook = new XSSFWorkbook(fisProducts);
				)
			{
				
				
				XSSFSheet productSheet = productWorkBook.getSheetAt(0);

				for (Row productRow : productSheet) {
					if (productRow.getRowNum() > 2) {

						String modelseries = quote(productRow.getCell(0).toString());
						String sku = quote(productRow.getCell(1).toString());
						String model = quote(productRow.getCell(2).toString());

						String sql = "INSERT INTO " + pd + " VALUES (" + modelseries + "," + sku + "," + model + ")";
						
						
						st.setString(1, productRow.getCell(2).toString());
						ResultSet rs = st.executeQuery();
						if (rs.next()) {
							
						} else {

							stmt.executeUpdate(sql);
						}
					}
				}
				

			} catch (Exception e) {


				LOGGER.error(EXCEPTION, e);

			} 

		}

	}

	public static CellRangeAddress getMergedRegion(Cell cell) {
		org.apache.poi.ss.usermodel.Sheet sheet = cell.getSheet();
		for (CellRangeAddress range : ((XSSFSheet) sheet).getMergedRegions()) {
			if (range.isInRange(cell.getRowIndex(), cell.getColumnIndex())) {
				return range;
			}
		}
		return null;
	}

	@SuppressWarnings("deprecation")
	public static void buildProductsInformationTable(Properties prop, File excelFile, String pdInfo) {

		LOGGER.debug("<<<<<<<<<<<<<<<<<<<  Executing buildProductsInformationTable  >>>>>>>>>>>>");
		
		

		if (excelFile.exists()) {
			new LinkedHashMap<>();
			Map<String, String> mdyMap = new LinkedHashMap<>();
			Map<String, String> mdyMapHeaders = UploadData.getCategoryHeaders(excelFile, 0);
			Map<String, String> filterMap = UploadData.getCategoryHeaders(excelFile, 1);
			LOGGER.debug("mdyMapHeaders  >>> " + mdyMapHeaders);
			LOGGER.debug("filterMap  >>> " + filterMap);
			 
			

			
			try (Connection dbConnection = MySqlConnect.getConnection(prop);
				 Statement stmt = (Statement) dbConnection.createStatement();
				FileInputStream fis = new FileInputStream(excelFile);
					XSSFWorkbook workBook = new XSSFWorkbook(fis);
					)
			{
				

				
				
				XSSFSheet sheet = workBook.getSheetAt(0);
				XSSFRow r = sheet.getRow(0);
				int colCount = r.getLastCellNum();
				sheet.getLastRowNum();

				String category = "";
				String filter = "";
				String subcategory = "";
				String cellValueString = "";
				for (Row row : sheet) {

					if (row.getRowNum() == 2) {
						for (Cell cell : row) {
							LOGGER.debug("");
							LOGGER.debug("cell.getAddress()" + cell.getAddress().toString());
							LOGGER.debug("cell Type is " + cell.getCellType());
							LOGGER.debug("cell address Type is " + cell.getAddress().toString());

							if (cell.getCellType() == 1) {
								mdyMap.put(cell.getAddress().toString().replaceAll("[0123456789]", ""),
										cell.getStringCellValue().replaceAll("[\\n]", ""));
							}
							if (cell.getCellType() == 0) {
								String val = NumberToTextConverter.toText(cell.getNumericCellValue());
								mdyMap.put(cell.getAddress().toString().replaceAll("[0123456789]", ""),
										val.replaceAll("[\\n]", ""));
							}
						}
					}
					if (row.getRowNum() > 2) {
						LOGGER.debug("Row Number is " + row.getRowNum());
						for (int i = 0; i < colCount; i++) {
							Cell cellValue = row.getCell(i);
							String cellAddress = row.getCell(i).getAddress().toString();
							String cellAddressForHeader = cellAddress.replaceAll("[0123456789]", "");
							LOGGER.debug(row.getCell(0) + ">>>" + row.getCell(1) + ">>>" + row.getCell(2) + ">>>"
									+ row.getRowNum() + ">>>" + mdyMap.get(cellAddressForHeader) + ">>>" + cellAddress
									+ ">>>" + cellValue);

							mdyMap.get(cellAddressForHeader);

							category = mdyMapHeaders.get(cellAddressForHeader);
							subcategory = mdyMap.get(cellAddressForHeader);
							filter = filterMap.get(cellAddressForHeader);

							cellValueString = cellValue.toString();
							if (cellValue.toString().isEmpty() || cellValue.toString().equalsIgnoreCase("")) {
								cellValueString = "No";
							} else if (cellValue.toString().equalsIgnoreCase("x")) {
								cellValueString = "Yes";
							}
							String modelseries = quote(row.getCell(0).toString());
							String sku = quote(row.getCell(1).toString());
							String model = quote(row.getCell(2).toString());

							if (!category.contains("|") && !filter.equalsIgnoreCase("range")
									&& category.contains("[")) {


								String secondvalue = category.substring(category.indexOf('[') + 1,
										category.indexOf(']'));
																String firstvalue = category.substring(0, category.indexOf('['));

								category = firstvalue.trim() + "|" + secondvalue;
							}

							category = quote(category);
							subcategory = quote(subcategory);
							cellValueString = quote(cellValueString);
							filter = quote(filter);
							String pdInfosql = "INSERT INTO " + pdInfo + " VALUES (" + modelseries + "," + sku + ","
									+ model + "," + category + "," + subcategory + "," + filter.toLowerCase() + ","
									+ cellValueString + ")";

							stmt.executeUpdate(pdInfosql);

						}
					}

				}

			} catch (Exception e) {


				LOGGER.error(EXCEPTION, e);

			} 
		} else {

			LOGGER.debug("The file >> " + excelFile.getPath() + "doesnt exits");
		}
	}

	public static String quote(String s) {
		return new StringBuilder().append('\'').append(s).append('\'').toString();
	}

	
}