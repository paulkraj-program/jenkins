package com.deere.teamsite.product;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Properties;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.Statement;

public class ExecuteUpload implements CSURLExternalTask {
	private static final Logger LOGGER = Logger.getLogger(ExecuteUpload.class);

	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {

		String iwmnt = "/iwmnt";
		String runMode = task.getVariable("runMode");
		String excelFilePath = "";
		String credFile = task.getVariable("properties");
		Properties prop = MySqlConnect.getProperties(credFile);

		CSAreaRelativePath[] files = task.getFiles();
		for (CSAreaRelativePath file : files) {

			excelFilePath = iwmnt + task.getArea().getUAI() + File.separator + file.getParentPath().toString()
					+ File.separator + file.getName();

		}
		File excelFile = new File(excelFilePath);

		String catName = task.getWorkflow().getVariable("cat");
		String pd = catName + "_category";
		String pdInfo = catName + "_product_information";
		if (runMode == null || runMode.equalsIgnoreCase("workflow")) {
			StringBuilder sql = new StringBuilder("CREATE TABLE IF NOT EXISTS " + pd);
			sql.append("(model_series VARCHAR(255), ");
			sql.append(" SKU VARCHAR(255), ");
			sql.append(" model VARCHAR(255) not NULL, ");
			sql.append(" PRIMARY KEY ( Model ))");

			StringBuilder pdInfoSql = new StringBuilder("CREATE TABLE IF NOT EXISTS " + pdInfo);
			pdInfoSql.append("(model_series VARCHAR(255), ");
			pdInfoSql.append(" SKU VARCHAR(255), ");
			pdInfoSql.append(" model VARCHAR(255) not NULL, ");
			pdInfoSql.append(" category VARCHAR(255) not NULL, ");
			pdInfoSql.append(" subcategory VARCHAR(255) not NULL, ");
			pdInfoSql.append(" filter VARCHAR(255) not NULL, ");
			pdInfoSql.append(" value VARCHAR(255) not NULL)");


			try (
				Connection dbConnection = MySqlConnect.getConnection(prop);
				Statement stmt = (Statement) dbConnection.createStatement();
					)
			{

				DatabaseMetaData dbm = (DatabaseMetaData) dbConnection.getMetaData();
				ResultSet tables = dbm.getTables(null, null, pd, null);
				ResultSet pfInfotable = dbm.getTables(null, null, pdInfo, null);
				LOGGER.debug("<<<<<<<<<< Executing the Upload >>>>>>>>>>>");
				if (tables.next()) {
					LOGGER.debug("Table exits");
					stmt.executeUpdate("DELETE FROM   " + pd);

				} else {
					LOGGER.debug("Table doesn't exits");

					stmt.executeUpdate(sql.toString());

				}

				if (pfInfotable.next()) {
					LOGGER.debug("Table exits");
					stmt.executeUpdate("DELETE FROM   " + pdInfo);

				} else {
					LOGGER.debug("Creating the Table " + pdInfoSql.toString());
					LOGGER.debug("Table pdInfo doesn't exits");

					stmt.executeUpdate(pdInfoSql.toString());

				}

				UploadData.buildProductsTable(prop, excelFile, pd);
				UploadData.buildProductsInformationTable(prop, excelFile, pdInfo);

			} catch (SQLException e) {
				LOGGER.error("SQL Exception occured in ExecuteUpload",e);
			} 

		} else if (runMode.equalsIgnoreCase("system")) {
			String javaCommand = task.getVariable("cmd");
			LOGGER.debug("Executing javaCommand >>> " + javaCommand + " " + excelFilePath + " " + catName);
			try {
				Process process = Runtime.getRuntime().exec(javaCommand + " " + excelFilePath + " " + catName);


				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String line;
				while ((line = reader.readLine()) != null) {
					LOGGER.debug(line);
				}

				reader.close();

			} catch (IOException e) {
				LOGGER.error("Exception occured while runMode is system",e);
			}
		}
		task.chooseTransition(task.getTransitions()[0], "Uploaded the Product Data");
	}
}
