package com.deere.teamsite.datasource;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSIterator;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSFileKindMask;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.datasource.ListDataSource;
import com.interwoven.datasource.core.DataSourceContext;

/**
 * DCTTypesDatasource is an implementation of a ListDataSource that returns the
 * list of available DCT types in the current branch, with the option of excluding the
 * defined categories and dct types.
 * @author cm54947
 */
public class DCTTypesDatasource  implements ListDataSource{
	private static final transient Logger LOGGER = Logger.getLogger(DCTTypesDatasource.class);
	private static final String TEMPLATEDATA_STRING = "templatedata";
	private static final String DEFAULT_EXCLUDE_DCT_TYPES_PATH = "/iwadmin/main/deere/syndication/STAGING/templatedata/CustomData/NameValueList/data/exclude_dct_types.xml";
	private static final Object CATEGORIES_STRING = "categories";
	private static final Object DATA_TYPES_STRING = "datatypes";
	private static final String ROOT_ELEMENT = "ListItem";
	private static final String KEY_ELEMENT = "Name";
	private static final String VALUE_ELEMENT = "Value";
	private List<CSDir> categoryDirsList = new ArrayList<CSDir>();
	Pattern categoriesListPattern = Pattern.compile ("");
	Pattern dataTypesListPattern = Pattern.compile ("");
	
	/* (non-Javadoc)
	 * @see com.interwoven.datasource.ListDataSource#execute(com.interwoven.datasource.core.DataSourceContext)
	 */
	public List<String> execute(DataSourceContext context) {
		try {
			String csFactory = context.getParameter("csFactory");
			LOGGER.debug("CSFactory: " + csFactory);
			
			CSClient client = DataSourceUtilities.getCSClient(csFactory);
			String currentBranch = context.getServerContext();//"/default/main/deere/us/en/WORKAREA/shared";//
			LOGGER.debug("Current Branch: " + currentBranch);
			
			
			//get excluded categories list and data-types from config list
			String path =  context.getParameter("excludeDCTTypesPath");
			if(path == null || "".equals(path)){
				path = DEFAULT_EXCLUDE_DCT_TYPES_PATH;
			}
			
			CSFile dctTypesFile = client.getFile(new CSVPath(path));
			Map<String, String> dctTypesMap = new HashMap<String, String> ();
			dctTypesMap = generatedctTypesMap (dctTypesFile);
			
			if (dctTypesMap.size () > 0) {
				String categories = dctTypesMap.get(CATEGORIES_STRING);
				if (categories != null && !"".equals (categories)) {
					LOGGER.debug("Excluded Categories:"+categories);
					categoriesListPattern = Pattern.compile (categories.replace (",", "|"));
				}
				String dataTypes = dctTypesMap.get(DATA_TYPES_STRING);
				if (dataTypes != null && !"".equals (dataTypes)) {
					LOGGER.debug("Excluded data types:"+dataTypes);
					dataTypesListPattern = Pattern.compile (dataTypes.replace (",", "|"));
				}
				
			}
			CSVPath vpath = new CSVPath(currentBranch).getArea().getPathNoServer().concat(TEMPLATEDATA_STRING);
			CSFile csFile = client.getFile(vpath);
			
			if(csFile != null && csFile.getKind() == CSDir.KIND){
				CSDir templatedataDir = (CSDir)csFile;
				CSIterator itDirs = templatedataDir.getFiles(CSFileKindMask.DIR, null, CSFileKindMask.DIR, null, 0, -1);
				while (itDirs.hasNext()) {
					CSDir childDir = (CSDir) itDirs.next();
					String categoryDir = childDir.getName();
					if(!categoriesListPattern.matcher (categoryDir).matches()){
						LOGGER.debug("Added to category List:"+categoryDir);
						categoryDirsList.add(childDir);
					}
				}
				
			}
			
			Set<String> dctTypes = new TreeSet<>();
			
			for(CSDir categoryDir:categoryDirsList){
				dctTypes.addAll(getDCTTypes(categoryDir));
			}
			
			return new ArrayList<>(dctTypes);
		} catch (CSException cse) {
			LOGGER.error("An error occurred during brach list retrieval.", cse);
			
			return Collections.singletonList("*** ERROR: Contact Admin ***");
		}
	}
	
	/**
	 * This method reads the DCR and generates map with key and value
	 * @param csFile CSFile of the DCR
	 * @return generated DCTTypes Map
	 */
	private Map<String, String> generatedctTypesMap(CSFile csFile) {
		Map<String,String> dctTypesMap = new HashMap<String,String>();	
		
		try {
			if(csFile!=null && CSSimpleFile.KIND == csFile.getKind()){
				LOGGER.debug("Reading DCT Types Mapping file "+csFile.getName ());    		
				try {
					CSSimpleFile simpleFile = (CSSimpleFile) csFile;
					Document doc = loadFile(simpleFile);
					if(doc != null){
						dctTypesMap = generateMap (doc,ROOT_ELEMENT,KEY_ELEMENT,VALUE_ELEMENT);
					}
				} catch (CSException e) {
					LOGGER.debug ("Reading DCT Types Mapping Document threw exception ");
				}    
			}
		}  catch (CSException e) {
			LOGGER.debug ("Error Generating DCT Types Map ");
			LOGGER.error("Error generating  DCT Types Map ", e);
		}
		return dctTypesMap;
	}

	/**
	 * It reads the DCR document and generates categories and datatypes map
	 * @param doc Document
	 * @param rootElement rootElement name
	 * @param keyElement key element name
	 * @param valueElement value element name
	 * @return
	 */
	private Map<String, String> generateMap(Document doc, String rootElement, String keyElement, String valueElement) {
		Map<String,String> dctTypesMapping = new HashMap<String,String>();
		Element root = doc.getRootElement();
		@SuppressWarnings("unchecked")
		List<Element> children = root.elements(rootElement);
		for (Element element : children) {
			// The option display value
			String name = element.elementText(keyElement);
			
			if (element.element(valueElement) != null) {
				// The option value
				String value = element.elementText(valueElement);				
				LOGGER.debug("Entry: " + name + " => " + value);
				dctTypesMapping.put(name, value);
			} else {
				LOGGER.debug("Entry: " + name + " => " + name);
				dctTypesMapping.put(name, name);
			}
		}
		
		return dctTypesMapping;
	}

	/**
	 * It loads the DCR file and returns the xml document
	 * @param simpleFile
	 * @return Document
	 * @throws CSException
	 */
	private Document loadFile(CSSimpleFile simpleFile) throws CSException {
		LOGGER.debug("Loading File: " + simpleFile.getName ());	
		InputStreamReader fis = null;
		try {
			if (simpleFile != null && simpleFile.isReadable ()) {
				fis = new InputStreamReader(simpleFile.getInputStream(true));
				Document document = new org.dom4j.io.SAXReader().read(fis);				
				fis.close ();
				return document;
			}
		} catch (Exception e) {
			LOGGER.debug ("Exception while reading the file "+simpleFile.getName ());
			LOGGER.error ("Unable to read File "+simpleFile.getName (), e);
		}
		finally {
			if(fis != null) {
	            try {
					fis.close();
				} catch (IOException e) {
			LOGGER.error("Exception occured while closing the InputStreamReader in loadFile method for DCTTypesDatasource",e);
				}
			}
		}
		
		return null;
	}

	/**
	 * This method iterated the category dir and returns the set of DCT Types by excluding specified dct types
	 * @param categoryDir CSDir
	 * @return set of DCT Types
	 * @throws CSException
	 */
	private Set<String> getDCTTypes(CSDir categoryDir) throws CSException {
		Set<String> dataTypes = new TreeSet<>();
		if(categoryDir!= null){
			CSIterator itDirs = categoryDir.getFiles(CSFileKindMask.DIR, null, CSFileKindMask.DIR, null, 0, -1);
			while (itDirs.hasNext()) {
				CSDir childDir = (CSDir) itDirs.next();
				String dataTypeDir = childDir.getName();
				if(!dataTypesListPattern.matcher (categoryDir.getName()+"/"+dataTypeDir).matches()){
					LOGGER.debug("Added to DCT Types List:"+categoryDir.getName()+"/"+dataTypeDir);
					dataTypes.add(categoryDir.getName()+"/"+dataTypeDir);
				}
			}
		}
		return dataTypes;
	}

	/*private Set<String> getBranches(CSBranch branch) throws CSException {
		Set<String> list = new TreeSet<>();
		String path = branch.getVPath().getPathNoServer().toString();
		LOGGER.debug("Branch Path: " + path);
		list.add(path);
		
		for (CSBranch child : branch.getSubBranches()) {
			path = branch.getVPath().getPathNoServer().toString();
			LOGGER.debug("Branch Path: " + path);
			list.add(path);
			list.addAll(getBranches(child));
		}
		
		return list;
	}*/
	
	/*public static void main(String[] args) throws CSException, IOException, JSONException {
		DCTTypesDatasource obj = new DCTTypesDatasource();
		
		obj.getList();
		obj.endSession();
	}

	public DCTTypesDatasource() {
		try {
			Properties properties = new Properties();
			properties.setProperty("com.interwoven.cssdk.factory.CSFactory",
					"com.interwoven.cssdk.factory.CSSOAPFactory");
			properties.setProperty("serviceBaseURL", "https://dce-ts-devl.tal.deere.com");
			CSFactory factory = CSFactory.getFactory(properties);
			System.out.println("Factory Initialized:"+factory);
			
			client = factory.getClient("cm54947", "",
					"june2017", Locale.US, "DWS", null);
			System.out.println("Got the CS Client");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void endSession() {
		if(client != null){
			client.endSession();
		}
		
	}

	private void getList() {
		System.out.println(execute(client.getContext()));
		
	}
*/
	
}
