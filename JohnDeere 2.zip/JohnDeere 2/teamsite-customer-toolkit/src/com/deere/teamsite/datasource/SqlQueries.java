package com.deere.teamsite.datasource;

public class SqlQueries {

	private SqlQueries() {
	    throw new IllegalStateException("SqlQueries Utility class");
	  }

	public static final String GETCATEGORY_QUERY = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA='tsdb_cat'";
	public static final String GETPRODUCTCATEGORY_QUERY = "select distinct CONCAT (category ,'^', filter) as category from ";
	public static final String GETPRODUCTSUBCATEGORY_QUERY = "select  GROUP_CONCAT(distinct subcategory SEPARATOR '|') as subcategory from <TABLE_NAME> where category=?";
	public static final String GETPRODUCTRANGE_QUERY ="select  w.subcategory ,min(cast(w.value AS SIGNED)) AS Min ,max(cast(w.value AS SIGNED)) AS Max from (select subcategory ,value from <TABLE_NAME> where filter='range') w group by w.subcategory";
    public static final String GETPRODUCT ="select * from <TABLE_NAME> where model = ? and Value != 'no' and subcategory not in ('Model Series','SKU','Model Number')";
    public static final String GETFILTERWIZARD_QUERY="select  category , GROUP_CONCAT(distinct subcategory SEPARATOR '^') as subcategory from <TABLE_NAME> where category not in ('Model Series','Model Number','SKU') group by category";
    public static final String GETFILTERCATAGORY_QUERY ="select  distinct category from <TABLE_NAME> where category not in ('Model Series','Model Number','SKU')";
}

