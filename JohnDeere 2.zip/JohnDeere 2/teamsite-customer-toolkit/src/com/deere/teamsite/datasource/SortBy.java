package com.deere.teamsite.datasource;

import java.util.*;

/**
 * Enumeration to sort the provided map by the specified value.  This
 * enumeration is used in conjunction with the NameValuePairDataSource.
 * @author Klish Group, Inc. [ND]
 */
enum SortBy {
	/** Do not sort the values for any provided Map instance */
	NONE,
	/** Sort the values of the Map instance by their display name (Map key) */
	NAME,
	/** Sort the values of the Map instance by their value (Map value) */
	VALUE,
	;
	
	/**
	 * Sort the provided Map instance by meaning of the SortBy instance.
	 * @param map The Map instance to sort
	 * @return The sorted Map instance
	 */
	public Map<String, String> sortMap(Map<String, String> map) {
		// Kick back any invalid or empty map
		if (map == null || map.isEmpty()) {
			return map;
		}
		
		switch (this) {
		case NAME:
			return sortMapByName(map);
			
		case VALUE:
			return sortMapByValue(map);
			
		case NONE:
		default:
			return map;
		}
	}
	
	private static Map<String, String> sortMapByName(Map<String, String> map) {
		// Since we are dealing with a Map<String, String> just use a SortedMap instance
		// TreeMap is the simplest and easiest Map implementation that gets us what we
		// want in sorting the Map by the keys.
		return new TreeMap<String, String> (map);
	}
	
	private static Map<String, String> sortMapByValue(Map<String, String> map) {
		// Add the Map.Entry instances to a List for sorting
		List<Map.Entry<String, String> > list = new ArrayList<Map.Entry<String, String> >(map.entrySet());
		
		// Sort the Map.Entry instances in the List by the entry value
		Collections.sort(list, new Comparator<Map.Entry<String, String> >() {
			@Override
			public int compare(Map.Entry<String, String> a, Map.Entry<String, String> b) {
				return a.getValue().compareTo(b.getValue());
			}
		});
		
		// Create a new LinkedHashMap instance (this preserves entry order upon iteration)
		Map<String, String> sorted = new LinkedHashMap<String, String>();
		
		// Add all of the 'sorted' entries to the new Map instance
		for (Map.Entry<String, String> entry : list) {
			sorted.put(entry.getKey(), entry.getValue());
		}
		
		return sorted;
	}
	
}