package com.deere.teamsite.datasource;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.deere.livesite.workflow.syndication.SyndicationUtilities;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.datasource.ListDataSource;
import com.interwoven.datasource.core.DataSourceContext;

/**
 * SyndicationTargetDatasource is an implementation of a ListDataSource that
 * returns the set of syndication target branches excluding the current branch
 * for use in the Syndication workflow.
 * @author Klish Group, Inc. [ND]
 */
public class SyndicationTargetDatasource implements ListDataSource {
	private static final transient Logger LOGGER = Logger.getLogger(SyndicationTargetDatasource.class);
	
	/* (non-Javadoc)
	 * @see com.interwoven.datasource.ListDataSource#execute(com.interwoven.datasource.core.DataSourceContext)
	 */
	@Override
	public List<String> execute(DataSourceContext context) {
		try {
			String csFactory = context.getParameter("csFactory");
			LOGGER.debug("CSFactory: " + csFactory);
			
			CSClient client = DataSourceUtilities.getCSClient(csFactory);
			String currentBranch = context.getServerContext();
			LOGGER.debug("Current Branch: " + currentBranch);
			currentBranch = new CSVPath(currentBranch).getBranch().toString();
			LOGGER.debug("Current Branch: " + currentBranch);
			
			boolean includeCurrent = Boolean.parseBoolean(context.getParameter("IncludeCurrent"));
			LOGGER.debug("Include Current: " + includeCurrent);
			
			Set<SyndicationTarget> configuration = SyndicationUtilities.loadSyndicationConfiguration(client);
			
			Set<String> branches = new TreeSet<>();
			for (SyndicationTarget target : configuration) {
				String path = target.getBranch();
				LOGGER.debug("SyndicationTarget Branch Path: " + path);
				branches.add(path);
			}
			
			if (!includeCurrent) {
				if (branches.contains(currentBranch)) {
					LOGGER.debug("Removing current branch: " + currentBranch);
					branches.remove(currentBranch);
				} else {
					LOGGER.debug("Current branch not found in branch list");
				}
			}
			
			return new ArrayList<>(branches);
		} catch (CSException cse) {
			LOGGER.error("An error occurred during syndicaton target brach list retrieval.", cse);
			
			return Collections.singletonList("*** ERROR: Contact Admin ***");
		}
	}
	
}
