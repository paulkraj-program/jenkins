package com.deere.teamsite.datasource;

import java.util.Map;
import org.apache.log4j.Logger;
import com.interwoven.datasource.MapDataSource;
import com.interwoven.datasource.core.DataSourceContext;
import com.interwoven.livesite.common.cssdk.datasource.AbstractDataSource;

public class DBDatasourceMap extends AbstractDataSource implements MapDataSource {

	private static final Logger LOGGER = Logger.getLogger(DBDatasourceMap.class);
	@Override
	public Map<String, String> execute(DataSourceContext context) {

		Map<String,String> mp;
		
		LOGGER.debug("In XMLDatasourceMap ");
       
        DSParameters dsParameters = new DSParameters();
        String requestParam = "";
        dsParameters.setRequestParam(requestParam);
        String listingType = context.getParameter("listingType");
        dsParameters.setListingType(listingType);
		String configAttribute=context.getParameter("configAttr");
		dsParameters.setConfigAttribute(configAttribute);
		String model=context.getParameter("model");
		dsParameters.setModel(model);
		dsParameters.setProperties(context.getParameter("properties"));
		mp = RetrieveResultSet.retrieveConfigAttributes(dsParameters);
		LOGGER.debug("In XMLDatasourceMap :: mp is >>"+mp.toString());
		return mp;
	}

}
