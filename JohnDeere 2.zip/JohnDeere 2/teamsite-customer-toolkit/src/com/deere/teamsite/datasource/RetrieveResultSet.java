package com.deere.teamsite.datasource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.deere.teamsite.product.MySqlConnect;
import com.mysql.jdbc.PreparedStatement;

public class RetrieveResultSet {

	private static final String GETCATEGORY = "GETCATEGORY";
	private static final String GETPRODUCTCATEGORY = "GETPRODUCTCATEGORY";
	private static final String GETPRODUCTRANGE = "GETPRODUCTRANGE";
	private static final String GETPRODUCT = "GETPRODUCT";
	private static final String GETFILTERWIZARD = "FILTERWIZARD";
	private static final String SQLEXCEPTION = "SQL Exception;";
	private static final String CATEGORY = "category";
	private static final String TABLENAME = "<TABLE_NAME>";
	private static final String SUBCATEGORY ="subcategory";
	private static final Log LOGGER = LogFactory.getLog(RetrieveResultSet.class);

	private RetrieveResultSet() {
		throw new IllegalStateException("DataSource Utility class");
	}

	@SuppressWarnings({ "unchecked", "resource" })
	public static Map<String, String> retrieveConfigAttributes(DSParameters ds) {

		Map<String, String> mp = new LinkedHashMap<>();

		ResultSet rs = null;
		ResultSet subrs = null;
		Properties prop = MySqlConnect.getProperties(ds.getProperties());

		Connection conn = MySqlConnect.getConnection(prop);
		String retrieveQuery = "";
		String retrieveSubCatQuery = "";
		String retrieveFilterCatQuery = "";
		if (ds.getConfigAttribute().equalsIgnoreCase(GETCATEGORY)) {

			List<String> result = new ArrayList<>();
			retrieveQuery = SqlQueries.GETCATEGORY_QUERY;

			try (PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(retrieveQuery);)
			{

				LOGGER.debug("final query is: " + retrieveQuery);
				rs = stmt.executeQuery();

				while (rs.next()) {
					if (rs.getString("TABLE_NAME").contains("product_information")) {

						String tableName = rs.getString("TABLE_NAME");
						tableName = tableName.replace("_product_information", "");
						result.add(tableName);

					}
				}
				Collections.sort(result);

				for (String a : result) {
					mp.put(a, a);
				}

			} catch (SQLException e) {

				LOGGER.error(SQLEXCEPTION,e);

				
			} finally {

				try {
					rs.close();
				} catch (SQLException reException) {

					LOGGER.error(SQLEXCEPTION,reException);

					
				}

				if (conn != null) {
					try {
						conn.close();
					}

					catch (SQLException e) {


						LOGGER.error(SQLEXCEPTION,e);

					}
				}
			}

		}
		if (ds.getConfigAttribute().equalsIgnoreCase(GETPRODUCTCATEGORY)) {
			mp = new LinkedHashMap<>();
			List<String> result = new ArrayList<>();
			String categoryValue = "";
			retrieveQuery = SqlQueries.GETPRODUCTCATEGORY_QUERY + ds.getListingType().trim();
			retrieveSubCatQuery = SqlQueries.GETPRODUCTSUBCATEGORY_QUERY;
			retrieveSubCatQuery = retrieveSubCatQuery.replace(TABLENAME, ds.getListingType().trim());


			try (Statement statemt = conn.createStatement();
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(retrieveSubCatQuery);)
					{

				rs = statemt.executeQuery(retrieveQuery);
				while (rs.next()) {

					if (!(rs.getString(CATEGORY).equalsIgnoreCase("Model Number^Model Number"))
							&& !(rs.getString(CATEGORY).equalsIgnoreCase("SKU^SKU"))
							&& !(rs.getString(CATEGORY).equalsIgnoreCase("Model Series^Model Series"))) {
						result.add(rs.getString(CATEGORY));
					}
				}
				for (String categoryFilter : result) {

					if (categoryFilter.contains("^")) {
						String[] categoryFilterArray = categoryFilter.split("\\^");
						categoryValue = categoryFilterArray[0];
					} else {
						categoryValue = categoryFilter;
					}

					stmt.setString(1, categoryValue);
					subrs = stmt.executeQuery();

					while (subrs.next()) {
						mp.put(categoryFilter, subrs.getString(SUBCATEGORY));
					}

				}


			} catch (SQLException e){

				LOGGER.error(SQLEXCEPTION,e);

			} finally {
				try {
					if(subrs != null) {
					subrs.close();
					}
					rs.close();
				} catch (SQLException subrsException) {

					LOGGER.error(SQLEXCEPTION,subrsException);

				}

				if (conn != null) {
					try {
						conn.close();

					} catch (SQLException e) {


						LOGGER.error(SQLEXCEPTION,e);

					}
				}
			}

		}
		if (ds.getConfigAttribute().equalsIgnoreCase(GETPRODUCTRANGE)) {
			mp = new LinkedHashMap<>();
			
			retrieveQuery = SqlQueries.GETPRODUCTRANGE_QUERY;
			retrieveQuery = retrieveQuery.replace(TABLENAME, ds.getListingType().trim());
			String subCat = "";
			try 
				(PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(retrieveQuery);)
				{
				rs = stmt.executeQuery();

				while (rs.next()) {

					subCat = rs.getString(SUBCATEGORY);

					Pattern pattern = Pattern.compile("\\[(.*?)\\]");
					Matcher matcher = pattern.matcher(subCat);

					while (matcher.find()) {
						subCat = matcher.group(1);

					}
					subCat = subCat.replaceAll("(^ )|( $)", "");

					mp.put(subCat, rs.getString("Min") + "|" + rs.getString("Max"));
				}
			} catch (SQLException e) {


				LOGGER.error(SQLEXCEPTION,e);

			} finally {

				try {
					rs.close();
				} catch (SQLException rsException) {

					LOGGER.error(SQLEXCEPTION,rsException);

				}

				if (conn != null) {
					try {
						conn.close();

					} catch (SQLException e) {


						LOGGER.error(SQLEXCEPTION,e);

					}
				}
			}

		}
		if (ds.getConfigAttribute().equalsIgnoreCase(GETPRODUCT)) {
			mp = new LinkedHashMap<>();
			
			retrieveQuery = SqlQueries.GETPRODUCT;
			retrieveQuery = retrieveQuery.replace(TABLENAME, ds.getListingType().trim());
			String subCat = "";
			String cat = "";
			String value = "";
			String filter = "";

			try (
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(retrieveQuery);)
			{


				stmt.setString(1, ds.getModel());

				LOGGER.debug("[retrieveConfigAttributes] final query is: " + retrieveQuery);
				rs = stmt.executeQuery();

				LOGGER.debug("[retrieveConfigAttributes] query executed");

				while (rs.next()) {

					subCat = rs.getString(SUBCATEGORY);
					cat = rs.getString(CATEGORY);
					value = rs.getString("value");
					filter = rs.getString("filter");

					Pattern pattern = Pattern.compile("\\[(.*?)\\]");
					Matcher matcher = pattern.matcher(subCat);

					while (matcher.find()) {
						subCat = matcher.group(1);

					}
					subCat = subCat.replaceAll("(^ )|( $)", "");
					if (cat.contains("|")) {
						String[] categoryFilterArray = cat.split("\\|");
						cat = categoryFilterArray[1];
					}

					if (filter.equalsIgnoreCase("radio") || filter.equalsIgnoreCase("multi-checkbox")) {
						if (mp.containsKey(cat)) {
							String a = mp.get(cat);
							a = a + "|" + subCat;
							mp.put(cat, a);
						} else {
							mp.put(cat, subCat);
						}
					}
					if (filter.equalsIgnoreCase("range")) {
						mp.put(subCat, value);
					}

				}

			} catch (SQLException e) {


				LOGGER.error(SQLEXCEPTION,e);

			} finally {
				LOGGER.debug("Closing the connection");
				try {
					rs.close();
				} catch (SQLException rsException) {

					LOGGER.error(SQLEXCEPTION,rsException);

				}

				if (conn != null) {
					try {
						conn.close();

					} catch (SQLException e) {


						LOGGER.error(SQLEXCEPTION,e);

						
					}
				}
			}

		}
		if (ds.getConfigAttribute().equalsIgnoreCase(GETFILTERWIZARD)) {
			mp = new LinkedHashMap<>();
			ResultSet filterCatrs = null;
			retrieveQuery = SqlQueries.GETFILTERWIZARD_QUERY;
			retrieveQuery = retrieveQuery.replace(TABLENAME, ds.getListingType().trim());
			retrieveFilterCatQuery = SqlQueries.GETFILTERCATAGORY_QUERY;
			retrieveFilterCatQuery = retrieveFilterCatQuery.replace(TABLENAME, ds.getListingType().trim());
			String cat = "";


			try (
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(retrieveQuery);
				PreparedStatement filterCatstmt = (PreparedStatement) conn.prepareStatement(retrieveFilterCatQuery);)
			{


				rs = stmt.executeQuery();
				filterCatrs = filterCatstmt.executeQuery();
				while (filterCatrs.next()) {

					cat = filterCatrs.getString(CATEGORY);
					mp.put(cat, cat);
				}
				while (rs.next()) {

					cat = rs.getString(CATEGORY);
					mp.put(cat, rs.getString(SUBCATEGORY));
				}

			} catch (SQLException e) {


				LOGGER.error(SQLEXCEPTION,e);

			} finally {
				LOGGER.debug("Closing the connection");
				try {
					rs.close();

					
					if(filterCatrs != null) {
					filterCatrs.close();
					}
				} catch (SQLException rsException) {


					LOGGER.error(SQLEXCEPTION,rsException);

				}

				if (conn != null) {
					try {
						conn.close();

					} catch (SQLException e) {


						LOGGER.error(SQLEXCEPTION,e);

					}
				}

			}

		}

		return mp;

	}

}
