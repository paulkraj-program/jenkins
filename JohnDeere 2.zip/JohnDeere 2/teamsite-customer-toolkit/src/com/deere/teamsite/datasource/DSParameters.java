package com.deere.teamsite.datasource;

public class DSParameters {
	
	String listingType;
    String configAttribute;
	String model;
	String requestParam;
	String properties;
	
	
	public String getProperties() {
		return properties;
	}
	public void setProperties(String properties) {
		this.properties = properties;
	}
	public String getRequestParam() {
		return requestParam;
	}
	public void setRequestParam(String requestParam) {
		this.requestParam = requestParam;
	}
	public String getListingType() {
		return listingType;
	}
	public void setListingType(String listingType) {
		this.listingType = listingType;
	}
	public String getConfigAttribute() {
		return configAttribute;
	}
	public void setConfigAttribute(String configAttribute) {
		this.configAttribute = configAttribute;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}

}
