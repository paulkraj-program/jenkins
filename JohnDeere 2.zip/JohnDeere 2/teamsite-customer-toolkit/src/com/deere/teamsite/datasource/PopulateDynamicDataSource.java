package com.deere.teamsite.datasource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;

import com.deere.livesite.authoring.utils.CssdkUtils;
import com.deere.livesite.dws.taxonomy.constant.TaxonomyConstants;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.datasource.SortedValuesMapDataSource;
import com.interwoven.datasource.core.DataSourceContext;
import com.interwoven.livesite.dom4j.Dom4jUtils;

public class PopulateDynamicDataSource implements SortedValuesMapDataSource {

	private static final transient Logger LOGGER = Logger.getLogger(PopulateDynamicDataSource.class);
	private static final String PARAM_CSFACTORY = "csFactory";
	private static final String PARAM_LOOKUP_TYPE = "lookupType";
	private static final String PARAM_SUB_CATEGORY_LOOKUP_TYPE = "sublookupType";
	private static final String CATEGORY_RELATED_ARTICLE = "category_related_article";
	private static final String SUBCATEGORY_RELATED_ARTICLE = "subcategory_related_article";
	private static final String ROOT_ELEMENT = "ListItem";
	private static final String KEY_ELEMENT = "Name";
	private static final String VALUE_ELEMENT = "Value";
	private static final String VALUE_INDUSTRY = "industry";
	private static final String FILE_EXTENSION_XML = ".xml";
	private static final String DEFAULT_INDUSTRY_CATEGORY = "/iwmnt/iwadmin/main/deere/syndication/STAGING/templatedata/CustomData/NameValueList/data/industries_mapping.xml";
	private static final String DEFAULT_NAMEVALUE_LIST_PATH = "/iwmnt/iwadmin/main/deere/syndication/STAGING/templatedata/CustomData/NameValueList/data/";
	private static final String DEFAULT_SUPER_CATEGORY = "/iwmnt/iwadmin/main/deere/syndication/STAGING/templatedata/CustomData/NameValueList/data/category_mapping.xml";
	private static final Pattern LOCALE_PATTERN = Pattern.compile("^(.*)/deere/([^/]+)/([^/]+)/([A-Z]*)/([^/]+)");
	private static CSClient csClient;
	Map<String, String> optionsMap = new LinkedHashMap<String, String>();
	private String industryFilePath;

	@Override
	public Map<String, String> execute(DataSourceContext context) {
		try {
			csClient = CssdkUtils.getCSClient();
			String csFactory = context.getParameter(PARAM_CSFACTORY);
			LOGGER.debug("CSFactory: " + csFactory);
			final String lookupType = context.getParameter(PARAM_LOOKUP_TYPE);
			LOGGER.debug("lookupType: " + lookupType);
			optionsMap = getLookupType(context, lookupType);
		} catch (Exception ex) {
			LOGGER.debug("Error occured while creating lookup fields ",ex);
		}
		return optionsMap;
	}

	/**
	 * LookUp Type selector,pass the required lookupType and add the custom
	 * method to be executed
	 * <inline command="Datasource:executeComponent:Populate Dynamic
	 * DataSource:lookupType=CATEGORY_RELATED_AIRTCLE" />
	 * 
	 * @param context
	 * @param lookupType
	 * @return
	 */
	private Map<String, String> getLookupType(DataSourceContext context, final String lookupType) {
		LOGGER.debug("Executing getLookupType");
		Map<String, String> categoryMap = new LinkedHashMap<String, String>();
		switch (lookupType) {
		case CATEGORY_RELATED_ARTICLE:
			categoryMap = getRelatedArticlesCategory(context);
			break;
		case SUBCATEGORY_RELATED_ARTICLE:
			categoryMap = getRelatedArticlesSubCategory(context);
			break;
		default:
			break;

		}
		return categoryMap;

	}

	private Map<String, String> getRelatedArticlesSubCategory(DataSourceContext context) {

		LOGGER.debug("Executing getRelatedArticlesSubCategory");
		String subTypeCategory = context.getParameter(PARAM_SUB_CATEGORY_LOOKUP_TYPE);
		if (subTypeCategory.equalsIgnoreCase("Industry")) {
			return getIndustries(context);
		}
		return optionsMap;

	}

	private Map<String, String> getIndustries(DataSourceContext context) {
		String locale = getLocale(context.getServerContext());
		if (locale != null && !"".equals(locale)) {
			industryFilePath = DEFAULT_NAMEVALUE_LIST_PATH + VALUE_INDUSTRY + TaxonomyConstants.UNDERSCORE + locale
					+ FILE_EXTENSION_XML;
		} else {
			industryFilePath = DEFAULT_INDUSTRY_CATEGORY;
		}
		return getLookupMap(industryFilePath);
	}

	/**
	 * Method to get locale to fetch correct xml document
	 * 
	 * @param serverContext
	 * @return
	 */
	private String getLocale(String serverContext) {
		if (serverContext != null) {
			Matcher matcher = LOCALE_PATTERN.matcher(serverContext);
			if (matcher.find()) {
				return matcher.group(3) + "_" + matcher.group(2);
			}
		}
		return null;

	}

	private Map<String, String> getRelatedArticlesCategory(DataSourceContext context) {
		LOGGER.debug("Executing getRelatedArticlesCategory");
		return getLookupMap(DEFAULT_SUPER_CATEGORY);

	}

	/**
	 * Getting lookup map from XMl Document
	 * 
	 * @param filePath
	 * @return
	 */
	private Map<String, String> getLookupMap(String filePath) {
		Map<String, String> loopupMap = new HashMap<String, String>();
		Document lookupDocument;
		CSVPath csvpath = new CSVPath(filePath);
		LOGGER.debug("Path :" + csvpath.toString());
		lookupDocument = retrieveDocument(csvpath.toString());
		loopupMap = generateMap(lookupDocument, ROOT_ELEMENT, KEY_ELEMENT, VALUE_ELEMENT);
		LOGGER.debug("Map  fetched from file " + filePath + ":" + loopupMap.toString());
		return loopupMap;
	}

	/**
	 * Method to generate map from document
	 * 
	 * @param doc
	 * @param rootElementName
	 * @param elementName
	 * @param elementValue
	 * @return
	 */
	private Map<String, String> generateMap(Document doc, String rootElementName, String elementName,
			String elementValue) {
		Map<String, String> urlMapping = new HashMap<String, String>();
		Element root = doc.getRootElement();
		@SuppressWarnings("unchecked")
		List<Element> children = root.elements(rootElementName);
		for (Element element : children) {
			// The option display value
			String name = element.elementText(elementName);

			if (element.element(elementValue) != null) {
				// The option value
				String value = element.elementText(elementValue);
				LOGGER.debug("Entry: " + name + " => " + value);
				urlMapping.put(name, value);
			} else {
				LOGGER.debug("Entry: " + name + " => " + name);
				urlMapping.put(name, name);
			}
		}

		return urlMapping;
	}

	/**
	 * Retrieve the document for the given path.
	 *
	 * @param relativePath
	 *            the relative path
	 * @return the document
	 */
	private Document retrieveDocument(String relativePath) {
		Document document = null;
		InputStream is = null;
		try {
			File dcrFile = new File(relativePath);
			LOGGER.debug("Inside Parsing " + dcrFile.getAbsolutePath());
			if (dcrFile.exists()) {
				LOGGER.debug("Parsing " + dcrFile.getAbsolutePath());
				is = new FileInputStream(dcrFile);
				document = Dom4jUtils.newDocument(is);
			}
			LOGGER.debug("File doesn't exits " + dcrFile.getAbsolutePath());

		} catch (FileNotFoundException fileNotfoundException) {
			LOGGER.debug(relativePath + " file could not be found ", fileNotfoundException);
			return null;
		} catch (Exception exception) {
			LOGGER.debug("Error while parsing the dcr is  ", exception);
			return null;
		}

		return document;
	}
}
