package com.deere.teamsite.datasource;

import static com.deere.teamsite.datasource.PopulateLookupValues.DataSourceParameterNames.LOOKUP_TYPE;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.deere.teamsite.common.constants.PopulateLookupConstants;
import com.interwoven.datasource.MapDataSource;
import com.interwoven.datasource.core.DataSourceContext;

/**
 * The Class PopulateLookupValues.
 */
public class PopulateLookupValues implements MapDataSource {
	/**
	 * HashMap to store the parsed DCR XML values.
	 */
	private Map<String, String> dcrContentMap = new LinkedHashMap<String, String>();

	/** LOGGER variable created. */
	private static final Log LOGGER = LogFactory
			.getLog(PopulateLookupValues.class);

	/**
	 * This function return the map of options for drop down
	 * 
	 * @return Map of dropdown values
	 * @param dataSourceContext
	 *            of the DCT
	 */
	public Map<String, String> execute(DataSourceContext dataSourceContext) {
		LOGGER.debug("------ In PopulateLookupValues Class ------");
		//System.out.println("Inside the PopulateLookupValues");

		final String lookupType = dataSourceContext.getParameter(LOOKUP_TYPE
				.toString());
		/*final String siteName = dataSourceContext.getParameter(SITE_NAME
				.toString());*/
		
		final String branchName = getBranchName(dataSourceContext);
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("lookupType is  " + lookupType);
			//LOGGER.debug("siteName is  " + siteName);
			LOGGER.debug("branchName is  " + branchName);
		}
		//MappingFolderNameDSHelper helper =  new MappingFolderNameDSHelper();
		/*final Map<String, String> folderNameMap = helper.getMappingFolderName(dataSourceContext);
		String folderName =  null;*/
		/*if(folderNameMap.size()>1){
			throw new RuntimeException("site configurations are not correct");
		}else{
			// get the first value
			folderName = folderNameMap.values().iterator().next();
			//System.out.println("folderName  is " + folderName);
		}*/
		
		//folderName = folderNameMap.values().iterator().next(); 
		
		StringBuilder lookupXMLFilePath = new StringBuilder();
		lookupXMLFilePath.append(branchName);
		lookupXMLFilePath.append(PopulateLookupConstants.LOOKUP_DCR_WA);
		//lookupXMLFilePath.append(folderName);
		//lookupXMLFilePath.append("/");
		lookupXMLFilePath.append(lookupType);
		lookupXMLFilePath.append(PopulateLookupConstants.DCR_EXTENSION);
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("lookupXMLFilePath path is - " + lookupXMLFilePath);
		}
		//System.out.println("lookupXMLFilePath is " +lookupXMLFilePath);
				
		return parseFile(lookupXMLFilePath.toString());
	}

	/**
	 * This method opens the dcr xml file and create a input stream object.
	 * 
	 * @param dcrPath
	 *            absolute path of the dcr xml
	 * @return InputStream input stream object of the xml
	 */
	public final Map<String, String> parseFile(String dcrPath) {
		InputStream is = null;
		try {
			File dcrFile = new File(dcrPath);
			if (dcrFile.exists()) {
				LOGGER.debug("Parsing " + dcrFile.getAbsolutePath());
				is = new FileInputStream(dcrFile);
				dcrContentMap = parseXMLAndStoreContent(is);
			} else {
				//This is fall back mechanism for "Uk_UA" branch. Need to be removed once content gets updated
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(" Fall back mechanisom has been called for Uk_UA Branch for for reading populate lookup " + dcrPath);
				}
				String primaySideDirectoryName = getPrimarySiteDirectoryNameFromDCR(dcrPath);
				if("uk_UA".equals(primaySideDirectoryName)){
					dcrPath = dcrPath.replaceFirst("/uk_UA/", "/Uk_UA/");
					dcrContentMap = parseFile(dcrPath);
				}
			}
		} catch (FileNotFoundException fileNotfoundException) {
			LOGGER.error(dcrPath + " file could not be found ",
					fileNotfoundException);
			return null;
		} catch (Exception exception) {
			LOGGER.error("Error while parsing the dcr is  ", exception);
			return null;
		}
		return dcrContentMap;
	}
	
	/**
	 * This method gets the PrimarySiteDirectoryNameFromDCR from the dcr path passed.
	 * 
	 * @param dcrPath
	 *            - the DCR path to get the siteName from.
	 * @return the PrimarySiteDirectoryNameFromDCR else null if not found
	 */
	public static String getPrimarySiteDirectoryNameFromDCR(String dcrPath) throws Exception{
		String primaySideDirectoryName = null;
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(" Extracting PrimarySiteDirectoryNameFromDCR from : " + dcrPath);
		}
		// check if DCR Path is null
		if (dcrPath != null && !dcrPath.equals("")) {
			String[] dcrPathElements = dcrPath.split("/");
			if (dcrPathElements.length >= 5) {
				primaySideDirectoryName = dcrPathElements[5].trim();
			}
		}
		else {
			LOGGER.error("Invalid DCR Path  " + "DCR path is " + dcrPath);
			throw new Exception("Invalid DCR Path " + dcrPath);
		}

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(" Returning the primaySideDirectoryName as : " + primaySideDirectoryName);
		}
		return primaySideDirectoryName;
	}

	/**
	 * This class creates the HashMap containing multiple objects like String
	 * and ArrayList from the given XML input stream. For replicant node of XML,
	 * ArrayList is prepared and for all other nodes, String is prepared for
	 * each node. This method also calls the method parseReplicantElement to
	 * parse the replicant node of the XML.
	 * 
	 * @param inputStream
	 *            input stream of the DCR XML
	 * @return HashMap containing the
	 */
	private Map<String, String> parseXMLAndStoreContent(
			final InputStream inputStream) {
		Document document = null;
		Element element = null;
		NodeList keyChildNodeList = null;
		NodeList valueChildNodeList = null;
		try {
			// initialize the return map
			//dcrContentMap.put("", "--Select--");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			document = dbf.newDocumentBuilder().parse(inputStream);
			NodeList nodeList = document
					.getElementsByTagName(PopulateLookupConstants.LOOKUP_VALUE_CONTAINER);
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node currentNode = nodeList.item(i);
				if (currentNode instanceof Element) {
					element = (Element) currentNode;
					keyChildNodeList = element
							.getElementsByTagName(PopulateLookupConstants.LOOKUP_OPTION_LABEL);
					valueChildNodeList = element
							.getElementsByTagName(PopulateLookupConstants.LOOKUP_OPTION_VALUE);
					if (keyChildNodeList.getLength() != 0
							&& valueChildNodeList.getLength() != 0) {
						dcrContentMap.put(valueChildNodeList.item(0)
								.getTextContent().trim(), keyChildNodeList.item(0)
								.getTextContent().trim());
					}
				}
			}
		} catch (ParserConfigurationException parseException) {
			LOGGER.debug("Parse Error while parsing dcr ", parseException);
		} catch (IOException ioException) {
			LOGGER.debug("I/O Error while parsing dcr ", ioException);
		} catch (SAXException saxException) {
			LOGGER.debug("SAX Error while parsing dcr ", saxException);
		}
		return dcrContentMap;
	}

	/**
	 * The Enum DataSourceParameterNames.
	 */
	public enum DataSourceParameterNames {

		/** The LOCALE. */
		LOCALE("Locale"),
		/** The LOOKU p_ type. */
		LOOKUP_TYPE("lookupType"),
		/** Site name */
		SITE_NAME("siteName");
		/** The name. */
		private String name;

		/**
		 * Instantiates a new data source parameter names.
		 * 
		 * @param name
		 *            the name
		 */
		private DataSourceParameterNames(String name) {
			this.name = name;
		}

		/**
		 * @return String name of the parameter
		 */
		public String toString() {
			return this.name;
		}
	}

	/**
	 * This method gets the vpath from the DataSourceContext object and fetches
	 * the branchName from it.
	 * 
	 * @param dataSourceContex
	 *            to get the branchName
	 * @return branchName
	 */
	public String getBranchName(DataSourceContext dataSourceContex) {
		String path = dataSourceContex.getServerContext().replace("//", "");
		String[] pathArray = path.split("/");
		return path.replace(pathArray[0], "/iwmnt");
	}
}
