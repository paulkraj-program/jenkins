package com.deere.teamsite.datasource;

import com.deere.livesite.workflow.constants.MaintenanceReminderConstants;
import com.deere.livesite.workflow.CommonServices;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSIterator;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFileKindMask;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSSortKey;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.datasource.SortedValuesMapDataSource;
import com.interwoven.datasource.core.DataSourceContext;
import com.interwoven.livesite.common.util.IterableIterator;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 * Datasource to get the list of all the DCRs for a specific Category/Content type
 */
public class DcrListDataSource implements SortedValuesMapDataSource {
	
	private static final transient Logger LOGGER = Logger.getLogger(DcrListDataSource.class);
	
	
	private static CSClient _client = null;

	public Map<String, String> execute(DataSourceContext context) {
		String folderPath = context.getParameter(MaintenanceReminderConstants.PARAM_AREA_FOLDER_PATH);
		LOGGER.debug("Area Folder Path: " + folderPath);
		String fullFolderPath = context.getParameter(MaintenanceReminderConstants.PARAM_FULL_FOLDER_PATH);
		LOGGER.debug("Full Folder Path: " + fullFolderPath);
		String csFactory = context.getParameter(MaintenanceReminderConstants.PARAM_CSFACTORY);
		LOGGER.debug("CSFactory: " + csFactory);

		CSVPath vpath = null;
		if ((fullFolderPath != null) && (!"".equals(fullFolderPath))) {
			vpath = new CSVPath(fullFolderPath);
		} else if ((folderPath != null) && (!"".equals(folderPath))) {
			vpath = new CSVPath(context.getServerContext()).concat(folderPath);
		}
		try {
			_client = DataSourceUtilities.getCSClient(csFactory);
			if (_client != null) {
				return execute(vpath);
			}
		} catch (CSException cse) {
			LOGGER.error( "An error occurred communicating with the content management system", cse);
		}
		return Collections.singletonMap(MaintenanceReminderConstants.VAL_EMPTY_DEFAULT, MaintenanceReminderConstants.KEY_EMPTY_DEFAULT);
	}

	/**
	 * Method to parse the directory in workarea and get the list of all the DCRs 
	 * @param path
	 * @return Map of DCR path and DCR Label
	 */
	private static Map<String, String> execute(CSVPath path) {
		LOGGER.debug("File Path: " + path);
		if (path == null) {
			LOGGER.info("VPath was null; returning empty map");
			return Collections.singletonMap(MaintenanceReminderConstants.VAL_EMPTY_DEFAULT, MaintenanceReminderConstants.KEY_EMPTY_DEFAULT);
		}
		Map<String, String> map = new LinkedHashMap<String, String>();
		try {
			List<CSDir> dirQueue = CommonServices.getSourceDirectories(_client, path);
			while (dirQueue.size() > 0) {
				getDcrs(dirQueue, true, map);
			}
		} catch (CSException cse) {
			LOGGER.error("An error occurred communicating with the content management system", cse);
		}
		if ((map == null) || (map.isEmpty())) {
			return Collections.singletonMap(MaintenanceReminderConstants.VAL_EMPTY_DEFAULT, MaintenanceReminderConstants.KEY_EMPTY_DEFAULT);
		}
		return new TreeMap<String, String>(map);
	}

	/**
	 * Method to parse the workarea folder and gets all the DCRs recursively 
	 * @param queue
	 * @param isRecursive
	 * @param map
	 * @throws CSException
	 */
	public static void getDcrs(List<CSDir> queue, boolean isRecursive, Map<String, String> map) throws CSException {
		CSDir directory = (CSDir) queue.remove(0);

		LOGGER.debug("Processing Directory : " + directory.getVPath().getAreaRelativePath().toString());
		CSSortKey[] cssortKey = new CSSortKey[1];
		cssortKey[0] = new CSSortKey(1, true);
		CSIterator iterator = directory.getFiles(CSFileKindMask.SIMPLEFILE, cssortKey, CSFileKindMask.SIMPLEFILE, null, 0, -1);
		if (iterator != null) {
			@SuppressWarnings("unchecked")
			IterableIterator<CSSimpleFile> iterable = new IterableIterator<CSSimpleFile>(iterator);
			for (CSSimpleFile file : iterable) {
				if (CommonServices.isDCR(file)) {
					String dcrName = CommonServices.getFieldValue(file, "Name");
					String fileName = CommonServices.getDcrName(file);
					if ((dcrName != null) && (!dcrName.isEmpty())) {
						dcrName = fileName + " - " + dcrName;
					} else {
						dcrName = fileName;
					}
					map.put(file.getVPath().getAreaRelativePath().toString(), dcrName);
				}
			}
		}
		if (isRecursive) {
			iterator = directory.getFiles(CSFileKindMask.DIR, cssortKey, 0, null, 0, -1);
			if (iterator != null) {
				@SuppressWarnings("unchecked")
				IterableIterator<CSDir> iterable = new IterableIterator<CSDir>(iterator);
				for (CSDir dir : iterable) {
					queue.add(dir);
				}
			}
		}
	}


}
