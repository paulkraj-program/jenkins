package com.deere.teamsite.datasource;

import java.io.*;
import java.util.*;
import org.apache.log4j.*;
import org.dom4j.*;
import com.interwoven.cssdk.common.*;
import com.interwoven.cssdk.filesys.*;
import com.interwoven.datasource.*;
import com.interwoven.datasource.core.*;
import com.interwoven.livesite.common.util.*;
import com.interwoven.livesite.external.*;

/**
 * NameValuePairDataSource is an implementation of SortedValuesMapDataSource this class
 * builds a map of options from the DCR provided as a parameter.  This class takes three
 * parameters:<br />
 * <ul>
 * 		<li>AreaPath - The relative path to the desired DCR [optional with FullPath]</li>
 * 		<li>FullPath - The full VPath to the desired DCR [optional with AreaPath]</li>
 * 		<li>SortBy - The desired output sort, options include: [ NONE, NAME, VALUE ]</li>
 * </ul>
 * One of AreaPath or FullPath are required for this class to return any valid content; however,
 * if both are provided FullPath will take precedence over AreaPath.<br />
 * The SortBy is an enumerated parameter that takes one of three values as listed.  The
 * meaning of those values is as follows:<br />
 * <ul>
 * 		<li>NONE - The options are not sorted and presented to the user as they appear in the input DCR</li>
 * 		<li>NAME - The options are sorted by the display name</li>
 * 		<li>VALUE - The optios are sorted by the value</li>
 * </ul>
 * 
 * @author Klish Group, Inc. [ND]
 */
/*
 * Sample Input DCR XML Document:
 * 	<?xml version="1.0" encoding="UTF-8"?>
 * 	<ValueList>
 * 		<ListItem>
 * 			<Name>Tractors</Name>
 * 		</ListItem>
 * 	</ValueList>
 * 
 * Sample Component Datum:
 * 	<Datum ID="D01" Type="SelectSingle" Name="Items" Label="Selectable Item List" >
 * 		<Generator Object="com.deere.livesite.dct.datasources.NameValuePairDataSource" Method="getOptions" >
 * 			<Parameters>
 * 				<Datum ID="D01-G01-P01" Name="AreaPath" Label="Relative Path" Type="String" >templatedata/CustomData/ValueList/data/industries.xsl</Datum>
 * 				<Datum ID="D01-G01-P02" Name="FullPath" Label="Full Path" Type="String" >/iwadmin/main/deere/syndication/WORKAREA/shared/templatedata/CustomData/ValueList/data/projects.xml</Datum>
 * 				<Datum ID="D01-G01-P03" Name="SortBy" Label="Sort Options By" Type="SelectSingle" >
 * 					<Option Selected="true" ><Display>Do Not Sort</Display><Value>none</Value></Option>
 * 					<Option><Display>By Display Name</Display><Value>name</Value></Option>
 * 					<Option><Display>By Option Value</Display><Value>value</Value></Option>
 * 				</Datum>
 * 			</Parameters>
 * 		</Generator>
 * 	</Datum>
 * 
 * DataSource Configuration Entry:
 * 	<datasource>
 * 		<name>Name Value Pair Datasource</name>
 * 		<classname>com.deere.livesite.dct.datasources.NameValuePairDataSource</classname>
 * 		<param name="servername">tsdev.deere.com</param>
 * 		<param name="serviceBaseURL">http://teamsite.deere.com</param>
 * 		<param name="csFactory">com.interwoven.cssdk.factory.CSJavaFactory</param>
 * 	</datasource>
 * 
 * Sample DCR Item with Inline Command:
 * 	<item name="Industries" pathid="Industries" required="t" >
 * 		<label>Industries</label>
 * 		<select multiple="t" >
 * 			<inline command="Datasource:executeComponent:Name Value Pair Datasource:AreaPath=templatedata/CustomData/ValueList/data/industries.xml" />
 * 		</select>
 * 	</item>
 */
public class NameValuePairDataSource implements SortedValuesMapDataSource {
	private static final transient Logger LOGGER = Logger.getLogger(NameValuePairDataSource.class);
	
	private static final String ELEMENT_OPTION = "ListItem";
	private static final String ELEMENT_NAME = "Name";
	private static final String ELEMENT_VALUE = "Value";
	
	private static final String KEY_EMPTY_DEFAULT = "*** No Entries ***";
	private static final String KEY_SELECT_DEFAULT = "*** Select a Value ***";
	private static final String VAL_EMPTY_DEFAULT = "";
	
	private static final String PARAM_OPTION_ELEMENT = "OptionElement";
	private static final String PARAM_AREA_PATH = "AreaPath";
	private static final String PARAM_FULL_PATH = "FullPath";
	private static final String PARAM_SORT_BY = "SortBy";
	private static final String PARAM_CSFACTORY = "csFactory";
	
	/**
	 * getOptions is the NameValuePairDataSource class entry point method as a TeamSite/LiveSite
	 * generator for use in LiveSite component data.
	 * @param context The current PropertyContext instance
	 * @return The XML Document instance containing the generated options.
	 */
	public Document getOptions(PropertyContext context) {
		String path = (String) context.getParameters().get(PARAM_AREA_PATH);
		LOGGER.debug("Area Path: " + path);
		String fullPath = (String) context.getParameters().get(PARAM_FULL_PATH);
		LOGGER.debug("Full Path: " + fullPath);
		String optionElement = (String) context.getParameters().get(PARAM_OPTION_ELEMENT);
		LOGGER.debug("Option Element: " + optionElement);
		String sortBy = (String) context.getParameters().get(PARAM_SORT_BY);
		LOGGER.debug("SortBy: " + sortBy);
		
		// Build out the vPath from either the relative path or the full path
		CSVPath vpath = null;
		if (fullPath != null && !"".equals(fullPath)) {
			vpath = new CSVPath(fullPath);
		} else if (path != null && !"".equals(path)) {
			vpath = new CSVPath(context.getFileDAL().getRoot()).concat(path);
		}
		
		// Create an singleton map instance in case of exception
		Map<String, String> map = Collections.singletonMap(VAL_EMPTY_DEFAULT, KEY_EMPTY_DEFAULT);
		
		try {
			map = execute(DataSourceUtilities.getCSClient(), vpath, optionElement, sortBy, true);
		} catch (CSException cse) {
			LOGGER.debug("An error occurred communicating with the content management system", cse);
		}
		
		// Create an XML Document with a root element named 'Options'
		Document document = DocumentHelper.createDocument(DocumentHelper.createElement("Options"));
		Element root = document.getRootElement();
		
		// Add all of the 'Option' elements to the XML Document from the generated Map
		for (Map.Entry<String, String> entry : map.entrySet()) {
			GeneratorUtils.addOption(root, entry.getValue(), entry.getKey());
		}
		
		return document;
	}
	
	@Override
	public Map<String, String> execute(DataSourceContext context) {
		String path = context.getParameter(PARAM_AREA_PATH);
		LOGGER.debug("Area Path: " + path);
		String fullPath = context.getParameter(PARAM_FULL_PATH);
		LOGGER.debug("Full Path: " + fullPath);
		String optionElement = context.getParameter(PARAM_OPTION_ELEMENT);
		LOGGER.debug("Option Element: " + optionElement);
		String sortBy = context.getParameter(PARAM_SORT_BY);
		LOGGER.debug("SortBy: " + sortBy);
		String csFactory = context.getParameter(PARAM_CSFACTORY);
		LOGGER.debug("CSFactory: " + csFactory);
		
		// Build out the vPath from either the relative path or the full path
		CSVPath vpath = null;
		if (fullPath != null && !"".equals(fullPath)) {
			vpath = new CSVPath(fullPath);
		} else if (path != null && !"".equals(path)) {
			vpath = new CSVPath(context.getServerContext()).concat(path);
		}
		
		try {
			return execute(DataSourceUtilities.getCSClient(csFactory), vpath, optionElement, sortBy, false);
		} catch (CSException cse) {
			LOGGER.error("An error occurred communicating with the content management system", cse);
			// Create and return an singleton map instance in case of exception
			return Collections.singletonMap(VAL_EMPTY_DEFAULT, KEY_EMPTY_DEFAULT);
		}
	}
	
	public static Map<String, String> execute(CSClient client, CSVPath path) {
		return execute(client, path, null, null, false);
	}
	private static Map<String, String> execute(CSClient client, CSVPath path, String optionElement, String sortByString, boolean isGenerator) {
		// Convert the sort by parameter string into a value of the enumeration
		SortBy sortBy = SortBy.NONE;
		if (sortByString != null && !"".equals(sortByString)) {
			try {
				sortBy = SortBy.valueOf(sortByString);
			} catch (IllegalArgumentException iae) {
				// Ignore this exception and use the default sort by value (NONE)
			}
		}
		
		if (optionElement == null || "".equals(optionElement)) {
			optionElement = ELEMENT_OPTION;
		}
		
		// Log the input values
		LOGGER.debug("File Path: " + path);
		LOGGER.debug("Sort By: " + sortBy);
		LOGGER.debug("Option Element: " + optionElement);
		
		// Return the default collection when no valid path was provided
		if (path == null) {
			LOGGER.info("VPath was null; returning empty map");
			return Collections.singletonMap(VAL_EMPTY_DEFAULT, KEY_EMPTY_DEFAULT);
		}
		
		Map<String, String> map = new LinkedHashMap<String, String>();
		if (isGenerator) {
			map.put(VAL_EMPTY_DEFAULT, KEY_SELECT_DEFAULT);
		}
		
		try {
			// Read the file (it should be of kind CSSimpleFile)
			CSFile file = client.getFile(path);
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				// Read the contents of the file into an XML document
				CSSimpleFile dcr = (CSSimpleFile) file;
				InputStream input = new BufferedInputStream(dcr.getInputStream(false));
				Document document;
				try {
					document = new org.dom4j.io.SAXReader().read(input);
				} finally {
					if (input != null) { try { input.close(); } catch (IOException e) { } }
				}
				
				// Get the root element and then from the root element get the list of child elements
				Element root = document.getRootElement();
				@SuppressWarnings("unchecked")
				List<Element> children = root.elements(optionElement);
				
				// Get the option name and values from each of the child elements
				for (Element element : children) {
					// The option display value
					String name = element.elementText(ELEMENT_NAME);
					
					if (element.element(ELEMENT_VALUE) != null) {
						// The option value
						String value = element.elementText(ELEMENT_VALUE);
						
						LOGGER.debug("Entry: " + name + " => " + value);
						map.put(value, name);
					} else {
						LOGGER.debug("Entry: " + name + " => " + name);
						map.put(name, name);
					}
				}
			}
		} catch (DocumentException de) {
			LOGGER.error("An error occurred reading the XML content", de);
		} catch (CSException cse) {
			LOGGER.error("An error occurred communicating with the content management system", cse);
		}
		
		// Sort the map before returning
		map = sortBy.sortMap(map);
		
		// Make sure the sorted map is valid if not return the default collection
		if (map == null || map.isEmpty()) {
			return Collections.singletonMap(VAL_EMPTY_DEFAULT, KEY_EMPTY_DEFAULT);
		}
		
		return map;
	}
	
}
