package com.deere.teamsite.datasource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSBranch;
import com.interwoven.cssdk.filesys.CSStore;
import com.interwoven.datasource.ListDataSource;
import com.interwoven.datasource.core.DataSourceContext;

/**
 * BranchDatasource is an implementation of a ListDataSource that returns the
 * list of available branches in a store, with the option of excluding the
 * current branch.
 * @author Klish Group, Inc. [ND]
 */
public class BranchDatasource implements ListDataSource {
	private static final transient Logger LOGGER = Logger.getLogger(BranchDatasource.class);
	
	/* (non-Javadoc)
	 * @see com.interwoven.datasource.ListDataSource#execute(com.interwoven.datasource.core.DataSourceContext)
	 */
	@Override
	public List<String> execute(DataSourceContext context) {
		try {
			String csFactory = context.getParameter("csFactory");
			LOGGER.debug("CSFactory: " + csFactory);
			
			CSClient client = DataSourceUtilities.getCSClient(csFactory);
			String currentBranch = context.getServerContext();
			LOGGER.debug("Current Branch: " + currentBranch);
			
			boolean excludeCurrent = Boolean.parseBoolean(context.getParameter("ExcludeCurrent"));
			LOGGER.debug("Exclude Current: " + excludeCurrent);
			
			List<String> excludedStores = Collections.emptyList();
			String excludedStoreString = context.getParameter("ExcludedStores");
			if (excludedStoreString != null && !"".equals(excludedStoreString)) {
				String[] excludedStoreArray = excludedStoreString.split(",");
				if (excludedStoreArray != null && excludedStoreArray.length > 0) {
					excludedStores = Arrays.asList(excludedStoreArray);
				}
			}
			LOGGER.debug("Excluded Stores: " + excludedStores);
			
			Set<String> branches = new TreeSet<>();
			for (CSStore store : client.getRoot().getStores()) {
				if (excludedStores.contains(store.getName())) {
					LOGGER.debug("Excluded Store: " + store.getName());
					continue;
				}
				
				for (CSBranch branch : store.getBranches()) {
					String path = branch.getVPath().getPathNoServer().toString();
					LOGGER.debug("Branch Path: " + path);
					branches.add(path);
					branches.addAll(getBranches(branch));
				}
			}
			
			if (excludeCurrent) {
				if (branches.contains(currentBranch)) {
					branches.remove(currentBranch);
				}
			}
			
			return new ArrayList<>(branches);
		} catch (CSException cse) {
			LOGGER.error("An error occurred during brach list retrieval.", cse);
			
			return Collections.singletonList("*** ERROR: Contact Admin ***");
		}
	}
	
	private Set<String> getBranches(CSBranch branch) throws CSException {
		Set<String> list = new TreeSet<>();
		String path = branch.getVPath().getPathNoServer().toString();
		LOGGER.debug("Branch Path: " + path);
		list.add(path);
		
		for (CSBranch child : branch.getSubBranches()) {
			path = branch.getVPath().getPathNoServer().toString();
			LOGGER.debug("Branch Path: " + path);
			list.add(path);
			list.addAll(getBranches(child));
		}
		
		return list;
	}
	
}
