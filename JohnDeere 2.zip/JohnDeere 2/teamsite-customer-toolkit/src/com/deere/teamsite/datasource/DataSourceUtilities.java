package com.deere.teamsite.datasource;

import java.util.Locale;
import java.util.Properties;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.factory.CSFactory;

/**
 * DataSourceUtilities is a class that contains utility methods for use in
 * developing TeamSite map, list, etc. data sources.
 * @author Klish Group, Inc. [ND]
 */
public class DataSourceUtilities {
	
	private static final String PROP_CS_FACTORY = "com.interwoven.cssdk.factory.CSFactory";
	
	private static final String PROP_JAVA_FACTORY = "com.interwoven.cssdk.factory.CSJavaFactory";
	
	private DataSourceUtilities() { }
	
	/**
	 * Get a CSClient instance for the current user defaulting to the CSJavaFactory
	 * class if the System properties does not already contain a CSFactory
	 * definition.
	 * @return The CSClient instance
	 * @throws CSException
	 */
	public static CSClient getCSClient() throws CSException {
		return getCSClient(PROP_JAVA_FACTORY);
	}
	/**
	 * Get a CSClient instance for the current user using the provided CSFactory
	 * class if the System properties does not already contain a CSFactory
	 * definition.
	 * @param csFactory The fully qualified class name of the CSFactory implementation
	 * @return The CSClient instance
	 * @throws CSException
	 */
	public static CSClient getCSClient(String csFactory) throws CSException {
		if (csFactory == null || "".equals(csFactory)) {
			csFactory = PROP_JAVA_FACTORY;
		}
		
		Properties properties = new Properties(System.getProperties());
		
		if (!properties.containsKey(PROP_CS_FACTORY)) {
			properties.put(PROP_CS_FACTORY, csFactory);
		}
		
		CSFactory factory = CSFactory.getFactory(properties);
		
		return factory.getClientForCurrentUser(Locale.getDefault(), "DataSourceContext", null);
	}	

}
