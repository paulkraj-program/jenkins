package com.deere.livesite.workflow;

/**
 * Enumeration for all of the JSON types that are specified to be used in the POST command
 * to the WSO2 service specified in PostToAkeneoTask class.
 * 
 * Each JSONType has the identifier type associated with it and the service name specified in the 
 * json filename.
 * 
 * @author Klish Group, Inc
 *
 */
public enum JSONType {
	ACCESSORIES("accessories", "sku"), 
	BAZAARVOICE("bazaarvoice", "sku"), 
	CLOSESTCOMPARISON("closestcomparison", "sku"), 
	COMPETINGMACHINES("competingmachines", "sku"), 
	FEATURES("features", "sku"), 
	JDPS("jdps", "sku"), 
	PRODUCT360("product360", "sku"), 
	SALESMANUAL("salesmanual", "sku"), 
	SPECCHECK("speccheck", "sku"), 
	SPECIFICATIONS("specifications", "sku"),
	;

	private String jsonServiceExtName;
	private String id_type;

	private JSONType(String extName, String idtype) {
		jsonServiceExtName = extName;
		id_type = idtype;
	}

	public String getExtName() {
		return jsonServiceExtName;
	}
	
	public boolean isServiceRelated(String name) {
		if (jsonServiceExtName.equals(name) || this.toString().toLowerCase().equals(name)) {
			return true;
		}
		return false;
	}

	public String getIDType() {
		return id_type;
	}
}
