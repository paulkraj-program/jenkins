package com.deere.livesite.workflow.translation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import com.deere.livesite.workflow.syndication.SyndicationTarget;

/**
 * RetrievalInfo is a POJO that contains information about a retrieved
 * translation project in order to build an e-mail to the initiator and project
 * manager about the retrieved content.
 * 
 * @author Klish Group, Inc. [ND]
 */
public class RetrievalInfo {

	private static final String ELEMENT_INFO = "RetrievalInfo";
	private static final String ELEMENT_CONTENT = "Content";
	private static final String ELEMENT_RETRIEVED = "Retrieved";
	private static final String ELEMENT_FAILED = "Failed";
	private static final String ELEMENT_UNKNOWN = "Unknown";
	private static final String ELEMENT_TARGET = "Target";
	private static final String ELEMENT_BRANCH = "Branch";
	private static final String ELEMENT_FILE = "File";
	private static final String ATTR_REASON = "reason";

	private static class Failure {
		private final String path;
		private final Exception reason;

		public Failure(String path, Exception e) {
			this.path = path;
			this.reason = e;
		}

	}

	TranslationJob translationJob;
	Map<SyndicationTarget, List<String>> retrieved;
	Map<SyndicationTarget, List<Failure>> failed;
	List<String> unknown;

	// List<String> unknownFileList=new ArrayList<String>();
	/**
	 * Create a new RetrievalInfo instance for the provided TranslationJob
	 * 
	 * @param translationJob
	 *            The TranslationJob instance
	 */
	public RetrievalInfo(TranslationJob translationJob) {
		this.translationJob = translationJob;

		retrieved = new LinkedHashMap<>();
		failed = new LinkedHashMap<>();
		unknown = new ArrayList<>();
	}

	/**
	 * Add a retrieved file to this instance
	 * 
	 * @param target
	 *            The SyndicationTarget for the file
	 * @param file
	 *            The path to the file
	 */
	public void addRetrievedFile(SyndicationTarget target, String file) {
		List<String> list = retrieved.get(target);

		if (list == null) {
			list = new ArrayList<>();
			retrieved.put(target, list);
		}

		list.add(file);
	}

	/**
	 * Add a failed file to this instance
	 * 
	 * @param target
	 *            The SyndicationTarget for the file
	 * @param file
	 *            The path to the file
	 * @param e
	 *            The Exception reason for the failure
	 */
	public void addFailedFile(SyndicationTarget target, String file, Exception e) {
		List<Failure> list = failed.get(target);

		if (list == null) {
			list = new ArrayList<>();
			failed.put(target, list);
		}

		list.add(new Failure(file, e));
	}

	/**
	 * Add an unknown file to this instance
	 * 
	 * @param file
	 *            The path to the file in the archive
	 */
	public void addUnknownFile(String file) {
		unknown.add(file);
	}

	/* * Get an unknown file from this instance **/

	public List<String> getUnknown() {
		return unknown;
	}

	/**
	 * Generate an XML element from this instance
	 * 
	 * @return The XML element containing the content of this instance
	 */
	public Element toElement() {
		/*
		 * <RetrievalInfo> <transJob /> <Content> <Retrieved> <Target> <Branch
		 * /> <File /> ... </Target> ... </Retrieved> <Failed> <Target> <Branch
		 * /> <File reason="" /> ... </Target> ... </Failed> <Unknown> <File />
		 * ... </Unknown </Content> </RetrievalInfo>
		 */
		Element element = DocumentHelper.createElement(ELEMENT_INFO);

		Element translationElement = translationJob.toElement();
		element.add(translationElement);

		Element contentElement = element.addElement(ELEMENT_CONTENT);

		Element retrievedElement = contentElement.addElement(ELEMENT_RETRIEVED);

		for (Map.Entry<SyndicationTarget, List<String>> entry : retrieved.entrySet()) {
			SyndicationTarget target = entry.getKey();
			Element targetElement = retrievedElement.addElement(ELEMENT_TARGET);
			targetElement.addElement(ELEMENT_BRANCH).setText(target.getBranch());

			for (String file : entry.getValue()) {
				targetElement.addElement(ELEMENT_FILE).setText(file);
			}
		}

		Element failureElement = contentElement.addElement(ELEMENT_FAILED);

		for (Map.Entry<SyndicationTarget, List<Failure>> entry : failed.entrySet()) {
			SyndicationTarget target = entry.getKey();
			Element targetElement = failureElement.addElement(ELEMENT_TARGET);
			targetElement.addElement(ELEMENT_BRANCH).setText(target.getBranch());

			for (Failure file : entry.getValue()) {
				Element fileElement = targetElement.addElement(ELEMENT_FILE);
				fileElement.setText(file.path);
				fileElement.addAttribute(ATTR_REASON, file.reason.getLocalizedMessage());

			}
		}

		Element unknownElement = contentElement.addElement(ELEMENT_UNKNOWN);

		for (String file : unknown) {
			unknownElement.addElement(ELEMENT_FILE).setText(file);
		}

		return element;
	}

}
