package com.deere.livesite.workflow;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.livesite.common.error.LiveSiteError;
import com.interwoven.livesite.common.util.PatternWrapper;
import com.interwoven.livesite.common.xml.XmlParseableUtils;
import com.interwoven.livesite.workflow.WorkflowUtils;
import com.interwoven.livesite.workflow.model.Callback;
import com.interwoven.livesite.workflow.task.PageConversionTask;
import com.interwoven.livesite.workflow.task.TaskContext;

/**
 * This class is created to generate the html pages directly in the translated Path
 * @author Klish group, Inc. [AG]
 *
 */
public class CustomPageConversionURLTranslationTask extends PageConversionTask {

	/**
	  * This function checks if the HTMLs are generated for the Page and attaches those 
	  * generated HTML to the task. It then transitions to the success task in the workflow.
	  * @param doc Contains the response of the custom service 
	  * @param task Current task 
	  * @throws CSException
	  */
	@SuppressWarnings ("rawtypes")
	@Override
	protected Callback handleSuccess (Document doc, TaskContext context) throws CSException {
		@SuppressWarnings ("unchecked")
		List<? extends Node> fileElements = doc.getRootElement ().selectNodes ("OutputFiles/File");

		List<CSAreaRelativePath> areaRelativePathsToAttach = new LinkedList<CSAreaRelativePath> ();
		Set vpaths = buildTaskFileVpathSet (context.getTask ());

		StringBuffer message = new StringBuffer ();
		message.append ("Successfully converted ").append (fileElements.size ()).append (" pages.");
		for (Node fileElementNode : fileElements) {
			Element fileElement = (Element) fileElementNode;
			String path;
			try {
				this.mLogger.debug ("not decoded value " + fileElement.valueOf ("Vpath"));
				path = URLDecoder.decode (fileElement.valueOf ("Vpath"), "UTF-8");

				this.mLogger.debug ("decoded value " + path);
				CSVPath vpath = new CSVPath (path);
				if (!vpaths.contains (vpath.getPathNoServer ().toString ())) {
					this.mLogger.debug ("Path " + fileElement.valueOf ("Vpath"));
					areaRelativePathsToAttach.add (vpath.getAreaRelativePath ());
					this.mLogger.debug ("Vpath " + vpath.getAreaRelativePath ());
				}
			} catch (UnsupportedEncodingException e) {
				this.mLogger.debug ("error decoding the file name ");
			}
		}
		int attachCount = areaRelativePathsToAttach.size ();
		if (attachCount > 0) {
			context.getTask ().attachFiles ((CSAreaRelativePath[]) areaRelativePathsToAttach.toArray (new CSAreaRelativePath[0]));
			if (this.mLogger.isDebugEnabled ()) {
				this.mLogger.debug ("convertPages: attached " + attachCount + " generated files to the job.");
			}
			message.append ("  " + attachCount + " generated files were attached to the job.");
		}
		return WorkflowUtils.getSuccessCallback (context.getTask (), message.toString ());
	}
	
	@Override
	protected Callback handleFailure(Document doc, TaskContext context)
	{
	     @SuppressWarnings ("unchecked")
	     List<? extends Node> errorElements = doc.getRootElement().selectNodes("Error");
	     
	     String callbackMessage = "Error while generating pages.";
	     for (Node errorElementNode : errorElements)
	     {
	       Element errorElement= (Element) errorElementNode;
	       LiveSiteError error = (LiveSiteError)XmlParseableUtils.parse(errorElement);
	       WorkflowUtils.addError(error, context.getWorkflow());
	     }
	     
	 	Node errorMessage = doc.getRootElement().selectSingleNode ("Error/Exception/Cause/Message");
	 	if(errorMessage != null){
	 		return WorkflowUtils.getFailureCallback(context.getTask(), errorMessage.getText (), null);
	 	}
	     
	    return WorkflowUtils.getFailureCallback(context.getTask(), callbackMessage, null);
	}

	/**
	 * This method fetches the variables from the workflow task and put them in the Map.
	 * @param task
	 * @return
	 * @throws CSException
	 */
	@SuppressWarnings ({ "unchecked", "rawtypes" })
	protected Map getWorkflowParameterMap (TaskContext context) throws CSException {
		Map params = new HashMap ();

		String suffix = WorkflowUtils.findVariable (context.getTask (), getSuffixVariableName ());
		params.put ("suffix", suffix == null ? "" : suffix);

		String destDir = WorkflowUtils.findVariable (context.getTask (), "DestinationDirectory");
		if ((destDir == null) || ("".equals (destDir.trim ()))) {
			throw new RuntimeException ("Missing required variable: DestinationDirectory");
		}
		params.put ("destDir", destDir);

		String processor = WorkflowUtils.findVariable (context.getTask (), "Processor");
		params.put ("processor", processor == null ? "" : processor);

		List<PatternWrapper> filterPatterns = buildFilterPatterns (context);

		List<String> vpaths = new LinkedList<String> ();

		String areaVpath = context.getTask ().getArea ().getVPath ().getPathNoServer ().toString ();
		for (CSAreaRelativePath path : context.getTask ().getFiles ()) {
			String absoluteVpath = areaVpath.concat ("/").concat (path.toString ());
			if ((filterPatterns == null) || (PatternWrapper.processPatterns (absoluteVpath, filterPatterns))) {
				vpaths.add (areaVpath + "/" + path.toString ());
			} else if (this.mLogger.isDebugEnabled ()) {
				this.mLogger.debug ("getWorkflowParameterMap: vpath excluded by filter patterns: " + absoluteVpath + ", will not be converted.");
			}
		}
		params.put ("vpath", vpaths);

		// Languages which do not require the translation
		String blackListLanguages = context.getTask ().getVariable ("BlackListLanguages");
		if (blackListLanguages != null && !blackListLanguages.isEmpty ())
			params.put ("BlackListLanguages", blackListLanguages);

		//Page Link patterns that do not require the translation
		String ignorePageLinks = context.getTask ().getVariable ("BlackListPageLinks");
		if (ignorePageLinks != null && !ignorePageLinks.isEmpty ())
			params.put ("BlackListPageLinks", ignorePageLinks);

		//Branches that do not require the translation
		String ignoreBranchNames = context.getTask ().getVariable ("BlackListBranchNames");
		if (ignoreBranchNames != null && !ignoreBranchNames.isEmpty ())
			params.put ("BlackListBranchNames", ignoreBranchNames);

		//Branches that do not require the translation
		String ignoreFileFolderNames = context.getTask ().getVariable ("BlackListFileFolderNames");
		if (ignoreFileFolderNames != null && !ignoreFileFolderNames.isEmpty ())
			params.put ("BlackListFileFolderNames", ignoreFileFolderNames);

		//Folder path for the URL Mapping File
		String urlMappingFolder = context.getTask ().getVariable ("UrlMappingFolderPath");
		if (urlMappingFolder != null && !urlMappingFolder.isEmpty ())
			params.put ("UrlMappingFolderPath", urlMappingFolder);

		if (this.mLogger.isDebugEnabled ()) {
			this.mLogger.debug ("getWorkflowParameterMap: parameters:\n");

			Set set = params.entrySet ();
			Iterator it = set.iterator ();
			while (it.hasNext ()) {
				Map.Entry<String, Object> entry = (Map.Entry) it.next ();
				this.mLogger.debug ("getWorkflowParameterMap: parameter: " + (String) entry.getKey () + ": " + entry.getValue ().toString () + "\n");
			}
		}
		return params;
	}

}
