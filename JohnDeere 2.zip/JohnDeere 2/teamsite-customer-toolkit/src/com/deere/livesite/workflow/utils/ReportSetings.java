package com.deere.livesite.workflow.utils;
import java.util.List;

public class ReportSetings {

	private String locale;
	private String branches;
	private String sitemapFile;
	private String dictionaryFile;
	private List<String> Sitemapurls;
	private String workareaPath;
	private List<SitemapPages> SitemapPages;
    private int taskid;
	
	public int getTaskid() {
		return taskid;
	}
	public void setTaskid(int taskid) {
		this.taskid = taskid;
	}
	public List<SitemapPages> getSitemapPages() {
		return SitemapPages;
	}
	public void setSitemapPages(List<SitemapPages> sitemapPages) {
		SitemapPages = sitemapPages;
	}

	
	
	public String getWorkareaPath() {
		return workareaPath;
	}
	public void setWorkareaPath(String workareaPath) {
		this.workareaPath = workareaPath;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getBranches() {
		return branches;
	}
	public void setBranches(String branches) {
		this.branches = branches;
	}
	public String getSitemapFile() {
		return sitemapFile;
	}
	public void setSitemapFile(String sitemapFile) {
		this.sitemapFile = sitemapFile;
	}
	public String getDictionaryFile() {
		return dictionaryFile;
	}
	public void setDictionaryFile(String dictionaryFile) {
		this.dictionaryFile = dictionaryFile;
	}
	public List<String> getSitemapurls() {
		return Sitemapurls;
	}
	public void setSitemapurls(List<String> sitemapurls) {
		Sitemapurls = sitemapurls;
	}

	
}
