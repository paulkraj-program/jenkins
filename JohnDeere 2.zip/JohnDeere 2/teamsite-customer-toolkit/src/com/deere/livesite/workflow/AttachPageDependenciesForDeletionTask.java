package com.deere.livesite.workflow;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FilenameUtils;
import org.apache.james.mime4j.util.LangUtils;

import com.deere.livesite.maintainence.TeamsiteLogsComonUtils;
import com.deere.livesite.workflow.common.urlmapping.URLMappingCommonServices;
import com.interwoven.cssdk.access.CSUser;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * This task is used in Delete Workflow to attach the associated JSON and HTML
 * for the .page It also checks if the user selected folder. It will only allow
 * folder to be deleted if it is empty otherwise it will remove the folder from
 * the task. It also verifies if the files attached to the workflow do not
 * include the files that are not allowed to be deleted.
 * 
 * Addition: The URLs now support the translated path. So, the deletion of files
 * would be done in translated path.
 * 
 * @author Klish Group, INC. [AG]
 *
 */

public class AttachPageDependenciesForDeletionTask extends AbstractURLExternalTask {

	private static final Pattern EXCLUDED_FILE_PATTERN = Pattern
			.compile("datacapture.cfg|default.site|default.sitemap|sitemap.xml|[^/]*\\.taxonomies|robots.txt");

	private static final String PAGE_EXTENSION = "page";
	private static final String MISMATCHED_RELATIVE_PATH = "InvalidRelativePath";
	private boolean useTranslatedPath = true;

	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {

		Map<String, String> urlMap = new HashMap<String, String>();
		String translatePath = task.getVariable("UseTranslatedPath");
		ArrayList<String> excludeMisMatchLocale = new ArrayList<>();
		if (translatePath != null && !translatePath.isEmpty()) {
			useTranslatedPath = Boolean.valueOf(translatePath);
		}

		// Read the URL Mapping File
		if (useTranslatedPath) {
			String urlMappingFolderPath = task.getVariable("UrlMappingFolderPath");
			if (urlMappingFolderPath == null || urlMappingFolderPath.isEmpty())
				urlMappingFolderPath = URLMappingCommonServices.DEFAULT_URL_MAP_FOLDER_PATH;
			LOGGER.debug("URL Mapping Folder Path " + urlMappingFolderPath);
			String urlMappingFile = URLMappingCommonServices.generateMappingFilePath(task.getFiles(),
					urlMappingFolderPath);
			LOGGER.debug("URL Mapping File Path " + urlMappingFile);
			CSFile csURLMappingFile = task.getArea().getFile(new CSAreaRelativePath(urlMappingFile));
			urlMap = URLMappingCommonServices.generateURLMap(csURLMappingFile);
		}
		// Fetch the list of files to be excluded from deletion
		String excludedFiles = task.getVariable("ExcludedFileList");
		Pattern excludeFilePatterns = EXCLUDED_FILE_PATTERN;
		if (excludedFiles != null && !"".equals(excludedFiles)) {
			excludeFilePatterns = Pattern.compile(excludedFiles.replace(",", "|"));
		}

		// Read all the files to be processed
		List<CSAreaRelativePath> filesToProcess = new ArrayList<>();
		for (CSAreaRelativePath areaRelativePath : task.getFiles()) {
			LOGGER.info("Processing File : " + areaRelativePath);

			CSFile file = task.getArea().getFile(areaRelativePath);
			if (file == null) {
				LOGGER.info("File " + areaRelativePath + " does not exist in workarea");
				continue;
			}
			String workAreaPathName = task.getArea().getVPath().getPathNoServer().toString();
			String countryValue = new String();
			String languageValue = new String();
			String loacleValPandD = "false";
			String countryRelativeValue = new String();
			String languageRelativeValue = new String();
			LOGGER.debug("Workarea path name : "+workAreaPathName);
			final String regex = "(.*)(\\/deere\\/)(.*)(\\/WORKAREA\\/shared)(.*)";
			final String regexRelative = "(.*)(\\/deere\\/)(.*)(\\/website\\/)(.*)";
			final String regexRelativePandD = "(.*)(\\/deere\\/)(.*)(\\/*)";
			// final String string = "/default/main/deere/us/en/WORKAREA/shared";
			String relativePath = areaRelativePath.toString();
			final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
			final Matcher matcher = pattern.matcher(workAreaPathName);
			while (matcher.find()) {
			   if(matcher.group(3).contains("/")){
				   String [] arrayLocale = matcher.group(3).split("/");
				    if(arrayLocale.length > 1) {
				    	countryValue = arrayLocale[0];
				    	languageValue = arrayLocale[1];
					}
			   }
			   else if(matcher.group(3).equalsIgnoreCase("privacy-and-data")) {
				   countryValue = "privacy-and-data";
				   languageValue = "";
			   }
			   else {
				   countryValue = "";
					languageValue = "";
			   }
			   }
			  
			LOGGER.debug("country name of workarea: " + countryValue);
			LOGGER.debug("language name of workarea: " + languageValue);
			
			final Pattern patternRelative = Pattern.compile(regexRelative, Pattern.MULTILINE);
			final Matcher matcherRelative = patternRelative.matcher(relativePath);
			while (matcherRelative.find()) {
				if(matcherRelative.group(3).contains("/")) {
					String [] arrayLocale = matcherRelative.group(3).split("/");
				    if(arrayLocale.length > 1) {
				    	countryRelativeValue = arrayLocale[0];
				    	languageRelativeValue = arrayLocale[1];
					}
				}			    
				else {
					countryRelativeValue = "";
					languageRelativeValue = "";
					}
			    }
			LOGGER.debug("country name of Relative Path: " + countryRelativeValue);
			LOGGER.debug("language name of Relative Path : " + languageRelativeValue);
			
			final Pattern patternRelativePandD = Pattern.compile(regexRelativePandD, Pattern.MULTILINE);
			final Matcher matcherRelativePandD = patternRelativePandD.matcher(relativePath);
			while (matcherRelativePandD.find()) {
				if(matcherRelativePandD.group(3).contains("/")) {
					String [] arrayLocalePandD = matcherRelativePandD.group(3).split("/");
					 if(arrayLocalePandD.length > 1) {
						 
						 if(arrayLocalePandD[0].contains("-")) {
							 loacleValPandD = "true";
							 LOGGER.debug("Inside privacy and data branch and contains proper relative path.");
						 }
					 else {
						 loacleValPandD = "false";
					 }
				}
				}
			}
			LOGGER.debug("locale Value for Privacy and Data branch ="+loacleValPandD);
			
			if(!countryValue.equalsIgnoreCase("privacy-and-data") && (!countryValue.equals(countryRelativeValue) || !languageValue.equals(languageRelativeValue))) {
				excludeMisMatchLocale.add(relativePath);
				//Detach from task
				LOGGER.debug("Country or locale for relative path and workarea are mismatch");
				LOGGER.debug("Mismatched data : "+excludeMisMatchLocale.toString());
			}
			else if(countryValue.equalsIgnoreCase("privacy-and-data") && loacleValPandD.contentEquals("false")) {
				excludeMisMatchLocale.add(relativePath);
				LOGGER.debug("Country or locale for relative path and workarea are mismatch");
				LOGGER.debug("Mismatched data : "+excludeMisMatchLocale.toString());
			}
			else
			{
				if (CSDir.KIND == file.getKind()) {
					LOGGER.debug("Expanding contents of directory: " + areaRelativePath);
					List<CSSimpleFile> simpleFiles = getAllFilesInDirectory(task, (CSDir) file);
	
					// Attach to workflow only if directory is empty
					if (simpleFiles.size() <= 0) {
						filesToProcess.add(areaRelativePath);
						CSAreaRelativePath htmlDir = getDirectoryInHTMLFolder(client, task, areaRelativePath, urlMap);
						if (htmlDir != null)
							filesToProcess.add(htmlDir);
					}
				} else if (CSSimpleFile.KIND == file.getKind()) {
					LOGGER.debug("Adding file to processing list: " + areaRelativePath);
					if (!isFileExcluded(areaRelativePath.getName(), excludeFilePatterns)) {
						filesToProcess.add(areaRelativePath);
						if (areaRelativePath.toString().startsWith("sites")
								&& !areaRelativePath.getExtension().equalsIgnoreCase("page") && urlMap.size() > 0) {
							String filePathWithoutSite = areaRelativePath.toString().replace("sites", "html");
							CSAreaRelativePath translatedFilePath = new CSAreaRelativePath(
									translatePath(filePathWithoutSite, urlMap));
							filesToProcess.add(translatedFilePath);
						}
						if (PAGE_EXTENSION.equalsIgnoreCase(areaRelativePath.getExtension())) {
							filesToProcess.addAll(getAssociatedHTMLAndJson(task, file, urlMap));
						}
					}
				}
			}
		}
		
		task.detachFiles(task.getFiles());
		task.getWorkflow().setVariable(MISMATCHED_RELATIVE_PATH, excludeMisMatchLocale.toString());
		LOGGER.debug("Mismatch variable value = "+ MISMATCHED_RELATIVE_PATH);
		LOGGER.debug("Mismatch task variable value = "+ task.getWorkflow().getVariable(MISMATCHED_RELATIVE_PATH));
		// Attach the files to be deleted by the workflow.
		if (filesToProcess.size() > 0) {
			CSAreaRelativePath[] paths = filesToProcess.toArray(new CSAreaRelativePath[filesToProcess.size()]);
			task.attachFiles(paths);
			LOGGER.debug("Attached JSON and HTML dependencies for .page to workflow: " + Arrays.asList(paths));
		}
		else if(excludeMisMatchLocale.size() > 0 && filesToProcess.size() == 0) {
			LOGGER.debug("No valid Files attached to the workflow, Invalid files to be sent over email.. ");
			CSUser user = task.getOwner();
			String emailAddress = user.getEmailAddress();
			LOGGER.debug("emailAddress: " + emailAddress);
			String userName = user.getDisplayName();
			LOGGER.debug("User Name: " + userName);
			int jobID = task.getWorkflowId();
			TeamsiteLogsComonUtils.notifyInvalidPathDeleteworkflow(excludeMisMatchLocale,jobID,emailAddress,userName);
			LOGGER.debug("Only invalid paths attached to workflow email sent to the job owner.");
			WorkflowServices.chooseNamedTransition(task, "NoFilesAttachedTransition", "No Files Attached",
					"No Files to be Deleted");
		}
		else {
			LOGGER.debug("No Files attached to the workflow");
			WorkflowServices.chooseNamedTransition(task, "NoFilesAttachedTransition", "No Files Attached",
					"No Files to be Deleted");
		}
		
	}

	/**
	 * This function finds the corresponding directory to be deleted in the HTML
	 * folder. If the directory exists in the HTML folder then it is added to
	 * the workflow for deletion.
	 * 
	 * @param client
	 *            The current CSClient instance.
	 * @param task
	 *            The current task.
	 * @param areaRelativePath
	 *            The path of the directory in sites folder.
	 * @return The path to the HTML directory.
	 * @throws CSException
	 */
	private CSAreaRelativePath getDirectoryInHTMLFolder(CSClient client, CSTask task,
			CSAreaRelativePath areaRelativePath, Map<String, String> urlMap) throws CSException {

		LOGGER.debug("Check the Directory in HTML Folder");
		// Attached file is valid.
		String path = areaRelativePath.toString();

		// Find if directory is present under HTML folder
		String htmlDirPath = path.replaceFirst ("sites", "html");
		LOGGER.debug ("HTML Directory Path "+htmlDirPath);
		CSAreaRelativePath translatedFilePath = new CSAreaRelativePath(translatePath(htmlDirPath, urlMap));
		LOGGER.debug ("Translated path : " + translatedFilePath.toString());
		CSFile file = task.getArea ().getFile (translatedFilePath);
		if (file != null && CSDir.KIND == file.getKind ()) {
			return new CSAreaRelativePath (translatedFilePath);
		}		
		return null;
	}
	/**
	 * This function generates the corresponding URLs for the JSON and HTML files of the .page and attaches them
	 * to the tasks if the JSON and HTML Files are present.
	 * @param task The current task.
	 * @param currentFile The .page file to be deleted.
	 * @return The list of .html and .json files associated with the .page
	 * @throws CSException
	 */
	private List<CSAreaRelativePath> getAssociatedHTMLAndJson (CSTask task, CSFile currentFile, Map<String,String> urlMap) throws CSException {
		List<CSAreaRelativePath> filesToAttach = new ArrayList<> ();
		if (currentFile == null) {
			LOGGER.debug ("File is not in the Workarea");
		} else {
			// Attached file is valid. Attach its associated JSON and HTML at this step
			String path = currentFile.getVPath ().getAreaRelativePath ().toString ();

			//Attach JSON File
			String jsonPath = path.replaceFirst ("sites", "html");
			jsonPath = jsonPath.replace (".page", ".json");
			if(urlMap.size ()>0){				
				jsonPath = translatePath (jsonPath, urlMap);
			}
			
		//	CSFile jsonFile = client.getFile (new CSVPath (jsonPath));
			CSFile jsonFile =  task.getArea().getFile(new CSAreaRelativePath (jsonPath));
			if (jsonFile != null) {
				LOGGER.debug ("Json Path " + jsonPath);
				filesToAttach.add (jsonFile.getVPath ().getAreaRelativePath ());
			}

			//Attach HTML File
			String htmlPath = path.replaceFirst ("sites", "html");
			htmlPath = htmlPath.replace (".page", ".html");
			if(urlMap.size ()>0){				
				htmlPath =  translatePath (htmlPath, urlMap);
			}
			CSFile htmlFile = task.getArea().getFile(new CSAreaRelativePath (htmlPath));
			if (htmlFile != null) {
				LOGGER.debug ("HTML File Path " + htmlPath);
				filesToAttach.add (htmlFile.getVPath ().getAreaRelativePath ());
			}
		}

		return filesToAttach;
	}
	/**
	 * This functions checks if the page is excluded from being deleted
	 * by doing pattern matching.
	 * @param link The file path
	 * @param pattern The excluded file pattern 
	 * @return 
	 */
	private boolean isFileExcluded (String link, Pattern pattern) {
		Matcher matcher = pattern.matcher (link);
		if (matcher.find ()) {
			return true;
		}
		return false;
	}

	/**
	 * This method gets all the files in the directory attached to the workflow task.
	 * @param task The current task
	 * @param directory The directory selected by the workflow
	 * @return The list of files in the directory
	 * @throws CSException
	 */
	private List<CSSimpleFile> getAllFilesInDirectory (CSTask task, CSDir directory) throws CSException {
		List<CSSimpleFile> paths = new ArrayList<> ();
		List<CSDir> queue = new ArrayList<> ();
		queue.add (directory);

		while (!queue.isEmpty ()) {
			CSDir curr = queue.remove (0);

			for (CSNode child : curr.getChildren ()) {

				if (CSDir.KIND == child.getKind ()) {
					queue.add ((CSDir) child);
				} else if (CSSimpleFile.KIND == child.getKind ()) {
					paths.add ((CSSimpleFile) child);
				}
			}
		}

		return paths;
	}	
	/**
	 * This function returns the translated page link
	 * @param pageLink Page Link 
	 * @param urlMap Map containing the translated values of the folders 
	 * @return
	 */
	private String translatePath(String pageLink, Map<String,String> urlMap){
		StringBuilder newPath = new StringBuilder();
		if(urlMap.size () > 0 && pageLink != null){
			String [] pathArray = pageLink.split ("/");
				
			for(String path:pathArray){
				String fileExtension = FilenameUtils.getExtension (path);
				if(	!fileExtension.isEmpty ()){
					String key = path.substring (0, path.indexOf (fileExtension)-1);					
					if(urlMap.containsKey (key)){
						newPath.append (urlMap.get (key)+"."+fileExtension);
					}else{
						newPath.append (path);
					}
					
				}else{
					if(urlMap.containsKey (path)){
						newPath.append (urlMap.get (path)+"/");
					}else{
						newPath.append (path+"/");
					}					
				}
			}			
		}
		
		if(newPath.length () > 0){
			LOGGER.debug ("Translated URL "+newPath.toString ());
			return newPath.toString ();   
		}
				
		return pageLink;
			
	}
}
