package com.deere.livesite.workflow.common.urlmapping;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;

import com.deere.livesite.authoring.common.constants.PIMContsants;
import com.deere.livesite.workflow.exception.CustomRuntimeException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSArea;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * This class contains the common functions to read URL Mapping file 
 * 
 * @author Klish Group, INC. [AG]
 *
 */
public class URLMappingCommonServices {
	
	protected static final transient Logger LOGGER = Logger.getLogger(URLMappingCommonServices.class);
	
	private static final String URL_MAPPING_ROOT_ELEMENT = "ListItem";	
	private static final String URL_MAPPING_SOURCE_ELEMENT = "Source";
	private static final String URL_MAPPING_TARGET_ELEMENT = "Target";	
	public static final Pattern LOCALE_PATTERN = Pattern.compile ("([^/]+)/([^/]+)/website");
	public static final String DEFAULT_URL_MAP_FOLDER_PATH = "templatedata/URLMapping/MappingList/data/";
	private static final Pattern[] INDEX_PAGE_LINK_PATTERNS = { Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/products(/.*/)index\\.html"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/industries(/.*/)index\\.html"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website(/.*/)index\\.html") };
	private static final Pattern[] NON_INDEX_PAGE_LINK_PATTERNS = { Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/products(/.*)"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/industries(/.*)"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website(/.*)") };
	public static Properties properties = new Properties();
	private static final Pattern PAGE_LINK_PATTERN = Pattern.compile ("(.*/website(/products/|/industries/|/))(.*)");
	
	List<String> blackListFolderFileName = new ArrayList<String>(Arrays.asList ("index"));
	public static final Pattern blackListLanguagePattern = Pattern.compile ("en");
	public static final Pattern blackListTranslationPageLinkPattern = Pattern.compile (".*/website/json/mapping/.*");
	/**
	 * This task reads the file 
	 * @param simpleFile Simple File for URL Mapping File
	 * @return Document
	 * @throws CSException
	 */
	public static Document loadFile(CSSimpleFile simpleFile) throws CSException {
		LOGGER.debug("Loading File: " + simpleFile.getName ());	
		InputStreamReader fis = null;
		try {
			if (simpleFile != null && simpleFile.isReadable ()) {
				 fis = new InputStreamReader(simpleFile.getInputStream(true));
				Document document = new org.dom4j.io.SAXReader().read(fis);				
				fis.close ();
				return document;
			}
		} catch (Exception e) {
			LOGGER.debug ("Exception while reading the file "+simpleFile.getName ());
			LOGGER.error ("Unable to read File "+simpleFile.getName (), e);
		}
		finally {
			if(fis != null) {
	            try {
					fis.close();
				} catch (IOException e) {
					LOGGER.error ("Caught Exception in closing the InputStreamReader in loadFile for URLMappingCommonService : " ,e);
				}
			}
		}
		return null;
	}
	
	/**
	 * This function reads the XML document in the format:
	 * 
	 * <Options>
	 * 	<Name>abc</Name><Value>def</Value>
	 *  <Name>abc</Name><Value>def</Value>
	 *  <Name>abc</Name><Value>def</Value>
	 * </Options>
	 *  
	 *  and created the map using the values
	 * @param document URL Mapping XML document
	 * @param rootElementName Name of the root element 
	 * @param elementName Name of element to be used as key
	 * @param elementValue Name of the element to be used as Value
	 * @return Map containing Source and Target values
	 */
	public static Map<String,String> generateMap(Document document, String rootElementName, String elementName, String elementValue){
		Map<String,String> urlMapping = new HashMap<String,String>();
		Element root = document.getRootElement();
		@SuppressWarnings("unchecked")
		List<Element> children = root.elements(rootElementName);
		for (Element element : children) {
			// The option display value
			String name = element.elementText(elementName);
			
			if (element.element(elementValue) != null) {
				// The option value
				String value = element.elementText(elementValue);				
				LOGGER.debug("Entry: " + name + " => " + value);
				urlMapping.put(name, value);
			} else {
				LOGGER.debug("Entry: " + name + " => " + name);
				urlMapping.put(name, name);
			}
		}
		
		return urlMapping;		
	}
	
	
	/**
	 * This function is reading the URL Map file and generating the map for the translated URL
	 * @param urlMappingFile
	 * @return
	 */
	public static Map<String,String> generateURLMap(CSFile urlMappingFile){
		Map<String,String> urlMap = new HashMap<String,String>();	
		
		try {
			if(urlMappingFile!=null && CSSimpleFile.KIND == urlMappingFile.getKind()){
				LOGGER.debug("Reading URL Mapping file "+urlMappingFile.getName ());    		
				try {
					CSSimpleFile simpleFile = (CSSimpleFile) urlMappingFile;
					Document doc = loadFile(simpleFile);
					if(doc != null){
						urlMap = generateMap (doc,URL_MAPPING_ROOT_ELEMENT,URL_MAPPING_SOURCE_ELEMENT,URL_MAPPING_TARGET_ELEMENT);
					}
				} catch (CSException e) {
					LOGGER.debug ("Reading URL Mapping Document threw exception ");
				}    
			}
		}  catch (CSException e) {
			LOGGER.debug ("Error Generating URL Map ");
			LOGGER.error("Error generating URL Map ", e);
		}
		return urlMap;
		
	}
	
	
	/**
	 * This function will generate the URL Mapping file path based on the locale of the pages attached to workflow
	 * @param files
	 * @param urlMappingFolderPath
	 * @return
	 */
	public static String generateMappingFilePath (CSAreaRelativePath[] files, String urlMappingFolderPath) {

		for (CSAreaRelativePath filePath : files) {
			Matcher m = LOCALE_PATTERN.matcher (filePath.toString ());
			if (m.find ()) {
				if (!urlMappingFolderPath.endsWith ("/"))
					urlMappingFolderPath = urlMappingFolderPath + "/";
				return urlMappingFolderPath + m.group (2) + "_" + m.group (1) + ".xml";
			}
		}

		return "";
	}

	
	
	public  String translatePath (String pageLink, Map<String, String> urlMap, boolean checkPatterns) {
		StringBuilder newPath = new StringBuilder ();
		if (urlMap.size () > 0 && pageLink != null) {
			String[] pathArray = pageLink.split ("/");

			for (String path : pathArray) {
				String fileExtension = FilenameUtils.getExtension (path);
				if (!fileExtension.isEmpty ()) {
					String key = path.substring (0, path.indexOf (fileExtension) - 1);
					if (urlMap.containsKey (key)) {
						newPath.append (urlMap.get (key) + "." + fileExtension);
					} else {
						if (checkPatterns && fileExtension.equalsIgnoreCase ("html") && !blackListFolderFileName.contains (key)) {
							LOGGER.debug("Translation not found in mapping file for key " +path);
							throw new CustomRuntimeException("Translation not found in mapping file for key "+path);
						} else {
							newPath.append (path);
						}
					}

				} else {
					if (urlMap.containsKey (path)) {
						newPath.append (urlMap.get (path) + "/");
					} else {
						if (checkPatterns && !blackListFolderFileName.contains (path)) {
							LOGGER.debug("Translation not found in mapping file for key "+path);
							throw new CustomRuntimeException("Translation not found in mapping file for key "+path);
						} else {
							newPath.append (path+"/");
						}						
					}
				}
			}
		}

		if (newPath.length () > 0) {
			LOGGER.debug ("Translated URL " + newPath.toString ());
			return newPath.toString ();
		}

		return null;

	}
	
	/**
	 * This function gets the translated path for the page. 
	 * It breaks the page path into two parts
	 * - First Part does not need translation
	 * - Second Part needs translation
	 * It sends the second part of the path for the translation. 
	 * In the translation function if the dictionary does not contain translated 
	 * value for any of the folder or filename then null is returned. The CPW errors out if this happens.
	 * @param filePath File Path to be translated
	 * @param urlMap Map containing the translated values of folders and files
	 * @return
	 */
	public static String getTranslatedFilePath (String filePath, Map<String, String> urlMap) {

		if (filePath != null && !"".equals (filePath)) {

			//Only translate the page path which is not in the ignore Page link pattern 
			if (!blackListTranslationPageLinkPattern.matcher (filePath).find ()) {

				//Path which does not need translation
				String filePathPart1 = "";
				//Path which needs translation
				String filePathPart2 = "";
				Matcher filePathMatcher = PAGE_LINK_PATTERN.matcher (filePath);
				if (filePathMatcher.find ()) {
					filePathPart1 = filePathMatcher.group (1);
					filePathPart2 = filePathMatcher.group (3);
				} else {
					filePathPart2 = filePath;
				}
				LOGGER.debug ("File Path Part 1 " + filePathPart1);
				LOGGER.debug ("File Path Part 2 " + filePathPart2);
				String translatedPath = new URLMappingCommonServices().translatePath (filePathPart2, urlMap, true);
				if (translatedPath == null || "".equals (translatedPath)) {
					return null;
				} else
					return filePathPart1 + translatedPath;
			} else
				return filePath;
		}
		return null;
	}
	
	/**
	 * This method matches the URL patterns against the attached pages
	 * and updates it to match the page URL pattern used in production and preview servers.
	 * @param pageLink The URL of the page
	 * @return Updated URL 
	 */
	public static String updateURL(String pageLink) {
		for (Pattern pattern : INDEX_PAGE_LINK_PATTERNS) {
			Matcher matcher = pattern.matcher(pageLink);
			if (matcher.find()) {
				return matcher.group(1) + matcher.group(2);
			}
		}

		for (Pattern pattern : NON_INDEX_PAGE_LINK_PATTERNS) {
			Matcher matcher = pattern.matcher(pageLink);
			if (matcher.find()) {
				return matcher.group(1) + matcher.group(2);
			}
		}

		if (!(pageLink.startsWith("/"))) {
			pageLink = "/" + pageLink;
		}

		return pageLink;
	}

	public static void readPropertiesFile(CSTask task) throws CSException {
		LOGGER.debug("Reading Properties File");
		CSArea area = task.getArea();
		CSFile file = area.getFile(new CSAreaRelativePath(PIMContsants.DEFAULT_PROPERTIES_FILE_PATH));
		
		if (file != null && file.getKind() == CSSimpleFile.KIND) {
			try (InputStream input = new BufferedInputStream(((CSSimpleFile) file).getInputStream(true))) {
				properties.load(input);
				LOGGER.debug("Successfully loaded properties file");
			} catch (Exception e) {
				LOGGER.debug("Entered in Catch Block as there are some issues with loading properties file!!");
				LOGGER.error("Unable to read properties file ", e);
			}
		} else {
			LOGGER.error("Properties file for area " + area.getVPath().toString() + " does NOT exist");
		}
		
	}
	
	/**
	 * Get the specified property from the loaded properties 
	 * @param name The name of the desired property
	 * @return The property value
	 */
	protected final String getProperty(String name) {
		return properties.getProperty(name);
	}

	
	/**
	 * This function checks if the translation for the site is required.
	 * If the language is a whitelist language  then we do not need the translated URL for that site otherwise we 
	 * need the translated URL.
	 * @param files Files attached to the current workflow task
	 * @return True if the language is not in whitelist i.e. translation is required. 
	 * If the language is in whitelist then translation is not required. 
	 */
	public static boolean isTranslationRequiredForSite (String path) {
		LOGGER.debug ("isTranslationRequiredForSite check path "+path);
		Matcher m = LOCALE_PATTERN.matcher (path);
		if (m.find ()) {			
			Matcher languageMatch = blackListLanguagePattern.matcher (m.group (2));
			if (languageMatch.find ()) {
				LOGGER.debug ("Translation of URL is not required");
				return false;
			}
		}
	
		LOGGER.debug ("Translation of URL is required");
		return true;
	}
	
	
	
}
