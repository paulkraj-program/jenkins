package com.deere.livesite.workflow; 


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.deere.livesite.workflow.translation.TranslationTask;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSIterator;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSFileKindMask;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSSortKey;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import org.apache.log4j.Logger; 
import com.deere.livesite.authoring.common.constants.*;
import com.deere.livesite.workflow.constants.GenericConstants;


public class UrlMappingUtility {

	private static final String BRANCH_PATH = "/default/main/deere/";
	private static final String WORKAREA = "/WORKAREA/shared/";
	private static final String INDUSTRIES="industries";
		
	private static List<String> listOfValidData = null;
	private static List<String> listOfInvalidData = null;
	private static List<String> listOfSourcedData = null;
	private static HashSet<String> listOfValidURLData = null;
	private static HashSet<String> listOfInvalidURLData = null;
	private static HashSet<String> listOfSourcedURLData = null;
	private static HashSet<String>  listofSortData= null;
	private static LinkedHashSet<String>  final_duplicateData= null;
	
	private static final transient Logger LOGGER = Logger.getLogger(UrlMappingUtility.class);
	 String EmailSender=GenericConstants.EMAIL_FROM;
	 String Email_CC=GenericConstants.EMAIL_CC;
	 static String products=PIMContsants.PRODUCTS;
	 static String finance=PIMContsants.FINANCE;
	 
		public static Map<String, List<String>> CreateConnection(String localeName,CSWorkarea sworkArea,String dictionary) throws IOException, ParserConfigurationException, SAXException, CSAuthorizationException, CSObjectNotFoundException, CSExpiredSessionException, CSRemoteException, CSException, ClassNotFoundException {
			CSFile csTaxonomyFile = sworkArea.getFile(new CSAreaRelativePath(dictionary));
			    BufferedWriter writer = null;
				CSSimpleFile csSimpleUrlMappingFile = (CSSimpleFile) csTaxonomyFile;
				InputStream instreamUrlMapping = csSimpleUrlMappingFile.getInputStream(true);
				String[] locale=localeName.split("/");
		
				String dictionaryPath="/opentext/TeamSite/local/bin/custom/urlMappingUtility/input"+locale[0]+"_"+locale[1]+".xml"; 
				File file = new File(dictionaryPath);
				LOGGER.debug("Input xml File path " + dictionaryPath); 

				if (file.createNewFile())
				{
					LOGGER.debug("Input xml created successfully"); 
				} else {
				  
				}
		        BufferedReader inputReader = new BufferedReader(new InputStreamReader(instreamUrlMapping));
		        StringBuilder sb = new StringBuilder();
		        String inline = "";
		        LOGGER.debug("Writing to input xml"); 
		        try {
		        while ((inline = inputReader.readLine()) != null) {
		          sb.append(inline);
		 
		          String fileContent = inline;
		         
		          writer = new BufferedWriter(new FileWriter(dictionaryPath));
		          writer.write(fileContent);
		          writer.close();
		            }
		          }
		          catch (Exception e) {
		              e.getStackTrace();
		            }
		          finally {
		        	  if(writer != null) {
		        		  writer.close();
		        	  }
		          }
		        
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
	        dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(dictionaryPath);
	        doc.getDocumentElement().normalize();
	      
	        NodeList nList = doc.getElementsByTagName("ListItem");
	       
	     
	        String Source = null;
			 String Target = null;
			 
			 List<String> listOfValidData=new ArrayList<String>(); 
			 List<String>  listOfInvalidData=new ArrayList<String>(); 
			 List<String>  listOfSourceData=new ArrayList<String>();
			 
	        for (int temp = 0; temp < nList.getLength(); temp++) 
	        {
	           Node nNode = nList.item(temp);
	         
	           if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	              Element eElement = (Element) nNode;
	              
	             
	              Source=eElement.getElementsByTagName("Source").item(0).getTextContent();
	              Target=eElement.getElementsByTagName("Target").item(0).getTextContent();
	          
	              if(Source.equals(Target))
	              {
	            	  if(Source.equals(INDUSTRIES) || Source.equals(products) || Source.equals(finance))
	            	  {
	            	
	            	  }
	            	  else 
	            	  {   
	            		  listOfSourceData.add(Target);
	            	}
	              }
	              else  if(!Source.equals(Target))
	              {
	            	  if(Source.equals(INDUSTRIES) || Source.equals(products) || Source.equals(finance) )
	            	  {
	            		
	            	  }
	            	  else {
	            		  listOfValidData.add(Target);
	            		  listOfInvalidData.add(Source);
	           	   }
	              }
	              }
	              
	           }
	        
	        Map<String,List<String>> map =new HashMap<String, List<String>>();
	        map.put("validData",listOfValidData);
	        map.put("invalidData",listOfInvalidData);
	        map.put("sourceData",listOfSourceData);
	        LOGGER.debug("Source and target sperated and added to Map"); 
	     return map;
	     }
		
		
		
		public void HtmlFetchFromTeamsite(String localeName,CSClient csclient) {
			listOfValidURLData=new HashSet<String>(); 
			listOfInvalidURLData=new HashSet<String>(); 
			listOfSourcedURLData=new HashSet<String>();
			final_duplicateData=new LinkedHashSet<String>();
			listofSortData=new HashSet<String>();
			try {
				
				if(csclient!=null)
				{
					UrlMappingDataRead umdr=new UrlMappingDataRead();
															
					String area = BRANCH_PATH + localeName + WORKAREA;
					CSWorkarea workArea = csclient.getWorkarea(new CSVPath(area), true);	
					String filePath="html/deere/"+localeName+"/website";
					CSAreaRelativePath relativePath = new CSAreaRelativePath(filePath);	
					CSFile file = workArea.getFile(relativePath);
					
					String dictionaryPath = filePath+"/dictionary.xml";
				
					Map<String,List<String>> map=CreateConnection(localeName,workArea,dictionaryPath);
					listOfValidData = map.get("validData");
					listOfInvalidData = map.get("invalidData");
					listOfSourcedData=map.get("sourceData");
					LOGGER.debug("Fetching of HTML Level begins"); 
					
					
					CSDir baseDir = (CSDir) file;
					
						CSSortKey[] sortArray = new CSSortKey[1];
						sortArray[0] = new CSSortKey(CSSortKey.NAME, true);

						CSIterator csFileIterator = baseDir.getFiles(CSFileKindMask.ALLNONHOLES,sortArray,CSFileKindMask.DIR,null,0,-1,true);  
                        			//IterableIterator<CSSimpleFile> iterable = new IterableIterator<CSSimpleFile>(csFileIterator); 
                        			if (null != csFileIterator) {
                                  			LOGGER.debug("Total Number Of Files :" + csFileIterator.getTotalSize());
                                  			while (csFileIterator.hasNext()) {
                                           		CSFile iterableFile = (CSFile) csFileIterator.next();
                                            			if (iterableFile instanceof CSDir) {
                                                     			CSDir dirs=(CSDir) iterableFile;
                                                     
                                                     			String parent =dirs.getParent().getVPath().toString()+"/";
                                                     			LOGGER.debug("previous parent : "+parent);
                                                     			String level=dirs.getVPath().getName();
                                                     			LOGGER.debug("level : "+level);
                                                     			validateNodeForUrlMappingDataIndividual(level,parent,listOfSourcedData, listOfInvalidData, listOfValidData);
                                           }
                        }
                        }
					  
					 
					for(String x:listOfSourcedURLData)
					  {
						String wordIs=getLastWord(x);
			     		listofSortData.add(wordIs);
			     	  }

				for(String x:listofSortData) {
					for(String x1:listOfSourcedURLData)
					{
					if(x1.contains(x))
					{
						final_duplicateData.add(x1);
					}
				}
			}
				Date date = new Date() ;
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				
				String filePathOfOutput= umdr.CreateXML(listOfValidURLData,listOfInvalidURLData,final_duplicateData,localeName);
				
				EmailTemplateImpl emailTemp=new EmailTemplateImpl();
				emailTemp.getInstance();
				emailTemp.getMailSession();
				
				String receiverString=csclient.getCurrentUser().getEmailAddress();
				String subject="URL MAPPING REPORT - "+localeName+" "+dateFormat.format(date);
				emailTemp.sendEmail(EmailSender,receiverString ,localeName, Email_CC, subject, filePathOfOutput);
					 
				}
				else
				{
					LOGGER.debug("Error no client found");
				}
				csclient.endSession();
				LOGGER.debug("Ending client session");
			} catch (Exception e) {
				LOGGER.error ("Caught exception in HtmlFetchFromTeamsite method  for UrlMappingUtility Task : " + e + e.getMessage ());
			}
		}
		
		private static void validateNodeForUrlMappingDataIndividual(String levelOfNodeAtNthPosition,String parent,List<String> listOfSourcedData, List<String> listOfInvalidData, List<String> listOfValidData){
			 a: for (String x : listOfInvalidData) {
				 if(x.equals(INDUSTRIES) || x.equals(products)  || x.equals(finance) )
		       	  {
					 continue a;
		       	  }else if(levelOfNodeAtNthPosition.equals(x)) {
		       		 listOfInvalidURLData.add(parent+levelOfNodeAtNthPosition);
					}
		       	  
		       	  }
		
			b: for (String x1 : listOfValidData) {
						if(x1.equals(INDUSTRIES) || x1.equals(products)  || x1.equals(finance) )
				       	  {
							 continue b;
				       	  }else if(levelOfNodeAtNthPosition.equals(x1)) {
				       		listOfValidURLData.add(parent+levelOfNodeAtNthPosition);
							}
				}
		      c: for (String y : listOfSourcedData) {
					 if(y.equals(INDUSTRIES) || y.equals(products)  || y.equals(finance) )
			       	  {
						 continue c;
			       	  }else if(levelOfNodeAtNthPosition.equals(y) )
			       		  {
			       		  	listOfSourcedURLData.add(parent+levelOfNodeAtNthPosition);
			       		 
			       		  } 
			       	  
			    	  }  	  
		}
		
		


	public static String getLastWord(String input) {
	    String wordSeparator = "/";
	    boolean inputIsOnlyOneWord = !StringUtils.contains(input, wordSeparator);
	    if (inputIsOnlyOneWord) {
	        return input;
	    }
	    return StringUtils.substringAfterLast(input, wordSeparator);
	}
	

}
