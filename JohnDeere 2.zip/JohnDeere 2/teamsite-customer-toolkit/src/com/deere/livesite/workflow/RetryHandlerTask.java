package com.deere.livesite.workflow;

import java.util.Hashtable;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.cssdk.workflow.CSWorkflow;

/**
 * This class is an implementation of CSURLExternalTask and it is designed to
 * transition a workflow back to the task before an error occurred.  The task
 * requires that before each task that could possibly transition to the error
 * task a preprocess workflow variable be set by the task that is the name of
 * the transition back to that task from the error flow.  The error variable
 * name is configurable on this transition task.
 * @author Klish Group, Inc
 * @since 1.0
 */
public class RetryHandlerTask implements CSURLExternalTask {
	private static final transient Logger LOGGER = Logger.getLogger(RetryHandlerTask.class);

	public void execute(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable parameters) throws CSException {
		try {
			String errorVariable = task.getVariable("ErrorVariableName");
			if (errorVariable == null || "".equals(errorVariable)) {
				errorVariable = "ErrorTaskName";
			}
			CSWorkflow workflow = task.getWorkflow();
			String transitionName = workflow.getVariable(errorVariable);
	
			LOGGER.info("Task # " + task.getId() + " - Attempting to retry task " + transitionName);
	
			task.chooseTransition(transitionName, "Retry - \"" + transitionName + "\"");
		} catch (CSException cse) {
			LOGGER.debug("An error occured during retry transition back to task: " + cse.getLocalizedMessage(), cse);
		}
	}

}
