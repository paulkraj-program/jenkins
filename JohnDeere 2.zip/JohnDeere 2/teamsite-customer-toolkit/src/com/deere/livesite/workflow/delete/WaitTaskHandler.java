package com.deere.livesite.workflow.delete;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.deere.livesite.workflow.utils.CommonUtil;
import com.deere.teamsite.common.constants.TaskVariableConstants;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

public class WaitTaskHandler implements CSURLExternalTask {

	private static final transient Logger LOGGER = Logger.getLogger(WaitTaskHandler.class);

	public void execute(CSClient client, CSExternalTask task, Hashtable params) throws CSException {
		LOGGER.info("WaitTask handler starting");

		// get the publish time and check if the user wants to publish the file now or later
		String publishTime = task.getVariable(TaskVariableConstants.PUBLISH_TIME);
		LOGGER.info("Publish value is :" + publishTime);

		// get the delete time and check if the user wants to delete the file now or later
		String deleteTime = task.getVariable(TaskVariableConstants.DELETE_TIME);
		LOGGER.info("Delete value is :" + deleteTime);

		// get the deploy date that User has set
		String deploydate = task.getVariable(TaskVariableConstants.DEPLOY_DATE);
		LOGGER.info("User time is :" + deploydate);

		// get the time zone of user
		String timeZone = task.getVariable(TaskVariableConstants.TIME_ZONE);
		LOGGER.info("Time zone is :" + timeZone);

		String nextTask = task.getVariable(TaskVariableConstants.NEXT_TRANSITION);
		LOGGER.info("Next transition is :" + nextTask);

		if (publishTime != null && !StringUtils.isEmpty(publishTime) && publishTime.equalsIgnoreCase("publishNow")) {

			LOGGER.info("Exiting WaitTask task for Publish Now workflow id :" + task.getWorkflowId());

			task.setDescription("Publishing now");
			task.chooseTransition(nextTask, "Publish Now");

			LOGGER.info("Coming out WaitTask task for Publish Now workflow id : " + task.getWorkflowId());

		} else if (deleteTime != null && !StringUtils.isEmpty(deleteTime) && deleteTime.equalsIgnoreCase("deleteNow")) {

			LOGGER.info("Exiting WaitTask task for Publish Now workflow id :" + task.getWorkflowId());

			task.setDescription("Deleting now");
			task.chooseTransition(nextTask, "Delete Now");

			LOGGER.info("Coming out WaitTask task for Delete Now workflow id : " + task.getWorkflowId());

		} else {

			task.setDescription(task.getDescription() + " at " + deploydate + " " + timeZone);

			Date beforeConvertDate = null;

			long timeDifference = 0;

			Date date = CommonUtil.convertStringToDate(deploydate, TaskVariableConstants.DATE_FORMAT);

			LOGGER.info("User Input Date:" + date);

			SimpleDateFormat isoFormat = new SimpleDateFormat(TaskVariableConstants.DATE_FORMAT);

			isoFormat.setTimeZone(TimeZone.getTimeZone(timeZone));

			try {
				beforeConvertDate = isoFormat.parse(deploydate);
				// take user time and time zone
				LOGGER.info("User Input Date with Timezone : " + CommonUtil.formatDateToString(beforeConvertDate,
						TaskVariableConstants.DATE_FORMAT, timeZone));

				// convert user time and time zone into EDT time zone
				String sDateInAmerica = CommonUtil.formatDateToString(beforeConvertDate,
						TaskVariableConstants.DATE_FORMAT, TaskVariableConstants.EDT);

				LOGGER.info("Converted Time with Timezone(default EDT) : " + sDateInAmerica);

				Date workFlowTimerAsDate = CommonUtil.convertStringToDate(sDateInAmerica,
						TaskVariableConstants.DATE_FORMAT);

				// get the server time
				String serverTime = CommonUtil.getServerTime(TaskVariableConstants.DATE_FORMAT);

				LOGGER.info("Server time is :" + serverTime);

				Date serverTimeAsDate = CommonUtil.convertStringToDate(serverTime, TaskVariableConstants.DATE_FORMAT);

				timeDifference = workFlowTimerAsDate.getTime() - serverTimeAsDate.getTime();

				LOGGER.info("diff is " + timeDifference + " milliseconds");

			} catch (Exception e) {

				LOGGER.error("Error in  WaitTaskHandler.execute" + e);

			}

			if (timeDifference > 0) {

				LOGGER.info("Workflow will be intiated in....." + timeDifference + " milliseconds");

				// wait till this difference.
				Thread waitWorkflowThread = Thread.currentThread();

				try {

					waitWorkflowThread.sleep(timeDifference);

				} catch (Exception ex) {

					LOGGER.error("Error in thread sleep " + ex.getMessage());

				}
				LOGGER.info("Waited " + timeDifference + " milliseconds for workflow id : " + task.getWorkflowId());
			}

			LOGGER.info("Exiting WaitTask task for workflow id :" + task.getWorkflowId());

			task.chooseTransition(nextTask, "Wait time completed successfully, moving to next task");

		}
	}

}
