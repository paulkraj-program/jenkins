package com.deere.livesite.workflow.constants;

public class WorkflowConstants {

	public static final String DCR_FILENAME = "DCRFileName";
	public static final String DCRFILELIST = "DCRFileList"; 
	public static final String DCRFILELISTPATH="DcrFileListPath";
	public static final String TASK_VARIABLE_SELECTED_PDF_LIST="SelectedPdfList";
	public static final String TASK_VARIABLE_ASSET_WA="AssetWorkareaPath";
	public static final String PDF_EXT="ValidPDFExtensions";
	public static final String ASSETS_EXT="AssetsExtensions";
	
	
}
