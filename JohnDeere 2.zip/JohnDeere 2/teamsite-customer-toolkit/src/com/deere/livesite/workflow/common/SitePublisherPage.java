package com.deere.livesite.workflow.common;

import com.deere.livesite.workflow.constants.MaintenanceReminderConstants;
import com.deere.livesite.workflow.CommonServices;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.livesite.business.BusinessPage;
import com.interwoven.livesite.common.business.BusinessException;
import com.interwoven.livesite.iw.servlet.LiveSiteContext;
import com.interwoven.livesite.model.Resource;
import com.interwoven.livesite.model.Site;
import com.interwoven.livesite.model.page.ComponentData;
import com.interwoven.livesite.model.page.Page;
import com.interwoven.livesite.model.page.PageComponent;
import com.interwoven.livesite.model.page.PageProperties;
import com.interwoven.livesite.model.rendering.PageLayoutConfigInfo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

/**
 * Class to generate Site Publisher pages and update the component
 * with the reference to product DCR.
*/
public class SitePublisherPage {
	static final transient Logger LOGGER = Logger.getLogger(SitePublisherPage.class);
	
	private CSClient client = null;
	private LiveSiteContext lsContext = null;
	private List<String> pageTemplateList = new ArrayList<String>();
	private String targetPagePath = "";
	private Site lssite = null;
	private PageLayoutConfigInfo pageLayoutInfo = new PageLayoutConfigInfo(false);

	
	public SitePublisherPage(CSClient client, String targetPagePath, String pageTypeId, String pageLayoutId, String canvasPath, List<String> pageTemplateList) {
		this.client = client;
		this.targetPagePath = targetPagePath;
		this.pageTemplateList = pageTemplateList;
		pageLayoutInfo = new PageLayoutConfigInfo(pageTypeId, pageLayoutId, canvasPath, DocumentHelper.createElement("EmbeddedLayout"));
		if (client != null) {
			lsContext = LiveSiteContext.getInstance(client);
		}
		lssite = lsContext.getBusinessSite().getSite(targetPagePath);
	}

	/**
	 * Generates the Site Publisher Page 
	 * @param pageTitle
	 * @param overwrite
	 * @throws CSException
	 * @return Generated Page object 
	 */
	public Page generate(String pageTitle, boolean overwrite) throws CSException {
		
		Page createdPage = null;
		
		BusinessPage businessPage = lsContext.getBusinessPage();
		
		if (lssite != null) {
			String[] templates = getTemplates(pageTemplateList);

			CommonServices.createParentDirectories(client, client
					.getWorkarea(new CSVPath(targetPagePath).getArea(),true), new CSVPath(targetPagePath).getAreaRelativePath().getParentPath());

			LOGGER.debug("Target Path  " + targetPagePath);
			LOGGER.debug("Page Name : " + new CSVPath(targetPagePath).getName());
			LOGGER.debug("pageLayoutInfo : " + pageLayoutInfo.toString());
			LOGGER.debug("Site Path : " + lssite.getPath());

			String pageName = CommonServices.executeRegex(targetPagePath, ".*/sites/.+?(/.+).page");
			try {

				//TODO - Uncommenmt this when running on 16.x instance
				createdPage = businessPage.insertPage(pageName,pageLayoutInfo, lssite.getPath(), lssite, false, false, templates, false, true);
				
				//TODO - (Works on 8.x) Comment this when running on 16.x instance
				//createdPage = businessPage.insertPage(pageName,pageLayoutInfo, lssite.getPath(), lssite, false, false, false, templates, false, true);
				
				
				if (createdPage != null) {
					LOGGER.debug("Generated Page : " + createdPage.getVPath());
					PageProperties pageProps = new PageProperties();
					pageProps.setTitle(pageTitle);
					pageProps.setPageLayoutConfigInfo(pageLayoutInfo);
					
					/*Resource jsResource = new Resource();
					jsResource.setPath(MaintenanceReminderConstants.PAGE_RESOURCE_PATH_TYPEAHEAD);
					jsResource.setIsEnabled(true);
					jsResource.setType(1);
					
					Resource cssResource = new Resource();
					cssResource.setPath(MaintenanceReminderConstants.PAGE_RESOURCE_PATH_CSS);
					cssResource.setIsEnabled(true);
					cssResource.setType(0);
					
					List<Resource> resources = new ArrayList<Resource>();
					resources.add(jsResource);
					resources.add(cssResource);
					
					pageProps.setResources(resources);*/
					createdPage.setProperties(pageProps);
					
					CSFile tFile = client.getFile(new CSVPath(createdPage.getVPath()));
					
					if(tFile!= null && tFile.getKind() == CSSimpleFile.KIND){
						businessPage.savePage((CSSimpleFile) tFile, createdPage, pageLayoutInfo, lssite, false);	
					}
					
					
				}
			} catch (BusinessException buex) {
				LOGGER.error("Error generating Sitepublisher page." + targetPagePath);
			}
		} else {
			LOGGER.error("Unable to get Site object to generate Sitepublisher page.");
		}
		return createdPage;
	}

	/**
	 * Updates the component with the new DCR path 
	 * @param createdPage
	 * @param areaId
	 * @param dcr
	 * @param componentName
	 * @param datumId
	 * @throws CSException
	 */
	public void updateComponentDcr(Page createdPage, String areaId, String dcr,
			String componentName, String datumId) throws CSException {
		
		Collection<PageComponent> pageComponents = createdPage.getComponentsInFixedArea(areaId);
		
		if ((dcr != null) && (!dcr.isEmpty())) {
			CSVPath dcrPath = new CSVPath(dcr);
			
			if(dcrPath!=null){
				for (PageComponent pageComponent : pageComponents) {
					if (pageComponent.getName().equalsIgnoreCase(componentName)) {
						String filePath = dcrPath.getAreaRelativePath().toString();
						ComponentData compData = pageComponent.getData();

						Element elem = compData.findDatumElementById(datumId);
						((Element) elem.selectSingleNode("DCR")).setText(filePath);
						elem.addAttribute("Changed", "true");
						pageComponent.setData(compData);
					}
				}
			}
			
			BusinessPage businessPage = lsContext.getBusinessPage();
			CSFile tFile = client.getFile(new CSVPath(createdPage.getVPath()));
			
			if(tFile != null && tFile instanceof CSSimpleFile){
				businessPage.savePage((CSSimpleFile) tFile, createdPage, pageLayoutInfo, lssite, false);
				CommonServices.createChildAssociation((CSSimpleFile) tFile, client.getFile(new CSVPath(dcr)), "Sitepub.Deployable");
			}
		}
	}

	/**
	 * Gets the templates that needs to be added to the page
	 * @param templates
	 * @return array of templates
	 */
	private String[] getTemplates(List<String> templates) {
		String[] templatePaths = new String[templates.size()];
		int i = 0;
		for (String template : templates) {
			if (template.startsWith("/")) {
				template = template.substring(1, template.length());
			}
			templatePaths[i] = (MaintenanceReminderConstants.TEMPLATE_PATH_PREFIX + template);
		}
		return templatePaths;
	}
}
