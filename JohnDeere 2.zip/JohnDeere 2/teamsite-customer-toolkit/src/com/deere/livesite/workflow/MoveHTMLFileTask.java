package com.deere.livesite.workflow;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FilenameUtils;
import com.deere.livesite.workflow.common.urlmapping.URLMappingCommonServices;
import com.deere.livesite.workflow.syndication.SyndicationUtilities;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSPathCommentPair;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSExternalTask;

/**
 * This class is used in Content Publish workflow to move all the files except the page and DCRs to the translated path
 * using the URL Mapping file.
 * 
 * JIRA -319
 * - Updated the path of the URL Mapping file(Dictionary) to be in the workarea specific to site.
 * - Updated task to fail if the URL Mapping File (Dictionary) is not present for the sites with 
 * 		languages other than ones listed in Whitelist Language Pattern specifically languages other than english
 * 		Also, it ignores translation of the certain folder patterns
 * 
 * - Updated to remove the step to move the html files from html folder to translated path since
 *   the Page Generation Task has been updated to generate the html pages directly in translated path for non-english sites.
 * 
 * @author Klish Group, INC. [AG]
 *
 */
public class MoveHTMLFileTask extends AbstractURLExternalTask {

	private static Pattern PAGE_LINK_PATTERN = Pattern.compile ("(.*/website(/products/|/industries/|/))(.*)");
	
	//Default Values set here for the task variables
	//All the patterns below can be set via the task variables in the CPW workflow.
	//The task variables in CPW workflow will need to have comma separated list of patterns 
	//Pattern for the page link path which do not need translation
	Pattern blackListTranslationPageLinkPattern = Pattern.compile (".*/website/json/mapping/.*");
	//Pattern for the language which do not need translation
	Pattern blackListLanguagePattern = Pattern.compile ("en");
	//Pattern for the branch names which do not need the translation
	Pattern blackListBranchNamesPattern = Pattern.compile ("Assets");
	//Pattern for file names or folder names that do not need translation. 
	//Based on this pattern CPW will not break if the names mentioned below are not in the Dictionary file. 
	Pattern blackListFolderFileNamePattern = Pattern.compile ("index");
	//Default path of the URL Mapping file
	String urlMappingFolderPath = URLMappingCommonServices.DEFAULT_URL_MAP_FOLDER_PATH;
	
	Pattern listJsonFileForPathUpdate = Pattern.compile ("subcategories.json|products.json|offers.json");
	String country = "us";
	String language = "en";
	
	String errorFolderOrFileName = "";
	boolean moveJsonInTranslatedPath = false;

	@Override
	protected void execute (CSClient client, CSExternalTask task) throws CSException {

		Map<String, String> urlMap = new HashMap<String, String> ();		
		
		//Fetch all the task variables from the workflow
		fetchTaskVariables(task);
		//If the branch name is in whitelist do not translate URL for that site		
		String branchName = task.getArea ().getBranch ().getName ();
		if(branchName != null && !"".equals (branchName) && blackListBranchNamesPattern.matcher (branchName).find ()){
			LOGGER.debug("Branch Name is in black list. Hence, URL translation will not be done.");
		
			chooseSuccessTransition (task);			
		}else{
    		    
    		CSAreaRelativePath[] files = task.getFiles ();
    
    		// Create the urlMap for the translation of URL
    		String urlMappingFile = URLMappingCommonServices.generateMappingFilePath (files, urlMappingFolderPath);
    		LOGGER.debug ("URL Mapping File Path " + urlMappingFile);
    		CSFile csURLMappingFile = task.getArea ().getFile (new CSAreaRelativePath (urlMappingFile));
    		urlMap = URLMappingCommonServices.generateURLMap (csURLMappingFile);
    		boolean isTranslationRequiredVar = isTranslationRequiredForSite(files);
    		//If dictionary file is present translate the URL
    		if (urlMap.size () > 0) {
    			try {
    				ArrayList<CSAreaRelativePath> detachFileList = new ArrayList<CSAreaRelativePath> ();
    				ArrayList<CSAreaRelativePath> attachFileList = new ArrayList<CSAreaRelativePath> ();
    				CSAreaRelativePath[] detachPages = null;
    				CSAreaRelativePath[] attachPages = null;
    
    				List<CSPathCommentPair> pathCommentPairList = new ArrayList<CSPathCommentPair>();
    				CSWorkarea workarea = client.getWorkarea (task.getArea ().getVPath (), false);
    				for (CSAreaRelativePath file : files) {
    					if (file != null) {
    						LOGGER.debug ("Current File Path " + file.toString ());
    						CSFile csFile = task.getArea ().getFile (file);
    
    						if (file.getExtension () != null && csFile != null && csFile.isValid () && CSHole.KIND != csFile.getKind ()) {
    							//translate URL only if the files being deployed are under sites folder or has extension html
    							if ((file.toString ().startsWith ("sites") && !FilenameUtils.getExtension (file.toString ()).equalsIgnoreCase ("page"))  || (moveJsonInTranslatedPath && file.getExtension ().equalsIgnoreCase ("json"))) {
    								String translatedPath = getTranslatedFilePath (file.toString (), urlMap);
    								if (translatedPath == null || "".equals (translatedPath)) {
    									LOGGER.debug ("Translated Path was not generated successfully. Folder or filename missing in dictionary");
    									chooseFailureTransition (task, new CSException (0, "Translated Path was not generated successfully. Folder or filename: " + errorFolderOrFileName +" missing in dictionary "));
    									break;
    								}    
    								if (translatedPath.startsWith ("sites") && !FilenameUtils.getExtension (translatedPath).equalsIgnoreCase ("page")) {    									
    									//Copy the files to the translated path if its not the .page file and is present in sites folder
    									CSAreaRelativePath translatedFilePath = new CSAreaRelativePath (translatedPath.replace ("sites", "html"));
    									LOGGER.debug ("Translated File Path " + translatedFilePath.toString ());
    									SyndicationUtilities.createParentDirectories (client, workarea, translatedFilePath.getParentPath ());
    									if(listJsonFileForPathUpdate.matcher (FilenameUtils.getName (translatedFilePath.toString ())).find ()){
    										LOGGER.debug("This Json file needs path updates ");    										
    										String translatedJsonContent = updateJsonPath(csFile, urlMap);    										
    										if(translatedJsonContent != null && !translatedJsonContent.isEmpty ()){
    											LOGGER.debug("Translated JSON Content ");
    											csFile.copy (translatedFilePath, true);	
    											CSFile translatedJsonFile = workarea.getFile (translatedFilePath);
    											if(translatedJsonFile != null && translatedJsonFile.getKind () != CSHole.KIND && translatedJsonFile.isReadable ()){
    												CSSimpleFile translatedJsonSimpleFile = (CSSimpleFile)translatedJsonFile;
    												translatedJsonSimpleFile.write (translatedJsonContent.getBytes(Charset.forName("UTF-8")), 0,translatedJsonContent.getBytes(Charset.forName("UTF-8")).length , true);
    											}
    										}else{
    											LOGGER.debug("Translated JSON Content was blank or null");
    											csFile.copy (translatedFilePath, true);	    											
    										}     										
    									}else    										 									
    										csFile.copy (translatedFilePath, true);
    									attachFileList.add (translatedFilePath);
    									pathCommentPairList.add(new CSPathCommentPair(file, "Submitted through CPW ID "+task.getId ()));
    									detachFileList.add (file);
    									LOGGER.debug ("File copied " + translatedFilePath);
    								} else if (translatedPath.startsWith ("html") && FilenameUtils.getExtension (translatedPath).equalsIgnoreCase ("json") ) {
    									//Move the generated HTML to the translated path
    									CSAreaRelativePath translatedFilePath = new CSAreaRelativePath (translatedPath);
    									LOGGER.debug ("Translated File Path " + translatedFilePath.toString ());
    									if (!file.toString ().equals (translatedFilePath.toString ())) {
    										SyndicationUtilities.createParentDirectories (client, workarea, translatedFilePath.getParentPath ());
    										csFile.move (translatedFilePath, true);
    										attachFileList.add (translatedFilePath);
    										detachFileList.add (file);
    										pathCommentPairList.add(new CSPathCommentPair(file, "Submitted through CPW ID "+task.getId ()));
    										LOGGER.debug ("File Moved " + translatedFilePath);
    									}
    								}
    							}
    						}
    					}
    				}
    				//Submit the files that are being detached
    				if(pathCommentPairList!=null && pathCommentPairList.size()>0){
    					workarea.submitDirect("Submitted through CPW ID "+task.getId (), null, pathCommentPairList.toArray(new CSPathCommentPair[pathCommentPairList.size()]), 0);
					}
    				//Detach the files moved and copied to translated path
    				if (detachFileList.size () > 0) {
    					detachPages = new CSAreaRelativePath[detachFileList.size ()];
    					detachPages = detachFileList.toArray (detachPages);
    					LOGGER.debug ("Detached File List " + Arrays.toString(detachPages));
    					task.detachFiles (detachPages);
    				}
    				//Attach the files moved and copied to new translated path
    				if (attachFileList.size () > 0) {
    					attachPages = new CSAreaRelativePath[attachFileList.size ()];
    					attachPages = attachFileList.toArray (attachPages);
    					LOGGER.debug ("Attached File List " + Arrays.toString(attachPages));
    					task.attachFiles (attachPages);
    				}
    			} catch (CSException e) {
    				LOGGER.debug ("Error While Detaching Pages. ", e);
    				chooseFailureTransition (task, new CSException (0, "Failed while moveing HTML File"+e.getMessage ()));
    			}
    
    		} else if (isTranslationRequiredVar) {
    			//Since the Dictionary file is not present, check if this language requires translation, if yes break the CPW and if not let it run
    			LOGGER.debug ("Move HTML File Task failure since Dictionary file is not present and site requires translation");
    			chooseFailureTransition (task, new CSException (0, "Move HTML File Task failure since Dictionary file is not present and site requires translation"));
    		}
		}

	}

	/**
	 * This function checks if the translation for the site is required.
	 * If the language is a whitelist language  then we do not need the translated URL for that site otherwise we 
	 * need the translated URL.
	 * @param files Files attached to the current workflow task
	 * @return True if the language is not in whitelist i.e. translation is required. 
	 * If the language is in whitelist then translation is not required. 
	 */
	private boolean isTranslationRequiredForSite (CSAreaRelativePath[] files) {

		for (CSAreaRelativePath filePath : files) {
			Matcher m = URLMappingCommonServices.LOCALE_PATTERN.matcher (filePath.toString ());
			if (m.find ()) {
				country = m.group(1);
				language = m.group(2);				
				Matcher languageMatch = blackListLanguagePattern.matcher (m.group (2));
				if (languageMatch.find ()) {
					LOGGER.debug ("Translation of URL is not required");
					return false;
				}
			}
		}
		LOGGER.debug ("Translation of URL is required");
		return true;
	}

	/**
	 * This function gets the translated path for the page. 
	 * It breaks the page path into two parts
	 * - First Part does not need translation
	 * - Second Part needs translation
	 * It sends the second part of the path for the translation. 
	 * In the translation function if the dictionary does not contain translated 
	 * value for any of the folder or filename then null is returned. The CPW errors out if this happens.
	 * @param filePath File Path to be translated
	 * @param urlMap Map containing the translated values of folders and files
	 * @return
	 */
	private String getTranslatedFilePath (String filePath, Map<String, String> urlMap) {

		if (filePath != null && !"".equals (filePath)) {

			//Only translate the page path which is not in the ignore Page link pattern 
			if (!blackListTranslationPageLinkPattern.matcher (filePath).find ()) {

				//Path which does not need translation
				String filePathPart1 = "";
				//Path which needs translation
				String filePathPart2 = "";
				Matcher filePathMatcher = PAGE_LINK_PATTERN.matcher (filePath);
				if (filePathMatcher.find ()) {
					filePathPart1 = filePathMatcher.group (1);
					filePathPart2 = filePathMatcher.group (3);
				} else {
					filePathPart2 = filePath;
				}
				LOGGER.debug ("File Path Part 1 " + filePathPart1);
				LOGGER.debug ("File Path Part 2 " + filePathPart2);
				String translatedPath = translatePath (filePathPart2, urlMap);
				if (translatedPath == null || "".equals (translatedPath)) {
					return null;
				} else
					return filePathPart1 + translatedPath;
			} else
				return filePath;
		}
		return null;
	}

	/**
	 * This function returns the translated page link 
	 * It ignores the translation of the file names or folder names listed in white list
	 * if they are not listed in the Dictionary file (URL Mapping File)
	 * @param pageLink Page Link 
	 * @param urlMap Map containing the translated values of the folders 
	 * @return
	 */
	private String translatePath (String pageLink, Map<String, String> urlMap) {
		StringBuilder newPath = new StringBuilder ();
		if (urlMap.size () > 0 && pageLink != null) {
			String[] pathArray = pageLink.split ("/");

			for (String path : pathArray) {
				String fileExtension = FilenameUtils.getExtension (path);
				if (!fileExtension.isEmpty ()) {
					String key = path.substring (0, path.indexOf (fileExtension) - 1);
					if (urlMap.containsKey (key)) {
						newPath.append (urlMap.get (key) + "." + fileExtension);
					} else {
						if (fileExtension.equalsIgnoreCase ("html") && !blackListFolderFileNamePattern.matcher (path).find ()) {
							LOGGER.debug ("Filename: " + path + " is not present in the Dictionary to translate");
							errorFolderOrFileName = path;
							return null;
						} else {
							newPath.append (path);
						}
					}

				} else {
					if (urlMap.containsKey (path)) {
						newPath.append (urlMap.get (path) + "/");
					} else {
						if (!blackListFolderFileNamePattern.matcher (path).find ()) {
							LOGGER.debug ("Folder name: " + path + " is not present in the Dictionary to translate");
							errorFolderOrFileName = path;
							return null;
						} else {
							newPath.append (path+"/");
						}						
					}
				}
			}
		}

		if (newPath.length () > 0) {
			LOGGER.debug ("Translated URL " + newPath.toString ());
			return newPath.toString ();
		}

		return null;

	}
	
	/**
	 * This function fetches the task variable values set in the workflow 
	 * @param task Current Workflow Task
	 * @throws CSException
	 */
	private void fetchTaskVariables(CSExternalTask task) throws CSException{
		
		// Languages which do not require the translation
		String blackListLanguages = task.getVariable ("BlackListLanguages");
		if (blackListLanguages != null && !"".equals (blackListLanguages)) {
			blackListLanguagePattern = Pattern.compile (blackListLanguages.replace (",", "|"));
		}

		//Page Link patterns that do not require the translation
		String ignorePageLinks = task.getVariable ("BlackListPageLinks");
		if (ignorePageLinks != null && !"".equals (ignorePageLinks)) {
			blackListTranslationPageLinkPattern = Pattern.compile (ignorePageLinks.replace (",", "|"));
		}
		
		//Branches that do not require the translation
		String ignoreBranchNames = task.getVariable ("BlackListBranchNames");
		if (ignoreBranchNames != null && !"".equals (ignoreBranchNames)) {
			blackListBranchNamesPattern = Pattern.compile (ignoreBranchNames.replace (",", "|"));
		}
		
		//Branches that do not require the translation
		String ignoreFileFolderNames = task.getVariable ("BlackListFileFolderNames");
		if (ignoreFileFolderNames != null && !"".equals (ignoreFileFolderNames)) {
			blackListFolderFileNamePattern = Pattern.compile (ignoreFileFolderNames.replace (",", "|"));
		}
		
		//Folder path for the URL Mapping File
		String urlMappingFolder = task.getVariable ("UrlMappingFolderPath");
		if (urlMappingFolder != null && !urlMappingFolder.isEmpty ())
			urlMappingFolderPath = urlMappingFolder;		
		
		//List JSON files which needs path update 
		String listJsonFiles = task.getVariable ("ListJsonFileForPathUpdate");
		if (listJsonFiles != null && !listJsonFiles.isEmpty ())
			listJsonFileForPathUpdate =  Pattern.compile (listJsonFiles.replace (",", "|"));
		
		//Flag to check if we need to move the json from english HTML folders to traslated HTML folders
		String moveJson= task.getVariable ("MoveJsonInTranslatedPath");
		if (moveJson != null && !moveJson.isEmpty ())
			moveJsonInTranslatedPath = Boolean.valueOf (moveJson);		
				
		
		
	}
	
	/** 
	 * This function updates the path in offers.json, products.json and subcategories.json to the translated path
	 * @param file
	 * @param urlMap
	 * @return Translated file content
	 */
	private String updateJsonPath(CSFile file,Map<String, String> urlMap){
		
		BufferedReader br = null;
		try {
			br = new BufferedReader (new InputStreamReader (((CSSimpleFile) file).getInputStream (true)));
			StringBuilder content = new StringBuilder();
			String line;
			while ((line = br.readLine ()) != null) {
				content.append (line);
			}
				
			String unTranslatedContent = content.toString ();
			LOGGER.debug ("Json Content before translation "+unTranslatedContent);
			for (String key : urlMap.keySet()) {
				if(unTranslatedContent.contains ("/"+key+"/")){
					unTranslatedContent=unTranslatedContent.replaceAll ("/"+key+"/","/"+urlMap.get (key)+"/" );
				}
				if(unTranslatedContent.contains ("/"+key+"'")){
					unTranslatedContent=unTranslatedContent.replaceAll ("/"+key+"'","/"+urlMap.get (key)+"'" );
				}
			}
			unTranslatedContent = unTranslatedContent.replaceAll ("[^/]+/[^/]+/website", country+"/"+language+"/website");
			return unTranslatedContent;			     
			 
		}catch (CSException csex) {
			LOGGER.error ("Failed retrieving file references: ", csex);
		} catch (IOException ioex) {
			LOGGER.error ("Failed retrieving file references: ", ioex);
		} finally {
			if (br != null) {
				try {
					br.close ();
				} catch (Exception ex) {
					LOGGER.error ("Failed closing reader ", ex);
				}
			}
		}
		return "";
	}
}
