package com.deere.livesite.workflow.utils;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.dom4j.Document;
import org.dom4j.Element;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Response;
import org.jsoup.select.Elements;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.interwoven.livesite.dom4j.Dom4jUtils;

public class TeamSiteCommonUtils {
	private static final transient Logger LOGGER = Logger.getLogger(TeamSiteCommonUtils.class);
	public static String getSiteMap(ReportSetings settings) {

		String srcLocale = new String();
		String sitemap = new String();
		String regex ="(.)*(/main/deere/)(.*)(/WORKAREA/shared)";
		Pattern patternToFind = Pattern.compile(regex);
		String workareaPath = settings.getWorkareaPath();
	    Matcher match = patternToFind.matcher(workareaPath);
	    Boolean isMatched = match.matches();
	    if(isMatched) {
			 srcLocale = StringUtils.substringBetween(workareaPath, "/deere/", "/WORKAREA/shared");
			 sitemap=workareaPath+"/html/deere/"+srcLocale+"/website/sitemap.xml";
			 LOGGER.debug("Sitemap is >>>"+sitemap);
			 if (!Files.isReadable(Paths.get(sitemap))) {
				 sitemap="";
			 }
        }
       return sitemap;
    }
	public static String getSiteDictionary(ReportSetings settings) {
		// TODO Auto-generated method stub
		// "/default/main/deere/at/de/WORKAREA/shared/html/deere/at/de/website/sitemap.xml";
		///default/main/deere/de/de/WORKAREA/shared;
		String srcLocale = new String();
		String dictionary = new String();
		String regex ="(.)*(/main/deere/)(.*)(/WORKAREA/shared)";
		Pattern patternToFind = Pattern.compile(regex);
		String workareaPath = settings.getWorkareaPath();
	    Matcher match = patternToFind.matcher(workareaPath);
	    Boolean isMatched = match.matches();
	    if(isMatched) {
			 srcLocale = StringUtils.substringBetween(workareaPath, "/deere/", "/WORKAREA/shared");
			 dictionary=workareaPath+"/html/deere/"+srcLocale+"/website/dictionary.xml";
			 LOGGER.debug("dictionary is >>>"+dictionary);
			 if (!Files.isReadable(Paths.get(dictionary))) {
				 dictionary="";
			 }
        }
       return dictionary;
    }
    public static List<String> getSiteMapUrls(ReportSetings settings) {
		// TODO Auto-generated method stub
		List<String> Urls;
		Urls = new ArrayList<String>();
		File file = new File(settings.getSitemapFile());
		try {
			
			InputStream is = new FileInputStream(file);
			Document doc = Dom4jUtils.newDocument(is);
			if (null != doc) {
				Element root = doc.getRootElement();
				Iterator<Element> elements = root.elementIterator("url");
				
				while (elements.hasNext()) {
					Element urlEle = elements.next();
					Element loc = urlEle.element("loc");
					//System.out.println("Urls added is >>"+loc.getText());
					Urls.add(loc.getText());
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error occured in getSiteMapUrls for TeamSiteCommonUtils",e);
		}
		
		return Urls;
	}
	public static List<SitemapPages> getSiteMapUrls(ReportSetings settings,Boolean getSiteMapUrls) {
		// TODO Auto-generated method stub
		List<String> Urls;
		List<SitemapPages>listPages = new ArrayList<SitemapPages>();
		Urls = new ArrayList<String>();
		Map<String, String> map;
		File file = new File(settings.getDictionaryFile());
		
		try {
			map = new HashMap<String, String>();
			InputStream is = new FileInputStream(file);
			Document doc = Dom4jUtils.newDocument(is);
			if (null != doc) {
				Element root = doc.getRootElement();
				Iterator<Element> elements = root.elementIterator("ListItem");
				
				while (elements.hasNext()) {
					Element urlEle = elements.next();
					Element Target = urlEle.element("Target");
					Element Source = urlEle.element("Source");
					map.put(Target.getText(), Source.getText());
					}
				} 
			
			
			LOGGER.debug("Map size is >>>"+map.size());
			for (String sitemapurl:settings.getSitemapurls()) {
				//System.out.println("<<<<<<<<<<<<<<< START >>>>>>>>>>>>>>>>>>>>>>");
				SitemapPages pagesAttributes = new SitemapPages();
				String domainNameFromURL = new String();
				try {
					java.net.URL u = new URL(sitemapurl);
					 domainNameFromURL="https://"+u.getHost();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					LOGGER.error("MalformedURLException occured in getSiteMapUrls for TeamSiteCommonUtils",e);
				}
				pagesAttributes.setSitemapUrl(sitemapurl);
				//System.out.println("domainNameFromURL >>>>>>"+domainNameFromURL);
				String []urlPath = sitemapurl.split(domainNameFromURL);
				//System.out.println("sitemapurl >>"+sitemapurl);
				//System.out.println("urlPath Size >> "+urlPath.length);
				String[] urlPathArray  = urlPath[1].split("/");
				String htmlFile = new String();
				String htmlFileTranslated = new String();
				String toReplace = File.separator+settings.getLocale()+File.separator;
				htmlFile = getKeyPattern(urlPath[1],toReplace,"html");
				htmlFile = htmlFile.replaceAll("\\s+", "");
				//System.out.println("Converted toString from >>"+urlPath[1] +"to >>>>>"+htmlFile);
                List<String>pathFromDictionaryList = new ArrayList<>();
				for(int i =1 ;i<urlPathArray.length;i++) {
					//System.out.println("urlPathArray split is >>"+urlPathArray[i]);
					
					String h=map.get(urlPathArray[i]);
					if(h!=null) {
						//System.out.println("found in dictionary >> "+urlPathArray[i] +">> "+h);
						pathFromDictionaryList.add(h);
					}
					else {
						pathFromDictionaryList.add(urlPathArray[i]);
					}
					
				}
				
				String pathFromDictionary = String.join("/",pathFromDictionaryList);
				htmlFileTranslated = getKeyPattern(File.separator+pathFromDictionary,toReplace,"page");
				
				
				//System.out.println("Converted toString from >>"+pathFromDictionary +"to >>>>>"+htmlFileTranslated);
				pagesAttributes.setConvertedSitemapUrl(domainNameFromURL+File.separator+pathFromDictionary);
				pagesAttributes.setKeySiteMapPagePath(htmlFile);
				pagesAttributes.setKeyTranslatedSiteMapPagePath(htmlFileTranslated);
				pagesAttributes.setWorkAreaVPath(settings.getWorkareaPath());

				listPages.add(pagesAttributes);
			
			}
			} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
				LOGGER.error("FileNotFoundException occured in getSiteMapUrls for TeamSiteCommonUtils",e);
		}
		
		
		return listPages;
	}
	
	public static List<SitemapPages> getSiteMapUrlsEnglish(ReportSetings settings,Boolean getSiteMapUrls) {
		// TODO Auto-generated method stub
		LOGGER.debug("Inside English locale getsitemapURL method..........................................");
		List<String> Urls;
		List<SitemapPages>listPages = new ArrayList<SitemapPages>();
		Urls = new ArrayList<String>();
		Map<String, String> map;
	//	File file = new File(settings.getDictionaryFile());
		
		try {
			map = new HashMap<String, String>();
		//	InputStream is = new FileInputStream(file);
		//	Document doc = Dom4jUtils.newDocument(is);
		/*	if (null != doc) {
				Element root = doc.getRootElement();
				Iterator<Element> elements = root.elementIterator("ListItem");
				
				while (elements.hasNext()) {
					Element urlEle = elements.next();
					Element Target = urlEle.element("Target");
					Element Source = urlEle.element("Source");
					map.put(Target.getText(), Source.getText());
					}
				} 
			*/
			
			LOGGER.debug("Map size is >>>"+map.size());
			for (String sitemapurl:settings.getSitemapurls()) {
				//System.out.println("<<<<<<<<<<<<<<< START >>>>>>>>>>>>>>>>>>>>>>");
				SitemapPages pagesAttributes = new SitemapPages();
				String domainNameFromURL = new String();
				try {
					java.net.URL u = new URL(sitemapurl);
					 domainNameFromURL="https://"+u.getHost();
				} catch (MalformedURLException e) {
					LOGGER.error("MalformedURLException occured in getSiteMapUrlsENglish for TeamSiteCommonUtils",e);
					
				}
				pagesAttributes.setSitemapUrl(sitemapurl);
				//System.out.println("domainNameFromURL >>>>>>"+domainNameFromURL);
				String []urlPath = sitemapurl.split(domainNameFromURL);
				//System.out.println("sitemapurl >>"+sitemapurl);
				//System.out.println("urlPath Size >> "+urlPath.length);
				String[] urlPathArray  = urlPath[1].split("/");
				String htmlFile = new String();
				String htmlFileTranslated = new String();
				String toReplace = File.separator+settings.getLocale()+File.separator;
				htmlFile = getKeyPattern(urlPath[1],toReplace,"html");
				htmlFile = htmlFile.replaceAll("\\s+", "");
				//System.out.println("Converted toString from >>"+urlPath[1] +"to >>>>>"+htmlFile);
                List<String>pathFromDictionaryList = new ArrayList<>();
				for(int i =1 ;i<urlPathArray.length;i++) {
					//System.out.println("urlPathArray split is >>"+urlPathArray[i]);
					
					String h=map.get(urlPathArray[i]);
					if(h!=null) {
						//System.out.println("found in dictionary >> "+urlPathArray[i] +">> "+h);
						pathFromDictionaryList.add(h);
					}
					else {
						pathFromDictionaryList.add(urlPathArray[i]);
					}
					
				}
				
				String pathFromDictionary = String.join("/",pathFromDictionaryList);
				htmlFileTranslated = getKeyPattern(File.separator+pathFromDictionary,toReplace,"page");
				
				
				//System.out.println("Converted toString from >>"+pathFromDictionary +"to >>>>>"+htmlFileTranslated);
				pagesAttributes.setConvertedSitemapUrl(domainNameFromURL+File.separator+pathFromDictionary);
				pagesAttributes.setKeySiteMapPagePath(htmlFile);
				pagesAttributes.setKeyTranslatedSiteMapPagePath(htmlFileTranslated);
				pagesAttributes.setWorkAreaVPath(settings.getWorkareaPath());

				listPages.add(pagesAttributes);
			
			}
			} catch (Exception e) {
			// TODO Auto-generated catch block
				LOGGER.error("Exception occured in getSiteMapUrlsENglish for TeamSiteCommonUtils",e);
		}
		
		
		return listPages;
	}

	private static String getKeyPattern(String UrlPathwithoutDomain,String toReplace,String type) {
		// TODO Auto-generated method stub
		LOGGER.debug("Printing All UrlPathwithoutDomain >>>>>>>>>>>>>>>>>>>>>>>>"+UrlPathwithoutDomain);
		UrlPathwithoutDomain = UrlPathwithoutDomain.replaceFirst(toReplace, "");
		//String[] b = UrlPathwithoutDomain.split("/");
		String tempurlPath= UrlPathwithoutDomain;
		String paramaterhtmlFile = new String();
		tempurlPath = tempurlPath.replaceAll("\\s+", "");
		if(tempurlPath.endsWith("/")) {

			tempurlPath= tempurlPath.substring(0, tempurlPath.length() - 1);
		 }
		LOGGER.debug("Printing All tempurlPath >>>>>>>>>>>>>>>>>>>>>>>>"+tempurlPath);
		/*
		 * if(b.length>3) { if(!tempurlPath.contains(".html")) {
		 * 
		 * paramaterhtmlFile = b[b.length -3]+File.separator+b[b.length
		 * -2]+File.separator+b[b.length -1]+File.separator+"index.html";
		 * if(paramaterhtmlFile.contains("//")) {
		 * LOGGER.debug("Printing 1 >>>>>>>>>>>>>>>>>>>>>>>>"+paramaterhtmlFile); } }
		 * else {
		 * 
		 * paramaterhtmlFile = b[b.length -4]+File.separator+b[b.length
		 * -3]+File.separator+b[b.length -2]+File.separator+b[b.length -1];
		 * if(paramaterhtmlFile.contains("//")) {
		 * LOGGER.debug("Printing 2 >>>>>>>>>>>>>>>>>>>>>>>>"+paramaterhtmlFile); } }
		 * 
		 * }else {
		 * 
		 * if(!tempurlPath.contains(".html")) {
		 * 
		 * paramaterhtmlFile = tempurlPath+File.separator+"index.html";
		 * if(paramaterhtmlFile.contains("//")) {
		 * LOGGER.debug("Printing 3 >>>>>>>>>>>>>>>>>>>>>>>>"+paramaterhtmlFile); } }
		 * else { paramaterhtmlFile = tempurlPath; if(paramaterhtmlFile.contains("//"))
		 * { LOGGER.debug("Printing 4 >>>>>>>>>>>>>>>>>>>>>>>>"+paramaterhtmlFile); } }
		 * 
		 * 
		 * 
		 * }
		 */
		if(!tempurlPath.contains(".html")) {
			tempurlPath = tempurlPath+File.separator+"index.html";
		}
		String[] tempurlPathArray =tempurlPath.split("/");
		if(tempurlPathArray.length>4) {
			paramaterhtmlFile = tempurlPathArray[tempurlPathArray.length -4]+File.separator+tempurlPathArray[tempurlPathArray.length -3]+File.separator+tempurlPathArray[tempurlPathArray.length -2]+File.separator+tempurlPathArray[tempurlPathArray.length -1];
    		}
		else {
			paramaterhtmlFile =tempurlPath;
		}
		if(type.equalsIgnoreCase("page")) {
			paramaterhtmlFile = paramaterhtmlFile.replaceFirst(".html", ".page");
		}
		LOGGER.debug("Printing All paramaterhtmlFile >>>>>>>>>>>>>>>>>>>>>>>>"+paramaterhtmlFile);
		return paramaterhtmlFile;
	}
	public static List<Future<SitemapPages>> getPageDetails(List<SitemapPages> translatedSitemapurls) {
		// TODO Auto-generated method stub
		List<Future<SitemapPages>> listPages = new ArrayList<>();
		ExecutorService executor = new ThreadPoolExecutor(100, 100, 0L, TimeUnit.MILLISECONDS,new LinkedBlockingQueue<Runnable>());
		Iterator<SitemapPages> sitemapUrlIterator = translatedSitemapurls.iterator();
		int i =0;
		try {
			while (sitemapUrlIterator.hasNext()) {
				SitemapPages SitemapPageObject = sitemapUrlIterator.next();
				//System.out.println("Executing :" + i + " out of " + translatedSitemapurls.size() + " --> " + SitemapPageObject.getSitemapUrl());
				Future<SitemapPages> future = executor.submit(new Callable<SitemapPages>() {

					@Override
					public SitemapPages call() throws Exception {
						// TODO Auto-generated method stub
						
						SitemapPages pageObject = getDetails(SitemapPageObject);
						//System.out.println("pageObject to String>>>>"+pageObject.toString());
						return pageObject;
					}
					
				});
				//System.out.println("future >>>>>>>>>>>>>>>>>>>>"+future.isDone());
				listPages.add(future);
				i++;
			}
			return listPages;
			
		}
		catch (Exception e) {
			return null;
			
		} finally {
			executor.shutdown();
		}
		
			
			
		}
	static String getMetaTag(org.jsoup.nodes.Document document, String attr) {
		 String s = new String();
		 try {
		 if(attr != null || !"".equals(attr) || !"null".equals(attr)) {
		    Elements elements = document.select("meta[name=" + attr + "]");
		    for (org.jsoup.nodes.Element element : elements) {
		         s = element.attr("content");

		        if (s != null || !"null".equalsIgnoreCase(s)) {} 
		        else {s = "";}
		    }
		 } 
		 
		 }catch(Exception e)
		 {
			 //System.out.println("null");
		 }
		// System.out.println("Value of getMataTag: >>>"+s);
	 return s;
	}
	protected static SitemapPages getDetails(SitemapPages sitemapPageObject) {
		// TODO Auto-generated method stub
		String sitemapPageUrl = sitemapPageObject.getSitemapUrl();
		String TeamsitePage = new String();
		//System.out.println("Processing for >>>>>>>"+sitemapPageUrl);
        Response response = null;
        try {
			response = Jsoup.connect(sitemapPageUrl).userAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.21 (KHTML, like Gecko) Chrome/19.0.1042.0 Safari/535.21").timeout(30000).execute();
			int statusCode = response.statusCode();
			//System.out.println("Status code :="+statusCode);
			
			
			if(statusCode == 200)
			{
				org.jsoup.nodes.Document document = Jsoup.connect(sitemapPageUrl).get();
				sitemapPageObject.setHttpStatusCode(statusCode);
				sitemapPageObject.setIsLive(Boolean.TRUE);
				//String categoryPath = document.getElementsByAttributeValueContaining("name", "category-path").toString();
			    //String productPath = document.getElementsByAttributeValueContaining("name", "product-path").toString();
			    
			   
			   /* 
			    if(!categoryPath.isEmpty()) {
			    	categoryPath =getMetaTag(document,"category-path");
			    	TeamsitePage =categoryPath;
			    	 sitemapPageObject.setTeamsitePage(categoryPath);
			    	 
			    	// System.out.println("productPath"+categoryPath);
			    }
			    if(!productPath.isEmpty()) {
			    	productPath=getMetaTag(document,"product-path");
			    	TeamsitePage =productPath;
			    	//System.out.println("productPath"+productPath);
			    	sitemapPageObject.setTeamsitePage(productPath);
			    }
			    */
			}
			else{
				sitemapPageObject.setHttpStatusCode(statusCode);
				if(statusCode !=200) {
					sitemapPageObject.setIsLive(Boolean.FALSE);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
		
		}
	        return sitemapPageObject;
		}
	public static Map<String, String> getFolderMap(String Folder) {
		
		

		// TODO Auto-generated method stub
		Map<String, String> parameterGethtmlMap = new HashMap<String, String>();
		try {
		    Path startPath = Paths.get(Folder);
		    Files.walkFileTree(startPath, new SimpleFileVisitor<Path>() {
		        @Override
		        public FileVisitResult preVisitDirectory(Path dir,
		                BasicFileAttributes attrs) {
		            //System.out.println("Dir: " + dir.toString());
		            return FileVisitResult.CONTINUE;
		        }

		        @Override
		        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
		        	if(file.toString().contains(".html") || file.toString().contains(".page")) {
		        		String tempFile = file.toString();
		        		if(file.toString().contains("website/industries")) {
		        			tempFile = tempFile.replaceFirst("/industries/", "/");
		        		}
		        		else if(file.toString().contains("website/products")){
		        			tempFile = tempFile.replaceFirst("/products/", "/");
		        		}
		            	String[] htmlFiletoString= tempFile.split(Folder+File.separator);
		            	
		            	String htmlFile = htmlFiletoString[1];
		            	//System.out.println("Processing for File:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " +htmlFile); 
		        		String[] splithtmlFiletoString= htmlFile.split("/");
		        		//System.out.println("Processing for File with size:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " +splithtmlFiletoString.length);
		        		if(splithtmlFiletoString.length>4) {
		        		htmlFile = splithtmlFiletoString[splithtmlFiletoString.length -4]+File.separator+splithtmlFiletoString[splithtmlFiletoString.length -3]+File.separator+splithtmlFiletoString[splithtmlFiletoString.length -2]+File.separator+splithtmlFiletoString[splithtmlFiletoString.length -1];
		        		}
		        		//System.out.println("Processed File:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " +htmlFile);
		        		
		            	 parameterGethtmlMap.put(htmlFile.toString().trim(), file.toString());
		            }
		            return FileVisitResult.CONTINUE;
		        }

		        @Override
		        public FileVisitResult visitFileFailed(Path file, IOException e) {
		            return FileVisitResult.CONTINUE;
		        }
		    });
		} catch (IOException e) {
			LOGGER.error("Exception occured in getFolderMap for TeamSiteCommonUtils",e);
		}
		return parameterGethtmlMap;
	}
	public static Map<String, String> gethtmlMapbyStream(String htmlFolder) {
		// TODO Auto-generated method stub
		Map<String, String> parameterGethtmlMap = new HashMap<String, String>();
		
		try(
				Stream<Path> walk = Files.walk(Paths.get(htmlFolder));
				
				) 
		{
			 List<File> filesInFolder =  walk.filter(Files::isRegularFile).map(Path::toFile).collect(Collectors.toList());
			for(File f :filesInFolder) {
				String[] htmlFiletoString= f.toString().split(htmlFolder+File.separator);
            	String htmlFile = htmlFiletoString[1];
            	 System.out.println("File:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " +htmlFile); 
            	 parameterGethtmlMap.put(htmlFile, f.toString());
			}
		} catch (IOException e) {
			LOGGER.error("Exception occured in gethtmlMapbyStream for TeamSiteCommonUtils",e);
		}
		finally {
		
		}
		return parameterGethtmlMap;
	}
	public static String generateReport(ReportSetings settings) {
		// TODO Auto-generated method stub
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFSheet sheet = workbook.createSheet("URL_Mapping");
		String  ReportFile = new String();
		try {
		Row frow = sheet.createRow(0); 
		Cell cell = frow.createCell(0);
		 cell.setCellValue("SiteMapUrl"); 
		 cell = frow.createCell(1);
		 cell.setCellValue("TeamSitePage");
		 cell = frow.createCell(2);
		 cell.setCellValue("IndexPage");
		 cell = frow.createCell(3);
		 cell.setCellValue("IndexHTML");
		 cell = frow.createCell(4);
		 cell.setCellValue("isLive");
		 cell = frow.createCell(5);
		 cell.setCellValue("Response");

		    sheet.setAutoFilter(CellRangeAddress.valueOf("A1:E1"));
		    
	 		sheet.setColumnWidth(0,77*256);
	 		sheet.setColumnWidth(1,77*256);
	 		sheet.setColumnWidth(2,20*256);
	 		sheet.setColumnWidth(3,20*256);
	 		sheet.setColumnWidth(4,20*256);
		 int rownum = 1; 
		 for (SitemapPages pages : settings.getSitemapPages())
		 { 
			 Row row = sheet.createRow(rownum++); 
			 createList(pages, row);
		  
		 }
		 FileOutputStream out;
		  ReportFile = "/tmp/URLMapping_Report_"+settings.getTaskid()+".xlsx";
		 File file = new File(ReportFile);
		 file.createNewFile();
			out = new FileOutputStream(file);
			
			 workbook.write(out); 
			 out.close();
		} catch (IOException e) {
			LOGGER.error("Exception occured in generateReport for TeamSiteCommonUtils",e);

		} 
		 // file name with path
		
		
		return ReportFile;
	}
	private static void createList(SitemapPages pages, Row row) {
		// TODO Auto-generated method stub
		Cell cell = row.createCell(0);
        cell.setCellValue(pages.getSitemapUrl());
     
        cell = row.createCell(1);
        cell.setCellValue(pages.getTeamsitePage());
        cell = row.createCell(2);
        cell.setCellValue(pages.getContainsIndexPage());
        cell = row.createCell(3);
        cell.setCellValue(pages.getContainsIndexHTML());
        cell = row.createCell(4);
        cell.setCellValue(pages.getIsLive());
        cell = row.createCell(5);
        cell.setCellValue(pages.getHttpStatusCode());

	}
}
