package com.deere.livesite.workflow;


import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class EmailTemplateImpl  {

	
	private static final Log logger = LogFactory
			.getLog(EmailTemplateImpl.class);
	private static final String EMAIL_PATTERN = "^(.+)@(.+)$";
	private static Session mailSession;

	EmailTemplateImpl() {
		// private constructor
	}

	// Inner class to provide instance of class
	private static class EmailTemplateImplSingleton {
		private static final EmailTemplateImpl INSTANCE = new EmailTemplateImpl();
	}

	public static EmailTemplateImpl getInstance() {
		return EmailTemplateImplSingleton.INSTANCE;
	}


	public Session getMailSession() {
		if (mailSession == null) {
			Properties mailProperties = new Properties();
			mailProperties.put("generic_email_mail_host_name","mail.dx.deere.com" );
			mailSession = Session.getDefaultInstance(mailProperties, null);
		}
		return mailSession;
	}


	public void sendEmail(String senderAddressKey, String toRecipientAddress, String locale,
			String ccMailAddressKey, String mailSubjectKey,String filePath) {

		String recipientAddress;
		String ccMailAddress;
		String senderAddress;
		String mailSubject;

		if (logger.isDebugEnabled()) {

			logger.debug("Send Email Functionality Start");
			logger.debug("**************************************************************");
			logger.debug("Sender Address Key : " + senderAddressKey);
			logger.debug("To Recipient Address: " + toRecipientAddress);
			logger.debug("cc Mail Address Key: " + ccMailAddressKey);
			logger.debug("Mail Subject Key: " + mailSubjectKey);
			
		}

		try {

			if (mailSession == null) {
				mailSession = getMailSession();
			}
			// Create a default MimeMessage object.
			Message message = new MimeMessage(mailSession);

			// Recipient - TO email ID needs to be Set.
			if (null != toRecipientAddress && !"".equals(toRecipientAddress)) {
				Pattern pattern = Pattern.compile(EMAIL_PATTERN);
				Matcher matcher = pattern.matcher(toRecipientAddress);
				if (matcher.matches()) {
					 recipientAddress = toRecipientAddress;
					// Set To: header field of the header.
					message.setRecipients(Message.RecipientType.TO,
							InternetAddress.parse(recipientAddress));
				} else {
					logger.debug("Recipient Email Address is Invalid");
				}
			}

			// Recipient - CC email ID needs to be Set.
			if (null != ccMailAddressKey && !"".equals(ccMailAddressKey)
					&& !ccMailAddressKey.isEmpty()) {
				ccMailAddress = ccMailAddressKey;
				if (null != ccMailAddress && !"".equals(ccMailAddress)) {
					message.setRecipients(Message.RecipientType.CC,
							InternetAddress.parse(ccMailAddress));
				}
				if (logger.isDebugEnabled()) {
					logger.debug("Mail Recipient CC Set to : " + ccMailAddress);
				}
			}
			
			// Sender's email ID needs to be set.
			if (null != senderAddressKey && !"".equals(senderAddressKey)) {
				senderAddress = senderAddressKey;
				// Set From: header field of the header.
				message.setFrom(new InternetAddress(senderAddress));
				if (logger.isDebugEnabled()) {
					logger.debug("Mail Sender Address Set to : "
							+ senderAddress);
				}
			}

			// Sender's email ID needs to be set.
			if (null != mailSubjectKey && !"".equals(mailSubjectKey)
					&& !mailSubjectKey.isEmpty()) {
				mailSubject = mailSubjectKey;
				// Set Subject: header field
				message.setSubject(mailSubject);
				if (logger.isDebugEnabled()) {
					logger.debug("Mail Subject Set to : " + mailSubject);
				}
			} else if (logger.isDebugEnabled()) {
				logger.debug("Mail Subject is Empty or null and not set");
			}

			// This mail has 2 part, the BODY and the embedded image
			MimeMultipart multipart = new MimeMultipart("related");
			String msg = "";
			if(mailSubjectKey != null) {
				if(mailSubjectKey.contains("Asset Report")) {
					msg="Attached is the Asset report for "+locale+". This Report Contains All asset details with respect of selected locale including DCR data";
				}
				else if(mailSubjectKey.contains("Associated Pages of")) {
					msg="Attached is the report for "+locale+". This Report Contains associated page details for selected DCRs in workflow.";
				}
				else{
					msg="Attached is the report for "+locale+". This report consists of comparison between HTML directory and URL Mapping file.";
				}
			}
			
			logger.debug("Mail Body Part : "+ msg);
			// first part (the html)
			BodyPart messageBodyPart = new MimeBodyPart();
			
			messageBodyPart.setContent(msg, "text/html");
			// add it
			multipart.addBodyPart(messageBodyPart);

			messageBodyPart = new MimeBodyPart();
			MimeBodyPart attachPart = new MimeBodyPart();
			 
            try {
                attachPart.attachFile(filePath);
            } catch (IOException ex) {
            	logger.debug ("Caught exception in runIt(). Details: " + ex +ex.getMessage ());
            }

            multipart.addBodyPart(attachPart);

			// put everything together
			message.setContent(multipart);
			// Send message
			Transport.send(message);

			if (logger.isDebugEnabled()) {
				logger.debug("                 Email Sent Successfully....");
				logger.debug("**************************************************************");
			}

		}catch (MessagingException e) {
			logger.error("Exception Occured While sending Email :"
					+ e.getMessage());
		} finally {
			mailSession = null;
		}

	}

}
