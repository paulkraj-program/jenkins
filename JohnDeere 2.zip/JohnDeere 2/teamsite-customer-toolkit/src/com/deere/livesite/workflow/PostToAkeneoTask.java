package com.deere.livesite.workflow;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.deere.livesite.workflow.syndication.SyndicationUtilities;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.livesite.util.NodeHelper;

/**
 * Provides the implementation for posting specified JSON files 
 * to the WSO2 service that associates them with products in Akeneo 
 * by their unique identifier and JSON service field type.
 * 
 * @author Klish Group, Inc.
 *
 */
public class PostToAkeneoTask implements CSURLExternalTask {

	static final transient Logger LOGGER = Logger.getLogger(PostToAkeneoTask.class);

	//Names of workflow variables
	private static final String ARG_URL = "endpoint_url";
	private static final String ARG_TYPE = "file_type";
	private static final String ARG_PROTOCOL = "protocol";
	private static final String ARG_HOST = "host";
	private static final String ARG_PORT = "port";

	private static final String SUCCESS_TRANSITION = "Post to Akeneo Success";
	private static final String FAILURE_TRANSITION = "Post to Akeneo Failure";

	private static final String SERVICE = "service=";
	private static final String LOCALE = "&locale=";
	private static final String DATA = "&data=";
	private static final String ID_TYPE = "&identifiertype=";
	private static final String ID_VAL = "&identifiervalue=";

	private static final String POST_TO_AKENEO_REVIEW = "&PostToAkeneoReview=";
	private static final String VAR_REVIEW_REQUIRED = "ReviewRequired";


	@Override
	public void execute(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable parameters) throws CSException {
		LOGGER.debug("Starting Post to Akeneo task.");

		//Get workflow variables
		String url = task.getVariable(ARG_PROTOCOL) + "://" + task.getVariable(ARG_HOST) + ":" + task.getVariable(ARG_PORT) + task.getVariable(ARG_URL);
		String type = task.getVariable(ARG_TYPE);

		String reviewPosttoAkeneo = task.getVariable(VAR_REVIEW_REQUIRED);
		
		LOGGER.debug("Post to Akeneo Flag : " + reviewPosttoAkeneo);

		// Load the syndication configuration and filter to the desired items
		Set<SyndicationTarget> configuration = SyndicationUtilities.loadSyndicationConfiguration(client);

		// Filter the configuration to only the source syndication target (branch)
		SyndicationTarget source = SyndicationTarget.filterByBranch(configuration, task.getArea().getBranch().getVPath().getPathNoServer().toString());
		LOGGER.debug("SyndicationTarget Source: " + source);

		//Get the locale
        String locale = source.getLocale().replace("-", "_");
		//String locale = "en_US";

		//Get all attached files to process
		CSFile[] files = task.getArea().getFiles(task.getFiles());

		for (CSFile file : files) {
			//Throw out bad files
			if (CSSimpleFile.KIND != file.getKind()) {
				LOGGER.warn("Wrong file type detected for file " + file.getName() + ". This file will not be posted.");
				continue;
			}

			CSSimpleFile csFile = (CSSimpleFile) file;
			//Get the contents of the file
			String name = csFile.getName();
			LOGGER.debug("File name is " + name);
			
			String rawData = readFile(csFile);
			if (rawData != null) {
			//Get the unique identifier from the file name
			String uid = name.substring(0, name.lastIndexOf("_"));
			String ext = csFile.getVPath().getExtension();
			JSONType serviceType = null;

			LOGGER.debug("File extension is " + ext);
			//Get the type of JSON file from the file name
			//If not one of the specified types, throw it out
			try {
				String service = name.substring(name.lastIndexOf("_") + 1, name.lastIndexOf(".") == -1 ? name.length() : name.lastIndexOf("."));
				LOGGER.debug("Service is "+service);
				for (JSONType serv_type : JSONType.values()) {
					if (serv_type.isServiceRelated(service)) {
						serviceType = serv_type;
						break;
					}
				}
			} catch (NullPointerException | IllegalArgumentException e) {
				LOGGER.warn("JSON type for file " + name + " was invalid or nonexistent. This file will not be posted.");
			}
			
			LOGGER.debug("Service type is "+serviceType);
			//Throw out all non JSON files except for the product360 ones
			if (("json".equals(ext) && serviceType != null) || (serviceType != null && serviceType.equals(JSONType.PRODUCT360))) {
				LOGGER.debug("ServiceType is " + serviceType.toString().toLowerCase());
				if (ext.equals("xml")) {
					type = type.replace("json", "xml");
				}				
				String comp_url = url + SERVICE + serviceType.toString().toLowerCase() + LOCALE + locale + DATA + ext + ID_TYPE + serviceType.getIDType() + ID_VAL + uid + POST_TO_AKENEO_REVIEW + reviewPosttoAkeneo;
				LOGGER.debug("{URL: \"" + comp_url + "\", File Name:\"" + name + "\", Content:\"" + rawData + "\"}");

				//Setup post command to WSO2 service
				try {
					URL u = new URL(comp_url);
					HttpURLConnection conn = (HttpURLConnection) u.openConnection();
					conn.setDoOutput(true);
					conn.setRequestMethod("POST");
					conn.setRequestProperty("Content-Type", type);
					conn.setRequestProperty("Content-Length", String.valueOf(rawData.length()));

					try (OutputStream os = conn.getOutputStream()) {
						os.write(rawData.getBytes());
					}
					for (Map.Entry<String, List<String>> e : conn.getHeaderFields().entrySet()) {
						String str = e.getKey() + ": ";
						for (String s : e.getValue()) {
							str += s + ", ";
						}
						LOGGER.debug(str);
					}

					int responseCode = conn.getResponseCode();

					//Check to see that post was successful
					if (responseCode != 200) {
						LOGGER.error("POST request returned error: " + responseCode + "-" + conn.getResponseMessage());
						task.chooseTransition(FAILURE_TRANSITION, "Error posting files to Akeneo. Returned response code " + String.valueOf(responseCode));
					} 
						
					
				} catch (IOException ioe) {
					LOGGER.error("IOException thrown", ioe);
					task.chooseTransition(FAILURE_TRANSITION, "Error posting files to Akeneo. IOException thrown: " + ioe.getMessage());
				}
			} else {
				LOGGER.debug("File " + name + " had wrong extension or invalid service type.");
				
			}
			
		}
	}
		task.chooseTransition(SUCCESS_TRANSITION, "COMPLETED posting all files to Akeneo.");
	}

	/**
	 * Method that reads the contents of a given CSSimpleFile to a string
	 * @param CSSimpleFile csfile
	 * @return String contents
	 * @throws CSException
	 */
	private String readFile(CSSimpleFile csfile) throws CSException {
		try {
		if (csfile.getVPath().getExtension() != null  && csfile.getVPath().getExtension().equals("json")) {
			byte[] buffer = new byte[4096];
			int count;
			try (InputStream in = new BufferedInputStream(csfile.getInputStream(true))) {
				OutputStream os = new ByteArrayOutputStream();
				while ((count = in.read(buffer)) > 0) {
					os.write(buffer, 0, count);
				}
				return os.toString();
			} catch (IOException ioe) {
				LOGGER.error("Error reading file " + csfile.getVPath().getAreaRelativePath(), ioe);
				throw new CSException(ioe);
			}
		} else {
			return NodeHelper.readFileData(csfile);
		}
		}
		catch(CSException ex) 
		{
			LOGGER.error("Skipping File" + csfile.getVPath().getAreaRelativePath(),ex);
			return null;
		}
		
	}
}