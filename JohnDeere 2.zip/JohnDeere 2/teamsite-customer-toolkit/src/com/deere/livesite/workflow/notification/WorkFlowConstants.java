package com.deere.livesite.workflow.notification;

public class WorkFlowConstants {

	public static final String MAIL_ENCODING = "UTF-8";
	public static final String MAIL_MIME_TYPE = "text/html";
    public static final String NO_REPLY_TO_ADDRESS ="no-reply@johndeere.com";
    public static final String PAGE_EXTENSION = "page";
    public static final String SERVER_NAME = "serverName";
    public static final String DEFAULT_PROPERTIES_FILE_PATH = "iw/config/johndeere/constants.properties";
    public static final String NODE = "Node";
    

    }


