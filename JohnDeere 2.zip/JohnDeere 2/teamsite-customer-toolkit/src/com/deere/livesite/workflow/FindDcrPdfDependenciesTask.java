package com.deere.livesite.workflow;

import java.io.UnsupportedEncodingException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import com.deere.livesite.workflow.constants.WorkflowConstants;
import com.deere.teamsite.common.constants.UiUtilsConstants;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.livesite.workflow.WorkflowUtils;

import opennlp.tools.ml.maxent.quasinewton.LineSearch;

import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;

/**
 * FindDcrPDFDependenciesTask finds the PDF's attached to the DCR on the page
 * and creates a temp file containing the list of those files. The temp file
 * path is set in the Workflow Variables to be used by the Deploy Image task to
 * deploy the image files in Preview and Prod servers. This task also attaches
 * other files to the workflow which are referenced in the DCR. The file
 * extensions to be attached are specified through the
 * extensionFilesToAttachFromDCR variable.
 * 
 * @author Klish Group, Inc. [AG]
 *
 */
public class FindDcrPdfDependenciesTask extends AbstractURLExternalTask {
	private static final transient Logger findDcrPdfDependenciesTaskLogger = Logger.getLogger(FindDcrPdfDependenciesTask.class);
	private static String pdfFileValidExtension = "pdf";
	//private static String extensionFilesToAttachFromDCR = "json";
	private static String assetsValidExtension="js|css|gif|jpg|swf|png|ipx|mov|mvr|jpeg|jpe|tif|eps|bmp|pcx|flv|xml|mp3";

	@Override
	public void execute(CSClient client, CSExternalTask task) throws CSException {
		// execute(client, (CSTask) task);
		
		
	}

	public static void attachAssetsToTask(CSClient client, CSTask task, String selectedPDFList)
			throws CSException, UnsupportedEncodingException {
		CSAreaRelativePath[] taskFilesRelativePaths = task.getFiles ();
		Set<String> finalFileList = new HashSet<String>();
		findDcrPdfDependenciesTaskLogger.debug("Inside attachPDFToTask :::::::: " + selectedPDFList);
		String fileListPath = WorkflowUtils.findVariable(task, "pdfFileListPath");
		if(selectedPDFList!=null && !selectedPDFList.equals("")) {
		String[] selectedPDFArr = selectedPDFList.split(",");
		findDcrPdfDependenciesTaskLogger.debug("Setting Global workflow variable ::selectedPDFList:: ");
		task.getWorkflow().setVariable("selectedPDFList", selectedPDFList);
		
	
		
		for (String pdfFile : selectedPDFArr) {
			String decodedPDFValue = URLDecoder.decode(pdfFile, StandardCharsets.UTF_8.toString());
			findDcrPdfDependenciesTaskLogger.debug("Decode value is " + decodedPDFValue);
			finalFileList.add(decodedPDFValue);
		}
		}
		if (fileListPath != null && !"".equals(fileListPath)) {
			fileListPath += File.separator +task.getWorkflowId() + ".txt";
		} else {
			fileListPath = File.separator +task.getWorkflowId() + ".txt";
		}

		findDcrPdfDependenciesTaskLogger.debug("File Path for creating the file List " + fileListPath);
		String validAssetsExtensions = WorkflowUtils.findVariable(task, WorkflowConstants.ASSETS_EXT);
		if (validAssetsExtensions != null && !"".equals(validAssetsExtensions)) {
			assetsValidExtension = validAssetsExtensions.replaceAll(",", "|");
		}
		findDcrPdfDependenciesTaskLogger.debug("Pattern for the assets file Validation " + assetsValidExtension);
		for (CSAreaRelativePath taskFileRelativePath : taskFilesRelativePaths) {
			CSFile file = task.getArea ().getFile (taskFileRelativePath);
			Pattern assetsExtensionPatterns = Pattern.compile(assetsValidExtension, Pattern.CASE_INSENSITIVE);
			if (assetsExtensionPatterns.matcher(FilenameUtils.getExtension(file.getName())).find()) {
				findDcrPdfDependenciesTaskLogger.debug("Assets file found :"+file.getName()+" Adding path :"+taskFileRelativePath.toString());
				finalFileList.add(taskFileRelativePath.toString());
			}
			
		}
		try {
			writePDFFileList(fileListPath, finalFileList);
		} catch (Exception e) {
			findDcrPdfDependenciesTaskLogger.error("Error writing Assets/PDFs file List ", e);
			throw new CSException();
		}
		
		
		//set the pdf file list path in workflow task variable
		/*
		 * task.getWorkflow ().setVariable ("pdfFileListPath", fileListPath); //
		 * task.getWorkflow().setVariable("odSubst_imageFileListPath", fileListPath);
		 * CSTask[] tasks = task.getWorkflow ().getTasks (); for (CSTask t : tasks) {
		 * t.setVariable ("odSubst_pdfFileListPath", fileListPath); }
		 */
	}

	public static Set<String> getPDFSet(CSClient client, CSTask task) throws CSException {

		CSAreaRelativePath[] taskFilesRelativePaths = task.getFiles();
		findDcrPdfDependenciesTaskLogger.debug("Files attached in task " + taskFilesRelativePaths);

		// File extensions for pdfs to be written in the file
		String validPDfExtensions = WorkflowUtils.findVariable(task, WorkflowConstants.PDF_EXT);
		if (validPDfExtensions != null && !"".equals(validPDfExtensions)) {
			pdfFileValidExtension = validPDfExtensions.replaceAll(",", "|");
		}
		findDcrPdfDependenciesTaskLogger.debug("Pattern for the pdf file Validation " + pdfFileValidExtension);

		Set<String> referencedPDFPathsForDCRFile = new HashSet<String>();
		
		for (CSAreaRelativePath taskFileRelativePath : taskFilesRelativePaths) {

			CSFile file = task.getArea().getFile(taskFileRelativePath);

			// Attach PDF dependencies in case a file is a DCR
			if (file != null && file.getKind() == CSSimpleFile.KIND
					&& ((CSSimpleFile) file).getContentKind() == CSSimpleFile.kDCR) {

				findDcrPdfDependenciesTaskLogger.debug("Processing " + taskFileRelativePath.getName() + " for PDF dependencies");

				Set<String> referencedPDFFilePaths = getPDFFileReferences((CSSimpleFile) file);
				if (referencedPDFFilePaths.size() > 0) {
					Pattern pdfFileExtensionPatterns = Pattern.compile(pdfFileValidExtension, Pattern.CASE_INSENSITIVE);
					// Pattern fileExtensionPatterns = Pattern.compile
					// (extensionFilesToAttachFromDCR, Pattern.CASE_INSENSITIVE);
					for (String filePath : referencedPDFFilePaths) {
						findDcrPdfDependenciesTaskLogger.debug("Referenced PDF File Paths " + filePath);
						if (pdfFileExtensionPatterns.matcher(FilenameUtils.getExtension(filePath)).find()) {
							referencedPDFPathsForDCRFile.add(filePath);
						}
					}

				} else {
					task.getWorkflow().setVariable(WorkflowConstants.TASK_VARIABLE_SELECTED_PDF_LIST, "");
				}
			}
			else if(file != null && file.getName().contains(".pdf")) {
				findDcrPdfDependenciesTaskLogger.debug("Processing " + taskFileRelativePath.getName());
				referencedPDFPathsForDCRFile.add(taskFileRelativePath.toString());
			}
		}
		Set<String> pdfFileExistsInTeamSite = new HashSet<String>();
		String workareaAssestsPath = task.getVariable(WorkflowConstants.TASK_VARIABLE_ASSET_WA);
		CSVPath path = new CSVPath(workareaAssestsPath);
		CSWorkarea workarea = client.getWorkarea(path, true);
		for (String pdfFileinDCR : referencedPDFPathsForDCRFile) {
			findDcrPdfDependenciesTaskLogger.debug("PDF files before replacing patterns " + pdfFileinDCR);
			if (pdfFileinDCR.startsWith("/")) {
				String pdfFilePath = pdfFileinDCR.substring(1);
				String modifiedPDFFilePath = pdfFilePath.replaceAll(UiUtilsConstants.ENCODED_SPACE_PATTERN, " ");
				CSAreaRelativePath csarea = new CSAreaRelativePath(modifiedPDFFilePath);
				findDcrPdfDependenciesTaskLogger.debug("AssetWorkareaPath "+workarea.getName());
				findDcrPdfDependenciesTaskLogger.debug("File path of the asset "+csarea.getParentPath());
				CSFile pdfFile = workarea.getFile(csarea);
				findDcrPdfDependenciesTaskLogger.debug(pdfFile);
				if (pdfFile != null && pdfFile.getKind() == CSSimpleFile.KIND) {
					String modifiedPDFFileInDcr = pdfFileinDCR.replaceAll(UiUtilsConstants.ENCODED_SPACE_PATTERN, " ");
					pdfFileExistsInTeamSite.add(modifiedPDFFileInDcr);
				}
			}
			else {
				String modifiedPDFFilePath = pdfFileinDCR.replaceAll(UiUtilsConstants.ENCODED_SPACE_PATTERN, " ");
				CSAreaRelativePath csarea = new CSAreaRelativePath(modifiedPDFFilePath);
				findDcrPdfDependenciesTaskLogger.debug("AssetWorkareaPath "+workarea.getName());
				findDcrPdfDependenciesTaskLogger.debug("File path of the asset "+csarea.getParentPath());
				CSFile pdfFile = workarea.getFile(csarea);
				findDcrPdfDependenciesTaskLogger.debug(pdfFile);
				if (pdfFile != null && pdfFile.getKind() == CSSimpleFile.KIND) {
					String modifiedPDFFileInDcr = pdfFileinDCR.replaceAll(UiUtilsConstants.ENCODED_SPACE_PATTERN, " ");
					pdfFileExistsInTeamSite.add(modifiedPDFFileInDcr);
				}
			}
		}
		return pdfFileExistsInTeamSite;
	}

	/**
	 * This function writes the PDF file list to be used by Opendeploy to deploy the
	 * PDF files associated with the DCR on the page deployed.
	 * 
	 * @param aFileName                    name of the file list
	 * @param referencedPDFPathsForDCRFile paths for the PDF present in the DCR
	 * @throws IOException
	 */

	private static void writePDFFileList(String fileName, Set<String> referencedPDFPathsForDCRFile)
			throws IOException {
		
		
		try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(fileName), StandardCharsets.UTF_8)) {
			for (String csa : referencedPDFPathsForDCRFile) {
				writer.write(csa);
				writer.newLine();
			}
			// writer.close();
		}
	}

	/**
	 * Get Valid File Name References by reading each line of the file and comparing
	 * patterns with provided valid file extension list
	 * 
	 * @param file File to read and find valid references
	 * @return List of Area Relative Paths of references files
	 */
	private static Set<String> getPDFFileReferences(CSSimpleFile file) {

		findDcrPdfDependenciesTaskLogger.info("Getting References from File : " + file.getVPath());
		Pattern validFilesPattern = Pattern
				.compile("(\\/([a-zA-Z_0-9-\\s\\/]*\\/[^/]+\\.(" + pdfFileValidExtension + "))?)");

		Matcher matcher;
		String line;
		Set<String> allFilesMap = new HashSet<String>();

		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(((CSSimpleFile) file).getInputStream(true)));
			while ((line = br.readLine()) != null) {
				matcher = validFilesPattern.matcher(line);
				while (matcher.find()) {
					allFilesMap.add(matcher.group());
				}
			}
		} catch (CSException csex) {
			findDcrPdfDependenciesTaskLogger.error("Failed retrieving file references: ", csex);
		} catch (IOException ioex) {
			findDcrPdfDependenciesTaskLogger.error("Failed retrieving file references: ", ioex);
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (Exception ex) {
					findDcrPdfDependenciesTaskLogger.error("Failed closing reader ", ex);
				}
			}
		}

		findDcrPdfDependenciesTaskLogger.info("File contains " + allFilesMap.size() + " reference(s)");
		return allFilesMap;
	}

}