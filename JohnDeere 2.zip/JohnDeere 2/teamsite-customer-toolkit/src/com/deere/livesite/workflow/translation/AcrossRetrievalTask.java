package com.deere.livesite.workflow.translation;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.owasp.esapi.ESAPI;

import com.deere.livesite.workflow.common.Utlis;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.deere.livesite.workflow.syndication.SyndicationUtilities;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSBranch;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.cssdk.workflow.CSWorkflowEngine;
import com.interwoven.livesite.dom4j.Dom4jUtils;
/**
 * AcrossRetrievalTask is an implementation of the Runnable class that downloads
 * completed translation projects from the Across FTP server and places the
 * content back into TeamSite in the proper location. Once the download is
 * completed successfully and the content is dropped into TeamSite properly the
 * archive is deleted from the remote server.
 * 
 * @author Klish Group, Inc. [ND]
 */
public class AcrossRetrievalTask implements IRetrievalTask {
	private static final transient Logger LOGGER = Logger.getLogger(AcrossRetrievalTask.class);

	/** Email configuration path for the TeamSite content retrieval e-mail */
	public static final String TEAMSITE_PATH_EMAIL_CONFIGURATION = "/iwadmin/main/deere/syndication/STAGING/configuration/retrieval_email.properties";
	/** Email configuration path for the Akeneo content retrieval e-mail */
	public static final String AKENEO_PATH_EMAIL_CONFIGURATION = "/iwadmin/main/deere/syndication/STAGING/configuration/akeneo_retrieval_email.properties";

	private static final String PROP_EMAIL_SUBJECT = "across.retrieval.subject";
	private static final String PROP_EMAIL_SENDER = "across.retrieval.sender";
	private static final String PROP_EMAIL_TEMPLATE = "arcoss.retrieval.template";

	/** Location of the Across FTP server connection properties */
	private static final String RESOURCE_ID = "com/deere/syndication/across.properties";


	private static final String PATH_SUFFIX = "/deere/";

	
	/**
	 * Regular expression pattern for the FTP archive file names of TeamSite
	 * translation archives
	 */
	public static final String REGEX_TEAMSITE_ARCHIVE_FILE = "Deere\\.com_TeamSite_(env\\-[^_]+_)(([a-zA-Z])+[-a-zA-Z]+_)?(\\d+)_.+\\.zip";
	/**
	 * Regular expression pattern for the FTP archive file names of Akeneo
	 * translation archives
	 */
	public static final String REGEX_AKENEO_ARCHIVE_FILE = "Deere\\.com_PIM_(env\\-[^_]+_)?(\\d+)_.+\\.zip";
	/**
	 * Regular expression pattern for the FTP archive file names of TeamSite
	 * translation archives from target branch
	 */
	public static final String REGEX_TEAMSITE_TARGET_ARCHIVE_FILE = "Deere\\.com_(env\\-[^_]+_)(([a-zA-Z])+[-a-zA-Z]+_)?(\\d+)_.+\\.zip";

	/**
	 * Regular expression pattern for the FTP archive file environment pattern
	 */
	public static final String REGEX_ENVIRONMENT = "env\\-([^_]+)_";
	/**
	 * Pattern for environment injection into archive filenames
	 */
	private static final String PATTERN_ENVIRONMENT = "env-{0}_";

	private static final String ARCHIVE_CONTROL_FILE = "control.xml";

	private static final String WORKFLOW_JOBSPEC = "/iwadmin/main/config/STAGING/workflow/translation-retrieval/workflow.xml";

	private final String archiveFilePattern;
	private final String emailConfigurationPath;
	private final String csFactory;

	private IRetrievalPostProcessor retrievalPostProcessor;
	private static final String SITES = "sites";
	
	private static final String LOCALE_SENDFORTRANSLATION_EXT_ATTR="LocaleSendForTranslation";
	
	/**
	 * Create a new AcrossRetrievalTask for archives that match the given
	 * archive file pattern. Upon success an e-mail is sent out based on the
	 * provided e-mail configuration. Retrieved content is processed through the
	 * provided IRetrievalPostProcessor instance.
	 * 
	 * @param archiveFilePattern
	 *            The regular expression pattern for the content archives
	 * @param emailConfigurationPath
	 *            The full vpath for the e-mail configuration file
	 * @param csFactory
	 *            The CSFactory instance fully qualified class name
	 * @param retrievalPostProcessor
	 *            The IRetrievalPostProcessor instance used to process content
	 */
	public AcrossRetrievalTask(String archiveFilePattern, String emailConfigurationPath, String csFactory,
			IRetrievalPostProcessor retrievalPostProcessor) {
		this.archiveFilePattern = archiveFilePattern;
		this.emailConfigurationPath = emailConfigurationPath;
		this.csFactory = csFactory;
		this.retrievalPostProcessor = retrievalPostProcessor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		try {
			doRetrieval();
		} catch (IOException ioe) {
			LOGGER.error("Failed during translation project retrieval process", ioe);
			ioe.getStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.deere.livesite.workflow.translation.IRetrievalTask#doRetrieval()
	 */
	@SuppressWarnings("null")
	@Override
	public void doRetrieval() throws IOException {
		try {
			// Get a CSClient instance for processing the files back into
			// TeamSite
			Properties properties = new Properties();
			properties.setProperty("com.interwoven.cssdk.factory.CSFactory", csFactory);

			CSFactory factory = CSFactory.getFactory(properties);
			CSClient client = factory.getClientForCurrentUser(Locale.getDefault(), "AcrossTranslation", null);
			LOGGER.debug("Obtained CSClient instance for user: " + client.getCurrentUser().getName());

			// Load the syndication configuration and filter to the desired
			// items
			Set<SyndicationTarget> configuration = SyndicationUtilities.loadSyndicationConfiguration(client);
			LOGGER.debug("Loaded Syndication Target configuration: " + configuration);

			// Download archived projects from the FTP server
			FileTransfer transfer = new FileTransfer(RESOURCE_ID);
			LOGGER.debug("Output path :"+FileTransfer.outputPath);
			List<File> projects = transfer
					.process(new TranslationArchiveDownloader(FileTransfer.outputPath, archiveFilePattern, PATH_SUFFIX));
			List<File> completed = new ArrayList<File>(projects.size());
			String targetAreaVPath = null;
			// Unzip archives to the proper destination
			for (File archive : projects) {
				Document controlDocument = getControlXmlFromArchive(archive);
				if (controlDocument == null) {
					LOGGER.error("Malformed translation archive; missing control.xml file");
					continue;
				}

				
				LOGGER.debug("Control XML -- " + controlDocument.asXML());
				/*
				 * Update the control.xml for es-ES-traditional : QC 1168 : END
				 */

				TranslationJob translationJob = TranslationJob.build(controlDocument, configuration);
				RetrievalInfo retrievalInfo = new RetrievalInfo(translationJob);
				String srcFilePathLocale = srcFilePathControlFile(controlDocument);
                LOGGER.debug("srcFilePathLocale from srcFilePathControlFile method is :: srcSource>>>>>>>>>>>>"+srcFilePathLocale);
				try (ZipInputStream input = new ZipInputStream(new FileInputStream(archive))) {
					ZipEntry entry = null;
					while ((entry = input.getNextEntry()) != null) {
						LOGGER.debug("Processing Archive Entry: " +  ESAPI.encoder().encodeForHTML(entry.getName()));
						Pattern pattern = Pattern.compile("Output/([^/]+)/(.*)");
						Matcher matcher = pattern.matcher(entry.getName());
						LOGGER.debug("File from the zip " + ESAPI.encoder().encodeForHTML(entry.getName()));
						if (ARCHIVE_CONTROL_FILE.equals(entry.getName())) {
							LOGGER.debug("Archive entry '" + ESAPI.encoder().encodeForHTML(entry.getName()) + "' is control file; skipping");
							continue;
						} else if (entry.isDirectory()) {
							LOGGER.debug("Archive entry '" + ESAPI.encoder().encodeForHTML(entry.getName()) + "' is directory; skipping");
							continue;
						}
						if (!matcher.matches()) {
							LOGGER.debug("Archive entry '" + ESAPI.encoder().encodeForHTML(entry.getName()) + "' is NOT localized content; skipping");
							retrievalInfo.addUnknownFile(entry.getName());
							continue;
						}

						String locale = matcher.group(1);
						String curr = matcher.group(2);

						LOGGER.debug("locale: " + ESAPI.encoder().encodeForHTML(locale));
						LOGGER.debug("Current file: " + ESAPI.encoder().encodeForHTML(curr));

						
						List<String> targetBranchList=getBranchListForAcrossLocale(locale, configuration,translationJob);
						//Converting inputStream top string
						String inputFile=IOUtils.toString(input, "UTF-8");
						
						for(String targetBranch:targetBranchList){
						if (targetBranch != null && !targetBranch.isEmpty()) {
							LOGGER.debug("Branch found :" + ESAPI.encoder().encodeForHTML(targetBranch) + " For Across Locale mapped in targets.xml :"
									+ ESAPI.encoder().encodeForHTML(locale));
							targetAreaVPath = targetBranch.concat("/WORKAREA/shared");
							LOGGER.debug("targetAreaVPath: " + targetAreaVPath);

						}

						else {
							LOGGER.debug("Branch Not found For Across Locale mapped in targets.xml :" + ESAPI.encoder().encodeForHTML(locale));
						}

						SyndicationTarget source = translationJob.getTranslationTask().getSource();
											
						SyndicationTarget target = SyndicationTarget
						.filterByBranch(translationJob.getTranslationTask().getTargets(), targetBranch);
						
						try {

							LOGGER.debug("Source file: " + source.toString());

							if (source == null || target == null) {
								LOGGER.debug("Source or Target NULL: Archive entry '" + ESAPI.encoder().encodeForHTML(entry.getName())
										+ "' is NOT localized content; skipping");
								retrievalInfo.addUnknownFile(entry.getName());
								continue;
							}
							LOGGER.debug("going to update extended attribute for Target locales"+target.getLocale());
							// Determine the target path of the file in TeamSite
							CSBranch branch = client.getBranch(new CSVPath(target.getBranch()), true);
							CSWorkarea workarea = branch.getWorkareas()[0];
							
							CSAreaRelativePath path = new CSAreaRelativePath(curr);
							CSVPath targetPath = workarea.getVPath().concat(path.toString());
							
							// Determine the source path of the file in TeamSite
							try {
							CSBranch sourceBranch = client.getBranch(new CSVPath(source.getBranch()), true);
							CSWorkarea sourceWorkarea = sourceBranch.getWorkareas()[0];
							
							CSAreaRelativePath realtivePath = new CSAreaRelativePath(curr);
							
							CSAreaRelativePath sourceRelativePath=getSourcePath(realtivePath, target, source);
							CSVPath sourceFilePath = sourceWorkarea.getVPath().concat(sourceRelativePath.toString());
							//Get LocaleSendForTranslation ExtendedAtrribute
							LOGGER.debug("Fetching extended attribute from source file :"+sourceFilePath.toString() +" for source locale :"+source.getLocale());
							
							CSFile sourceFile = client.getFile(sourceFilePath);
								
							
							ArrayList<String> existingAttributesValues=Utlis.getExistingExtendedAttribute((CSSimpleFile)sourceFile);
							LOGGER.debug("Fetched locales from file "+existingAttributesValues.toString()+" Target Locale:"+target.getLocale());
							if(existingAttributesValues !=null && !existingAttributesValues.isEmpty() && existingAttributesValues.contains(target.getLocale())) {
								LOGGER.debug("Process file to remove extended attribute ");
								Iterator<String> extAttrIter = existingAttributesValues.iterator();
								while(extAttrIter.hasNext()){
								    String existingAttributeValue = extAttrIter.next();
								    if( existingAttributeValue.equals(target.getLocale())){
								    	extAttrIter.remove();
								    	LOGGER.debug("Removed locale "+existingAttributeValue);
								    }
								}
										
							}
							
							
							
							
							
							if (existingAttributesValues!=null && !existingAttributesValues.isEmpty()) {
							LOGGER.debug("ExistingAttributesValues is not null");
							LOGGER.debug("Updating existing Extended Attribute Values "+existingAttributesValues.toString() +" File :"+sourceFile.getVPath() +"target locale found "+target.getLocale());
							((CSSimpleFile) sourceFile).setExtendedAttributes(new CSExtendedAttribute[] {
									new CSExtendedAttribute(LOCALE_SENDFORTRANSLATION_EXT_ATTR, getExistingTargetLocales(existingAttributesValues)) });
							}
							else{
								LOGGER.debug("Deleting LocaleSendForTranslation Extended Atrribute");
								((CSSimpleFile) sourceFile).deleteExtendedAttributes(new String[] {LOCALE_SENDFORTRANSLATION_EXT_ATTR} );
							}
							}
							catch(Exception ex)
							{
							
								LOGGER.error("Error while fetching/updating LocaleSendForTranslation extended attribute",ex);
							}
							
							// Replace the source locale with the target locale
							// in the path
							targetPath = source.getTargetPath(targetPath, target);
							if(targetPath.toString().contains(SITES)){
								targetPath = replaceSitePath(targetPath.toString(),curr,target);
							}
							LOGGER.debug("Retrieving file: " + ESAPI.encoder().encodeForHTML(curr) + "; target path: " + ESAPI.encoder().encodeForHTML(targetPath.toString()));

							CSWorkarea targetArea = client.getWorkarea(targetPath.getArea(), true);

							SyndicationUtilities.createParentDirectories(client, targetArea,
									targetPath.getAreaRelativePath().getParentPath());

							// Write the file from the archive into TeamSite
							CSFile targetFile = client.getFile(targetPath);
							if (targetFile == null) {
								targetFile = targetArea.createSimpleFile(targetPath.getAreaRelativePath());
							}

							if (targetFile == null || CSSimpleFile.KIND != targetFile.getKind()) {
								LOGGER.error("Target file does not exist or is not a CSSimpleFile");
								throw new CSException(-1, "Target file does not exist or is not a CSSimpleFile");
							}

							if(!srcFilePathLocale.isEmpty()) {
								
								LOGGER.debug("srcFilePathLocale fro retrievalPostProcessor is >>>>>>>>>>>>>>>>>>>>>>"+srcFilePathLocale);
							
								SyndicationTarget srcSource = SyndicationTarget.filterByLocale(configuration, srcFilePathLocale);
								
								retrievalPostProcessor.process(client, targetArea, (CSSimpleFile) targetFile, inputFile, srcSource,
										target);
							}
							
							else {
							retrievalPostProcessor.process(client, targetArea, (CSSimpleFile) targetFile, inputFile, source,target);
							}

							retrievalInfo.addRetrievedFile(target, curr);
						} catch (Exception e) {
							
							LOGGER.error("Failed processing translation retrieval archive entry: " + ESAPI.encoder().encodeForHTML(entry.getName()),
									e);
							retrievalInfo.addFailedFile(target, curr, e);
						}
					}
				}
				}
				if (retrievalInfo.failed.size() == 0) {
					completed.add(archive);
				}

				Properties emailProperties = loadEmailProperties(client, emailConfigurationPath);

				String emailSubject = emailProperties.getProperty(PROP_EMAIL_SUBJECT);
				String senderAddress = emailProperties.getProperty(PROP_EMAIL_SENDER);
				String templatePath = emailProperties.getProperty(PROP_EMAIL_TEMPLATE);

				AcrossRetrievalEmailTask emailTask = new AcrossRetrievalEmailTask(emailSubject, senderAddress,
						templatePath);

				emailTask.addToAddress(translationJob.getInitiatorEmail());
				emailTask.addCCAddress(translationJob.getJobContact());

				emailTask.execute(client, retrievalInfo);

				/* Changes to initiate workflow - START */

				try {
					LOGGER.debug("Files in the zip " + retrievalInfo.retrieved.size());
					if (null != translationJob.getpostToAkeneo() && !"".equals(translationJob.getpostToAkeneo())
							&& translationJob.getpostToAkeneo().equals("true")) {
						LOGGER.debug("Get the Post to Akeneo flag " + translationJob.getpostToAkeneo());

						List<String> retrievedFilelist = new ArrayList<String>();
						LOGGER.debug("Get the retrieval entry set size " + retrievalInfo.retrieved.entrySet().size());
						for (Map.Entry<SyndicationTarget, List<String>> entry : retrievalInfo.retrieved.entrySet()) {
							// SyndicationTarget target = entry.getKey();
							for (String file : entry.getValue()) {
								LOGGER.debug("Add file to Retrieved filelist " + ESAPI.encoder().encodeForHTML(file));
								retrievedFilelist.add(file);
							}
						}
						if (retrievalInfo.getUnknown() != null && retrievalInfo.getUnknown().size() > 0) {
							LOGGER.debug("Unknown files found: Add to File list");
							if (retrievedFilelist != null && retrievedFilelist.size() > 0) {
								LOGGER.debug("File list is not null");
								if (!retrievedFilelist.contains(retrievalInfo.getUnknown().toString())) {
									LOGGER.debug("Add unknown file " + ESAPI.encoder().encodeForHTML(retrievalInfo.getUnknown().toString()));
									retrievedFilelist.addAll(retrievalInfo.getUnknown());
								} else {
									retrievedFilelist.addAll(retrievalInfo.getUnknown());
								}

							}
						}
						LOGGER.debug("Updated filelist " + retrievedFilelist.size());
						List<String> relativeFileList;
						String regex = "Output/([^/]+)/";
						LOGGER.debug("List of files to be attached - " + retrievedFilelist.size());
						for (String file : retrievedFilelist) {
							LOGGER.debug("List File - " + ESAPI.encoder().encodeForHTML(file));
						}
						relativeFileList = getRelativePath(retrievedFilelist, regex);
						File filePath = new File(WORKFLOW_JOBSPEC);
						LOGGER.debug("Use workflow XML - " + filePath.getAbsolutePath());
						CSWorkflow csworkflow = null;
						CSWorkflowEngine engine = null;
						engine = client.getWorkflowEngine();
						LOGGER.debug("Initiating Workflow ************************** - ");
						csworkflow = engine.createWorkflow(createDCRJobXML(client,
								filePath.getAbsolutePath().toString(), relativeFileList, targetAreaVPath).asXML());
						LOGGER.debug("Post to Akeneo Workflow Initiated with - " + csworkflow.getId());
					} else {
						LOGGER.debug(
								"Non features/specifications/accessories selected:: Automatic update to PIM is not needed");
					}
				} catch (CSException ex) {
					LOGGER.debug("CSException caught ---- " + ex.getMessage());

				} catch (Exception ex) {
					LOGGER.debug("Exception caught ---- " + ex.getMessage());
				}

				/* Changes to initiate workflow - END */
			}
			LOGGER.debug("Output path:"+FileTransfer.outputPath);
			if (transfer.process(new TranslationArchiveDeleter(completed, FileTransfer.outputPath))) {
				LOGGER.debug("Successfully deleted translation archives on remote server");
			}
			// Delete all of the archives from the file system
			for (File archive : projects) {
				archive.delete();
			}
		} catch (CSException cse) {
			LOGGER.debug("CSE Exception caught - " + cse.getMessage());
			throw new IOException(cse);

		}
	}

	/**
	 * Method to get the src locale selected from the control file
	 * @param control file
	 * @return en-TT
	 */
	private String srcFilePathControlFile(Document controlDocument) {
		String srcLocale = new String();
		SAXReader reader = new SAXReader();
		
		Element rootElement = controlDocument.getRootElement();
		String regex ="(.)*(/deere/)(.*)(/website/)(.*)";
		System.out.println("Root Element: "+rootElement.getName());
		Node value = rootElement.selectSingleNode("/translationJob/acrossPjt/translationTask/simpleTask/srcFiles/srcFile/srcFilePath/text()");
		String srcFilePath = value.getText();
		LOGGER.debug("srcFilePathControlFile:: srcFilePath from Control file is  >>>>>>>>>>>>>>>>>>>>>>>"+srcFilePath);
		Pattern patternToFind = Pattern.compile(regex);
	    Matcher match = patternToFind.matcher(srcFilePath);
		Boolean isMatched = match.matches();
		LOGGER.debug("srcFilePathControlFile:: srcFilePath from Control file matched with Deere Website  >>>>>>>>>>>>>>>>>>>>>>>"+isMatched);
		if(isMatched) {
		String m = StringUtils.substringBetween(srcFilePath, "/deere/", "/website");
		
		if (m.equalsIgnoreCase("tt/en")) {
			srcLocale ="en-TT";
		}
		
		}
		
		return srcLocale;
	}

	/**
	 * Method to replace default site path for non-english initiated workflows
	 * @param targetPath
	 * @param currentFile
	 * @param target
	 * @return
	 */
	private CSVPath replaceSitePath(String targetPath, String currentFile, SyndicationTarget target) {

		//Getting site path from output package pattern
		Pattern sourceSitePathReplacePattern = Pattern.compile("sites/deere/([^/]+)/([^/]+)");
		Matcher matcher = sourceSitePathReplacePattern.matcher(currentFile);
		if (matcher.find()) {
			String sitePath = matcher.group(1) + "/" + matcher.group(2);
			targetPath=targetPath.replaceAll(sitePath, target.getSitePath());
		}
		LOGGER.debug("targetPath after replace " + targetPath);
		targetPath=validateGeneratedPath(targetPath,sourceSitePathReplacePattern);
		LOGGER.debug("targetPath after validation " + targetPath);

		return new CSVPath(targetPath);
	}


	/**
	 * Method to validate if the target path generated is valid or not,matching branch locale and site path locale
	 * @param targetPath
	 * @param sourceSitePathReplacePattern
	 * @return
	 */
	private String validateGeneratedPath(String targetPath, Pattern sourceSitePathReplacePattern) {
		// TODO Auto-generated method stub
		Pattern localeReplacePattern = Pattern.compile("main/deere/([^/]+)/([^/]+)");
		Matcher sourceLocaleMatcher = sourceSitePathReplacePattern.matcher(targetPath);
		Matcher sitePathMatcher=localeReplacePattern.matcher(targetPath);

		if(sourceLocaleMatcher.find()){
			if(sitePathMatcher.find())
			{
				if(!sourceLocaleMatcher.group(1).equals(sitePathMatcher.group(1)))
				{
					LOGGER.debug("Locale are different in generated Target path for branch and output zip ");
					LOGGER.debug("Locale found from branch "+sourceLocaleMatcher.group(1));
					LOGGER.debug("Locale found in Output Zip"+sitePathMatcher.group(1));
					targetPath=targetPath.replace(sourceLocaleMatcher.group(1),sitePathMatcher.group(1));
					LOGGER.debug("Target path generated :"+targetPath);
					return targetPath;
				}
					
			}
		}
		LOGGER.debug("Target path has been validated and generated properly "+targetPath);
		return targetPath;
	}


	private Document getControlXmlFromArchive(File archive) throws IOException {
		LOGGER.debug("Inspecting " + archive.getName() + " for control.xml file");
		try (ZipInputStream input = new ZipInputStream(new FileInputStream(archive))) {
			ZipEntry entry = null;
			while ((entry = input.getNextEntry()) != null) {
				LOGGER.debug("Archive Entry Name: " + ESAPI.encoder().encodeForHTML(entry.getName()));
				if (ARCHIVE_CONTROL_FILE.equalsIgnoreCase(entry.getName())) {
					ByteArrayOutputStream output = new ByteArrayOutputStream();
					byte[] buffer = new byte[4096];
					int count = 0;
					while ((count = input.read(buffer)) > 0) {
						output.write(buffer, 0, count);
					}

					try {
						LOGGER.debug("Found control.xml file");
						return new org.dom4j.io.SAXReader().read(new ByteArrayInputStream(output.toByteArray()));
					} catch (DocumentException de) {
						throw new IOException(de);
					}
				}
			}
		}

		LOGGER.warn("control.xml file not found in translation archive");
		return null;
	}

	private static Properties loadEmailProperties(CSClient client, String configurationPath) throws CSException {
		CSFile file = client.getFile(new CSVPath(configurationPath));
		Properties properties = new Properties();
		InputStream input = null;
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			 
			try {
				input = new BufferedInputStream(((CSSimpleFile) file).getInputStream(true));
				properties.load(input);
			} catch (IOException ioe) {
				throw new CSException(ioe);
			}
			finally {
				if(input != null) {
		            try {
		            	input.close();
					} catch (IOException e) {
						LOGGER.error("IOException occured  while closing the InputStream in the method loadEmailProperties for AcrossRetrivelTask",e);
					}
				}
				}
		}

		return properties;
	}

	public static String buildArchiveFilenameEnvironment() {
		String environment = AcrossRetrievalServlet.getEnvironment();
		LOGGER.debug("Environment: " + environment);

		if (null != environment && !"".equals(environment)) {
			LOGGER.debug("Using environment specific archive filename: " + environment);
			return MessageFormat.format(PATTERN_ENVIRONMENT, environment);
		}

		LOGGER.debug("Using non-environment specific archive filename");
		return "";
	}

	public static List<String> getRelativePath(List<String> absolutefile, String regex) {
		List<String> relativeFilePathList = new ArrayList<>();

		if (absolutefile != null && !absolutefile.isEmpty()) {
			for (String file : absolutefile) {
				LOGGER.debug("absolute file List - " + ESAPI.encoder().encodeForHTML(file));
				relativeFilePathList.add(file.replaceFirst(regex, ""));
			}

		}

		return relativeFilePathList;

	}

	// Method to fetch the locale based on Across Locale set in targets.xml
	public static String getBranchForAcrossLocale(String locale, Set<SyndicationTarget> configuration) {
		for (SyndicationTarget target : configuration) {
			if (target.getLocale().equals(locale.trim())) {
				
				return target.getBranch();
			}
		}
		return null;
	}
	
	/**
	 * Method to get list of branches mapped with across locale
	 * @param locale
	 * @param configuration
	 * @param translationJob 
	 * @return
	 */
	
	public static List<String> getBranchListForAcrossLocale(String locale, Set<SyndicationTarget> configuration, TranslationJob translationJob) {
		List<String> targetBranchList=new ArrayList<String>();
		for (SyndicationTarget target : configuration) {
			if (target.getAcrossLocale()!=null && target.getAcrossLocale().equals(locale.trim())) {
				targetBranchList.add(target.getBranch());
			}
			else if(target.getLocale().equals(locale.trim()))
			{
				targetBranchList.add(target.getBranch());
			}
		}
		LOGGER.debug("getBranchListForAcrossLocale list - " + targetBranchList.toString());
		return getTargetBranchFromTranslationJob(translationJob,targetBranchList);
		
	}
	
	/**
	 * Method to return branch based on target locale
	 * @param translationJob
	 * @param targetBranchList
	 * @return
	 */

	private static List<String> getTargetBranchFromTranslationJob(TranslationJob translationJob,List<String> targetBranchList) {
		List<String> targetTranslationJobBranchList=new ArrayList<String>();
		for(SyndicationTarget target:translationJob.getTranslationTask().getTargets()){
		for(String branch :targetBranchList){
			if(target.getBranch().equals(branch)){
				targetTranslationJobBranchList.add(branch);
			}
		}
	}
		LOGGER.debug("getTargetBranchFromTranslationJob list - " + targetTranslationJobBranchList.toString());
		return targetTranslationJobBranchList;
	}

	
	private Document createDCRJobXML(CSClient client, String filePath, List<String> fileList, String areaVPath)
			throws CSException {
		Document jobDocument = null;
		CSVPath path = new CSVPath(filePath);
		CSSimpleFile csFile = (CSSimpleFile) (client.getFile(path));
		LOGGER.debug("CSFile created for workflow xml " + csFile.getName());
		jobDocument = Dom4jUtils.newDocument(csFile.getInputStream(true));
		Element element = jobDocument.getRootElement();
		for (int i = 0, size = element.nodeCount(); i < size; i++) {
			Node node = element.node(i);
			if (node instanceof Element) {
				String nodeName = node.getName();
				LOGGER.debug("nodeName" + nodeName);
				if (nodeName != null && (nodeName.equals("externaltask") || nodeName.equals("grouptask")
						|| nodeName.equals("submittask"))) {
					Element innerElement = (Element) node;
					for (int j = 0, sizeInnerNode = innerElement.nodeCount(); j < sizeInnerNode; j++) {
						Node nodeInner = innerElement.node(j);
						if (nodeInner instanceof Element) {
							String nodeInnerName = nodeInner.getName();
							Element userInnerElement = (Element) nodeInner;
							if (nodeInnerName.equals("areavpath")) {
								userInnerElement.addAttribute("v", "");
								LOGGER.debug("areaVPath value for attribute v :" + areaVPath);
								userInnerElement.addAttribute("v", areaVPath);

							} else if (nodeInnerName.equals("files")) {
								if (fileList != null && !fileList.isEmpty()) {
									Element filesElement = (Element) nodeInner;
									for (String file : fileList) {
										Element fileElement = filesElement.addElement("file");
										fileElement.addAttribute("path", file);
										fileElement.addAttribute("comment", "");

									}

								}
							}
						}
					}
				}
			}
		}

		LOGGER.debug("Final JOB document " + jobDocument.asXML());

		return jobDocument;

	}
	
	private String getExistingTargetLocales(List<String> extendedAttributes) {
		StringBuilder targetLocalBuilder=new StringBuilder();
		for(String attr :extendedAttributes) {
		targetLocalBuilder.append(attr).append(",");
		}
		String targetLocales=targetLocalBuilder.toString();
		if(targetLocales.length()>0) {
			LOGGER.debug("Setting LocaleSendForTranslation Attribute :"+targetLocales.substring(0, targetLocales.length()-1));
			return targetLocales.substring(0, targetLocales.length()-1);
		}
		return null;
	}
	
	/**
	 * Convert the provided CSAreaRelativePath to a target path from the source path
	 * @param sourcePath The source path
	 * @param target The syndication target
	 * @return The target path
	 */
	public CSAreaRelativePath getSourcePath(CSAreaRelativePath sourcePath, SyndicationTarget target,SyndicationTarget source) {
		// Replace the source locale with the target locale in the path
		LOGGER.debug("Converting source path to target path: " + sourcePath);
		return new CSAreaRelativePath(replacePath(sourcePath.toString(), target, source));
	}
	
	/**
	 * Convert the provided path to a target path from the source path
	 * @param path The source path
	 * @param target The syndication target
	 * @return The target path
	 */
	public String replacePath(String path, SyndicationTarget target,SyndicationTarget source) {
		path = path.replaceAll(target.getLocale(), source.getLocale());
		LOGGER.debug("Replaced target locale with source locale: " + path +" Replacing "+target.getLocale()+" with :"+source.getLocale());
		
		path = path.replaceAll(target.getSitePath(), source.getSitePath());
		LOGGER.debug("Replaced target site path with source site path: " + path+" Replacing "+target.getSitePath()+" with :"+source.getSitePath());
		
		return path;
	}

}