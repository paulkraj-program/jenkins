package com.deere.livesite.workflow.translation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
// import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * XmlConverter converts an provided XML Document to JSON or a provided JSON
 * object to an XML document.
 * @author Klish Group, Inc [ND]
 */
public final class XmlConverter {
	// private static final transient Logger LOGGER = Logger.getLogger(XmlConverter.class);
	
	// Private constructor
	private XmlConverter() { }
	
	/**
	 * Convert the provided XML document to JSON
	 * @param document The XML document to convert
	 * @return The JSONObject of the converted XML document
	 * @throws JSONException
	 */
	public static JSONObject toJson(Document document) throws JSONException {
		Element root = document.getRootElement();
		JSONObject object = new JSONObject();
		
		toJsonFromElement(root, object);
		
		return object;
	}
	
	private static void toJsonFromElement(Element element, JSONObject context) throws JSONException {
		JSONObject object = new JSONObject();
		String text = element.getText();
		
		if (text != null && !"".equals(text)) {
			context.accumulate(element.getName(), toJsonValue(text));
		} else {
			if ("true".equals(element.attributeValue("isArray"))) {
				// LOGGER.debug(element.getName() + " is array");
				if (!context.has(element.getName())) {
					context.put(element.getName(), new JSONArray());
				}
			}
			
			@SuppressWarnings("unchecked")
			List<Element> children = element.elements();
			
			for (Element child : children) {
				toJsonFromElement(child, object);
			}
			
			if (object.length() > 0) {
				context.accumulate(element.getName(), object);
			}
		}
	}
	
	private static Object toJsonValue(String value) {
		if (value == null) {
			return JSONObject.NULL;
		} else if ("null".equals(value)) {
			return JSONObject.NULL;
		} else if ("true".equals(value)) {
			return Boolean.TRUE;
		} else if ("false".equals(value)) {
			return Boolean.FALSE;
		}
		
		try {
			Long l = Long.valueOf(value);
			if (l.longValue() == l.intValue()) {
				return Integer.valueOf(l.intValue());
			}
			return l;
		} catch (Exception e) {
			// Ignore the NumberFormatException
		}
		
		try {
			Double n = Double.valueOf(value);
			if (!n.isInfinite() && n.isNaN()) {
				return n;
			}
		} catch (Exception e) {
			// Ignore the NumberFormatException
		}
		
		return value;
	}
	
	/**
	 * Convert the provided JSONObject to an XML document
	 * @param object The JSONObject to convert
	 * @return The converted XML Document
	 * @throws JSONException
	 */
	public static Document toXml(JSONObject object) throws JSONException {
		Document document = DocumentHelper.createDocument();
		
		List<Node> list = toXMLNode(object);
		for (Node node : list) {
			document.add(node);
		}
		
		return document;
	}
	
	private static List<Node> toXMLNode(Object object) throws JSONException {
		return toXMLNode(object, null);
	}
	private static List<Node> toXMLNode(Object object, String elementName) throws JSONException {
		List<Node> list = new ArrayList<>();
		
		if (object instanceof JSONObject) {
			String[] names = JSONObject.getNames((JSONObject) object);
			if (names == null) {
				names = new String[0];
			}
			
			for (String name : names) {
				Object value = ((JSONObject) object).get(name);
				
				if (value == null) {
				} else if (value.getClass().isArray()) {
					value = new JSONArray(value);
				}
				
				if (value instanceof JSONArray) {
					for (int i = 0; i < ((JSONArray) value).length(); ++i) {
						Object childValue = ((JSONArray) value).get(i);
						Element childElement = DocumentHelper.createElement(name);
						
						childElement.addAttribute("isArray", "true");
						List<Node> children = toXMLNode(childValue);
						for (Node node : children) {
							childElement.add(node);
						}
						
						list.add(childElement);
					}
					
					if (((JSONArray) value).length() == 0) {
						Element childElement = DocumentHelper.createElement(name);
						
						childElement.addAttribute("isArray", "true");
						
						list.add(childElement);
					}
				} else if ("".equals(value)) {
					Element childElement = DocumentHelper.createElement(name);
					
					list.add(childElement);
				} else {
					list.addAll(toXMLNode(value, name));
				}
			}
			
			if (elementName != null) {
				Element element = DocumentHelper.createElement(elementName);
				
				for (Node node : list) {
					element.add(node);
				}
				
				return Collections.<Node>singletonList(element);
			}
			
			return list;
		} else if (object instanceof JSONArray || object.getClass().isArray()) {
			if (object.getClass().isArray()) {
				object = new JSONArray(object);
			}
			
			for (int i = 0; i < ((JSONArray) object).length(); ++i) {
				Object childValue = ((JSONArray) object).get(i);
				Element childElement = DocumentHelper.createElement(elementName == null ? "json-array" : elementName);
				
				childElement.addAttribute("isArray", "true");
				List<Node> children = toXMLNode(childValue);
				for (Node node : children) {
					childElement.add(node);
				}
				
				list.add(childElement);
			}
			
			if (elementName != null) {
				Element element = DocumentHelper.createElement(elementName);
				
				for (Node node : list) {
					element.add(node);
				}
				
				return Collections.<Node>singletonList(element);
			}
			
			return list;
		} else {
			String content = (object == null) ? null : object.toString();
			if (elementName == null) {
				return Collections.<Node>singletonList(DocumentHelper.createText(content));
			} else if (content == null) {
				return Collections.<Node>singletonList(DocumentHelper.createElement(elementName));
			}
			
			Element childElement = DocumentHelper.createElement(elementName);
			
			childElement.setText(content);
			
			return Collections.<Node>singletonList(childElement);
		}
	}

}
