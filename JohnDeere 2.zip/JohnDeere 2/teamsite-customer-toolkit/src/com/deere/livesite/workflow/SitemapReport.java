package com.deere.livesite.workflow;
import java.io.File;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Future;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.access.CSAuthenticationException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.deere.livesite.workflow.utils.*;


public class SitemapReport implements CSURLExternalTask{
	private static final transient Logger LOGGER = Logger.getLogger(SitemapReport.class);
	static String htmlFolder = new String();
	static String sitesFolder = new String();
	static Map<String, String> htmlMap = new HashMap<String, String>();
	static Map<String, String> pageMap = new HashMap<String, String>();
	static String iwmnt = "/iwmnt";
	@SuppressWarnings("unused")
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		// TODO Auto-generated method stub
		List<String> Sitemapurls ;
		List<SitemapPages> httpstatusNotVlid;
		List<SitemapPages> teamsitePageNotVlid;
		List<String> pageNotLive ;
		List<SitemapPages> translatedSitemapurls ;

		
		Properties prop = new Properties();
       
			try {
				ReportSetings settings = new ReportSetings();
				httpstatusNotVlid = new ArrayList<SitemapPages>();
				teamsitePageNotVlid = new ArrayList<SitemapPages>();
				pageNotLive=new ArrayList<>();
				Boolean httpStatus = true;
				CSAreaRelativePath[] attachedFiles = task.getFiles();
				task.detachFiles(attachedFiles);
				String workareaPath = task.getArea().getUAI().toString();
				LOGGER.debug("workareaPath is >>"+workareaPath);
				
				settings.setWorkareaPath(SitemapReport.iwmnt+workareaPath);
				String parentBranch = client.getWorkarea(new CSVPath(workareaPath), false).getBranch().getParentBranch().getName().toString();
				String locale = client.getWorkarea(new CSVPath(workareaPath), false).getBranch().getName().toString();
				settings.setLocale(locale);
				LOGGER.debug("Branch is >>>>"+parentBranch+File.separator+locale);
				settings.setBranches(parentBranch+File.separator+locale);
				htmlFolder = SitemapReport.iwmnt+workareaPath+File.separator+"html/deere"+File.separator+parentBranch+File.separator+locale+File.separator+"website";
				sitesFolder = SitemapReport.iwmnt+workareaPath+File.separator+"sites/deere"+File.separator+parentBranch+File.separator+locale+File.separator+"website";
                Instant start = Instant.now();
				htmlMap = TeamSiteCommonUtils.getFolderMap(htmlFolder);
				pageMap = TeamSiteCommonUtils.getFolderMap(sitesFolder);

                  //htmlMap = TeamSiteCommonUtils.gethtmlMapbyStream(htmlFolder);
				LOGGER.debug("Size of htmlMap is >>>>>>################"+htmlMap.size());
				LOGGER.debug("Size of htmlMap is >>>>>>################"+pageMap.size());
				LOGGER.debug("Contents of htmlMap is >>>>>>################"+htmlMap);
				Instant end = Instant.now();

				Duration interval = Duration.between(start, end);

				LOGGER.debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    Execution time in seconds: >>>>>>>>>>>>>>>>>>>>>>>>>>" +interval.getSeconds());
				LOGGER.debug("Locale is >>>>>>"+locale);
				String sitemapFile = TeamSiteCommonUtils.getSiteMap(settings);
				settings.setSitemapFile(sitemapFile);
				LOGGER.debug("sitemapFile  is >>>>>>"+sitemapFile);
				if(sitemapFile.isEmpty() || sitemapFile != null || !"".equals(sitemapFile)) {
					Sitemapurls = new ArrayList<String>();
					Sitemapurls= TeamSiteCommonUtils.getSiteMapUrls(settings);
					settings.setSitemapurls(Sitemapurls);
					LOGGER.debug("Size of Sitemapurls is >>"+Sitemapurls.size());
                    String DictionaryFile = TeamSiteCommonUtils.getSiteDictionary(settings);
                    settings.setDictionaryFile(DictionaryFile);
                    translatedSitemapurls= TeamSiteCommonUtils.getSiteMapUrls(settings,true);
                    
                    //System.out.println("translatedSitemapurls>>"+translatedSitemapurls.toString());
                    LOGGER.debug("Size of translatedSitemapurls is >>"+translatedSitemapurls.size());
                    
                    List<Future<SitemapPages>> SiteMapDetails = TeamSiteCommonUtils.getPageDetails(translatedSitemapurls);
                    
                    LOGGER.debug( "SiteMapDetails.size()   >>>"+SiteMapDetails.size());
                   
                    translatedSitemapurls.clear();
        			for (Future<SitemapPages> f : SiteMapDetails) {
        				try {
        					SitemapPages u = f.get();
        						translatedSitemapurls.add(u);
                            } catch (Exception e) {
        					
        				}
        			}
        			 System.out.println( "StranslatedSitemapurls size after Clear  >>>"+translatedSitemapurls.size());
        			// System.out.println( "SiteMapDetails.size()   >>>"+translatedSitemapurls.toString());
					for (SitemapPages sp :translatedSitemapurls) {
						if(sp.getTeamsitePage()==null) {
							String pagePathFromTeamSite=pageMap.get(sp.getKeyTranslatedSiteMapPagePath());
							if(pagePathFromTeamSite !=null) {
								String[] pagePathFromTeamSiteArray = pagePathFromTeamSite.split(workareaPath);
								sp.setTeamsitePage(pagePathFromTeamSiteArray[1]);
								//System.out.println("pagePathFromTeamSite >>>>>"+pagePathFromTeamSiteArray[1]);
								sp.setContainsIndexPage(Boolean.TRUE);
							}
							else {
								sp.setTeamsitePage("No TeamSite Page Found");
								teamsitePageNotVlid.add(sp);
							}
							
						}

						if(sp.getKeySiteMapPagePath()!= null){
							LOGGER.debug("><=========================================================================================================");
							
							String strKeySiteMapPagePath = sp.getKeySiteMapPagePath().replaceAll("\\s+", "");
							strKeySiteMapPagePath = strKeySiteMapPagePath.replaceAll("//", "/");
							LOGGER.debug("Checkin->"+strKeySiteMapPagePath);
							String htmlPathFromTeamSite=htmlMap.get(strKeySiteMapPagePath);
							LOGGER.debug("Got "+htmlPathFromTeamSite);
							LOGGER.debug("=========================================================================================================");
							
							
							if(htmlPathFromTeamSite !=null) {
						   //System.out.println("htmlPathFromTeamSite >>>>>"+htmlPathFromTeamSite);
							sp.setContainsIndexHTML(Boolean.TRUE);
							//System.out.println("Contain index File is >>>>>>"+sp.toString());
							}
							else {
								//System.out.println("Contain index File is >>>>>>"+sp.toString());
								httpstatusNotVlid.add(sp);
							}
						}
					}

					//System.out.println("Count of HTTP_STATUS_CODE  invalid >>"+httpstatusNotVlid.toString() );
					//System.out.println("Count of NO TEAMSITE PAGE AVAILABE   >>"+teamsitePageNotVlid.size() );
					//System.out.println("Count of NO INDEC HTML AVAILABLE >>"+httpstatusNotVlid.size() );
					
					//System.out.println("Count of NO INDEC HTML AVAILABLE >>"+translatedSitemapurls.toString() );
					settings.setSitemapPages(translatedSitemapurls);
					settings.setTaskid(task.getId());
					String ReportFile = TeamSiteCommonUtils.generateReport(settings);
					task.getWorkflow().setVariable("ReportStatus", "yes");
					task.getWorkflow().setVariable("ReportPath", ReportFile);
					task.getWorkflow().setVariable("subject", task.getVariable("subject"));
				}
				
				
				else {
					LOGGER.debug("Sitemap File is not available for >>"+workareaPath );
					 task.getWorkflow().setVariable("ReportStatus", "no");
				}

				
			} catch (CSAuthenticationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSRemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			task.chooseTransition(task.getTransitions()[0], "URL Mapping Report Generated");
}
	
	
		
	}


	


		// TODO Auto-generated method stub
		
   
