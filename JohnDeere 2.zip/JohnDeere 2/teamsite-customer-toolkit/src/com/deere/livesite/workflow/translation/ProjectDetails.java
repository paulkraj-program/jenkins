package com.deere.livesite.workflow.translation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

import com.deere.livesite.authoring.common.constants.PIMContsants;
import com.deere.livesite.authoring.utils.DocumentUtils;
import com.deere.livesite.workflow.exception.CustomRuntimeException;
import com.deere.livesite.workflow.syndication.AbstractSendForTranslationTask;
import com.deere.livesite.workflow.common.urlmapping.URLMappingCommonServices;
import com.deere.livesite.workflow.constants.TranslationConstants;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.livesite.file.impl.CsFileDal;

/**
 * ProjectDetails is a class responsible for building the project details
 * section of the Across control.xml file. The content for the section is pulled
 * from the CSTask upon construction of the ProjectDetails class.
 * 
 * @author Klish Group, Inc. [ND]
 * 
 *         US91392 : Adding page information in <acrossPjtDesc> in control xml
 */
public class ProjectDetails {
	private static final transient Logger LOGGER = Logger.getLogger(ProjectDetails.class);

	private static final String VAR_PROJECT_NAME_PREFIX = "ProjectNamePrefix";
	private static final String VAR_PROJECT_PO = "ProjectPO";
	private static final String VAR_DESCRIPTION = "ProjectDescription";
	private static final String VAR_PROJECT_TYPE = "ProjectType";
	private static final String VAR_DEADLINE = "ProjectDeadline";
	private static final String VAR_SETTING_TEMPLATE_NAME = "SettingTemplateName";
	private static final String VAR_PARTIAL_CHECKOUT_INDICATOR = "PartialCheckoutIndicator";

	private static final String VAR_RELATION = "Relation";
	private static final String VAR_REGION = "Region";
	private static final String PIPE_SEPRATOR = "|";
	private static final String FORMAT_DEADLINE_VAR = "MM/dd/yyyy HH:mm";
	private static final String ANALYTICS_COMPONENT_DISPLAY_NAME = "Analytics";
	private static final String FORMAT_DEADLINE_DATE = "yyyyMMdd";
	private static final String FORMAT_DEADLINE_TIME = "HH:mm";
	private static final String TEAMSITE_LIVESITE_PAGETYPE = "TeamSite/LiveSite/PageType";
	public static final String DEFAULT_URL_MAP_FOLDER_PATH = "templatedata/URLMapping/MappingList/data/";
	private String name; // deeredotcom_1553700_MP42657_20170103_09.52.30
	private String description;
	private String type; // "Released";
	private ArrayList<String> manager; // "vavp0m\\CROSS001Q00L";
	private Date deadline;
	private String settingTemplateName; // "Deere.com-Marketing";

	private String partialCheckoutIndicator; // ???
	private StringBuilder pagePath = new StringBuilder();
	private StringBuilder pageMetaInfo = new StringBuilder();
	private String relation;
	private String region;
	Map<String, String> urlMap = new HashMap<String, String>();
	private static final String PREVIEW_DOMAIN_NAME="previewNode";
	/**
	 * Build a new instance of the ProjectDetails class using the provided
	 * CSTask instance.
	 * 
	 * @param task
	 *            The current CSTask instance
	 * @throws CSException
	 */
	public ProjectDetails(CSTask task, CSClient client, String ownerName, String metaTag) throws CSException {
		String namePrefix = task.getVariable(VAR_PROJECT_NAME_PREFIX);
		String pageInfoType = null;
		if (namePrefix == null || "".equals(namePrefix)) {
			namePrefix = "deeredotcom_";
		} else if (namePrefix != null && "***".equals(namePrefix)) {
			// Add a sentinel value for the empty string since we default on an
			// empty value
			// and the other workflows currently depend on that fact.
			namePrefix = "";
		}

		name = namePrefix + task.getWorkflowId() + "_" + ownerName;

		if (metaTag != null &&  !"".equals(metaTag)) {
			LOGGER.debug("Meta tag value available: " + metaTag + " update name ");
			name = name + "_" + metaTag;
		}

		LOGGER.debug("Project Name: " + name);
		try{
		CSFile[] files = task.getArea().getFiles(task.getFiles());
		URLMappingCommonServices.readPropertiesFile(task);
		String domainNameForPage=URLMappingCommonServices.properties.getProperty(PREVIEW_DOMAIN_NAME);
		LOGGER.debug("Preview Domain Name "+domainNameForPage);
		
		for (CSFile csfile : files) {
			LOGGER.debug("Process files to find and add page path :"+csfile.getVPath().getExtension());
			//Checking if file is .page and set its translated path in the project description
			if ((null != csfile.getVPath().getExtension())
					&& (csfile.getVPath().getExtension().equalsIgnoreCase(TranslationConstants.PAGE))) {
				LOGGER.debug("csfile area relative path for .page " + csfile.getVPath().getAreaRelativePath().toString());
				 
				 if(URLMappingCommonServices.isTranslationRequiredForSite(csfile.getVPath().toString())) {
				 urlMap=getTranslationMap(csfile.getVPath().toString(),task);
				 if (csfile.getVPath().getAreaRelativePath().toString().startsWith("sites") && urlMap !=null && urlMap.size() > 0 ) {
					String filePathWithoutSite = csfile.getVPath().getAreaRelativePath().toString().replace("sites", "html");
					LOGGER.debug("filePathWithoutSite : processing page :" + filePathWithoutSite);
					try{
					LOGGER.debug("is Translation Required For Site : processing page :"+URLMappingCommonServices.isTranslationRequiredForSite(filePathWithoutSite));
					CSAreaRelativePath translatedFilePath = new CSAreaRelativePath(URLMappingCommonServices.getTranslatedFilePath(filePathWithoutSite.replace(".page", ".html"), urlMap));
					LOGGER.debug("HTML Path value adding to description : processing page :" + domainNameForPage+URLMappingCommonServices.updateURL(translatedFilePath.toString()));
					pagePath.append(domainNameForPage).append(URLMappingCommonServices.updateURL(translatedFilePath.toString())).append(TranslationConstants.NEXT_LINE_DELIMITER);
					}
					catch(CustomRuntimeException translationNotFoundEx){
						LOGGER.error(translationNotFoundEx.getMessage());
						LOGGER.debug("Mapping file not found updating page path" + csfile.getVPath().toString());
						pagePath.append(csfile.getVPath().toString()).append(TranslationConstants.NEXT_LINE_DELIMITER);
					}
				}
				}
				 
				 else if (csfile.getVPath().getAreaRelativePath().toString().startsWith("sites")) {
							LOGGER.debug("EN based locale processing file "+csfile.getVPath().getAreaRelativePath().toString());
							String filePathWithoutSite = csfile.getVPath().getAreaRelativePath().toString().replace("sites", "html").replace(".page", ".html");
							LOGGER.debug("filePathWithoutSite : processing page :" + filePathWithoutSite);
							LOGGER.debug("HTML Path value adding to description : processing page :" + domainNameForPage+URLMappingCommonServices.updateURL(filePathWithoutSite));
							pagePath.append(domainNameForPage).append(URLMappingCommonServices.updateURL(filePathWithoutSite)).append(TranslationConstants.NEXT_LINE_DELIMITER);
						}
					 
				 
			
				pageInfoType = getRequestType(csfile);
				pageMetaInfo.append(getMetaTagFromPage(csfile, client, task, pageInfoType)).append("\n");
				LOGGER.debug("Page Path value " + pagePath);
			}	
			
			//Checking if file is pim_data.json and set its parent translated path in the project description
			else if((null != csfile.getVPath().getExtension())
					&& (csfile.getVPath().getExtension().equalsIgnoreCase(TranslationConstants.JSON_EXT))) {
				LOGGER.debug("csfile area relative parent path for JSON " + csfile.getParent().getVPath().getAreaRelativePath().toString());
				 
				 if(URLMappingCommonServices.isTranslationRequiredForSite(csfile.getVPath().toString())) {
				 urlMap=getTranslationMap(csfile.getParent().getVPath().toString(),task);
				 if (csfile.getParent().getVPath().getAreaRelativePath().toString().startsWith("sites") && urlMap !=null && urlMap.size() > 0 ) {
					String filePathWithoutSite = csfile.getParent().getVPath().getAreaRelativePath().toString().replace("sites", "html");
					LOGGER.debug("filePathWithoutSite : processing JSON :" + filePathWithoutSite);
					try{
					LOGGER.debug("is Translation Required For Site : processing JSON :"+URLMappingCommonServices.isTranslationRequiredForSite(filePathWithoutSite));
					CSAreaRelativePath translatedFilePath = new CSAreaRelativePath(URLMappingCommonServices.getTranslatedFilePath(filePathWithoutSite, urlMap));
					LOGGER.debug("JSON Web Path adding to description : processing JSON :" + domainNameForPage+URLMappingCommonServices.updateURL(translatedFilePath.toString()));
					pagePath.append(domainNameForPage).append(URLMappingCommonServices.updateURL(translatedFilePath.toString())).append(TranslationConstants.NEXT_LINE_DELIMITER);
					}
					catch(CustomRuntimeException translationNotFoundEx){
						LOGGER.error(translationNotFoundEx.getMessage());
						LOGGER.debug("Mapping file not found updating page path" + csfile.getVPath().toString());
						pagePath.append(csfile.getVPath().toString()).append(TranslationConstants.NEXT_LINE_DELIMITER);
					}
				}
				}
				 else if (csfile.getVPath().getAreaRelativePath().toString().startsWith("sites")) {
					   String filePathWithoutSite = csfile.getParent().getVPath().getAreaRelativePath().toString().replace("sites", "html");
						LOGGER.debug("filePathWithoutSite : processing JSON :" + filePathWithoutSite);
						LOGGER.debug("HTML Path value adding to description : processing JSON :" + domainNameForPage+URLMappingCommonServices.updateURL(filePathWithoutSite));
						pagePath.append(domainNameForPage).append(URLMappingCommonServices.updateURL(filePathWithoutSite)).append(TranslationConstants.NEXT_LINE_DELIMITER);
						LOGGER.debug("JSON Path value " + pagePath);
				 }
			}
			
		}
		
		}
		catch (Exception e) {
			LOGGER.debug("Exception occured during translating urls ");			
		}

		LOGGER.debug("Adding PagePath :" + (pagePath != null && !pagePath.toString().equals("")
				? pagePath.substring(0, pagePath.length() - 1) : ""));
		// Adding pagepath in the project description in Across end
		description = task.getVariable(VAR_PROJECT_PO) + " " + task.getVariable(VAR_DESCRIPTION) + " "
				+ (pageMetaInfo != null && !"".equals(pageMetaInfo.toString()) ? pageMetaInfo : "") + TranslationConstants.NEXT_LINE_DELIMITER + TranslationConstants.NEXT_LINE_DELIMITER
				+ (pagePath != null && !"".equals(pagePath.toString()) ? pagePath : "");

		LOGGER.debug("Project Description: " + description);

		type = task.getVariable(VAR_PROJECT_TYPE);
		LOGGER.debug("Project Type: " + type);

		manager = TranslationJob.getJobContactName(task);
		LOGGER.debug("Project Manager: " + manager);

		String deadlineString = task.getVariable(VAR_DEADLINE);
		LOGGER.debug("Project Deadline: " + deadlineString);
		try {
			deadline = new SimpleDateFormat(FORMAT_DEADLINE_VAR).parse(deadlineString);
		} catch (ParseException pe) {
			LOGGER.warn("Failed to parse deadline date: " + deadlineString);
			LOGGER.warn(pe.getLocalizedMessage());
			LOGGER.warn("Setting deadline to 20 days from today");

			Calendar calendar = new GregorianCalendar();
			calendar.add(Calendar.DAY_OF_YEAR, 20);
			deadline = calendar.getTime();
		}

		settingTemplateName = task.getVariable(VAR_SETTING_TEMPLATE_NAME);
		LOGGER.debug("Project Settings Template Name: " + settingTemplateName);

		partialCheckoutIndicator = task.getVariable(VAR_PARTIAL_CHECKOUT_INDICATOR);
		LOGGER.debug("Project Partial Checkout Indicator: " + partialCheckoutIndicator);

		relation = task.getVariable(VAR_RELATION);
		LOGGER.debug("Project Attribute Relation: " + relation);

		region = task.getVariable(VAR_REGION);
		LOGGER.debug("Project Attribute Region: " + region);
	}

	/**
	 * Generic method to retrieve Analytics Component by parsing a sitepublisher
	 * page
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param file
	 *            CSFile object (Sitepublisher page file)
	 * @return String TagType can be category or product
	 * @throws CSException
	 */

	private String getMetaTagFromPage(CSFile csFile, CSClient client, CSTask task, String tagType) {

		String metaData = "";

		try {
			Document document = new DocumentUtils(
					new CsFileDal(((CSWorkarea) task.getArea()).getVPath().toString(), client))
							.retrieveDocument(csFile.getVPath().getAreaRelativePath().toString());
			String analyticsDcrFilepath = getPageTagsDCR(document);
			LOGGER.debug("analyticsDcr File path " + analyticsDcrFilepath);
			if (analyticsDcrFilepath != null) {
				LOGGER.debug("Parsing Analytics DCR for metadata ");
				LOGGER.debug("CSV transform " + new CSVPath(analyticsDcrFilepath).toString());
				LOGGER.debug("HostName " + task.getArea().getVPath().getPathNoServer().toString());
				LOGGER.debug("analyticsDcrFile getVPath() " + task.getArea().getVPath().getPathNoServer().toString()
						+ "/" + analyticsDcrFilepath);
				CSFile analyticsDcrFile = client.getFile(new CSVPath(
						task.getArea().getVPath().getPathNoServer().toString() + "/" + analyticsDcrFilepath));
				Document analyticsDcrDocument = new DocumentUtils(
						new CsFileDal(((CSWorkarea) analyticsDcrFile.getArea()).getVPath().toString(), client))
								.retrieveDocument(analyticsDcrFile.getVPath().getAreaRelativePath().toString());
				LOGGER.debug("analyticsDcrDocument " + analyticsDcrDocument.asXML());
				if (analyticsDcrDocument != null && tagType != null) {
					// Check for category-name/product-model
					LOGGER.debug("Fetching Product/category Type");
					if (StringUtils.equals(tagType, PIMContsants.PRODUCT)) {
						LOGGER.debug("Page is product");
						metaData = analyticsDcrDocument.selectSingleNode(
								"/" + analyticsDcrDocument.getRootElement().getName() + "//MetaData/product-model-name")
								.getText();
					} else if (StringUtils.equals(tagType, PIMContsants.CATEGORY)) {
						LOGGER.debug("Page is category");
						metaData = analyticsDcrDocument.selectSingleNode(
								"/" + analyticsDcrDocument.getRootElement().getName() + "//MetaData/category-name")
								.getText();
					}

				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception occured  in the method getMetaTagFromPage for ProjectDetails",e);
			LOGGER.debug("Error during fetching MetaTag from attached page" + csFile.getVPath().toString());
		}
		return metaData;
	}

	/**
	 * Method to get analytics DCR file to fetch category/product information
	 * for sitepublisher pages
	 * 
	 * @param document
	 * @return Analytics DCR name
	 */
	private static String getPageTagsDCR(Document document) {
		LOGGER.debug("Processing page to find analytics DCR");
		@SuppressWarnings("unchecked")
		List<Node> nodes = document.selectNodes("/" + document.getRootElement().getName() + "//Page_Content" + "/*");

		for (Node node : nodes) {
			LOGGER.debug(" Processing PageContent nodes ");
			if (node.getName().equals(TranslationConstants.COMPONENT)) {
				LOGGER.debug("Looking for Analytics component");
				if (StringUtils.equalsIgnoreCase(
						node.selectSingleNode(TranslationConstants.DISPLAY_NAME_ATTR).getText(),
						ANALYTICS_COMPONENT_DISPLAY_NAME)) {

					@SuppressWarnings("unchecked")
					List<Node> segmentTag = node.selectSingleNode(TranslationConstants.SEGMENTS)
							.selectNodes(TranslationConstants.SEGMENTS_TAGS);
					for (Node segmentNode : segmentTag) {
						Element datumDCREle = (Element) segmentNode
								.selectSingleNode("//Datum" + "/" + "DCR[@Type='analytics']");
						if(datumDCREle != null) {
							LOGGER.debug("Found analytics DCR " + datumDCREle.getText());
							return datumDCREle.getText();
						}
						else
						{
							return null;
						}
					}
				}

			}

		}
		return null;

	}

	/**
	 * Build a new instance of the ProjectDetails class using the provided
	 * CSTask instance.
	 * 
	 * @param task
	 *            The current CSTask instance
	 * @throws CSException
	 */
	public ProjectDetails(CSTask task, String ownerName) throws CSException {
		String namePrefix = task.getVariable(VAR_PROJECT_NAME_PREFIX);
		if (namePrefix == null || "".equals(namePrefix)) {
			namePrefix = "deeredotcom_";
		} else if (namePrefix != null && "***".equals(namePrefix)) {
			// Add a sentinel value for the empty string since we default on an
			// empty value
			// and the other workflows currently depend on that fact.
			namePrefix = "";
		}

		name = namePrefix + task.getWorkflowId() + "_" + ownerName;
		LOGGER.debug("Project Name: " + name);

		description = task.getVariable(VAR_PROJECT_PO) + " " + task.getVariable(VAR_DESCRIPTION);
		LOGGER.debug("Project Description: " + description);

		type = task.getVariable(VAR_PROJECT_TYPE);
		LOGGER.debug("Project Type: " + type);

		manager = TranslationJob.getJobContactName(task);
		LOGGER.debug("Project Manager: " + manager);

		String deadlineString = task.getVariable(VAR_DEADLINE);
		LOGGER.debug("Project Deadline: " + deadlineString);
		try {
			deadline = new SimpleDateFormat(FORMAT_DEADLINE_VAR).parse(deadlineString);
		} catch (ParseException pe) {
			LOGGER.warn("Failed to parse deadline date: " + deadlineString);
			LOGGER.warn(pe.getLocalizedMessage());
			LOGGER.warn("Setting deadline to 20 days from today");

			Calendar calendar = new GregorianCalendar();
			calendar.add(Calendar.DAY_OF_YEAR, 20);
			deadline = calendar.getTime();
		}

		settingTemplateName = task.getVariable(VAR_SETTING_TEMPLATE_NAME);
		LOGGER.debug("Project Settings Template Name: " + settingTemplateName);

		partialCheckoutIndicator = task.getVariable(VAR_PARTIAL_CHECKOUT_INDICATOR);
		LOGGER.debug("Project Partial Checkout Indicator: " + partialCheckoutIndicator);

		relation = task.getVariable(VAR_RELATION);
		LOGGER.debug("Project Attribute Relation: " + relation);

		region = task.getVariable(VAR_REGION);
		LOGGER.debug("Project Attribute Region: " + region);
	}

	// We need this constructor for the builder method later
	private ProjectDetails() {
	}

	/** Get the project name */
	public String getName() {
		return name;
	}

	/** Get the project description */
	public String getDescription() {
		return description;
	}

	/** Get the project type */
	public String getType() {
		return type;
	}

	/** Get the project manager */
	/*
	 * public String getManager() { return manager; }
	 */

	public ArrayList<String> getManager() {
		return manager;
	}

	/** Get the project deadline date */
	public Date getDeadline() {
		return deadline;
	}

	/** Get the project setting template name */
	public String getSettingTemplateName() {
		return settingTemplateName;
	}

	/** Get the project partial checkout indicator */
	public String getPartialCheckoutIndicator() {
		return partialCheckoutIndicator;
	}
	
	/** Get the project relation US9412 */ 
	public String getRelation() {
		return relation;
	}

	/**
	 * Build the project details element for the Across control.xml file
	 * 
	 * @return The XML Element instance containing the project details.
	 */
	public Element toElement() {
		Element element = DocumentHelper.createElement("pjtDtls");

		element.addElement("acrossPjtNm").setText(name);
		element.addElement("acrossPjtDesc").setText(description);

		Element projectManagerElement = element.addElement("pjtMgrDtls");
		// element.addElement("pjtMgrDtls").addElement("pjtMgrNm").setText(manager);
		for (String managerItem : manager) {
			projectManagerElement.addElement("pjtMgrNm").setText(managerItem);
		}

		element.addElement("pjtType").setText(type);

		Element deadlineElement = element.addElement("pjtDeadline");

		deadlineElement.addElement("deadlineDate").setText(new SimpleDateFormat(FORMAT_DEADLINE_DATE).format(deadline));
		deadlineElement.addElement("deadlineTime").setText(new SimpleDateFormat(FORMAT_DEADLINE_TIME).format(deadline));

		element.addElement("acrossPstNm").setText(settingTemplateName);

		element.addElement("partialCheckoutInd").setText(partialCheckoutIndicator);

		if ((relation != null && !"".equals(relation)) || (region != null && !"".equals(region))) {
			Element projectAttributesElement = element.addElement("acrossPjtAttribs");

			if (relation != null && !"".equals(relation)) {
				projectAttributesElement.addElement("relation").setText(relation);
			}
			if (region != null && !"".equals(region)) {
				projectAttributesElement.addElement("gomRegion").setText(region);
			}
		}

		return element;
	}

	/**
	 * Build a ProjectDetails instance from the provided XML Element instance.
	 * 
	 * @param element
	 *            The XML Element instance from which to build a ProjectDetails
	 * @return The ProjectDetails instance built from the provided XML Element
	 *         instance
	 */
	static ProjectDetails build(Element element) {
		String name = element.elementText("acrossPjtNm");
		LOGGER.debug("Project Name: " + name);
		String description = element.elementText("acrossPjtDesc");
		LOGGER.debug("Project Description: " + description);
		String type = element.elementText("pjtType");
		LOGGER.debug("Project Type: " + type);
		List<Node> managerNode = element.selectNodes("pjtMgrDtls/pjtMgrNm");
		List<String> managerList = new ArrayList<String>();
		for (Node managerItem : managerNode) {
			managerList.add(managerItem.getText());
		}

		LOGGER.debug("Project Manager: " + managerList.toString());

		Element deadlineElement = element.element("pjtDeadline");
		String deadlineDate = deadlineElement.elementText("deadlineDate");
		String deadlineTime = deadlineElement.elementText("deadlineTime");
		LOGGER.debug("Project Deadline: " + deadlineDate + " " + deadlineTime);

		Date deadline = new Date();
		try {
			deadline = new SimpleDateFormat(FORMAT_DEADLINE_DATE + FORMAT_DEADLINE_TIME)
					.parse(deadlineDate + deadlineTime);
		} catch (ParseException pe) {
			LOGGER.warn("Failed to parse deadline date: " + deadlineDate + " " + deadlineTime);
			LOGGER.warn(pe.getLocalizedMessage());
		}

		String settingTemplateName = element.elementText("acrossPstNm");
		LOGGER.debug("Project Setting Template Name: " + settingTemplateName);

		String partialCheckoutIndicator = element.elementText("partialCheckoutInd");
		LOGGER.debug("Project Partial Checkout Indicator: " + partialCheckoutIndicator);

		String relation = "";
		Element relationElement = (Element) element.selectSingleNode("acrossPjtAttribs/relation");
		if (relationElement != null) {
			relation = relationElement.getText();
		}

		String region = "";
		Element regionElement = (Element) element.selectSingleNode("acrossPjtAttribs/region");
		if (regionElement != null) {
			region = regionElement.getText();
		}

		ProjectDetails projectDetails = new ProjectDetails();

		projectDetails.name = name;
		projectDetails.description = description;
		projectDetails.type = type;
		projectDetails.manager = new ArrayList<String>();
		projectDetails.manager.addAll(managerList);
		projectDetails.deadline = deadline;
		projectDetails.settingTemplateName = settingTemplateName;
		projectDetails.partialCheckoutIndicator = partialCheckoutIndicator;
		projectDetails.relation = relation;
		projectDetails.region = region;

		return projectDetails;
	}

	/**
	 * This method checks page's extended attribute(TeamSite/LiveSite/PageType)
	 * to check whether the page is category or product page.
	 * 
	 * @param csFile
	 *            of the page
	 * @return returns either category/product if extended attribute present,
	 *         otherwise returns null
	 * @throws CSException
	 */
	private String getRequestType(CSFile csFile) throws CSException {
		if (csFile != null && csFile instanceof CSSimpleFile) {
			CSSimpleFile csPage = (CSSimpleFile) csFile;
			CSExtendedAttribute csAttrib = csPage.getExtendedAttribute(TEAMSITE_LIVESITE_PAGETYPE);
			if (csAttrib == null)
				return null;
			return csAttrib.getValue();
		}

		return null;
	}
	/**
	 * This method translates the file path
	 * @param pagePath
	 * @return translated path
	 * @throws CSException 
	 * @throws CSExpiredSessionException 
	 * @throws CSObjectNotFoundException 
	 * @throws CSRemoteException 
	 * @throws CSAuthorizationException 
	 */
	private Map<String, String> getTranslationMap(String pagePath,CSTask task) {
		Map<String, String> urlMap = new HashMap<String, String>();
	/*	String urlMappingFolderPath = task.getVariable("UrlMappingFolderPath");
		if (urlMappingFolderPath == null || urlMappingFolderPath.isEmpty())*/
		String	urlMappingFolderPath = DEFAULT_URL_MAP_FOLDER_PATH;
		LOGGER.debug("URL Mapping Folder Path " + urlMappingFolderPath);
		try{
		String urlMappingFile = URLMappingCommonServices.generateMappingFilePath(task.getFiles(),
				urlMappingFolderPath);
		LOGGER.debug("URL Mapping File Path " + urlMappingFile);
		CSFile csURLMappingFile = task.getArea().getFile(new CSAreaRelativePath(urlMappingFile));
		urlMap = URLMappingCommonServices.generateURLMap(csURLMappingFile);
		return urlMap;
		}
		catch(Exception ex){
			LOGGER.debug("Exception Occured during parsing URL Mapping file");
		}
		return null;
	}

}
