package com.deere.livesite.workflow.translation;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * AcrossMultiArchiveRetrievalTask is an implementation of IRetrievalTask.  This
 * implementation takes a list of IRetrievalTask instances and invoked the
 * retrieval process on each of those instances whenever the retrieval process
 * is invoked on this instance.
 * @author Klish Group, Inc. [ND]
 */
class AcrossMultiArchiveRetrievalTask implements IRetrievalTask {
	private static final transient Logger LOGGER = Logger.getLogger(AcrossMultiArchiveRetrievalTask.class);
	
	private final List<IRetrievalTask> tasks;
	
	/**
	 * Create a new AcrossMultiArchiveRetrievalTask instance with the provided
	 * set of tasks.
	 * @param tasks The set of IRetrievalTask instances
	 */
	public AcrossMultiArchiveRetrievalTask(IRetrievalTask ...tasks) {
		this.tasks = Arrays.asList(tasks);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		try {
			doRetrieval();
		} catch (IOException ioe) {
			LOGGER.error("Failed during translation project retrieval process", ioe);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.translation.IRetrievalTask#doRetrieval()
	 */
	@Override
	public void doRetrieval() throws IOException {
		for (IRetrievalTask task : tasks) {
			task.doRetrieval();
		}
	}
	
}
