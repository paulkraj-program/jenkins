package com.deere.livesite.workflow.syndication;

/**
 * SendForTranslationFromTargetBranchTask is an CSURLExternalTask implementation that is
 * responsible for packaging and deploying a project to the Across FTP server.
 * This external builds the control.xml file based on the selected user settings
 * and then builds the archive containing the content.  Once the archive is
 * built it is then uploaded to the Across FTP server.
 * @author Klish Group, Inc. [ND]
 */
public class SendForTranslationFromTargetBranchTask extends SendForTranslationTask {
	
	private static final String ARCHIVE_FILENAME_PREFIX = "Deere.com_";
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.syndication.SendForTranslationTask#getArchiveFilenamePrefix()
	 */
	@Override
	protected String getArchiveFilenamePrefix() {
		return ARCHIVE_FILENAME_PREFIX;
	}
	
}
