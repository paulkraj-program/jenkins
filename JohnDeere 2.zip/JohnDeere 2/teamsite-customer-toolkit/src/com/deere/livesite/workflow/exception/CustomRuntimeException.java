package com.deere.livesite.workflow.exception;

public class CustomRuntimeException extends RuntimeException{
	
	/**
	 * Business specific exceptions
	 */
	private static final long serialVersionUID = 1L;

	public CustomRuntimeException(String msg) {
		super(msg);
	}        
}
         