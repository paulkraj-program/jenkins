package com.deere.livesite.workflow.translation;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.owasp.esapi.ESAPI;

import com.deere.livesite.workflow.common.Utlis;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSWorkarea;

public class AkeneoRetrievalPostProcessor implements IRetrievalPostProcessor {
	private static final Logger LOGGER = Logger.getLogger(AkeneoRetrievalPostProcessor.class);
//	private static final org.owasp.esapi.Logger ESAPI_LOGGER = ESAPI.getLogger(AkeneoRetrievalPostProcessor.class);
	private static final String URL_AKENEO_POSTBACK = "{0}/api/rest/translation";
	private static final String URL_WSO2_PRODUCT = "{0}/tscapi/updateproduct/{1}/{2}/{3}?SendForTranslation=n";
	private static final String URL_WSO2_CATEGORY = "{0}/tscapi/updatecategory/{1}/{2}/{3}?SendForTranslation=n";
	private static final String CUSTOM_RETRIEVAL = "/iwadmin/main/deere/syndication/STAGING/configuration/custom-retrieval.properties";
	private Properties retrievalProperties = null;
	private boolean isNdwsSite = false;
	private final String akeneoHost;
	private final String wso2Host;
	private final String akeneoTokenSvc;
	private static final String NDWS_LOCALE = "NDWS_LOCALE";
	private static final String ENCODING_UTF8 = "UTF-8";

	public AkeneoRetrievalPostProcessor(String akeneoHost, String wso2Host, String akeneoTokenSvc) {
		this.akeneoHost = akeneoHost;
		this.akeneoTokenSvc = akeneoTokenSvc;
		this.wso2Host = wso2Host;
	}

	@Override
	public void process(CSClient client, CSWorkarea targetArea, CSSimpleFile targetFile, String sourceInput,
			SyndicationTarget source, SyndicationTarget target) throws IOException, CSException {
		// Rebuild the translated content from the target content so the black
		// list does not need to be supplied to the codec
		LOGGER.debug("AkeneoRetrievalPostProcessor process :: SyndicationTarget source is >>>>>>>>>"+source);
		AkeneoDataCodec codec = new AkeneoDataCodec(null);
		retrievalProperties = Utlis.loadProperties(client, CUSTOM_RETRIEVAL);
		try {
			LOGGER.debug("XML formed from inputstream " + sourceInput);
			// Post process the XML content back to the proper JSON content

			Document document = DocumentHelper.parseText(sourceInput);
			LOGGER.debug("Processing File " + targetFile.getName());
			if (targetFile != null && targetFile.getName().equals("pim_data.json")) {
				LOGGER.debug("Content Update");
				String replacedContent = updateAcrossJson(document.asXML(), target);
				if (replacedContent != null && !replacedContent.isEmpty()) {
					LOGGER.debug("Content Replaced");
					Document doc = DocumentHelper.parseText(replacedContent);
					LOGGER.debug("Updated Content " + doc.asXML());
					postToAkeneo(client, targetFile, codec, doc, target, source);
				} else {
					LOGGER.debug("Content No Replaced PIM File");
					postToAkeneo(client, targetFile, codec, document, target, source);
				}
			} else {
				LOGGER.debug("Content No Replaced");
				postToAkeneo(client, targetFile, codec, document, target, source);
			}
		} catch (DocumentException de) {
			throw new CSException(de);
		}
	}

	private String replaceWithPattern(String originalContent, String replaceWith, Pattern pattern) {
		Matcher m = pattern.matcher(originalContent);
		return m.replaceAll(replaceWith);
	}

	private String updateAcrossJson(String jsonContent, SyndicationTarget target) {
		if (jsonContent != null && !jsonContent.isEmpty()) {
			LOGGER.debug("Original Content " + jsonContent);
			String locale = target.getLocale();
			// Fix for SABO Branches
			Pattern pattern = Pattern.compile("([0-9a-zA-Z]*)(-|_)([0-9a-zA-Z]*)");
			Matcher matcher = pattern.matcher(locale);
			String language = "";
			String country = "";
			if (matcher.find()) {
				language = matcher.group(1).toLowerCase();
				country = matcher.group(3).toLowerCase();
			}

			isNdwsSite = isValidNdwsSite(retrievalProperties, locale);

			LOGGER.debug("Country: " + country + ", Language: " + language + ", Locale: " + locale);
			LOGGER.debug("XML Tag Pattern " + language + "_" + country.toUpperCase() + ">");
			LOGGER.debug("Product Name Locale Pattern " + language + "_" + country + "_");
			LOGGER.debug("Path Locale Pattern " + "/" + country + "/" + language + "/");
			String content = replaceWithPattern(jsonContent, language + "_" + country.toUpperCase() + ">",
					Pattern.compile("(?i)[a-z]{2}_[A-Z]{2}>"));
			content = replaceWithPattern(content, language + "_" + country + "_",
					Pattern.compile("(?i)[a-z]{2}_[a-z]{2}_"));
			content = replaceWithPattern(content, "/" + country + "/" + language + "/",
					Pattern.compile("(?i)/[a-z]{2}/[a-z]{2}/"));
			LOGGER.debug("Replaced Content " + content);
			return content;
		}
		return "";
	}

	private void postToAkeneo(CSClient client, CSSimpleFile targetFile, AkeneoDataCodec codec, Document document,
			SyndicationTarget target, SyndicationTarget source) throws CSException, IOException {
		// Get the identifier for the product or the category/offering
		String id = codec.getJSONId(targetFile);
		LOGGER.debug("Identifier: " + id);

		if (akeneoHost != null && !"".equals(akeneoHost)) {
			String url = MessageFormat.format(URL_AKENEO_POSTBACK, akeneoHost);
			String content = codec.decodeToJSON(client, targetFile, document, target, source);
			StringBuilder builder = new StringBuilder().append(wso2Host).append(akeneoTokenSvc);
			String tokenSvcUri = builder.toString();
			LOGGER.debug("Token Svc URL :" + tokenSvcUri);
			String akeneoAuthToken = "Bearer YWE4NzIzMDFlOTM0OGM3Y2UyZTk4Yzg5Y2UxNzIwNTRhYjI0YjcyZTExMDA0YjVlZTE2NTI2YzExMTk4YTZlYg";
			LOGGER.debug("Akeneo Auth Token: " + akeneoAuthToken);

			Header[] headers = new Header[] {
					// new BasicHeader("Authorization", "WSSE profile=\"UsernameToken\"")
					new BasicHeader("Authorization", akeneoAuthToken) };

			// Get the identifier for the product or the category/offering
			id = codec.getJSONId(content);
			LOGGER.debug("Identifier: " + id);

			doPost(url, content, headers);
		}
	}

	private void postToWSO2(CSClient client, CSSimpleFile targetFile, AkeneoDataCodec codec, Document document,
			SyndicationTarget target, SyndicationTarget source) throws CSException, FileNotFoundException, IOException {
		// Get the identifier for the product or the category/offering
		String id = codec.getJSONId(targetFile);
		LOGGER.debug("Identifier: " + id);

		if (wso2Host != null && !"".equals(wso2Host)) {
			String locale = target.getLocale();
			// Fix for SABO Branches
			Pattern pattern = Pattern.compile("([0-9a-zA-Z]*)(-|_)([0-9a-zA-Z]*)");
			Matcher matcher = pattern.matcher(locale);
			String language = "";
			String country = "";
			if (matcher.find()) {
				language = matcher.group(1).toLowerCase();
				country = matcher.group(3).toLowerCase();
			}
			LOGGER.debug("Country: " + country + ", Language: " + language + ", Locale: " + locale);

			String url = "";
			String content = codec.decodeToJSON(client, targetFile, document, target, source);

			if (codec.isProduct(targetFile)) {
				url = MessageFormat.format(URL_WSO2_PRODUCT, wso2Host, country, language, id);
			} else if (codec.isCategory(targetFile)) {
				url = MessageFormat.format(URL_WSO2_CATEGORY, wso2Host, country, language, id);
			}

			doPost(url, content);
		}
	}

	private String doPost(String uri, String content, Header... headers) throws CSException {
		if (uri == null || "".equals(uri)) {
			return "";
		}

		LOGGER.debug("Post URL: " + uri);
		LOGGER.debug("isNdwsSite: " + isNdwsSite);
		LOGGER.debug("Post Payload: " + StringEscapeUtils.unescapeHtml3(content));

		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(uri);

		for (Header header : headers) {
			post.setHeader(header);
		}

		post.setHeader("Content-Type", "application/json;charset=UTF-8");

		try {
			if (isNdwsSite) {
				post.setEntity(new StringEntity(StringEscapeUtils.unescapeHtml3(content), ENCODING_UTF8));
			} else {
				post.setEntity(new StringEntity(content, ENCODING_UTF8));
			}
			HttpResponse response = client.execute(post);
			try(BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))) {
			StringBuilder builder = new StringBuilder();
			String line = "";

			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
		
			LOGGER.info("Result[" + ESAPI.encoder().encodeForHTML(Integer.toString(response.getStatusLine().getStatusCode())) + "]: " + ESAPI.encoder().encodeForHTML(builder.toString()));

			if (response.getStatusLine().getStatusCode() != 200) {
				return "";
			}

			return builder.toString();
			}
			} catch (Exception e) {
			throw new CSException(e);
		}
	}

	private String getAuthToken(String tokenSvcUri) {
		String content = null;
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpGet request = new HttpGet(tokenSvcUri);
		try {
			HttpResponse response = httpClient.execute(request);
			HttpEntity entity = response.getEntity();
			StatusLine statusLine = response.getStatusLine();

			LOGGER.debug( "Got response status code: " + statusLine.getStatusCode());

			if (statusLine.getStatusCode() == HttpStatus.SC_OK && entity != null) {

				content = IOUtils.toString(entity.getContent(), ENCODING_UTF8);
				if (StringUtils.isNotBlank(content)) {
					LOGGER.debug("Response: " + content);
				}

			} else {
				LOGGER.debug("Could not recieve Auth token from WSO2 : Response Status :" + statusLine.getStatusCode());
			}

		} catch (IOException e) {
			LOGGER.error("Error connecting token server endpoint: " + request.getURI(), e);
		}
		return content;

	}

	private boolean isValidNdwsSite(Properties properties, String locale) {
		try {
			String[] localeArray = properties.getProperty(NDWS_LOCALE).split(",");
			LOGGER.debug("NDWS locales from property file :" + Arrays.toString(localeArray));
			for (String localeItem : localeArray) {
				if (locale.equalsIgnoreCase(localeItem)) {
					LOGGER.debug("Is a valid NDWS Site : " + locale + " Processing locale" + localeItem);
					return true;
				}
			}
		} catch (Exception ex) {
			LOGGER.debug("Error while reading property ");
			return false;
		}
		return false;
	}

}
