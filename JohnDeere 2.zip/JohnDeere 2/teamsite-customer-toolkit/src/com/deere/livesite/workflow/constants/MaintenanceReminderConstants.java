package com.deere.livesite.workflow.constants;

public class MaintenanceReminderConstants {

	

	public static final String TEMPLATE_PATH_PREFIX = "/iwadmin/main/livesite/template/STAGING/";

	public static final String KEY_EMPTY_DEFAULT = "*** No Entries ***";
	
	public static final String VAL_EMPTY_DEFAULT = "";
	
	public static final String PARAM_AREA_FOLDER_PATH = "AreaFolderPath";
	
	public static final String PARAM_FULL_FOLDER_PATH = "FullFolderPath";
	
	public static final String PARAM_CSFACTORY = "csFactory";
	
	public static final String MAINTENANCE_TEMPLATE = "deere/pages/MaintenanceReminder.template";
	
	public static final String DEFAULT_SITE_NAME = "deere";
	
	public static final String DEFAULT_PAGE_FOLDER_PATH = "/website/parts-and-service/manuals-and-training/maintenance-reminder/";
	
	public static final String TASK_PARAM_OVERWRITE_PAGE ="OVERWRITE_PAGE";
	
	public static final String TASK_PARAM_OVERWRITE_DCR ="OVERWRITE_DCR";
	
	public static final String TASK_PARAM_GENERATE_FOLDER_PATH ="GENERATE_FOLDER_PATH";
	
	public static final String TASK_PARAM_SITE_NAME ="SITE_NAME";
	
	public static final String SUCCESS_TRANSITION = "Generate Files Success";
	
	public static final String FAILURE_TRANSITION = "Generate Files Failure";
	
	public static final String PARTS_SHEET_NAME = "PARTS";
	
	public static final String MODELS_SHEET_NAME = "MODELS TO UPLOAD";
	
	public static final String CATEGORY_SHEET_NAME = "PARTS CATEGORY";
	
	public static final String PAGE_LAYOUT_ID = "fixed-layout";
	
	public static final String PAGE_TYPE_ID = "htmlQuirksMode";
	
	public static final String CANVAS_PATH = "One-Column.xml";

	public static final String PRODUCT_COMPONENT_AREA = "row-2-area-1";
	
	public static final String PRODUCT_COMPONENT_DCR_DATUM_NAME = "ProductDCR";
	
	public static final String PRODUCT_COMPONENT_NAME ="Maintenance Reminder" ;
	
	public static final String PART_DCT_PATH = "/templatedata/maintenance-reminder/Part/data/";
	
	public static final String PRODUCT_DCT_PATH = "/templatedata/maintenance-reminder/Product/data/";

	public static final String DEFAULT_ASSET_BASE_PATH = "/assets/images/maintenance-reminder/";
	
	public static final String PAGE_RESOURCE_PATH_TYPEAHEAD = "assets/scripts/components/maintenance-reminder.js";
	
	public static final String PAGE_RESOURCE_PATH_CSS = "assets/styles/components/_maintenance-reminder-component.scss";
	
	public static final String PART_NUMBER_LABEL ="Part Number";
	
	public static final String PART_QTY ="Qty";
	
	public static final String PART_CHANGE_INTERVAL = "Change Interval (Hours)";
	
}
