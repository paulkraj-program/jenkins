package com.deere.livesite.workflow.translation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * TranslationTask is a representation of a simple translation task within the
 * Across control.xml file.  This class contains the information for the source
 * locale, the target locales, the target workflow tasks on the Across server
 * side.
 * @author Klish Group, Inc. [ND]
 */
public class TranslationTask {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationTask.class);
	
	private static final String VAR_WORKFLOW_NAME = "WorkflowName";
	private static final String VAR_PERFORMER_TYPE = "PerformerType";
	private static final String VAR_PERFORMER = "Performer";
	private static final String VAR_REPORTING_TEMPLATE = "ReportingTemplate";
	private static final String VAR_PACKAGING_TEMPLATE = "PackagingTemplate";
	
	private static final String VAR_TRANSFORM_DEFAULT = "DefaultTransformTemplate";
	private static final String VAR_TRANSFORM_PAGE = "SPPageTransformTemplate";
	private static final String VAR_TRANSFORM_DCR = "DCRTransformTemplate";
	private static final String VAR_TRANSFORM_JSON = "JSONTransformTemplate";
	
	private static final String VAR_DOC_TRANSFORM = "DocTransform";
	
	private static final String DEFAULT_WORKFLOW_NAME = "Deere.com-002-Translation-Correction";
	
	private static final String DEFAULT_PERFORMER_TYPE = "crowd";
	private static final String DEFAULT_PERFORMER = "Deere.com-Translators";
	private static final String DEFAULT_PACKAGING_TEMPLATE = "JD Enterprise - Base Template";
	
	private static final String DOCTYPE = "Tagged XML V2";
	
	static final String DATASOURCE_DELIMITER = "--";
	
	// Document Transformation Name values
	private static final String DEFAULT_TRANSFORM_JSON = "DeereDotCom - PIM System 2017 v1";
    private static final String DEFAULT_TRANSFORM_SPPAGE = "DeereDotCom - PAGE 2017 v1";
    private static final String DEFAULT_TRANSFORM_DCR = "DeereDotCom - TeamSite DCR 2017 v1";
    
    private static final String DEFAULT_DOC_TRANSFORM = "Teamsite v 1.0";
	
	// private static final String TASK0_NAME = "Document translation";
	// private static final String TASK1_NAME = "Document review & correction";
	
	private String defaultTransformTemplate;
	private String pageTransformTemplate;
	private String dcrTransformTemplate;
	private String jsonTransformTemplate;
	
	private String docTransform;
	
	private String workflowName;
	private String performerType;
	private String performer;
	private String reportingTemplate;
	private String packagingTemplate;
	//private String postToAkeneo;
	private SyndicationTarget source;
	private Set<SyndicationTarget> targets;
	private List<SourceFile> sourceFiles;
	
	private AcrossWorkflows workflows;
	
	/**
	 * Build a new TranslationTask instance using the provided parameters to
	 * access information from the workflow such as the attached files, source
	 * and target locales, etc.
	 * @param task The current CSTask instance
	 * @param source The syndication source locale
	 * @param targets The syndication target locale
	 * @throws CSException
	 */
	public TranslationTask(CSClient client, CSTask task, SyndicationTarget source, Set<SyndicationTarget> targets) throws CSException {
		workflowName = task.getVariable(VAR_WORKFLOW_NAME);
		if (workflowName == null || "".equals(workflowName)) {
			workflowName = DEFAULT_WORKFLOW_NAME;
		}
		LOGGER.debug("Project Workflow Name: " + workflowName);
		
		performerType = task.getVariable(VAR_PERFORMER_TYPE);
		performer = getPerformer(task);
		reportingTemplate = getReportingTemplate(task);
		
		packagingTemplate = task.getVariable(VAR_PACKAGING_TEMPLATE);
		if (packagingTemplate == null || "".equals(packagingTemplate)) {
			packagingTemplate = DEFAULT_PACKAGING_TEMPLATE;
		}
		
		if (performerType == null || "".equals(performerType)) {
			performerType = DEFAULT_PERFORMER_TYPE;
			performer = DEFAULT_PERFORMER;
		}
		LOGGER.debug("Project Performer Type: " + performerType);
		LOGGER.debug("Project Performer: " + performer);
		LOGGER.debug("Project Reporting Template: " + reportingTemplate);
		LOGGER.debug("Project Packaging Template: " + packagingTemplate);
		
		this.source = source;
		LOGGER.debug("Project Syndication Source: " + source);
		this.targets = targets;
		LOGGER.debug("Project Syndication Targets: " + targets);
		
		defaultTransformTemplate = task.getVariable(VAR_TRANSFORM_DEFAULT);
		if (defaultTransformTemplate == null || "".equals(defaultTransformTemplate)) {
			defaultTransformTemplate = DEFAULT_TRANSFORM_DCR;
		}
		
		// Pull the transform template name for SitePublisher Pages from the current workflow task
		pageTransformTemplate = task.getVariable(VAR_TRANSFORM_PAGE);
		if (pageTransformTemplate == null || "".equals(pageTransformTemplate)) {
			pageTransformTemplate = DEFAULT_TRANSFORM_SPPAGE;
		}
		LOGGER.debug("SitePublisher Page Transform Template: " + pageTransformTemplate);
		
		// Pull the transform template name for DCRs from the current workflow task
		dcrTransformTemplate = task.getVariable(VAR_TRANSFORM_DCR);
		if (dcrTransformTemplate == null || "".equals(dcrTransformTemplate)) {
			dcrTransformTemplate = DEFAULT_TRANSFORM_DCR;
		}
		LOGGER.debug("TeamSite DCR Transform Template: " + dcrTransformTemplate);
		
		// Pull the transform template name for JSON files from teh current workflow task
		jsonTransformTemplate = task.getVariable(VAR_TRANSFORM_JSON);
		if (jsonTransformTemplate == null || "".equals(jsonTransformTemplate)) {
			jsonTransformTemplate = DEFAULT_TRANSFORM_JSON;
		}
		
		docTransform = task.getVariable(VAR_DOC_TRANSFORM);
		if ("default".equalsIgnoreCase(docTransform) || "true".equalsIgnoreCase(docTransform)) {
			docTransform = DEFAULT_DOC_TRANSFORM;
		}
		LOGGER.debug("Across Document Transform: " + docTransform);
		
		sourceFiles = new ArrayList<>(task.getFiles().length);
		CSFile[] files = task.getArea().getFiles(task.getFiles());
		for (CSFile curr : files) {
			if (CSSimpleFile.KIND == curr.getKind()) {
				String transformationName = defaultTransformTemplate;
				
				CSSimpleFile file = (CSSimpleFile) curr;
				if (CSSimpleFile.kDCR == file.getContentKind()) {
					transformationName = dcrTransformTemplate;
				} else if ("page".equals(file.getVPath().getExtension())) {
					transformationName = pageTransformTemplate;
				} else if ("json".equals(file.getVPath().getExtension())) {
					transformationName = jsonTransformTemplate;
				}
				
				String path = file.getVPath().getAreaRelativePath().getParentPath().toString();
				
				sourceFiles.add(new SourceFile(path, file.getName(), DOCTYPE, docTransform, transformationName));
			}
		}
		
		workflows = new AcrossWorkflows(client);
	}
	// We need this constructor for the builder method later
	private TranslationTask() { }
	
	/** Get the project workflow name */
	public String getWorkflowName() {
		return workflowName;
	}
	/** Get the project performer type */
	public String getPerformerType() {
		return performerType;
	}
	/** Get the project performer */
	public String getPerformer() {
		return performer;
	}
	/** Get the project reporting template */
	public String getReportingTemplate() {
		return reportingTemplate;
	}
	/** Get the project packaging template */
	public String getPackagingTemplate() {
		return packagingTemplate;
	}
	
	/** Get the project source SyndicationTarget instance */
	public SyndicationTarget getSource() {
		return source;
	}
	/** Get the project target SyndicationTarget instances */
	public Set<SyndicationTarget> getTargets() {
		return Collections.unmodifiableSet(targets);
	}
	/** Get the project source files */
	public List<SourceFile> getSourceFiles() {
		return Collections.unmodifiableList(sourceFiles);
	}
	
	private String getPerformer(CSTask task) throws CSException {
		String performer = task.getVariable(VAR_PERFORMER);
		LOGGER.debug("Project Performer Variable: " + performer);
		String[] parts = performer.split(DATASOURCE_DELIMITER);
		if (parts != null && parts.length > 0) {
			performer = parts[0];
		}
		
		LOGGER.debug("Project Performer: " + performer);
		return performer;
	}
	
	private String getReportingTemplate(CSTask task) throws CSException {
		String performer = task.getVariable(VAR_PERFORMER);
		LOGGER.debug("Project Performer Variable: " + performer);
		String[] parts = performer.split(DATASOURCE_DELIMITER);
		if (parts != null && parts.length > 1) {
			performer = parts[1];
		} else {
			performer = task.getVariable(VAR_REPORTING_TEMPLATE);
		}
		
		LOGGER.debug("Project Reporting Template: " + reportingTemplate);
		return performer;
	}
	
	/**
	 * Build the XML element represented by this TranslationTask instance for
	 * inclusion in an Across control.xml file.
	 * @return The XML element to be included in a control.xml file
	 */
	public Element toElement() {
		Element element = DocumentHelper.createElement("translationTask");
		Element taskElement = element.addElement("simpleTask");
		
		taskElement.addElement("srcLocale").setText(source.getLocale());
		taskElement.addElement("acrossWorkflowNm").setText(workflowName);
		
		taskElement.add(SourceFile.toElement(sourceFiles));
		
		Element targetsElement = taskElement.addElement("targets");
		for (SyndicationTarget target : targets) {
			if (target.isTranslationEnabled()) {
				targetsElement.add(buildTargetElement(target));
			}
		}
		
		return element;
	}
	
	private Element buildTargetElement(SyndicationTarget target) {
		Element element = DocumentHelper.createElement("target");
		
		if (target.getAcrossLocale() != null && !"".equals(target.getAcrossLocale())) {
			element.addElement("targetLocale").setText(target.getAcrossLocale());
			element.addElement("externalTargetLocation").setText(target.getAcrossLocale().replace('-', '_'));
		} else {
			element.addElement("targetLocale").setText(target.getLocale());
			element.addElement("externalTargetLocation").setText(target.getLocale().replace('-', '_'));
		}
		
		element.addElement("teamsiteTargetLocale").setText(target.getLocale());
		
		// Include the first of the two workflow tasks for each target
		Element tasks = element.addElement("workflowTasks");
		
		if (workflows != null) {
			workflows.addWorkflowTasks(tasks, workflowName, performer, performerType, reportingTemplate, packagingTemplate, source.getLocale());
		}
		
		return element;
	}
	
	/**
	 * Build a TranslationTask instance from the provided XML Element instance.
	 * @param element The XML Element instance from which to build a TranslationTask
	 * @param configuration The configured SyndicationTarget set
	 * @return The TranslationTask instance built from the provided XML Element instance
	 */
	static TranslationTask build(Element element, Set<SyndicationTarget> configuration) {
		String workflowName = element.elementText("acrossWorkflowNm");
		String performerType = "";
		String performer = "";
		String reportingTemplate = "";
		String packagingTemplate = "";
		//String postToAkeneo="";
		
		String sourceLocale = element.elementText("srcLocale");
		LOGGER.debug("Source Locale: " + sourceLocale);
		SyndicationTarget source = SyndicationTarget.filterByLocale(configuration, sourceLocale);
		LOGGER.debug("Source Target: " + source);
		
		Element targetsElement = element.element("targets");
		@SuppressWarnings("unchecked")
		List<Element> targetElements = targetsElement.elements("target");
		List<String> locales = new ArrayList<String>();
		
		for (Element targetElement : targetElements) {
			String locale = targetElement.elementText("teamsiteTargetLocale");
			LOGGER.debug("Locale: " + locale);
			if (locale != null && !"".equals(locale)) {
				locales.add(locale);
			}
			
			/**Fetching the postToAkeneo flag value from control.xml
			postToAkeneo=targetElement.elementText("postToAkeneo");
			LOGGER.debug("Target postToAkeneo value: " + postToAkeneo);**/
			
			Element workflowTasks = targetElement.element("workflowTasks");
			Element workflowTask = workflowTasks.element("workflowTask");
			
			performerType = workflowTask.elementText("performerType");
			LOGGER.debug("Performer Type: " + performerType);
			performer = workflowTask.elementText("performer");
			LOGGER.debug("Performer: " + performer);
			reportingTemplate = workflowTask.elementText("reportingTemplate");
			LOGGER.debug("Reporting Template: " + reportingTemplate);
			packagingTemplate = workflowTask.elementText("packagingTemplate");
			LOGGER.debug("Packaging Template: " + packagingTemplate);
		}
		LOGGER.debug("Target Locale Set: " + locales);
		
		Set<SyndicationTarget> targets = SyndicationTarget.filterByLocales(configuration, locales);
		LOGGER.debug("Targets: " + targets);
		
		Element sourceFilesElement = element.element("srcFiles");
		List<SourceFile> sourceFiles = SourceFile.buildList(sourceFilesElement);
		
		TranslationTask translationTask = new TranslationTask();
		
		translationTask.workflowName = workflowName;
		translationTask.performerType = performerType;
		translationTask.performer = performer;
		translationTask.reportingTemplate = reportingTemplate;
		translationTask.packagingTemplate = packagingTemplate;
		
		translationTask.source = source;
		translationTask.targets = targets;
		
		translationTask.sourceFiles = sourceFiles;
		//translationTask.postToAkeneo=postToAkeneo;
		
		return translationTask;
	}
	
}
