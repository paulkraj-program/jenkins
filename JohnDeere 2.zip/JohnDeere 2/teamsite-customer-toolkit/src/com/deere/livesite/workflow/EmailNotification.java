package com.deere.livesite.workflow;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;

import javax.mail.util.ByteArrayDataSource;
import javax.xml.transform.TransformerException;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Element;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.access.CSGroup;
import com.interwoven.cssdk.access.CSUser;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSIterator;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.common.xml.ElementableUtils;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.transform.XSLTransformer;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.sharedutils100.mail.MailConfigException;
import com.interwoven.sharedutils100.mail.MailerConfig;
import com.interwoven.ui.teamsite.workflow.task.urltask.MailNotificationTask;

public class EmailNotification extends MailNotificationTask {
    private static final String MAIL_SUBJECT_TASK_VARIABLE = "mail_subject";
    private static final String MAIL_SENDER_VARIABLE = "mail_sender";
    private static final String MAIL_TEMPLATE_TASK_VARIABLE = "mail_template";
    private static final String MAILCONTENT_XMLTAG = "MailContent";
    private static final String JOB_XMLTAG = "Job";
    private static final String JOBDETAILS_XMLTAG = "JobDetails";
    private static final String JOBID_XMLTAG = "jobid";
    private static final String REQUESTEDBY_XMLTAG = "JobOwner";
    private static final String DATE_XMLTAG = "Date";
    private static final String REVIEWER_TASK = "review_task";
    private static final String REVIEWER_GROUP = "group";
    private static final String PUBLISH_TYPE = "publishtype";
    private static final String ASSIGNEDTO_XMLTAG = "AXML";
    private static final String NOTIFY_REVIEWER = "notify_reviewer";
    private static final String TESTING_NOTIFICATION = "testing";
    private static final transient Logger LOGGER = Logger.getLogger(EmailNotification.class);



    /**
     * This API is used to configure and send email notification
     */
    @Override
    protected MailerConfig createMailConfig(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable hash) throws MailConfigException, CSException {
        CSWorkflow job = task.getWorkflow();
        String subject = task.getVariable(MAIL_SUBJECT_TASK_VARIABLE) + job.getId();
        String mailTemplate = task.getVariable(MAIL_TEMPLATE_TASK_VARIABLE);
        MailerConfig mailConfig = new MailerConfig();
        mailConfig.setHost(MAIL_SERVER);
        mailConfig.setSubject(subject);
        mailConfig.setSender(task.getVariable(MAIL_SENDER_VARIABLE));
        String postAction = new String();
        String comment = new String();
        String recipientAddresses = new String();
        String EmailAddress = task.getWorkflow().getOwner().getEmailAddress();
        String reviewerGroup = task.getVariable(REVIEWER_GROUP);
        String reviewTask = task.getVariable(REVIEWER_TASK);
        String reviewerdetails = task.getVariable(NOTIFY_REVIEWER);
        String testingNotification = task.getVariable(TESTING_NOTIFICATION);

        if (reviewerGroup != null) {
            LOGGER.debug("Reviewer Group is  >>> " + reviewerGroup);
             CSGroup groupReview = client.getGroup(reviewerGroup, true);
             CSIterator groupUsers = groupReview.getUsers(true);
             
             if (testingNotification.equalsIgnoreCase("yes")) {
                 mailConfig.addToRecipient(EmailAddress);
             } else {
              while (groupUsers.hasNext()) {
                 CSUser groupUser = (CSUser) groupUsers.next();
                 String groupUserEmail = groupUser.getEmailAddress();
                 if (StringUtils.isNotBlank(groupUserEmail)) {
                     //recipientAddresses = recipientAddresses + groupUserEmail + ",";
                 	mailConfig.addToRecipient(groupUserEmail);
                 }
             }
             }
             
             LOGGER.debug("Reviewer Groups contains is  >>> " + recipientAddresses);

         } else if (reviewerdetails.equalsIgnoreCase("yes")) {
            CSTask reviewCSTask = getTaskByName(task, reviewTask);
            String reviewerEmail = reviewCSTask.getOwner().getEmailAddress().toString();

            mailConfig.addToRecipient(EmailAddress);
            mailConfig.addCcRecipient(reviewerEmail);
        } else {
            mailConfig.addToRecipient(EmailAddress);
        }

        String strTemplate = StringUtils.trim(mailTemplate);
        if (StringUtils.isBlank(strTemplate)) {

            transitionComment = "Required mail variable \"mail_template\" is missing. Mail is not sent.";
        }
        CSVPath templateVpath = new CSVPath(strTemplate);
        CSSimpleFile templateFile = (CSSimpleFile) client.getFile(templateVpath);
        // creating content xml for email template
        String contentXml = createContentXml(client, task, postAction, comment);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(contentXml.getBytes("UTF-8"));
            XSLTransformer.transform(inputStream, templateFile, outputStream);
        } catch (TransformerException tex) {
            transitionComment = "Exception when transforming email content. Mail is not sent.";
        } catch (UnsupportedEncodingException ueex) {
            transitionComment = "Unsupported encoding exception when transforming email content." + " Mail is not sent.";
        }
        mailConfig.addDataSource(new ByteArrayDataSource(outputStream.toByteArray(), "text/html"));
        return mailConfig;
    }
    private String createContentXml(CSClient client, CSExternalTask task, String pPostAction, String pComment) throws CSException {
        CSWorkflow job = task.getWorkflow();

        String reviewTask = task.getVariable(REVIEWER_TASK);
        String timezone = job.getVariable("TimeZones");
        Element mailContentRoot = ElementableUtils.newElement(MAILCONTENT_XMLTAG);

        Element jobElement = mailContentRoot.addElement(JOB_XMLTAG);
        Element jobDetails = jobElement.addElement(JOBDETAILS_XMLTAG);
        jobDetails.addElement(JOBID_XMLTAG).setText(String.valueOf(job.getId()));
        jobDetails.addElement(PUBLISH_TYPE).setText(job.getVariable("PublishTime"));
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date currentDate = new Date();
        jobDetails.addElement(DATE_XMLTAG).setText(dateFormat.format(currentDate));
        jobDetails.addElement(REQUESTEDBY_XMLTAG).setText(job.getOwner().getDisplayName());
        CSAreaRelativePath[] csarp = task.getFiles();
        for (CSAreaRelativePath attachedFile: csarp) {
            if (attachedFile != null) {
                String name = attachedFile.getName();
                String fullpath = task.getArea().getUAI() + "/" + attachedFile.getParentPath() + "/" + attachedFile.getName();
                Element jobFiles = jobDetails.addElement("FILES");
                jobFiles.addElement("FILE").setText(attachedFile.getParentPath() + "/" + attachedFile.getName());
            }
        }
        if (reviewTask != null) {

            LOGGER.debug("<<<<<<<<<<<<<<<<Review Task is Valid >>>>>>>>>>>>>>");
            CSTask reviewCSTask = getTaskByName(task, reviewTask);
            int reviewCSTaskId = reviewCSTask.getId();
            String reviewTaskURL = "https://" + client.getContext().getServerName() + "/iw-cc/command/iw.ccpro.task_details?taskid=" + reviewCSTaskId;
            jobDetails.addElement("ReviewTaskURL").setText(reviewTaskURL);
            if (!"<no user>".equalsIgnoreCase(reviewCSTask.getOwner().getName())) {
                jobDetails.addElement(ASSIGNEDTO_XMLTAG).setText(reviewCSTask.getOwner().getDisplayName());
            }


        }
        if (timezone != null && !timezone.equalsIgnoreCase("")) {

            LOGGER.debug("<<<<<<<<<<<<<<<<timezone  is Valid >>>>>>>>>>>>>>");
            Element timeZones = jobDetails.addElement("scheduledtimezones");
            ZoneId istZoneId = ZoneId.of("Asia/Kolkata");
            ZoneId estZoneId = ZoneId.of("America/New_York");
            ZoneId cstZoneId = ZoneId.of("America/Chicago");
            ZoneId cestZoneId = ZoneId.of("Europe/Berlin");
            ZoneId aestZoneId = ZoneId.of("Australia/Melbourne");
            ZoneId CurrentZoneId = istZoneId;

            if (timezone.trim().equalsIgnoreCase("IST")) {
                CurrentZoneId = istZoneId;
            LOGGER.debug("ZoneId is >>"+CurrentZoneId.getDisplayName(TextStyle.SHORT, Locale.ENGLISH));
            } else if (timezone.trim().equalsIgnoreCase("CST")) {
                CurrentZoneId = cstZoneId;
            LOGGER.debug("ZoneId is >>"+CurrentZoneId.getDisplayName(TextStyle.SHORT, Locale.ENGLISH));
            } else if (timezone.trim().equalsIgnoreCase("EST")) {
                CurrentZoneId = estZoneId;
            LOGGER.debug("ZoneId is >>"+CurrentZoneId.getDisplayName(TextStyle.SHORT, Locale.ENGLISH));          
            } else if (timezone.trim().equalsIgnoreCase("Europe/Berlin")) {
                CurrentZoneId = cestZoneId;
            LOGGER.debug("ZoneId is >>"+CurrentZoneId.getDisplayName(TextStyle.SHORT, Locale.ENGLISH));   
            } else if (timezone.trim().equalsIgnoreCase("Australia/Melbourne")){
                CurrentZoneId = aestZoneId;
             LOGGER.debug("ZoneId is >>"+CurrentZoneId.getDisplayName(TextStyle.SHORT, Locale.ENGLISH));
            }else {
            	 LOGGER.debug("<<<<<<<<<<<<<<<<timezone  is not Valid >>>>>>>>>>>>>>");
            }


            String dateInString = job.getVariable("DeployDate");
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
            OffsetDateTime date = LocalDateTime.parse(dateInString, dtf).atZone(CurrentZoneId).toOffsetDateTime();

            String ISTime = date.atZoneSameInstant(istZoneId).format(dtf);
            timeZones.addElement("timezone").setText(ISTime + " | Asia/Kolkata");


            String ESTime = date.atZoneSameInstant(estZoneId).format(dtf);
            timeZones.addElement("timezone").setText(ESTime + " | America/New_York");


            String CSTime = date.atZoneSameInstant(cstZoneId).format(dtf);
            timeZones.addElement("timezone").setText(CSTime + " | America/Chicago");


            String CESTime = date.atZoneSameInstant(cestZoneId).format(dtf);
            timeZones.addElement("timezone").setText(CESTime + " | Europe/Berlin");


            String AESTime = date.atZoneSameInstant(aestZoneId).format(dtf);
            timeZones.addElement("timezone").setText(AESTime + " | Australia/Melbourne");



        } else {

        }
        LOGGER.debug("XML Source for email is >>>>>>>>>>>>>>>>>>>>>>> " + mailContentRoot.asXML());



        return ElementableUtils.toString(mailContentRoot, true);
    }
    private CSTask getTaskByName(CSExternalTask currentTask, String taskName) throws CSAuthorizationException, CSRemoteException, CSObjectNotFoundException, CSExpiredSessionException, CSException {
        CSTask requiredTask = null;
        CSTask[] cstask = currentTask.getWorkflow().getTasks();

        for (CSTask task: cstask) {
            if (taskName.equalsIgnoreCase(task.getName())) {
                requiredTask = task;
                break;
            }
        }
        return requiredTask;
    }

}