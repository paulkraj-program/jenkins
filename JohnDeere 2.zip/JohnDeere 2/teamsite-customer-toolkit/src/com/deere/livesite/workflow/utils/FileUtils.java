package com.deere.livesite.workflow.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.deere.livesite.workflow.constants.WorkflowConstants;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.workflow.CSTask;



public class FileUtils {
	private static final transient Logger LOGGER = Logger.getLogger(FileUtils.class);
	/**
	 * Read the page paths data from temp file and delete the temp file after that : start
	 * @param pagePathsfile
	 * @param serverInstance
	 * @return
	 */
	public static ArrayList<String> readDCRPathFile(String pagePathsfile) {
		BufferedReader pagePathBReader = null;
	//	FileReader pagePathFReader = null;
		ArrayList<String> dcrFileListFromTmpFile = new ArrayList<String>();
		try {

			String pagePathline;

			pagePathBReader = Files.newBufferedReader(Paths.get(pagePathsfile), Charset.defaultCharset());

			while ((pagePathline = pagePathBReader.readLine()) != null && !"".equals(pagePathline)) {
				LOGGER.debug("Reading Temporary file for page paths is started in AttachDependenciesTask file :"
						+ pagePathline);
				dcrFileListFromTmpFile.add(pagePathline);
			}

			LOGGER.debug("file name for page path in AttachDependenciesTask is " + pagePathsfile);

		} catch (IOException ioe) {
			LOGGER.error("IOException occured  in the method readDCRPathFile for FileUtils",ioe);
		} finally {

			try {

				if (pagePathBReader != null)
					pagePathBReader.close();
				/*
				if (pagePathFReader != null)
					pagePathFReader.close();
				*/
				/*
				 * if(serverInstance.equalsIgnoreCase(PIMContsants.
				 * PROD_SERVER_INSTANCE)&&(tempFile.isFile())) {
				 * LOGGER.info("server instance is"+serverInstance); LOGGER.
				 * info("In AsynchronousTask, temporary page path file deletion started and its path is"
				 * +tempFile.getAbsolutePath()); boolean deletdFile =
				 * tempFile.delete(); LOGGER.
				 * info("In AsynchronousTask, temporary page path file deletion completed "
				 * +deletdFile); }
				 */

			} catch (IOException | SecurityException ioex) {
				LOGGER.error("Exception occured  while closing BufferReader the method readDCRPathFile for FileUtils",ioex);
			}

		}

		return dcrFileListFromTmpFile;
	}
	
	public  static String getDCRListFileName(String dcrFileListPath,CSTask task) throws Exception, CSException {
		// TODO Auto-generated method stub
		if (dcrFileListPath != null && !"".equals (dcrFileListPath)) {
			dcrFileListPath += File.separator + WorkflowConstants.DCRFILELIST + "_" + task.getWorkflowId () + ".txt";
		} else {
			dcrFileListPath = File.separator + WorkflowConstants.DCRFILELIST +"_"+task.getWorkflowId () + ".txt";
		}
		
		return dcrFileListPath;
	}

}
