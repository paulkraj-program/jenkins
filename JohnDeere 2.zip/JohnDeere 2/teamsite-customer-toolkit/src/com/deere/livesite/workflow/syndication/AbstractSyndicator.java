package com.deere.livesite.workflow.syndication;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSWorkarea;

/**
 * AbstractSyndicator is an abstract class that contains several utility methods
 * that are used during the syndication process.
 * @author Klish Group, Inc. [ND]
 */
public abstract class AbstractSyndicator implements Syndicator {
	protected final transient Logger LOGGER = Logger.getLogger(getClass());
	
	private static final String ATTR_TIMESTAMP = "TeamSite/Deere/Syndication/Timestamp";
	private static final String CONFIG_ROOT_NAME="iw-g11n";
	private static final String CONFIG_FILE_PATH="config.properties";
	private static final String BRANCH_MASTER_LOCALE="masterLocale";
	private static final String UNIX_DIR_SLASH="/";
	private static final String HYPEN="-";
	private static final String UNDERSCORE="_";
	private static final Properties properties = new Properties(); 
	
	/* Update the G11N locale attributes on the file */
	/* Method has been update post TS 16.6 upgrade for "G11N/Locale" as hypen(-) is not allowed */
	protected void updateLocaleAttributes(CSClient csClient,CSWorkarea workArea,CSFile file, String sourceLocale, String targetLocale) throws CSException {
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile target = (CSSimpleFile) file;
			LOGGER.debug("File for updation "+target.getVPath());
			CSWorkarea configWA=workArea.getBranch().getConfigBranch().getBranchConfigWorkarea();
			String masterLocale=getMasterLocale(configWA);
			if(null!=masterLocale && !masterLocale.equals("")) {
				targetLocale=masterLocale;
			}
			else {
				LOGGER.debug("Master Locale not set or unavailable in config.properties.Please check branch settings");
				targetLocale=targetLocale.replace(HYPEN,UNDERSCORE);
			}
			
			LOGGER.debug("setting Target file locale "+targetLocale);
			target.setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute("G11N/Locale", targetLocale),
					new CSExtendedAttribute("G11N/Localizable", "true"),
			});
		}
	}
	
	/* Get the masterLocale from config branch for non english locale */
	protected String getMasterLocale(CSWorkarea configWA) throws CSException {
		
		String masterLocale=null;
		InputStreamReader fis =null;
		String configFileRelativePath=CONFIG_ROOT_NAME+UNIX_DIR_SLASH+CONFIG_FILE_PATH;
		try {
		CSSimpleFile file = (CSSimpleFile) configWA.getFile(new CSAreaRelativePath(configFileRelativePath));
		LOGGER.debug("Loading File : " + file.getName());
			if (file!= null && file.isReadable()) {
				 fis = new InputStreamReader(file.getInputStream(true));
				properties.load(fis);
				masterLocale=properties.getProperty(BRANCH_MASTER_LOCALE);
				fis.close();
			}
		} catch (Exception e) {
			LOGGER.error("Error while fetching config.properties from config branch "+e.getMessage());
		} 
		finally {
		if(fis != null) {
            try {
				fis.close();
			} catch (IOException e) {
				LOGGER.error("Exception occured while closing the InputStreamReader in the method getMasterLocale for AbstractSynddicator",e);
			}
		}
		}

		return masterLocale;
	}
	/* Get the content modification date timestamp from the file */
	protected Date getTimestamp(CSFile file) throws CSException {
		return file.getContentModificationDate();
	}
	
	/* Get the syndication date timestamp from the extended attributes of the file */
	protected Date getSyndicationTimestamp(CSFile file) throws CSException  {
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile target = (CSSimpleFile) file;
			
			CSExtendedAttribute attr = target.getExtendedAttribute(ATTR_TIMESTAMP);
			if (attr != null && attr.getValue() != null && !"".equals(attr.getValue())) {
				String hexValue = attr.getValue();
				long timestamp = Long.parseLong(hexValue, 16);
				
				return new Date(timestamp);
			}
		}
		
		return null;
	}

	/* Set the syndication date timestamp on the extended attributes of the file */
	protected void setSyndicationTimestamp(CSFile file) throws CSException {
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile target = (CSSimpleFile) file;
			
			target.setExtendedAttributes(new CSExtendedAttribute[] {
					new CSExtendedAttribute(ATTR_TIMESTAMP, Long.toHexString(getTimestamp(target).getTime()))
			});
		}
	}
	
}
