package com.deere.livesite.workflow;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSAssociatable;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSExternalTask;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class CommonServices {
	static final transient Logger LOGGER = Logger.getLogger(CommonServices.class);

	
	private static final String DCR_TYPE_EA = "TeamSite/Templating/DCR/Type";
	
	/**
	 * Gets the list of file matching the extension
	 * @param task
	 * @return list of CSSimpleFile objects
	 * @throws CSException
	 */
	public static List<CSSimpleFile> getAttachedFiles(CSExternalTask task, List<String> extensions) throws CSException {
		
		List<CSSimpleFile> attachedFileList = new ArrayList<CSSimpleFile>();
		CSAreaRelativePath[] filePaths = task.getFiles();
		LOGGER.debug("Checking for valid files in the " + filePaths.length + " attached files");
		
		for (CSAreaRelativePath filePath : filePaths) {
			CSFile file = task.getArea().getFile(filePath);
			if (file != null
					&& extensions.stream().filter(s -> s.equalsIgnoreCase(file.getVPath().getExtension())).findFirst().isPresent()) {
				LOGGER.debug("File: " + filePath);
				attachedFileList.add((CSSimpleFile) file);
			}
		}
		LOGGER.debug("Found " + attachedFileList.size() + " valid files attached to the job");
		return attachedFileList;
	}

	/**
	 * Creates a DCR and sets the DCR Type EA 
	 * @param client
	 * @param document
	 * @param targetPath
	 * @return
	 * @throws CSException
	 * @throws IOException
	 */
	public static CSSimpleFile createDcr(CSClient client, Document document,
			CSVPath targetPath) throws CSException, IOException {
		targetPath = targetPath.getPathNoServer();
		CSFile targetFile = client.getFile(targetPath);
		if ((targetFile == null) || (targetFile.getKind() == CSHole.KIND)) {
			CSVPath areaPath = targetPath.getArea();
			CSWorkarea workarea = client.getWorkarea(areaPath, true);
			CSAreaRelativePath areaRelativePath = new CSAreaRelativePath(targetPath.getParentPath().getAreaRelativePath());

			createParentDirectories(client, workarea, areaRelativePath);

			targetFile = workarea.createSimpleFile(targetPath.getAreaRelativePath());
		}
		if ((targetFile != null) && (targetFile.getKind() == CSSimpleFile.KIND)) {
			CSSimpleFile targetCSFile = (CSSimpleFile) targetFile;
			writeToFile(document, targetCSFile, true);
			String templateType = getTemplateType(targetFile.getVPath().getAreaRelativePath().toString());
			CSExtendedAttribute[] ea = { new CSExtendedAttribute(DCR_TYPE_EA, templateType) };
			targetCSFile.setExtendedAttributes(ea);

			return (CSSimpleFile) targetFile;
		}
		LOGGER.debug("Failed Creating Target DCR :" + targetPath.toString());
		return null;
	}

	
	/** 
	 * readDcr retrieves the contents of the supplied DCR 
	 * and then if successful, passes that content to reportData.   
	 * @param CSSimpleFile dcr contains the specified DCR
	 * @param CSExternalTask task contains current workflow task
	 */
	public static Document readDcr(CSSimpleFile file) {
		try {
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				return new org.dom4j.io.SAXReader().read(new BufferedInputStream(((CSSimpleFile) file).getInputStream(false)));
			}
		} catch (DocumentException de) {
			LOGGER.error("Failed to parse DCR document: " + de);
		} catch (CSException cse) {
			LOGGER.error("Failed to load DCR document: " + cse);
		}

		return null;
	}
	
	public static void checkAndUpdateElement(Element root, String value, boolean replace){
		if(root!=null && (root.getText().isEmpty() || replace)){
			root.setText(value);
		}
	}
	
	
	/**
	 * Creates the directories recursively if the path doesnt exist.
	 * @param client
	 * @param workarea
	 * @param path
	 * @throws CSException
	 */
	public static void createParentDirectories(CSClient client,
			CSWorkarea workarea, CSAreaRelativePath path) throws CSException {
		if (client == null) {
			LOGGER.warn("Invalid CSClient instance; cannot create parent directory for path : "
					+ path);
			return;
		}
		if (workarea == null) {
			LOGGER.warn("Invalid workarea instance; cannot create parent directory for path : "
					+ path);
			return;
		}
		CSAreaRelativePath parentPath = path.getParentPath();
		if (!parentPath.isEmpty()) {
			createParentDirectories(client, workarea, parentPath);
		}
		CSVPath targetVPath = workarea.getVPath().concat(path.toString());
		CSFile file = client.getFile(targetVPath);
		if ((file == null) || (file.getKind() == 3)) {
			LOGGER.debug("Creating Directory : " + path);
			CSDir dir = workarea.createDirectory(path);
			dir.setGroup(dir.getParent().getGroup());
		}
	}

	/**
	 * Gets the Category and Data Type from a given DCR path
	 * @param dcrPath
	 * @return Category/DataType String
	 */
	public static String getTemplateType(String dcrPath) {
		Pattern dcrTypePattern = Pattern.compile("templatedata/(.*)/data/.*");
		Matcher dcrTypeMatcher = dcrTypePattern.matcher(dcrPath);
		if (dcrTypeMatcher.matches()) {
			return dcrTypeMatcher.group(1);
		}
		return "";
	}

	/**
	 * Writes the document object to a CSSimpleFile 
	 * @param document
	 * @param file
	 * @param isPrettyPrint
	 * @throws IOException
	 * @throws CSException
	 */
	public static void writeToFile(Document document, CSSimpleFile file,
			boolean isPrettyPrint) throws IOException, CSException {
		
		if(file !=null && document != null ){
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			OutputFormat format = new OutputFormat();
			if (isPrettyPrint) {
				format = OutputFormat.createCompactFormat();
				format = OutputFormat.createPrettyPrint();
			}
			XMLWriter writer = new XMLWriter(baos, format);
			writer.write(document);
			writer.close();

			String formattedXML = baos.toString();
			byte[] dcrFileContent = formattedXML.getBytes();
			file.write(dcrFileContent, 0L, dcrFileContent.length, true);
		}
	
		
	}

	/**
	 * Executes the regex for a given string
	 * @param inputString
	 * @param regEx
	 * @return Matched string
	 */
	public static String executeRegex(String inputString, String regEx) {
		String returnItem = null;
		Pattern dcrPattern = Pattern.compile(regEx);
		Matcher dcrMatcher = dcrPattern.matcher(inputString);
		if (dcrMatcher.find()) {
			returnItem = dcrMatcher.group(1);
		}
		return returnItem;
	}

	/**
	 * Verifies the CSFile exists and deletes. 
	 * @param file
	 * @return boolean
	 * @throws CSException
	 */
	public static boolean deleteFile(CSFile file) throws CSException {
		if ((file != null) && (file.isValid())) {
			file.delete();
			return true;
		}
		return false;
	}
	
	
	/**
	 * Sorts the map by value
	 * @param map
	 * @return
	 */
	public static Map<CSSimpleFile, String> sortMapByValue (Map<CSSimpleFile, String> map) {
		List<Map.Entry<CSSimpleFile, String>> entryList = new ArrayList<Map.Entry<CSSimpleFile, String>> (map.entrySet ());
		Collections.sort (entryList, new Comparator<Map.Entry<CSSimpleFile, String>> () {
			public int compare (Map.Entry<CSSimpleFile, String> a, Map.Entry<CSSimpleFile, String> b) {
				return a.getValue ().compareTo (b.getValue ());
			}
		});
		Map<CSSimpleFile, String> sortedMap = new LinkedHashMap<CSSimpleFile, String> ();
		for (Entry<CSSimpleFile, String> entry : entryList) {
			sortedMap.put (entry.getKey (), entry.getValue ());
		}

		return sortedMap;
	}
	
	/**
	 * Sorts the map by value
	 * @param map
	 * @return
	 */
	public static Map<CSSimpleFile, Integer> sortMapByIntegerValue (Map<CSSimpleFile, Integer> map) {
		List<Map.Entry<CSSimpleFile, Integer>> entryList = new ArrayList<Map.Entry<CSSimpleFile, Integer>> (map.entrySet ());
		Collections.sort (entryList, new Comparator<Map.Entry<CSSimpleFile, Integer>> () {
			public int compare (Map.Entry<CSSimpleFile, Integer> a, Map.Entry<CSSimpleFile, Integer> b) {
				return a.getValue ().compareTo(b.getValue ());
			}
		});
		Map<CSSimpleFile, Integer> sortedMap = new LinkedHashMap<CSSimpleFile, Integer> ();
		for (Entry<CSSimpleFile, Integer> entry : entryList) {
			sortedMap.put (entry.getKey (), entry.getValue ());
		}

		return sortedMap;
	}
	
	/**
	 * Verifies if the CSSimpleFile is a DCR. 
	 * @param file
	 * @return
	 * @throws CSException
	 */
	public static boolean isDCR(CSSimpleFile file) throws CSException {
		boolean isDCR = false;
		if ((file != null) && (file.getContentKind() != 3)
				&& (file.getContentKind() == 21)) {
			isDCR = true;
		}
		return isDCR;
	}

	/**
	 * Gets the file name of a DCR without the extension
	 * @param file
	 * @return
	 * @throws CSException
	 */
	public static String getDcrName(CSSimpleFile file) throws CSException {
		String dcrPath = "";
		if (file == null) {
			return dcrPath;
		}
		String fileName = file.getName();
		if ((file.getVPath().getAreaRelativePath().getExtension() != null)
				&& (!file.getVPath().getAreaRelativePath().getExtension()
						.isEmpty())) {
			dcrPath = fileName.substring(
					0,
					fileName.lastIndexOf(file.getVPath().getAreaRelativePath()
							.getExtension()));
		} else {
			dcrPath = fileName;
		}
		return dcrPath;
	}

	/**
	 * Get all the source directories that needs to be parsed to get list of all the DCR's
	 * @param rootFolder
	 * @return
	 * @throws CSException
	 */
	public static List<CSDir> getSourceDirectories(CSClient client, CSVPath rootFolder)
			throws CSException {
		CSFile csSitesRootDirObj = client.getFile(rootFolder);

		List<CSDir> dirQueue = new LinkedList<CSDir>();
		if ((csSitesRootDirObj != null) && (csSitesRootDirObj.getKind() != 3)
				&& (csSitesRootDirObj.getKind() == 2)) {
			dirQueue.add((CSDir) csSitesRootDirObj);
		} else {
			LOGGER.error("Invalid site root  : " + rootFolder);
		}
		return dirQueue;
	}
	
	/**
	 * Gets the value of a field within the DCR to use it as a Label in the datasouce map.
	 * @param file
	 * @param fieldPath
	 * @return
	 * @throws CSException
	 */
	public static String getFieldValue(CSSimpleFile file, String fieldPath) throws CSException {
		String value = "";
		if ((file != null) && (file.getContentKind() != 3)
				&& (file.getContentKind() == 21)) {
			try {
				InputStream input = new BufferedInputStream(file.getInputStream(false));
				Document document;
				try {
					document = new SAXReader().read(input);
					Element root = document.getRootElement();
					value = root.elementText(fieldPath);
				} finally {
					if (input != null) {
						try {
							input.close();
						} catch (IOException localIOException) {
						}
					}
				}
				try {
					input.close();
				} catch (IOException localIOException1) {
				}
				
			} catch (DocumentException de) {
				LOGGER.error("An error occurred reading the XML content", de);
			} catch (CSException cse) {
				LOGGER.error("An error occurred communicating with the content management system",cse);
			}
		}
		
		return value;
	}

	
	public static void createChildAssociation(CSSimpleFile child, CSFile file, String type) throws CSException {
		
		if (child == null || file == null){
			LOGGER.warn("Unable to set child association on file.");
			return;
		}
		
		boolean parentExists = (file != null) && (!(file instanceof CSHole));
		if ((parentExists) && (CSSimpleFile.KIND == file.getKind())){
			CSSimpleFile parentFile = (CSSimpleFile)file;
			child.createChildAssociations(new CSAssociatable[] { parentFile }, type, false);
		}else if (!parentExists){
			LOGGER.error("missing parent file " + file.getVPath().getPathNoServer().toString() + "\nfor\n" + child.getVPath().toString());
		}else{
			LOGGER.debug("skipping parent association creation for " + file.getVPath().getPathNoServer().toString() + " type=" + file.getKind());
		}
	}
	
	
	
	/**
	 * Method to convert Machine/Product name to camel case 
	 * @param str
	 * @return Camel case converted string.
	 */
	public static String toCamelCase(String str){
		
		if(str!=null && !str.isEmpty()){
			StringBuffer result = new StringBuffer();
			Pattern p = Pattern.compile("[a-z]", Pattern.CASE_INSENSITIVE);
			
			for(String word: str.split("\\s")){
				Matcher m = p.matcher(word);
	
				if(m.find()){
					result.append(" ").append(word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase());
				}else{
					result.append(" ").append(word);
				}
			}
			return result.toString().trim();
			
		}	
		
		return "";
	}
	
}
