package com.deere.livesite.workflow;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;

import com.deere.livesite.authoring.common.constants.PIMContsants;
import com.deere.livesite.workflow.common.urlmapping.URLMappingCommonServices;
import com.deere.teamsite.common.constants.UiUtilsConstants;
import com.deere.teamsite.ui.utils.PDFReaderUtils;
import com.interwoven.cssdk.access.CSUser;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.serverutils100.IWConfig;

/**
 * VelocitySearchUpdateTask class sends request to wso2 end point to update
 * velocity search This class excludes any fragment pages and sends request for
 * all other HTML files
 * 
 * @author cm54947
 *
 */

public class VelocitySearchUpdateTask extends AbstractURLExternalTask {
	private static final transient Logger velocitySearchUpdateTaskLogger = Logger.getLogger(VelocitySearchUpdateTask.class);
	private static final String VELOCITY_SEARCH_UPDATE_ENDPOINT = "VelocitySearchUpdateEndpoint";
	private static final String SERVERNAME = "serverName";
	private static final Pattern[] NON_INDEX_PAGE_LINK_PATTERNS = {
			Pattern.compile("[^/]+/([^/]+)/website/products(/.*)"),
			Pattern.compile("[^/]+/([^/]+)/website/industries(/.*)"), Pattern.compile("[^/]+/([^/]+)/website(/.*)") };
	private static final Pattern[] INDEX_PAGE_LINK_PATTERNS = {
			Pattern.compile("[^/]+/([^/]+)/website/products(/.*/)index.html"),
			Pattern.compile("[^/]+/([^/]+)/website/industries(/.*/)index.html"),
			Pattern.compile("[^/]+/([^/]+)/website(/.*/)index.html") };
	// private static final Pattern[] nonIndexPageLinkPatterns = { Pattern.compile
	// ("[^/]+/([^/]+)/website/products(/.*)"), Pattern.compile
	// ("[^/]+/([^/]+)/website/industries(/.*)"), Pattern.compile
	// ("[^/]+/([^/]+)/website(/.*)") };
	private static final Pattern[] ASSETS_LINK_PATTERNS = { Pattern.compile("/assets/") };

	private static final String VAR_OPERATION = "Operation";
	private static final String VAR_LOCALES_REGION_CONFIG_FILE = "LocalesRegionFile";
	private static final String HTML_FILE_LIST_PATH = "HtmlFileListPath";
	public static final String DELETE_FLAG = "isDelete";
	public static final String ASSETS_PATH_FILE = "AssetsFileListPath";
	public static final String QUERY_PARAM_QUESTION_MARK = "?";
	public static final String QUERY_PARAM_EQUALS = "=";
	public static final String QUERY_PARAM_COMMA_SEPARATOR = ",";
	public static final String QUERY_PARAM_ENABLED_LOCALES = "enabledLocales";
	public static final String QUERY_PARAM_MODIFIED_DATE = "modifiedDate";
	public static final String QUERY_PARAM_CREATION_DATE = "creationDate";
	public static final String PDF_EXT = ".pdf";

	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {
		// VelocitySearchUpdateEndpoint
		String velocitySearchUpdateEndPoint = task.getVariable(VELOCITY_SEARCH_UPDATE_ENDPOINT);
		String serverName = task.getVariable(SERVERNAME);
		String webURL = task.getVariable("WebURL");
		String htmlFileListPath = task.getVariable(HTML_FILE_LIST_PATH);
		String assetsFileListPath = task.getVariable(ASSETS_PATH_FILE);
		String operation = task.getVariable(VAR_OPERATION);
		String localesRegionConfigFile = task.getVariable(VAR_LOCALES_REGION_CONFIG_FILE);
		String isDeleteFlag = task.getVariable(DELETE_FLAG);
		velocitySearchUpdateTaskLogger.debug("Is Delete Workflow Variable :" + isDeleteFlag);
		String excludePattern = task.getVariable("ExcludePagePatterns");
		String region=null;
		String masterLocale=null;
		List<Pattern> excludePagePatterns = new ArrayList<Pattern>();
		try {
			masterLocale=PDFReaderUtils.getMasterLocale(client, task);
			velocitySearchUpdateTaskLogger.debug("Master locale:" + masterLocale);
		}
		catch(Exception ex) {
			velocitySearchUpdateTaskLogger.debug("Master locale not found");
		}
		
		if (excludePattern != null && !"".equals(excludePattern)) {
			for (String s : excludePattern.split(",")) {
				excludePagePatterns.add(Pattern.compile(s));
			}
		} else {
			excludePagePatterns.add(Pattern.compile("fragment[^/]*.html"));
		}
		// String htmlFileListPath = task.getVariable("HtmlFileListPath");
		if (velocitySearchUpdateEndPoint != null && !"".equals(velocitySearchUpdateEndPoint) && ((htmlFileListPath != null
				&& !"".equals(htmlFileListPath)) ||(assetsFileListPath !=null && !"".equals(assetsFileListPath)))) {
			try {
				List<String> urls = new ArrayList<String>();
				// String[] htmlFiles = htmlList.split(",");
				Set<String> htmlFiles = WorkflowServices.readFileList(htmlFileListPath);
				Set<String> assetsFiles = WorkflowServices.readFileList(assetsFileListPath);
				if ((htmlFiles != null && !htmlFiles.isEmpty())) {
					// check for user lock
					for (String file : htmlFiles) {
						if (file != null && !"".equals(file) && !file.startsWith("sites")) {
							String updatedUrl = updateURL(file, webURL, excludePagePatterns);
							if (updatedUrl != null) {
								urls.add(updatedUrl);
							}

						}
					}
				}
				if(assetsFiles != null && !assetsFiles.isEmpty()) {
					for (String file : assetsFiles) {
						if (file != null && !"".equals(file) && file.endsWith(PDF_EXT)) {
							String updatedUrl = updateURL(file, webURL, excludePagePatterns);
							if (updatedUrl != null) {
								// urls.add(updatedUrl);
								StringBuilder updatedPDFUrl = new StringBuilder(updatedUrl);
								velocitySearchUpdateTaskLogger.debug("File Processing : "+UiUtilsConstants.ASSETS_WA+UiUtilsConstants.SLASH+file);
								CSFile pdfFile = client.getFile(new CSVPath(UiUtilsConstants.ASSETS_WA+UiUtilsConstants.SLASH+file));
								try {
								//LOGGER.debug(pdfFile);
								CSSimpleFile csSimplePdfFile = (CSSimpleFile) pdfFile;
								velocitySearchUpdateTaskLogger.debug("PDF file object :"+csSimplePdfFile);
								String localeExtendedAttributeValue=csSimplePdfFile.getExtendedAttribute("Locales").getValue();
								if( localeExtendedAttributeValue != null && !localeExtendedAttributeValue.equals("") ) {
									
									updatedPDFUrl.append(QUERY_PARAM_QUESTION_MARK).append(QUERY_PARAM_ENABLED_LOCALES)
											.append(QUERY_PARAM_EQUALS)
											.append(localeExtendedAttributeValue != null
													? localeExtendedAttributeValue
													: "");
									if(masterLocale!=null && !masterLocale.equals("")) {
									updateLocaleExtendedAttribute(masterLocale,csSimplePdfFile);
									}
									//LOGGER.debug("PDF file payload url generated with master locale :" + updatedPDFUrl);
									velocitySearchUpdateTaskLogger.debug("PDF file payload url generated :" + updatedPDFUrl);
								}
								else if(masterLocale!=null && !masterLocale.equals("")) {
									updatedPDFUrl.append(QUERY_PARAM_QUESTION_MARK).append(QUERY_PARAM_ENABLED_LOCALES)
									.append(QUERY_PARAM_EQUALS)
									.append(masterLocale != null
											? masterLocale
											: "");
									updateLocaleExtendedAttribute(masterLocale,csSimplePdfFile);
									velocitySearchUpdateTaskLogger.debug("PDF file payload url generated with master locale :" + updatedPDFUrl);
								}
									urls.add(updatedPDFUrl.toString());
								} catch (Exception ex) {
									urls.add(updatedUrl);
								}

							}

						}
					}
				}
					// send request to search update end point
					boolean prod = serverName != null && !"".equals(serverName) && "prod".equals(serverName) ? true
							: false;
					// delete the temp file created foe HTML paths if the server name is prod
					if (prod) {
						try {
							Files.delete(Paths.get(htmlFileListPath));
							Files.delete(Paths.get(assetsFileListPath));
							velocitySearchUpdateTaskLogger.debug("Sucessfully Deleted the HTML and assets paths File:" + htmlFileListPath);
						} catch (IOException | SecurityException e) {
							velocitySearchUpdateTaskLogger.error("Error Deleting File list file ", e);
						}
					}
				
					if(htmlFiles != null && !htmlFiles.isEmpty()) {
						region = getRegion(htmlFiles, localesRegionConfigFile, client);
					}
					else {
						region="assets";
					}
					velocitySearchUpdateTaskLogger.debug("Region:" + region + " and Operation:" + operation);
					String emailId = getEmailAddress(task);
					// send request to Delete URL from search
					boolean isDelete = isDeleteFlag != null && !"".equals(isDeleteFlag) && "true".equals(isDeleteFlag)
							? true
							: false;
					velocitySearchUpdateTaskLogger.debug("Is Delete flag value: " + isDelete);
					sendRequest(urls, velocitySearchUpdateEndPoint, prod, operation, region, emailId, isDelete, client);
					velocitySearchUpdateTaskLogger.debug("Successfully updated Velocity Search");
					chooseSuccessTransition(task);
				
			} catch (CSException e) {
				velocitySearchUpdateTaskLogger.error("Error while sending request to velocity search Update end point", e);
				chooseFailureTransition(task,
						new CSException(0, "Failed while updating Velocity search" + e.getMessage()));
			}

		} else {
			velocitySearchUpdateTaskLogger.debug("Velocity Search Update Endpoint not configured, please check");
			chooseFailureTransition(task,
					new CSException(0, "Velocity Search Update Endpoint not configured,please check"));
		}

	}

	private String getEmailAddress(CSExternalTask task) {
		try {
			CSUser user = task.getOwner();
			if (user != null) {
				String emailAddress = user.getEmailAddress();
				if (velocitySearchUpdateTaskLogger.isDebugEnabled()) {
					velocitySearchUpdateTaskLogger.debug("emailAddress: " + emailAddress);
				}
				if (StringUtils.isEmpty(emailAddress)) {
					if (velocitySearchUpdateTaskLogger.isDebugEnabled()) {
						velocitySearchUpdateTaskLogger.debug("No email address found for " + user.getName() + ". Creating one...");
					}
					String userName = user.getDisplayName().replace(" ", "");
					emailAddress = userName + "@" + getDomain();
					if (velocitySearchUpdateTaskLogger.isDebugEnabled()) {
						velocitySearchUpdateTaskLogger.debug("Constructed email address: " + emailAddress);
					}
				}
				return emailAddress;
			}
		} catch (CSException e) {
			velocitySearchUpdateTaskLogger.error("Error while retrieving the email address", e);
		}

		return null;
	}

	private String getDomain() {
		IWConfig iwC = IWConfig.getConfig();
		if (iwC != null) {
			String domain = iwC.getString(PIMContsants.IW_SEND_MAIL, PIMContsants.MAILDOMAIN_STRING);
			if (domain == null) {
				domain = PIMContsants.DEFAULT_MAIL_DOMAIN;
			}
			return domain;
		}
		return null;
	}

	/**
	 * This method gives the region for the attached files based on the region
	 * configured in localesRegionConfigFile
	 * 
	 * @param htmlFiles               set of HTML file paths
	 * @param localesRegionConfigFile path of the locales-region configuration file
	 * @param client                  CSClient
	 * @return region
	 */
	private String getRegion(Set<String> htmlFiles, String localesRegionConfigFile, CSClient client) {
		String locale = getLocale(htmlFiles);
		if (locale != null && !"".equals(locale) && localesRegionConfigFile != null
				&& !"".equals(localesRegionConfigFile)) {
			try {
				CSFile csFile = client.getFile(new CSVPath(localesRegionConfigFile));
				if (csFile != null && csFile.getKind() == CSSimpleFile.KIND) {
					CSSimpleFile configFile = (CSSimpleFile) csFile;
					InputStream in = configFile.getInputStream(true);
					InputStreamReader fis = new InputStreamReader(in);
					Document document = new org.dom4j.io.SAXReader().read(fis);
					fis.close();
					if (document != null) {
						Map<String, String> localesRegionMap = URLMappingCommonServices.generateMap(document,
								"ListItem", "Name", "Value");
						if (localesRegionMap != null && !localesRegionMap.isEmpty()) {
							return localesRegionMap.get(locale);
						}
					}
				}
			} catch (CSException | DocumentException | IOException e) {
				velocitySearchUpdateTaskLogger.error("Error while reading locales-region mapping file:" + localesRegionConfigFile, e);
			}
		}
		return null;
	}

	/**
	 * It gives the locale based on the file paths
	 * 
	 * @param htmlFiles set of HTML file paths
	 * @return locale in the form of en_US
	 */
	private String getLocale(Set<String> htmlFiles) {
		for (String path : htmlFiles) {
			Matcher m = URLMappingCommonServices.LOCALE_PATTERN.matcher(path);
			if (m.find()) {

				return m.group(2) + "_" + m.group(1).toUpperCase();
			}
		}
		return null;
	}

	public void sendRequest(List<String> urls, String velocitySearchUpdateEndPoint, boolean prod, String operation,
			String region, String emailId, boolean isDelete, CSClient client) {
		String jSon = "{";
		if (urls.size() > 0) {
			int i = 0;
			for (String url : urls) {
				jSon = jSon.concat("\"file" + i + "\":\"" + url + "\",");
				i++;
			}
		}

		if (jSon.length() > 1) {
			jSon = jSon.substring(0, jSon.length() - 1);
		}

		jSon = jSon.concat("}");
		velocitySearchUpdateTaskLogger.debug("JSON File:\n" + jSon);
		System.out.println("JSON File:\n" + jSon);
		byte[] postData = jSon.getBytes();
		Map<String, String> params = new HashMap<String, String>();
		params.put("prod", Boolean.toString(prod));
		params.put("isDelete ", Boolean.toString(isDelete));
		velocitySearchUpdateTaskLogger.debug("Modified By Param : " + client.getCurrentUser().getName());
		params.put("modifiedBy", client.getCurrentUser().getName());
		if (operation != null && !"".equals(operation)) {
			params.put(VAR_OPERATION.toLowerCase(), operation);
		}
		if (region != null && !"".equals(region)) {
			params.put("region", region.toLowerCase());
		}
		if (emailId != null && !"".equals(emailId)) {
			params.put("useremail", emailId);
		}
		try {

			if (velocitySearchUpdateEndPoint != null && !"".equals(velocitySearchUpdateEndPoint))
				WorkflowServices.sendRequest(velocitySearchUpdateEndPoint, postData, params);
		} catch (Exception e) {
			velocitySearchUpdateTaskLogger.error("Error while updating Velocity Search", e);
		}

	}

	public String updateURL(String path, String webURL, List<Pattern> excludePagePatterns) {
		if (path != null && !"".equals(path)) {

			if (!isPageExcluded(path, excludePagePatterns)) {

				for (Pattern pattern : INDEX_PAGE_LINK_PATTERNS) {
					Matcher matcher = pattern.matcher(path);
					if (matcher.find()) {
						String url = matcher.group(1) + matcher.group(2);
						if (!url.startsWith("/"))
							url = "/" + url;
						return webURL + url;
					}
				}
				for (Pattern pattern : NON_INDEX_PAGE_LINK_PATTERNS) {
					Matcher matcher = pattern.matcher(path);
					if (matcher.find()) {
						String url = matcher.group(1) + matcher.group(2);
						if (!url.startsWith("/"))
							url = "/" + url;
						return webURL + url;
					}
				}

				if (path.startsWith("/assets/") || path.startsWith("assets/")) {

					if (!path.startsWith("/"))
						path = "/" + path;
					velocitySearchUpdateTaskLogger.debug("Assets found - generated url " + webURL + path);
					return webURL + path;

				}

				if (!path.startsWith("/")) {
					path = "/" + path;
				}
				return webURL + path;
			}
		}
		return null;
	}

	/**
	 * This functions checks if the page is excluded from being written to the
	 * sitemap by doing pattern matching.
	 * 
	 * @param pageLink
	 * @return
	 */
	private boolean isPageExcluded(String pageLink, List<Pattern> excludePagePatterns) {
		if (excludePagePatterns.size() > 0) {
			for (Pattern pattern : excludePagePatterns) {
				Matcher matcher = pattern.matcher(pageLink);
				if (matcher.find()) {
					return true;
				}
			}
		}
		return false;
	}
	
	private void updateLocaleExtendedAttribute(String localeFromTask,CSSimpleFile file) {
		ArrayList<String> existingLocales=new ArrayList<String>();
		try {
			velocitySearchUpdateTaskLogger.debug("Going to update file Locales extendedattribut");
		existingLocales=PDFReaderUtils.getListOfTaggedLocales(file.getExtendedAttribute("Locales").getValue());
		velocitySearchUpdateTaskLogger.debug("Locale - "+existingLocales.toString()+" already present");
		if(!existingLocales.isEmpty()) {
			if(!PDFReaderUtils.isSourcePresent(localeFromTask,existingLocales)) {
				velocitySearchUpdateTaskLogger.debug("Locale - "+localeFromTask+" already present");
				if(!localeFromTask.equals("null") && !localeFromTask.equals("") && localeFromTask!=null) {
				existingLocales.add(localeFromTask);
				}
			}
		}
		else {
			velocitySearchUpdateTaskLogger.debug("Adding new locale "+localeFromTask);
			if(!localeFromTask.equals("null") && !localeFromTask.equals("") && localeFromTask!=null) {
			existingLocales.add(localeFromTask);
			}
		}
		velocitySearchUpdateTaskLogger.debug("Locales to be updated "+PDFReaderUtils.getTargetLocales(existingLocales));
						
				((CSSimpleFile) file).setExtendedAttributes(new CSExtendedAttribute[] {
						new CSExtendedAttribute(UiUtilsConstants.EXT_ATTR_LOCALES,PDFReaderUtils.getTargetLocales(existingLocales)) });
	
	}
	catch(Exception ex) {
		velocitySearchUpdateTaskLogger.debug("Error while updating locale extended attribute" +ex.getMessage());
		
	}
	}

}
