package com.deere.livesite.workflow;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import java.io.BufferedReader;
/*import java.io.File;*/
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
/*import org.apache.commons.io.FileUtils;*/
/*import org.apache.log4j.Logger;*/

/**
 * @author Klish Group, Inc. [AG]
 * This task will check if the file has been deployed to production. If the File
 * is deployed Through TeamSite then the task will go to success If the file is
 * deployed through anything other than TeamSite then we will check the
 * EA(IsDeployedProd) on the index.page attached to the workflow, if it is set
 * and has value true then the task will go to success otherwise task will go to
 * failure.
 * 
 * @author rg96596
 * Additional feature has been added to auto deploy to production only those static pages which has
 * proper offers displayed in the HTML.
 * This class will be only initiated from ODScheduler as DNR script executing workflow from
 * //dce-ts-p.deere.com/iwadmin/main/config/WORKAREA/shared/workflow/auto-deployment
 * 
 */

public class ProductionAutoDeplomentCheckTask extends AbstractURLExternalTask {

	private static final String DEFAULT_DEPLOYED_THROUGH = "TeamSite";
	private static final String EXTENDED_ATTRIBUTE_PROD_DEPLOYED = "IsDeployedProd";
	private static final String VAR_PREVIEW_ONLY = "PreviewOnly";
	//protected final transient static Logger logger = Logger.getLogger(ProductionAutoDeplomentCheckTask.class);
	private static final String OFFERS_AVAILABLE="special-offers-listing-component container available active";

	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {

		LOGGER.debug("Production Deployment Check Task invoked");
		String deployedThrough = task.getVariable("DeployedThrough");
		if (task.getVariable(VAR_PREVIEW_ONLY) != null && task.getVariable(VAR_PREVIEW_ONLY).equalsIgnoreCase("true")) {
			LOGGER.debug("Preview flag is true :::");
			String imageFileListPath = task.getWorkflow().getVariable("imageFileListPath");
			String pagePathsfile = task.getWorkflow().getVariable("PagePathsFile");
			String htmlFileListPath = task.getWorkflow().getVariable("HtmlFileListPath");
			if (imageFileListPath != null && !"".equals(imageFileListPath)) {
				LOGGER.debug("Image File List Path: Proceed for deletion " + imageFileListPath);
				try {
					Files.delete(Paths.get(imageFileListPath));
				} catch (IOException | SecurityException e) {
					LOGGER.error("Error Deleting Image list file ", e);
				}
			}
			if (pagePathsfile != null && !"".equals(pagePathsfile)) {
				LOGGER.debug("Page File List Path: Proceed for deletion " + pagePathsfile);
				try {
					Files.delete(Paths.get(pagePathsfile));
				} catch (IOException | SecurityException e) {
					LOGGER.error("Error Deleting Page paths file list ", e);
				}
			}
			if (htmlFileListPath != null && !"".equals(htmlFileListPath)) {
				LOGGER.debug("HTML File List Path: Proceed for deletion " + htmlFileListPath);
				try {
					Files.delete(Paths.get(htmlFileListPath));
				} catch (IOException | SecurityException e) {
					LOGGER.error("Error Deleting HTML paths file list ", e);
				}
			}
			task.chooseTransition("Deploy To Preview Only", "Successfully Deployed to Preview Enviornment");
		}

		else {
			if (deployedThrough != null && !deployedThrough.isEmpty()) {
				LOGGER.debug("Deployed Through " + deployedThrough);
				if (deployedThrough.equalsIgnoreCase(DEFAULT_DEPLOYED_THROUGH)) {
					LOGGER.debug("The files are deployed through Teamsite: " + deployedThrough);
					List<CSAreaRelativePath> noChangedFiles = new ArrayList<CSAreaRelativePath>();
					try {
						for (CSAreaRelativePath areaRelativePath : task.getFiles()) {
							LOGGER.info("Processing File inside check: " + areaRelativePath + " "
									+ areaRelativePath.getName() + " " + areaRelativePath.getExtension());
							if (areaRelativePath.getName().contains(".html")) {
								CSFile file = task.getArea().getFile(areaRelativePath);

								if (file != null && CSHole.KIND != file.getKind()
										&& CSSimpleFile.KIND == file.getKind()) {
									CSSimpleFile csSimpleFile = (CSSimpleFile) file;
									LOGGER.info("Current version :" + csSimpleFile.getRevisionNumber());
									LOGGER.info("Previous version :" + (csSimpleFile.getRevisionNumber() - 2));
									String revision = csSimpleFile.getRevisionString();
									LOGGER.info("revision :" + revision);

									String olderRevision = getOlderVersion(csSimpleFile.getRevisionNumber(), revision);
									LOGGER.debug("Previous Revision " + olderRevision);
									/*
									 * boolean isEqual = isDifferentContent( (CSSimpleFile)
									 * csSimpleFile.getFileRevision(revision), (CSSimpleFile)
									 * csSimpleFile.getFileRevision(olderRevision)); LOGGER.debug("is same content "
									 * + isEqual);
									 */
									 LOGGER.info("File current version"+readPage((CSSimpleFile)csSimpleFile.getFileRevision(revision)));
									 boolean isvalidContent=isOffersAvailable(readPage((CSSimpleFile)csSimpleFile.getFileRevision(revision)));
									// LOGGER.info("File older version "+readPage((CSSimpleFile)csSimpleFile.getFileRevision(olderRevision)));
									/*
									 * if (isEqual) { LOGGER.debug("No changes in the file");
									 * noChangedFiles.add(areaRelativePath); }
									 */
									LOGGER.debug("Is valid content "+isvalidContent);
									if(!isvalidContent) {
										LOGGER.debug("Valid offers are not present "+isvalidContent);
										if(!(noChangedFiles.contains(areaRelativePath))) {
										LOGGER.debug("Adding to detachable list " + isvalidContent);	
										noChangedFiles.add(areaRelativePath);
										}
									}

								}
							}

						}
					} catch (Exception e) {
						LOGGER.debug("Error while comparing files");
					}

					CSAreaRelativePath[] noChangedFilesArray = new CSAreaRelativePath[noChangedFiles.size()];

					// ArrayList to Array Conversion
					for (int i = 0; i < noChangedFiles.size(); i++) {
						noChangedFilesArray[i] = noChangedFiles.get(i);
					}
					//removing file from Task if no changes are there
					task.detachFiles(noChangedFilesArray);
					chooseSuccessTransition(task);
				} else {
					for (CSAreaRelativePath areaRelativePath : task.getFiles()) {
						LOGGER.info("Processing File : " + areaRelativePath + " " + areaRelativePath.getName() + " "
								+ areaRelativePath.getExtension());

						if (areaRelativePath.getName().equalsIgnoreCase("index.page")) {
							CSFile file = task.getArea().getFile(areaRelativePath);
							if (file != null && CSHole.KIND != file.getKind() && CSSimpleFile.KIND == file.getKind()) {
								CSSimpleFile csSimpleFile = (CSSimpleFile) file;
								CSExtendedAttribute exAttr = csSimpleFile
										.getExtendedAttribute(EXTENDED_ATTRIBUTE_PROD_DEPLOYED);
								if (exAttr != null) {
									if (exAttr.getName().equalsIgnoreCase(EXTENDED_ATTRIBUTE_PROD_DEPLOYED)
											&& exAttr.getValue() != null
											&& exAttr.getValue().equalsIgnoreCase("true")) {
										LOGGER.debug("Deployed to Production.");
										chooseSuccessTransition(task);
									} else {
										LOGGER.debug(
												"Deployed Through attribute Value is Null. File is not deployed to Production.");
										chooseFailureTransition(task,
												new CSException(0,
														"Failed because the workflow Originated from " + deployedThrough
																+ "  and the file was not deployed to Production"));
									}
								} else {
									LOGGER.debug(
											"Deployed Through attribute is Null. File is not deployed to production.");
									chooseFailureTransition(task,
											new CSException(0,
													"Failed because the workflow Originated from " + deployedThrough
															+ "  and the file was not deployed to Production"));
								}
							}
						}
					}
				}
			}
		}
	}
/**
 * Method to find if generated page is having valid offers
 * @param pageContent
 * @return
 */
	private boolean isOffersAvailable(String pageContent) {
	
		if(!pageContent.contains(OFFERS_AVAILABLE)) {
			return false;
		}
		return true;
		
	}

	/**
	 * Create older revision of the file from current version
	 * 
	 * @param revisionNumber
	 * @param currentReversion
	 * @return
	 */
	private String getOlderVersion(long revisionNumber, String currentReversion) {
		String olderRevision = null;
		LOGGER.info("Current Version " + revisionNumber);
		LOGGER.info("Older version long" + Long.toString(revisionNumber - 2));
		LOGGER.info("Before Replace value "
				+ currentReversion.replace(currentReversion, Long.toString(revisionNumber - 2)));
		olderRevision = currentReversion.replace(Long.toString(revisionNumber), Long.toString(revisionNumber - 2));
		LOGGER.info("Previous Revision in method" + olderRevision);
		return olderRevision;
	}



	private String readPage(CSSimpleFile file) {
		InputStream in = null;
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {
			in = file.getBufferedInputStream(false);
			br = new BufferedReader(new InputStreamReader(in));

			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
		} catch (Exception e2) {
			LOGGER.error("error getting page content");
		} finally {
			try {
				if (in != null) {
					in.close();
				}

				if (br != null) {
					br.close();
				}
			} catch (Exception e3) {
				LOGGER.error((Object) ("failed to close " + file.getVPath()), (Throwable) e3);
			}
		}
		return sb.toString();
	}

/**
 * Comparing current and previous version
 * @param newVersion
 * @param olderVersion
 * @return
 */
	/*
	 * private boolean isDifferentContent(CSSimpleFile newVersion, CSSimpleFile
	 * olderVersion) {
	 * 
	 * LOGGER.info("Started reading files for compare ");
	 * LOGGER.info("New version path  " + newVersion.getVPath().toString());
	 * LOGGER.info("Old version path  " + olderVersion.getVPath().toString());
	 * boolean isTwoEqual = false; try { File newFile = new
	 * File(newVersion.getVPath().toString()); File oldFile = new
	 * File(olderVersion.getVPath().toString()); isTwoEqual =
	 * FileUtils.contentEquals(newFile, oldFile); } catch (IOException e) {
	 * LOGGER.error("Error while comparing files"); }
	 * 
	 * return isTwoEqual; }
	 */

}
