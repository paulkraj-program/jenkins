package com.deere.livesite.workflow.translation;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.deere.livesite.workflow.syndication.SyndicationUtilities;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSWorkarea;

/**
 * IRetrievalPostProcessor is an interface that processes files writing them
 * back to the target file.
 * @author Klish Group, Inc. [ND]
 */
public interface IRetrievalPostProcessor {
	
	/**
	 * Process the source input writing back the processed content to the
	 * target file.
	 * @param client The current CSClient instance
	 * @param targetArea The target workarea for the content
	 * @param targetFile The target file for the processed source input
	 * @param sourceInput The source input to process
	 * @param source The syndication target source
	 * @param target The syndication target target
	 * @throws IOException
	 * @throws CSException
	 */
	public void process(CSClient client, CSWorkarea targetArea, CSSimpleFile targetFile, String sourceInput, SyndicationTarget source, SyndicationTarget target) throws IOException, CSException;
	
	/**
	 * PassThroughPostProcessor is an implementation of IRetrievalPostProcessor
	 * this takes the source input and writes it back to the target file
	 * directly without any manipulation of the file content.
	 * @author Klish Group, Inc. [ND]
	 */
	public static class PassThroughPostProcessor implements IRetrievalPostProcessor {
		
	/*	private byte[] buffer = new byte[4096];
		private int count = 0;*/
		
		public void process(CSClient client, CSWorkarea targetArea, CSSimpleFile targetFile, String sourceInput, SyndicationTarget source, SyndicationTarget target) throws IOException, CSException {
			try (OutputStream output = new BufferedOutputStream(targetFile.getOutputStream(true))) {
				/*while ((count = sourceInput.read(buffer)) > 0) {
					output.write(buffer, 0, count);
				}*/
				output.write(sourceInput.getBytes("UTF-8"));
				
			}
			
			SyndicationUtilities.updateFileContent(client, targetArea, targetFile, source, target);
		}
		
	}

}
