package com.deere.livesite.workflow.syndication;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import com.deere.teamsite.datasource.NameValuePairDataSource;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.modeler.workflow.WFMFile;
import com.interwoven.modeler.workflow.WFMWorkflow;
import com.interwoven.modeler.workflow.commands.InProcessJavaCommand;

/**
 * TranslationRequestWorkflowPreprocessor is a workflow preprocessor for the
 * Translation Request workflow, which checks the attached files against a
 * administrator configurable blacklist which contains a set of regular
 * expressions.  The expressions are matched against the file path as well as
 * the file name, if a match if found the file is blacklisted and an Exception
 * is thrown indicating which files attached are blacklisted so the user may
 * select another set of files for translation.
 * @author Klish Group, Inc. [ND]
 */
public class TranslationRequestWorkflowPreprocessor implements InProcessJavaCommand {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationRequestWorkflowPreprocessor.class);
	
	private static String PATH_BLACKLIST = "/iwadmin/main/deere/syndication/STAGING/templatedata/CustomData/ValueList/data/translation-request-blacklist.xml";
	
	private static String PROP_CSFACTORY = "com.interwoven.cssdk.factory.CSFactory";
	private static String PROP_CSFACRORY_IMPL = "com.interwoven.cssdk.factory.CSJavaFactory";
	
	private static String ERROR_BLACKLISTED = "The selected file(s): {0} are not allowed to be sent for translation";
	
	/* (non-Javadoc)
	 * @see com.interwoven.modeler.workflow.commands.InProcessJavaCommand#execute(com.interwoven.modeler.workflow.WFMWorkflow, java.util.Map)
	 */
	@Override
	public WFMWorkflow execute(WFMWorkflow workflow, Map<String, String> parameters) {
		// Assert there is only a single file attached to the workflow
		WFMFile[] files = workflow.getFiles();
		
		String workareaPath = parameters.get("workarea");
		LOGGER.debug("Workarea Path: " + workareaPath);
		
		String path = parameters.get("blacklist");
		if (path == null || "".equals(path)) {
			path = PATH_BLACKLIST;
		}
		LOGGER.debug("BlackList Path: " + path);
		
		try {
			CSClient client = getCSClient();
			
			Map<String, String> blacklist = NameValuePairDataSource.execute(client, new CSVPath(PATH_BLACKLIST));
			Set<String> set = new TreeSet<String>();
			
			for (String value : blacklist.keySet()) {
				LOGGER.debug("Blacklist Pattern: " + value);
				Pattern pattern = Pattern.compile(value);
				Matcher matcher = null;
				
				for (WFMFile file : files) {
					CSSimpleFile csfile = getSimpleFile(client, file, workareaPath);
					
					LOGGER.debug("Checking File: " + file.getFilePath());
					matcher = pattern.matcher(file.getFilePath());
					if (matcher.matches()) {
						LOGGER.debug("File " + file.getFilePath() + " matched pattern " + value);
						set.add(file.getFilePath());
					}
					
					matcher = pattern.matcher(csfile.getName());
					if (matcher.matches()) {
						LOGGER.debug("File name " + csfile.getName() + " matched pattern " + value);
						set.add(file.getFilePath());
					}
				}
			}
			
			// Assert the set of matching blacklisted files is empty
			if (!set.isEmpty()) {
				StringBuilder builder = new StringBuilder();
				for (String item : set) {
					builder.append(item).append(System.getProperty("line.separator"));
				}
				String message = MessageFormat.format(ERROR_BLACKLISTED, builder.toString());
				LOGGER.warn(message);
				throw new RuntimeException(message);
			}
		} catch (CSException e) {
			throw new RuntimeException (e);
		}
		
		return workflow;
	}
	
	private static CSClient getCSClient() throws CSException {
		Properties properties = new Properties(System.getProperties());
		LOGGER.debug("Getting CSClient instance");
		
		if (properties.getProperty(PROP_CSFACTORY) == null) {
			properties.setProperty(PROP_CSFACTORY, PROP_CSFACRORY_IMPL);
		}
		
		CSFactory factory = CSFactory.getFactory(properties);
		return factory.getClientForCurrentUser(Locale.getDefault(), "WorkflowContext", null);
	}
	
	private static CSSimpleFile getSimpleFile(CSClient client, WFMFile file, String workareaPath) throws CSException {
		CSVPath path = new CSVPath(file.getFilePath());
		if (path.getAreaType() == CSVPath.NO_AREA) {
			path = new CSVPath(workareaPath).concat(path.toString());
		}
		
		LOGGER.debug("File Path: " + path);
		
		CSFile csfile = client.getFile(path);
		if (CSSimpleFile.KIND == csfile.getKind()) {
			return (CSSimpleFile) csfile;
		}
		
		LOGGER.error("File is not of kind CSSimpleFile");
		return null;
	}
	
}
