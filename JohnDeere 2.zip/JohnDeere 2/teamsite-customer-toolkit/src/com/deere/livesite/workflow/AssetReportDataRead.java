package com.deere.livesite.workflow;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


public class AssetReportDataRead {
	private static final transient Logger LOGGER = Logger.getLogger(AssetReportDataRead.class);
	public static String CreateXML(Set<String> templatedataFiles,Set<String> finalImageList,Set<String> assetBranchList,Set<String> unUtilizedAssets,Set<String> unUtilizedDCRs,Set<String> dcrListLocale,String localeName) throws IOException 
	{
		Date date = new Date() ;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		String[] locale=localeName.split("/");
		String outputFile="/opentext/TeamSite/local/bin/custom/URLContentCleanUp/AssetReport_"+locale[0]+"_"+locale[1]+"_"+dateFormat.format(date) + ".xlsx";
		LOGGER.debug("Output File path " + outputFile); 
			
		XSSFWorkbook workbook = new XSSFWorkbook();
               
        
		XSSFSheet sheet = workbook.createSheet("Valid Assets");
		XSSFSheet dcrList = workbook.createSheet("Valid DCR Files List");
		XSSFSheet imageAssetBranch = workbook.createSheet("Total Assets in Teamsite");
		XSSFSheet unUtilDCR = workbook.createSheet("Unutilized DCR for "+locale[0]+"_"+locale[1]);
		XSSFSheet unUtilImage = workbook.createSheet("Unutilized Assets for "+locale[0]+"_"+locale[1]);
		XSSFSheet totalDCRList = workbook.createSheet("Total DCR List for "+locale[0]+"_"+locale[1]);

		int rownum = 0;
		int assetRow = 0;
		int assetBranchRow = 0;
		int unutilisedAssetRow = 0;
		int unutilisedDCRRow = 0;
		int totalDCRRow = 0;
        
		for(String dcrItems : templatedataFiles) {
			Row row = dcrList.createRow(rownum++);
			  writeBook(dcrItems, row);
		}
		for(String imagedata : finalImageList)
		{
			 Row row = sheet.createRow(assetRow++);
			  writeBook(imagedata, row);
		}
		for(String assetBranch : assetBranchList) {
			Row row = imageAssetBranch.createRow(assetBranchRow++);
			 writeBook(assetBranch, row);
		}
		for(String unUtilImg : unUtilizedAssets) {
			Row row = unUtilImage.createRow(unutilisedAssetRow++);
			 writeBook(unUtilImg, row);
		}
		for(String unUtilDCRVal : unUtilizedDCRs) {
			Row row = unUtilDCR.createRow(unutilisedDCRRow++);
			 writeBook(unUtilDCRVal, row);
		}
		for(String dcrInTS : dcrListLocale) {
			Row row = totalDCRList.createRow(totalDCRRow++);
			 writeBook(dcrInTS, row);
		}
		 FileOutputStream out =null;
		try
		  {
       
        File file = new File(outputFile);
        file.createNewFile();
        LOGGER.debug("File created successfully");
        out = new FileOutputStream(file);
        LOGGER.debug("Writing to file started : "); 
        workbook.write(out);
        LOGGER.debug("Writing to file Completed : "); 
        out.close();
        workbook.close();
        LOGGER.debug("Writing to file successful : "); 
		  } catch (Exception e) {
			  LOGGER.error("Error occuered in the method CreateXML",e); 
		  }
		finally {
			if(out != null) {
	            try {
					out.close();
				} catch (IOException e) {
					LOGGER.error("IOException occuered while closing the fileOutputStream the method CreateXML",e); 
				}
			}
		}
    return outputFile;   
}
	
	
   private static void writeBook(String aURL, Row row) {
		for(int i=0;i<aURL.length();i++)
		{
	    Cell cell = row.createCell(i);
	    
	    cell.setCellValue(aURL);
		}
	    
	}
}
