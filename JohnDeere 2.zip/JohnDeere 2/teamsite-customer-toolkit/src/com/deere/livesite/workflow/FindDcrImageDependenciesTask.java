package com.deere.livesite.workflow;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.livesite.workflow.WorkflowUtils;

/**
 * FindDcrImageDependenciesTask finds the image attached to the DCR on the page and 
 * creates a temp file containing the list of those files. 
 * The temp file path is set in the Workflow Variables to be used by the Deploy Image
 * task to deploy the image files in Preview and Prod servers.
 * This task also attaches other files to the workflow which are referenced in the DCR. The file extensions
 * to be attached are specified through the extensionFilesToAttachFromDCR variable.
 * @author Klish Group, Inc. [AG]
 *
 */
public class FindDcrImageDependenciesTask extends AbstractURLExternalTask {
	private static final transient Logger findDcrImageDependenciesTaskLogger = Logger.getLogger(FindDcrImageDependenciesTask.class);
	private static String imageFileValidExtension = "gif|jpg|swf|png|ipx|mov|mvr|jpeg|jpe|tif|eps|bmp|pcx|flv|xml|mp3";
	private static String extensionFilesToAttachFromDCR = "json";
	
	
	@Override
	public void execute(CSClient client, CSExternalTask task) throws CSException {
		execute(client, (CSTask) task);
	}
	
	public static void execute(CSClient client, CSTask task) throws CSException {
		
		CSAreaRelativePath[] taskFilesRelativePaths = task.getFiles ();

		//File extensions for images to be written in the file
		String validImageExtensions = WorkflowUtils.findVariable (task, "ValidImageExtensions");
		if (validImageExtensions != null && !"".equals (validImageExtensions)) {
			imageFileValidExtension = validImageExtensions.replaceAll (",", "|");
		}
		findDcrImageDependenciesTaskLogger.debug ("Pattern for the Image File Validation " + imageFileValidExtension);

		//File extensions for other files to be attached to the workflow
		String validFileExtensions = WorkflowUtils.findVariable (task, "ValidFileExtensions");
		if (validFileExtensions != null && !"".equals (validFileExtensions)) {
			extensionFilesToAttachFromDCR = validFileExtensions.replaceAll (",", "|");
		}
		findDcrImageDependenciesTaskLogger.debug ("Pattern for the File Validation " + validFileExtensions);

		String fileListPath = WorkflowUtils.findVariable (task, "FileListPath");
		if (fileListPath != null && !"".equals (fileListPath)) {
			fileListPath += File.separator + task.getWorkflowId () + ".txt";
		} else {
			fileListPath = File.separator + task.getWorkflowId () + ".txt";
		}

		findDcrImageDependenciesTaskLogger.debug ("File Path for creating the file List " + fileListPath);
		Set<String> referencedImagePathsForDCRFile = new HashSet<String> ();
		Set<CSAreaRelativePath> referencedFilePathsToAttach = new HashSet<CSAreaRelativePath> ();
		for (CSAreaRelativePath taskFileRelativePath : taskFilesRelativePaths) {

			CSFile file = task.getArea ().getFile (taskFileRelativePath);

			//Attach image dependencies in case a file is a DCR
			if (file != null && file.getKind () == CSSimpleFile.KIND && ((CSSimpleFile) file).getContentKind () == CSSimpleFile.kDCR) {

				findDcrImageDependenciesTaskLogger.debug ("Processing " + taskFileRelativePath.getName () + " for image dependencies");

				Set<String> referencedFilePaths = getFileReferences ((CSSimpleFile) file);
				if (referencedFilePaths.size () > 0) {
					Pattern imageFileExtensionPatterns = Pattern.compile (imageFileValidExtension, Pattern.CASE_INSENSITIVE);
					Pattern fileExtensionPatterns = Pattern.compile (extensionFilesToAttachFromDCR, Pattern.CASE_INSENSITIVE);
					for (String filePath : referencedFilePaths) {
						findDcrImageDependenciesTaskLogger.debug("Referenced File Paths "+filePath);
						if (imageFileExtensionPatterns.matcher (FilenameUtils.getExtension (filePath)).find ()) {
							referencedImagePathsForDCRFile.add (filePath);
						} else if (fileExtensionPatterns.matcher (FilenameUtils.getExtension (filePath)).find ()) {
							if (filePath.startsWith ("/"))
								filePath = filePath.substring (1).intern ();
							CSAreaRelativePath path = new CSAreaRelativePath (filePath);
							CSFile csFile = task.getArea ().getFile (path);
							if (csFile != null)
								referencedFilePathsToAttach.add (new CSAreaRelativePath (filePath));
						}
					}
				}
			}
		}

		//Write the Image File List Path
		try {
			writeImageFileList (fileListPath, referencedImagePathsForDCRFile);
		} catch (IOException e) {
			findDcrImageDependenciesTaskLogger.error ("Error writing image file List ", e);
			throw new CSException ();
		}
		//Attach the other files referenced in the DCR
		if (referencedFilePathsToAttach.size () > 0) {
			CSAreaRelativePath[] paths = referencedFilePathsToAttach.toArray (new CSAreaRelativePath[referencedFilePathsToAttach.size ()]);
			task.attachFiles (paths);
			findDcrImageDependenciesTaskLogger.debug ("Attaching the files to the workflow " + Arrays.asList (paths));
		}
		//set the image file list path in workflow task variable
		task.getWorkflow ().setVariable ("imageFileListPath", fileListPath);
		//	task.getWorkflow().setVariable("odSubst_imageFileListPath", fileListPath);		
		CSTask[] tasks = task.getWorkflow ().getTasks ();
		for (CSTask t : tasks) {
			/* t.setVariable ("odSubst_imageFileListPath", fileListPath); */
			t.setVariable ("odSubst_assetsFileListPath", fileListPath);
		}

	}

	/**
	 * This function writes the image file list to be used by Opendeploy to
	 * deploy the image files associated with the DCR on the page deployed.
	 * @param aFileName name of the file list
	 * @param referencedImagePathsForDCRFile paths for the image present in the DCR
	 * @throws IOException
	 */
	private static void writeImageFileList (String aFileName, Set<String> referencedImagePathsForDCRFile) throws IOException {
		/*
		 * try (Stream<String> lines=Files.lines(Paths.get(aFileName))){
		 * Iterator<String> lineIterator=lines.iterator(); while(lineIterator.hasNext())
		 * { referencedImagePathsForDCRFile.add(lineIterator.next()); } }
		 * Files.delete(Paths.get(aFileName));
		 */
		//Append in the end of file if already exits
		OpenOption[] options=new OpenOption[] {StandardOpenOption.CREATE,StandardOpenOption.APPEND};
		try (BufferedWriter writer = Files.newBufferedWriter (Paths.get (aFileName), options)) {
			for (String csa : referencedImagePathsForDCRFile) {
				writer.write (csa);
				writer.newLine ();
			}
			//	writer.close();
		}
	}

	/**
	 * Get Valid File Name References by reading each line of the file and comparing patterns with provided valid file extension list
	 * @param file File to read and find valid references 
	 * @return List of Area Relative Paths of references files
	 */
	private static Set<String> getFileReferences (CSSimpleFile file) {

		findDcrImageDependenciesTaskLogger.info ("Getting References from File : " + file.getVPath ());
		Pattern validFilesPattern = Pattern.compile ("(\\/([a-zA-Z_0-9-\\s\\/]*\\/[^/]+\\.(" + imageFileValidExtension + "|" + extensionFilesToAttachFromDCR + "))?)");

		Matcher matcher;
		String line;
		Set<String> allFilesMap = new HashSet<String> ();

		BufferedReader br = null;
		try {
			br = new BufferedReader (new InputStreamReader (((CSSimpleFile) file).getInputStream (true)));
			while ((line = br.readLine ()) != null) {
				matcher = validFilesPattern.matcher (line);
				while (matcher.find ()) {
					allFilesMap.add (matcher.group ());
				}
			}
		} catch (CSException csex) {
			findDcrImageDependenciesTaskLogger.error ("Failed retrieving file references: ", csex);
		} catch (IOException ioex) {
			findDcrImageDependenciesTaskLogger.error ("Failed retrieving file references: ", ioex);
		} finally {
			if (br != null) {
				try {
					br.close ();
				} catch (Exception ex) {
					findDcrImageDependenciesTaskLogger.error ("Failed closing reader ", ex);
				}
			}
		}

		findDcrImageDependenciesTaskLogger.info ("File contains " + allFilesMap.size () + " reference(s)");
		return allFilesMap;
	}

}
