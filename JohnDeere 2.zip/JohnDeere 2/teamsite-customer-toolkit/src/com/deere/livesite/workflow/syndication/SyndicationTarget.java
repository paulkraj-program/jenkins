package com.deere.livesite.workflow.syndication;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSVPath;

/**
 * SyndicationTarget is a data class that contains a single configuration entry
 * for a branch that can be syndicated. 
 * @author Klish Group, Inc. [ND]
 */
public class SyndicationTarget {
	private static final transient Logger LOGGER = Logger.getLogger(SyndicationTarget.class);
	
	private final String branch;
	private final String locale;
	private final String sitePath;
	private final boolean translationEnabled;
	private final String acrossOverideLocale;
	/**
	 * Create a new SyndicationTarget instance
	 * @param branch The syndication branch
	 * @param locale The locale of the branch
	 * @param sitePath The locale based site path for the branch
	 * @param translationEnabled Flag indicating if translation is enabled on this branch
	 * @param acrossOverrideLocale used to override locale such as es-ES to es-Es traditional for across
	 */
	public SyndicationTarget(String branch, String locale, String sitePath, boolean translationEnabled, String acrossOverideLocale) {
		this.branch = branch;
		this.locale = locale;
		this.sitePath = sitePath;
		this.translationEnabled = translationEnabled;
		this.acrossOverideLocale = acrossOverideLocale;
	}
	public SyndicationTarget(String branch, String locale, String sitePath, boolean translationEnabled) {
		this.branch = branch;
		this.locale = locale;
		this.sitePath = sitePath;
		this.translationEnabled = translationEnabled;
		this.acrossOverideLocale = null;
	}
	
	/**
	 * Get the branch
	 * @return The branch
	 */
	public String getBranch() {
		return branch;
	}
	
	/**
	 * Get the locale
	 * @return The locale
	 */
	public String getLocale() {
		return locale;
	}
	
	/**
	 * Get the site path
	 * @return The site path
	 */
	public String getSitePath() {
		return sitePath;
	}
	
	
	/**
	 * Get the locale
	 * @return The locale
	 */
	public String getAcrossLocale() {
		return acrossOverideLocale;
	}
	
	/**
	 * Get the flag indicating if translation is enabled
	 * @return Flag indicating if translation is enabled
	 */
	public boolean isTranslationEnabled() {
		return translationEnabled;
	}
	
	/**
	 * Convert the provided CSVPath to a target path from the source path
	 * @param sourcePath The source path
	 * @param target The syndication target
	 * @return The target path
	 */
	public CSVPath getTargetPath(CSVPath sourcePath, SyndicationTarget target) {
		// Replace the source locale with the target locale in the path
		LOGGER.debug("Converting source path to target path: " + sourcePath);
		return new CSVPath(replacePath(sourcePath.toString(), target));
	}
	
	/**
	 * Convert the provided CSAreaRelativePath to a target path from the source path
	 * @param sourcePath The source path
	 * @param target The syndication target
	 * @return The target path
	 */
	public CSAreaRelativePath getTargetPath(CSAreaRelativePath sourcePath, SyndicationTarget target) {
		// Replace the source locale with the target locale in the path
		LOGGER.debug("Converting source path to target path: " + sourcePath);
		return new CSAreaRelativePath(replacePath(sourcePath.toString(), target));
	}
	/**
	 * Convert the provided path to a target path from the source path
	 * @param path The source path
	 * @param target The syndication target
	 * @return The target path
	 */
	public String replacePath(String path, SyndicationTarget target) {
		path = path.replaceAll(getLocale(), target.getLocale());
		LOGGER.debug("Replaced source locale with target locale: " + path);
		
		path = path.replaceAll(getSitePath(), target.getSitePath());
		LOGGER.debug("Replaced source site path with target site path: " + path);
		
		return path;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((branch == null) ? 0 : branch.hashCode());
		
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SyndicationTarget)) {
			return false;
		}
		
		SyndicationTarget other = (SyndicationTarget) obj;
		
		if (branch == null) {
			if (other.branch != null) {
				return false;
			}
		} else if (!branch.equals(other.branch)) {
			return false;
		}
		
		return true;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return new StringBuilder("SyndicationTarget [branch = ").append(branch)
				.append(", locale = ").append(locale)
				.append(", sitePath = ").append(sitePath)
				.append(", translationEnabled = ").append(translationEnabled)
				.append(", acrossOverideLocale = ").append(acrossOverideLocale)
				.append("]")
				.toString();
	}
	
	/**
	 * Filter the provided Set of targets looking for the specified branch
	 * @param targets The Set of targets to filter
	 * @param branch The branch for which to search
	 * @return The SyndicationTarget instance or null if not found
	 */
	public static SyndicationTarget filterByBranch(Set<SyndicationTarget> targets, String branch) {
		for (SyndicationTarget target : targets) {
			if (target.getBranch().equals(branch.trim())) {
				return target;
			}
		}
		
		return null;
	}
	
	/**
	 * Filter the provided Set of targets looking for the specified locale
	 * @param targets The Set of targets to filter
	 * @param locale The locale for which to search
	 * @return The SyndicationTarget instance or null if not found
	 */
	public static SyndicationTarget filterByLocale(Set<SyndicationTarget> targets, String locale) {
		for (SyndicationTarget target : targets) {
			if (target.getLocale().equals(locale.trim())) {
				return target;
			}
		}
		
		return null;
	}
	
	
	/**
	 * Get the locale from SyndicationTarget locale based on AcrossLocale if not present then default site locale
	 * @param targets The Set of targets to filter
	 * @param locale The locale for which to search
	 * @return The SyndicationTarget instance or null if not found
	 */
	public static SyndicationTarget filterByTargetLocale(Set<SyndicationTarget> targets, String locale) {
		for (SyndicationTarget target : targets) {
			if (target.getAcrossLocale() != null && !"".equals(target.getAcrossLocale())) {
				if (target.getAcrossLocale().equalsIgnoreCase(locale.trim())) {
					return target;
				}
			} else {
				if (target.getLocale() != null && !"".equals(target.getLocale())) {
					if (target.getLocale().equalsIgnoreCase(locale.trim())) {
						return target;
					}
				}
			}

		}
		return null;
	}
	
	
	
	/**
	 * Filter the provided Set of targets looking for the specified collection
	 * of branches
	 * @param targets The Set of targets to filter
	 * @param branch The branches for which to search
	 * @return A Set of SyndicationTarget instances
	 */
	public static Set<SyndicationTarget> filterByBranches(Set<SyndicationTarget> targets, Collection<String> branches) {
		Set<SyndicationTarget> set = new HashSet<>();
		
		for (String branch : branches) {
			SyndicationTarget target = filterByBranch(targets, branch.trim());
			if (target != null) {
				set.add(target);
			}
		}
		
		return set;
	}
	
	/**
	 * Filter the provided Set of targets looking for the specified collection
	 * of locales
	 * @param targets The Set of targets to filter
	 * @param branch The locales for which to search
	 * @return A Set of SyndicationTarget instances
	 */
	public static Set<SyndicationTarget> filterByLocales(Set<SyndicationTarget> targets, Collection<String> locales) {
		Set<SyndicationTarget> set = new HashSet<>();
		
		for (String locale : locales) {
			SyndicationTarget target = filterByLocale(targets, locale.trim());
			if (target != null) {
				set.add(target);
			}
		}
		
		return set;
	}
	
}
