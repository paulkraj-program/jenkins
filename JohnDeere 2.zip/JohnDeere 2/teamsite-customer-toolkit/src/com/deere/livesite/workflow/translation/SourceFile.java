package com.deere.livesite.workflow.translation;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

/**
 * SourceFile is a class that contains the information required for a source
 * file element in the control.xml file of the Across control.xml file.
 * @author Klish Group, Inc. [ND]
 */
final class SourceFile {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationTask.class);
	
	private final String path;
	private final String name;
	private final String docType;
	private final String docTransform;
	private final String transformationName;
	
	/**
	 * Create a new instance of the SourceFile class with the provided parameters
	 * @param path The file path
	 * @param name The file name
	 * @param docType The document type
	 * @param transformationName The document transformation name
	 */
	public SourceFile(String path, String name, String docType, String docTransform, String transformationName) {
		this.path = path;
		LOGGER.debug("Project Source File Path: " + this.path);
		this.name = name;
		LOGGER.debug("Project Source File Name: " + this.name);
		this.docType = docType;
		LOGGER.debug("Project Source File Document Type: " + this.docType);
		this.docTransform = docTransform;
		LOGGER.debug("Project Source File Document Transform: " + this.docTransform);
		this.transformationName = transformationName;
		LOGGER.debug("Project Source File Transformation Name: " + this.transformationName);
	}
	
	/** Get the source file path */
	public String getPath() {
		return path;
	}
	/** Get the source file name */
	public String getName() {
		return name;
	}
	/** Get the source file document type */
	public String getDocType() {
		return docType;
	}
	/** Get the source file transformation name */
	public String getTransformationName() {
		return transformationName;
	}
	
	/**
	 * Build the source file XML element containing for the control.xml file.
	 * @return The XML element to be included in a control.xml file
	 */
	public Element toElement() {
		Element element = DocumentHelper.createElement("srcFile");
		
		element.addElement("srcFilePath").setText(path);
		element.addElement("srcFileNm").setText(name);
		element.addElement("acrossDocType").setText(docType);
		if (docTransform != null && !"".equals(docTransform)) {
			element.addElement("acrossDocTransform").setText(docTransform);
		}
		element.addElement("acrossDstNm").setText(transformationName);
		
		return element;
	}
	
	/**
	 * Build the source elements for the Across control.xml file based on the
	 * provided list of SourceFile instances.
	 * @param sourceFiles The list of SourceFile instances.
	 * @return The XML element to be included in a control.xml file
	 */
	public static Element toElement(List<SourceFile> sourceFiles) {
		Element element = DocumentHelper.createElement("srcFiles");
		
		for (SourceFile file : sourceFiles) {
			element.add(file.toElement());
		}
		
		return element;
	}
	
	/**
	 * Build a List of SourceFile instances from the provided XML Element instance.
	 * @param element The XML Element instance from which to build a SourceFile List
	 * @return The List of SourceFile instances built from the provided XML Element instance
	 */
	static List<SourceFile> buildList(Element element) {
		@SuppressWarnings("unchecked")
		List<Element> sourceFileElements = element.elements("srcFile");
		List<SourceFile> list = new ArrayList<SourceFile>();
		
		for (Element sourceFileElement : sourceFileElements) {
			list.add(build(sourceFileElement));
		}
		
		return list;
	}
	
	/*
	 * Build a SourceFile instance from the provided XML Element instance.
	 * @param element The XML Element instance from which to build a SourceFile
	 * @return The SourceFile instance built from the provided XML Element instance
	 */
	private static SourceFile build(Element element) {
		String path = element.elementText("srcFilePath");
		String name = element.elementText("srcFileNm");
		String docType = element.elementText("acrossDocType");
		String docTransform = element.elementText("acrossDocTransform");
		String transformationName = element.elementText("acrossDstNm");
		
		return new SourceFile(path, name, docType, docTransform, transformationName);
	}
	
}
