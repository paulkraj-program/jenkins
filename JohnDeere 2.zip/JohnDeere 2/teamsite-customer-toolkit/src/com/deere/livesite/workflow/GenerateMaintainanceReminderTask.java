package com.deere.livesite.workflow;

import com.deere.livesite.workflow.constants.MaintenanceReminderConstants;
import com.deere.livesite.workflow.common.Parts;
import com.deere.livesite.workflow.common.Product;
import com.deere.livesite.workflow.common.SitePublisherPage;
import com.deere.livesite.workflow.CommonServices;
import com.deere.livesite.workflow.POIServices;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSArea;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.livesite.model.page.Page;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * URL External Task to parse the attached excel sheet and generate  
 * Parts DCRs,Product DCR and Site Publisher Pages  
 */
public class GenerateMaintainanceReminderTask implements CSURLExternalTask {
	static final transient Logger LOGGER = Logger.getLogger(GenerateMaintainanceReminderTask.class);
	
	
	private static final List<String> TEMPLATE_LIST;
	private CSClient _client = null;
	private CSArea currentWorkarea = null;
	private static boolean overwritePages = false;
	private static boolean overwriteDcrs = false;
	private static String siteName;
	private static String pageBasePath;

	static {
		List<String> templates = new ArrayList<String>();
		templates.add(MaintenanceReminderConstants.MAINTENANCE_TEMPLATE);
		TEMPLATE_LIST = Collections.unmodifiableList(templates);
	}

	public void execute(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable parameters) throws CSException {
		LOGGER.debug("Start Generate Maintainance Reminder Task");
		String successTransitionComment = "Completed generating all the files.";
		boolean success = true;

		overwritePages = Boolean.valueOf(task.getVariable(MaintenanceReminderConstants.TASK_PARAM_OVERWRITE_PAGE)).booleanValue();
		overwriteDcrs = Boolean.valueOf(task.getVariable(MaintenanceReminderConstants.TASK_PARAM_OVERWRITE_DCR)).booleanValue();
		pageBasePath = getVariable(task, MaintenanceReminderConstants.TASK_PARAM_GENERATE_FOLDER_PATH, MaintenanceReminderConstants.DEFAULT_PAGE_FOLDER_PATH);
		siteName = getVariable(task, MaintenanceReminderConstants.TASK_PARAM_SITE_NAME, MaintenanceReminderConstants.DEFAULT_SITE_NAME);
		
		try {
			List<CSSimpleFile> attachedFileList = CommonServices.getAttachedFiles(task, Stream.of("xls", "xlsx").collect(Collectors.toList()));

			currentWorkarea = task.getArea();
			_client = client;
			for (CSSimpleFile file : attachedFileList) {
				LOGGER.debug("Processing : " + file.getVPath().getPathNoServer());
				if (!generate(file)) {
					success = false;
				}
			}
		} catch (CSException e) {
			LOGGER.error("Failed generating Maintainance reminder pages");
		}
		
		LOGGER.debug("Completed Processing all the rows");
		
		if (success) {
			task.chooseTransition(MaintenanceReminderConstants.SUCCESS_TRANSITION, successTransitionComment);
		} else {
			task.chooseTransition(MaintenanceReminderConstants.FAILURE_TRANSITION, "Failed generating Maintainance reminder pages.");
		}
	}

	/**
	 * Method to parse the attached excel sheet and generate DCR's and Sitepublisher pages.
	 * @param excel
	 * @return boolean
	 */
	private boolean generate(CSSimpleFile excel) {
		OPCPackage pkg = null;
		boolean generateFailed = false;
		try {
			pkg = OPCPackage.open(excel.getInputStream(true));
			XSSFWorkbook workbook = new XSSFWorkbook(pkg);
			LOGGER.debug("Processing " + workbook.getNumberOfSheets() + " sheets in " + excel.getName());

			if(workbook.getNumberOfSheets() < 3){
				LOGGER.error("Excel is missing some sheets. Please upload the valid spreadhseet.");
				return false;
			}
			
			Sheet partsSheet = workbook.getSheet(MaintenanceReminderConstants.PARTS_SHEET_NAME);
			Sheet modelsSheet = workbook.getSheet(MaintenanceReminderConstants.MODELS_SHEET_NAME);
			Sheet categorySheet = workbook.getSheet(MaintenanceReminderConstants.CATEGORY_SHEET_NAME);
			if (partsSheet != null) {
				partsSheet = workbook.getSheetAt(0);
			}
			
			if (modelsSheet != null) {
				modelsSheet = workbook.getSheetAt(1);
			}
			
			if (categorySheet != null) {
				categorySheet = workbook.getSheetAt(2);
			}
			
			if (partsSheet != null && modelsSheet != null) {
				LOGGER.debug("Processing :" + partsSheet.getSheetName());

				Map<String, List<Integer>> allModels = getModels(partsSheet);
				Map<String, String> validModels = getModelsToUpload(modelsSheet);
				Map<String, String> partsCategory = getPartsCategory(categorySheet);
				
				LOGGER.info("Total Models to be processed in the sheet :" + validModels.size());
				Map<String, String[]> generatedParts = new HashMap<String, String[]>();
				
				for (Entry<String, List<Integer>> entry : allModels.entrySet()) {
					String modelNumber = entry.getKey();

					if(validModels.containsValue(modelNumber)){
						Map<String, List<String[]>> subModels = getSubModels(entry.getValue(), partsSheet, modelNumber,validModels);
						
						for(Entry<String, List<String[]>> subModel : subModels.entrySet()){
							List<String[]> parts = subModel.getValue();
							String modelInfo = (String) subModel.getKey();
							String machineName = getMachineName(((String[]) parts.get(0))[2]);
							String machineDesc = modelInfo.split("\\|")[1];
							String fileName = getFileName(modelInfo, machineName);
							String workareaPath = currentWorkarea.getVPath().getPathNoServer().toString();
							
							Parts partsDcr = new Parts(_client, workareaPath, fileName, parts, generatedParts);
							
							generatedParts = partsDcr.generate(overwriteDcrs);
							Product productDcr = new Product(_client, workareaPath, fileName, modelNumber, machineName, machineDesc, partsDcr.getPartsReference(), partsCategory);
							
							if (overwriteFile(productDcr.getDcrPath(), overwriteDcrs)) {
								productDcr.generate();
							}
							
							String targetPagePath = getSitepublisherPagePath(fileName, (parts.get(0))[0]);
							
							if (checkAndOverwritePage(targetPagePath, overwritePages)) {
								SitePublisherPage page = new SitePublisherPage(_client, targetPagePath, 
										MaintenanceReminderConstants.PAGE_TYPE_ID, 
										MaintenanceReminderConstants.PAGE_LAYOUT_ID,  
										MaintenanceReminderConstants.CANVAS_PATH, TEMPLATE_LIST);
								Page generatedPage = page.generate(modelInfo.replaceAll("\\|", " - "), false);
								if (generatedPage != null) {
									page.updateComponentDcr(generatedPage, MaintenanceReminderConstants.PRODUCT_COMPONENT_AREA, 
											productDcr.getDcrPath(), 
											MaintenanceReminderConstants.PRODUCT_COMPONENT_NAME, 
											MaintenanceReminderConstants.PRODUCT_COMPONENT_DCR_DATUM_NAME);
									generateFailed = true;
								} else {
									LOGGER.error("Error generating Site Publisher page for " + fileName);
								}
							} 
						}
					}
				}
			} else {
				LOGGER.error("Error reading workbook sheet");
			}
			
			workbook.close();
			pkg.close();
			
		} catch (IOException ioex) {
			LOGGER.error("Error reading excel spread sheet to generate pages.", ioex);
		} catch (InvalidFormatException ifex) {
			LOGGER.error("Format of the excel spread sheet is invalid.", ifex);
		} catch (CSException csex) {
			LOGGER.error("Error reading excel spread sheet to generate pages.", csex);
		} finally {
			try {
				if (pkg != null) {
					pkg.close();
				}
			} catch (Exception e) {
				LOGGER.error("Closing OPCPackage handle.");
			}
		}
		return generateFailed;
	}

	/**
	 * Method to format Machine
	 * @param machineName
	 * @return formatted string
	 */
	private static String getMachineName(String machineName){
	
		if(machineName!= null && machineName.contains(",")){
			String[] name = machineName.split(",");
			return CommonServices.toCamelCase(name[1].trim()) + " " + CommonServices.toCamelCase(name[0].trim()); 
		}
	
		return machineName;
	}

	/**
	 * Method to check if a sitepublisher page needs to be overwritten and delete if true.
	 * @param targetPagePath
	 * @param overwrite
	 * @return boolean
	 * @throws CSException
	 */
	public boolean checkAndOverwritePage(String targetPagePath,
			boolean overwrite) throws CSException {
		CSFile targetFile = _client.getFile(new CSVPath(targetPagePath));
		if (targetFile != null && targetFile.getKind() != CSHole.KIND && targetFile.isValid()) {
			if (overwrite || targetFile.isLocked()) {
				LOGGER.debug("Deleting Existing File : " + targetPagePath);
				if (!CommonServices.deleteFile(targetFile)) {
					LOGGER.warn("Error Deleting Existing Page");
					return false;
				}
			} else {
				return false;
			}
		}
		return true;
	}

	/**
	 * Method to determine if the file needs to be overwritten
	 * @param filePath
	 * @param overwrite
	 * @return boolean
	 * @throws CSException
	 */
	public boolean overwriteFile(String filePath, boolean overwrite)
			throws CSException {
		CSFile csFile = _client.getFile(new CSVPath(filePath));
		if (csFile == null || (csFile != null && csFile.getKind() == CSSimpleFile.KIND && csFile.isLocked())
				|| overwrite) {
			return true;
		}
		return false;
	}

	/**
	 * Method to read MODELS to UPLOAD sheet
	 * @param sheet
	 * @return Map of all valid Models with sub-model details
	 */
	private Map<String, String> getModelsToUpload(Sheet sheet) {
		Map<String, String> validModels = new HashMap<String, String>();
		if(sheet!=null){
			for (Row row : sheet) {
				if (row.getRowNum() != 0) {
					String modelNumber = POIServices.getCellValue(row.getCell(0));
					String modelName = POIServices.getCellValue(row.getCell(1));
					validModels.put(modelNumber + "|" + modelName, modelNumber);
				}
			}
		}
		return validModels;
	}
	
	/**
	 * Method to read the Parts Category sheet
	 * @param sheet
	 * @return Map of all the part group and the category they belong to
	 */
	private Map<String, String> getPartsCategory(Sheet sheet) {
		Map<String, String> partsCategory = new HashMap<String, String>();
		
		if(sheet!=null){
			for (Row row : sheet) {
				if (row.getRowNum() != 0) {
					String maintPart = POIServices.getCellValue(row.getCell(0));
					String asNeededPart = POIServices.getCellValue(row.getCell(1));
					String maintkit = POIServices.getCellValue(row.getCell(2));
					if(!maintPart.isEmpty()){
						partsCategory.put(maintPart,"MaintenancePart");
						partsCategory.put(asNeededPart,"AsNeededPart");
						partsCategory.put(maintkit,"Kits");
					}
				}
			}
		}
		return partsCategory;
	}
	
	/**
	 * Method to iterate through all the rows in the sheet and all model details
	 * @param sheet
	 * @return Map of model number to list of all the rows for the model.
	 */
	private Map<String, List<Integer>> getModels(Sheet sheet) {
		Map<String, List<Integer>> models = new HashMap<String, List<Integer>>();
		if(sheet!=null){
			for (Row row : sheet) {
				if (row.getRowNum() != 0) {
					String modelNumber = POIServices.getCellValue(row.getCell(4));
					models.putIfAbsent(modelNumber, new ArrayList<Integer>());
					models.get(modelNumber).add(Integer.valueOf(row.getRowNum()));
				}
			}
		}
		return models;
	}

	/**
	 * Reads the parts excel sheet and gets only the parts for valid models.
	 * @param rowNumbers
	 * @param sheet
	 * @param model
	 * @param validModels
	 * @return Map of all the sub models with the part details.
	 */
	
	private  Map<String, List<String[]>> getSubModels(List<Integer> rowNumbers,
			Sheet sheet, String model, Map<String, String> validModels ) {
		Map<String, List<String[]>> subModels = new HashMap<String, List<String[]>>();
		Map<String, String> validSubModels = getValidModels(validModels,model);
		
		for (Integer rowNum : rowNumbers) {
			String[] rowEntry = POIServices.getRowValues(sheet.getRow(rowNum.intValue()));

			String exception = rowEntry[10];
			
			if (exception.isEmpty()) {
				for(String key: validSubModels.keySet()){
					String subModel = key;
					subModels.putIfAbsent(subModel, new ArrayList<String[]>());
					subModels.get(subModel).add(rowEntry);	
				}
			} else {
				for (String part : exception.split("\\|")) {
					String subModelName = model + "|" + part;
					if(validModels.containsKey(subModelName)){
						subModels.putIfAbsent(subModelName,new ArrayList<String[]>());
						subModels.get(subModelName).add(rowEntry);
					}
				}
			}
		}

		return subModels;
	}

	/**
	 * Method to get valid sub models for a specific model number.
	 * @param validModels
	 * @param modelNumber
	 * @return Map of valid model name and Number.
	 */
	private static Map<String, String> getValidModels(Map<String, String> validModels, String modelNumber){
		Map<String, String> models = new HashMap<String, String>();
		for(Entry<String, String> model: validModels.entrySet()){
			
			if(model.getValue().equalsIgnoreCase(modelNumber)){
				models.put(model.getKey(),model.getValue());
			}
		}
		
		return models;
	}
	
	/**
	 * Method to create DCR path from the product information.
	 * @param modelInfo
	 * @param subFolder
	 * @return FileName relative to the data folder.
	 */
	private String getFileName(String modelInfo, String subFolder) {
		String fileName = "";
		String folderName = "";
		String modelNumber = modelInfo.split("\\|")[0];
		String modelName = modelInfo.split("\\|")[1];
		if ((modelName != null) && (!modelName.isEmpty())) {
			fileName = modelName.replaceAll("[^a-zA-Z0-9]", "");
		}
		if ((subFolder != null) && (!subFolder.isEmpty())) {
			folderName = subFolder.replaceAll("[^a-zA-Z0-9]", "-").concat("/");
			folderName = folderName.replaceAll("-+", "-");
			folderName = folderName.toLowerCase();
		}
		return folderName + modelNumber + "_" + fileName;
	}

	/**
	 * Method to create Site publisher path.
	 * @param targetPageName
	 * @param locale
	 * @return Full Vpath of the page to be created.
	 */
	private String getSitepublisherPagePath(String targetPageName, String locale) {
		locale = locale.replace("+", "/");
		return this.currentWorkarea.getVPath().getPathNoServer() + "/sites/"
				+ siteName + "/" + locale.toLowerCase() + pageBasePath
				+ targetPageName + "/index.page";
	}

	/**
	 * Get specific variable from task.
	 * @param task
	 * @param variableName
	 * @param defaultvalue
	 * @return Value for a specific task variable.
	 * @throws CSException
	 */
	private String getVariable(CSExternalTask task, String variableName,
			String defaultvalue) throws CSException {
		String value = "";

		String varValue = task.getVariable(variableName);
		if ((varValue != null) && (!varValue.isEmpty())) {
			value = varValue;
		} else {
			value = defaultvalue;
		}
		return value;
	}
}
