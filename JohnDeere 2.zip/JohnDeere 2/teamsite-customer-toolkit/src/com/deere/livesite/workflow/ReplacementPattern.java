package com.deere.livesite.workflow;

import java.util.List;
import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;

public class ReplacementPattern {
	private static final transient Logger LOGGER = Logger.getLogger(ReplacementPattern.class);
	private final String _pattern;
	private final String _replacement;

	public ReplacementPattern(String pattern, String replacement) {
		_pattern = pattern;
		_replacement = replacement;
		LOGGER.debug("Creating replacement pattern: " + _pattern + " => " + _replacement);
	}

	/**
	 * Apply the ReplacementPattern to the provided input string.
	 * @param input The input String with which to apply the pattern replacement
	 * @return The result of the replacement on the input String
	 */
	public String apply(String input) {
		if (input != null) {
			String output = input.replaceAll(_pattern, _replacement);
			LOGGER.debug("String after replacement: " + ESAPI.encoder().encodeForHTML(output));
			System.out.println("#" + input.replaceAll(_pattern, _replacement));
			return output;
		}
		LOGGER.debug("Input value was empty (null)");
		return null;
	}

	/**
	 * Applies patterns defined in the generate configuration file
	 * @param patternList	list of patterns to be applied
	 * @param source	text to have patterns applied to
	 * @return	the updated text after applying patterns
	 */
	public static String applyPatterns(String source, List<ReplacementPattern> patternList) {
		if (patternList != null && patternList.size() > 0) {
			for (ReplacementPattern pattern : patternList) {
				source = pattern.apply(source);
			}
		} else {
			LOGGER.info("No patterns available; returning source text unaltered.");
		}
		return source;
	}
}
