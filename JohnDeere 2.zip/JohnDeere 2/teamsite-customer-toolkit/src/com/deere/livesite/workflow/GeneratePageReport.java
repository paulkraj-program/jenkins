package com.deere.livesite.workflow;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;

import com.deere.livesite.workflow.constants.GenericConstants;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.sci.filesys.CSFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;



public class GeneratePageReport implements CSURLExternalTask {
	private static final  Logger LOGGER = Logger.getLogger(GeneratePageReport.class);
	private List<CSSimpleFile> AttachFiles;
	private HashSet<String> ParentAssociatedFiles;
	public void execute(CSClient client, CSExternalTask task, Hashtable arg2)  throws CSException {
		try {
			AttachFiles = new ArrayList<CSSimpleFile>();
			String branchName = "selected Branch";
			 XSSFWorkbook workbook = new XSSFWorkbook();
			   XSSFSheet sheet = workbook.createSheet("Page List");
			   int rownum = 1;
			   Row frow = sheet.createRow(0); 
			    
		 		Cell cell = frow.createCell(0);
		 		cell.setCellValue("DCR Name"); 
		 		
		 		cell = frow.createCell(1);
		 		cell.setCellValue("Page Name");
		 		sheet.setAutoFilter(CellRangeAddress.valueOf("A1:B1"));
		 		sheet.setColumnWidth(0,80*256);
		 		sheet.setColumnWidth(1,80*256);
			 CSAreaRelativePath[] relativePath = task.getFiles();
			 for (CSAreaRelativePath file : relativePath) {
				com.interwoven.cssdk.filesys.CSFile CSfile = task.getArea().getFile(file); 
					if (CSSimpleFile.KIND == CSfile.getKind()) {
				   		AttachFiles.add((CSSimpleFile)CSfile);
				   	 }
				   	if (CSDir.KIND == CSfile.getKind()) {
				       AttachFiles.addAll(getAllFilesInDirectory(task, (CSDir) CSfile, "ALL"));
				     }
				    }
				   LOGGER.debug("The Size of AttachFiles is >>>>>>>>"+AttachFiles.size());
				   LOGGER.debug("The Value of AttachFiles is >>>>>>>>"+AttachFiles);
				   ParentAssociatedFiles = new HashSet();
				   for(CSSimpleFile SiteFile: AttachFiles)  {
				     	 
					   String dcrValue = SiteFile.getVPath().toString();
				     	LOGGER.debug("SiteFile to check for Parent Dependency is >>>>"+dcrValue);
				     	
				     	
				     	 try {
				     		LOGGER.debug(">>>>>>>>>>>>>>>>>>>>Checking the association>>>>>>>>>>>>>>>");
				     		if(SiteFile instanceof CSSimpleFile && CSSimpleFile.kDCR == SiteFile.getContentKind()) {
				     	  CSAssociation[] allDependencies = SiteFile.getChildAssociations(null, false, false);
				      	
				     	 for(CSAssociation as:allDependencies) {
				     		
				     		
				     		if((as.getSecondary().getUAI().contains("/WORKAREA/")) && (as.getSecondary().getUAI().contains(".page"))) {
				     		  String as1 = as.getSecondary().getUAI();
				     		 
				     		ParentAssociatedFiles.add(as1);
				     		
									 XSSFRow row = sheet.createRow(rownum++);
									 XSSFCell cell1 = row.createCell(0);
									 XSSFCell cell2 = row.createCell(1);
									    if(dcrValue instanceof String)
									    	cell1.setCellValue((String)dcrValue);
									    if(as1 instanceof String)
										     cell2.setCellValue((String)as1);
				     		}
				     		}
				     	
						   
				     	 }

				     	 
				     	 }
				     	 
				     	 catch(Exception e) {
				     		LOGGER.error ("Caught exception in GeneratePageReport Task for getting the Association and adding to the Excel sheet : " + e + e.getMessage ());
				     	 }
				     	

				      }
				   LOGGER.debug("Total FIlelist of selected "+ParentAssociatedFiles.toString());
				   LOGGER.debug("Total FIlelist of Count "+ParentAssociatedFiles.size());
				   EmailTemplateImpl emailTemp=new EmailTemplateImpl();
				   String EmailSender=GenericConstants.EMAIL_FROM;
				   String Email_CC=GenericConstants.EMAIL_CC;

				   Date date = new Date() ;
				   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
				   
				  
				   String outputFile="/tmp/AssociatedPages"+dateFormat.format(date) + ".xlsx";
				   LOGGER.debug("Output File path " + outputFile); 
				  
				  
				  
				   
				   
				   try
				   {
				    //Write the workbook in file system
				    FileOutputStream out = new FileOutputStream(new File(outputFile));
				    workbook.write(out);
				    out.close();
				    LOGGER.debug("Page Generation report has been created successfully");
				   } 
				   catch (Exception e) 
				   {
					   LOGGER.error ("Caught exception while writing to workbook in GeneratePageReport Task : " + e + e.getMessage ());
				   }
				   finally {
				    workbook.close();
				   }
				   EmailTemplateImpl.getInstance();
				   emailTemp.getMailSession();

				   String receiverString=client.getCurrentUser().getEmailAddress();

				   String subject="Associated Pages of selected DCR Report"+dateFormat.format(date);
				   emailTemp.sendEmail(EmailSender,receiverString ,branchName, Email_CC, subject, outputFile);
		}
		catch(Exception e)
		{
			LOGGER.error ("Caught exception in GeneratePageReport Task : " + e + e.getMessage ());
		}
		task.chooseTransition(task.getTransitions()[0], "Report Generated for Associated Pages");
	}
	
	private static List<CSSimpleFile> getAllFilesInDirectory(CSTask task, CSDir directory,String type) {

		List<CSSimpleFile> paths = new ArrayList<CSSimpleFile>();
		List<CSDir> queue = new ArrayList<CSDir>();
		queue.add(directory);
		while (!queue.isEmpty()) {
			CSDir curr = queue.remove(0);
			
			try {
				for (CSNode child : curr.getChildren()) {
					if (CSDir.KIND == child.getKind()) {
						queue.add((CSDir) child);
					} else if (CSSimpleFile.KIND == child.getKind()) {
						
						if(type.equals("ALL")) {
						paths.add((CSSimpleFile) child);
					     }
						else if (type.equals("PAGE")){
							
							if(child.toString().contains(".page")) {
								paths.add((CSSimpleFile) child);
							}
						} 	
						else {}
					}
				}
			} catch (CSException e) {

				LOGGER.error ("CSException Caught in getAllFilesInDirectory for GeneratePageReport Task : " + e + e.getMessage ());
			}
		}
		
		return paths;
	}

	
}
