package com.deere.livesite.workflow.bulk;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;

import com.deere.livesite.authoring.common.constants.PIMContsants;
import com.deere.livesite.workflow.AbstractURLExternalTask;
import com.deere.livesite.workflow.FileDependency;
import com.deere.livesite.workflow.FileDependencyAnalyzer;
import com.deere.livesite.workflow.utils.FileUtils;
import com.deere.livesite.workflow.constants.WorkflowConstants;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSIllegalOpException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.livesite.workflow.WorkflowUtils;


/**
 * AttachDependenciesTask is an implementation of CSURLExternalTask that
 * processes the files attached to the workflow adding all files under
 * directories that are attached and processing all primary associations of the
 * processed files.  This task does the following items in order:
 * 	1) Add all child files of all directory files to the working list
 * 	2) Add all primary associations to the working list
 * 	3) Filter all files in the working list based on the filter criteria
 * 		*) Black list
 * 		*) Exclusion filter (regular expression) case-insensitive on relative file path
 * 	4) Detach all files from the workflow
 *  5) Attach remaining files in working list to workflow
 * @author Klish Group, Inc. [ND]
 */
public class AttachDependenciesTask extends AbstractURLExternalTask {
	private static final transient Logger attachDependenciesTaskLogger = Logger.getLogger(AttachDependenciesTask.class);

	private static final String PATH_GLOBAL_BLACKLIST = "/iwadmin/main/deere/syndication/STAGING/configuration/blacklist-bulk.txt";

	private static final String VAR_DISABLE_GLOBAL_BLACKLIST = "DisableGlobalBlacklist";
	
	private static final String DCRFILELIST ="DCRFileList";
	
	// iw/config/Syndication_Exclusionfilelist.cfg
	private static final String VAR_BLACKLIST_PATH		= "BlackListPath";
	private static Set<String> referencedDCRFileList = new HashSet<String> ();
	
	/**
	 * Iterate through all the attached files to the task. Check if there are any .page files attached 
	 * if yes then first find any XML, CSS or JS filename references available in .page file 
	 * if yes then see if there are any DCRs if any DCRs found then again try to find file references in DCR, 
	 * Do this for all attached .page files and referenced DCR files. 
	 * At last attached all unique files to the task and make sure all attached files do exist in TeamSite.
	 * Make a valid transition based on success and failure 
	 */
	@Override
	public void execute(CSClient client, CSExternalTask task) throws CSException {
		execute(client, (CSTask) task);
	}
	
	public static void execute(CSClient client, CSTask task) throws CSException {
		Set<String> blacklist = new TreeSet<>();
		
		// Check if the global black list is disabled
		if (!Boolean.parseBoolean(task.getVariable(VAR_DISABLE_GLOBAL_BLACKLIST))) {
			blacklist.addAll(loadBlacklistFile(client, new CSVPath(PATH_GLOBAL_BLACKLIST)));
		}
		
		// Load the blacklist file to filter out anything like default.site
		String blacklistPath = task.getVariable(VAR_BLACKLIST_PATH);
		attachDependenciesTaskLogger.debug("Blacklist Path: " + blacklistPath);
		
		if (blacklistPath != null && !"".equals(blacklistPath)) {
			CSVPath staging = task.getArea().getBranch().getStaging().getVPath().concat(blacklistPath);
			blacklist.addAll(loadBlacklistFile(client, staging));
		}
		attachDependenciesTaskLogger.debug("Black List: " + blacklist);
		
		// Build a list of CSSimpleFile with the files to process, expanding all
		// directories on the attached files list
		List<CSSimpleFile> filesToProcess = new ArrayList<>();
		
		for (CSAreaRelativePath areaRelativePath : task.getFiles()) {
			attachDependenciesTaskLogger.info("Processing Default Attached File : " + areaRelativePath);
			if (isInBlacklist(blacklist, areaRelativePath)) {
				attachDependenciesTaskLogger.info("EXCLUDING: Path " + areaRelativePath + " is on blacklist");
				continue;
			}
			
			CSFile file = task.getArea().getFile(areaRelativePath);
			
			if (file == null) {
				attachDependenciesTaskLogger.info("File " + areaRelativePath + " does not exist in workarea");
				continue;
			}
			
			if (CSDir.KIND == file.getKind()) {
				attachDependenciesTaskLogger.debug("Expanding contents of directory: " + areaRelativePath);
				filesToProcess.addAll(getAllFilesInDirectory(task, (CSDir) file, blacklist));
			} else if (CSSimpleFile.KIND == file.getKind()) {
				attachDependenciesTaskLogger.debug("Adding file to processing list: " + areaRelativePath);
					filesToProcess.add((CSSimpleFile) file);
				
			}
		}
		
		// Build a list of files to attach to the workflow
		List<CSAreaRelativePath> filesToAttach = new ArrayList<>();
		CSAreaRelativePath[] attachedPaths = task.getFiles();
		
		String filterPattern = FileDependencyAnalyzer.getFilterPatternString(task);
		FileDependencyAnalyzer analyzer = new FileDependencyAnalyzer(client, task.getArea(), filterPattern);
		
		// Find the all dependencies of the files to process
		for (CSSimpleFile file : filesToProcess) {
			attachDependenciesTaskLogger.info("DEPENDENCY: " + file.getVPath().getAreaRelativePath());
			
			filesToAttach.add(file.getVPath().getAreaRelativePath());
			
			// Find and attache dependencies for SitePublisher page files only
			// the analyzer will work for both DCRs and SitePublisher pages, so
			// we want to filter at this point instead.
			if ("page".equals(file.getVPath().getExtension())) {
				List<FileDependency> dependencies = analyzer.analyze(file);
				
				for (FileDependency dependency : dependencies) {
					isDCRFile(dependency,task);
					if (isInBlacklist(blacklist, dependency.getPath())) {
						attachDependenciesTaskLogger.info("EXCLUDING: Path " + dependency.getPath() + " is on blacklist");
						continue;
					}
					
					attachDependenciesTaskLogger.info("DEPENDENCY: " + dependency.getPath());
					filesToAttach.add(dependency.getPath());
				}
			}
		}
		
		String dcrFileListPath = WorkflowUtils.findVariable (task, WorkflowConstants.DCRFILELISTPATH);
		
		if (dcrFileListPath != null && !"".equals (dcrFileListPath)) {
			dcrFileListPath += File.separator + DCRFILELIST + "_" + task.getWorkflowId () + ".txt";
		} else {
			dcrFileListPath = File.separator + DCRFILELIST +"_"+task.getWorkflowId () + ".txt";
		}
		
		try {
			writeDCRFileList(dcrFileListPath, referencedDCRFileList);
		} catch (IOException e) {

			attachDependenciesTaskLogger.error("Error while creating DCR File list in  tmp" +e +e.getMessage());
			
			
		}
		// Remove all files currently attached to the workflow
		// This removed anything that might be originally attached and filtered
		// out by the blacklist, etc. (default.site, etc.) 
		task.detachFiles(attachedPaths);
		
		attachDependenciesTaskLogger.debug("Detached all files from workflow after dependency processing: " + Arrays.asList(attachedPaths));
		
		//Detaching DCR file from the attached files
		ArrayList<String> DCRPaths=null;
		task.setVariable(WorkflowConstants.DCR_FILENAME, dcrFileListPath);
		attachDependenciesTaskLogger.debug("Setting DCR fileList variable :"+task.getVariable(WorkflowConstants.DCR_FILENAME));
		if ((dcrFileListPath != null) && !"".equals(dcrFileListPath)){
			DCRPaths = FileUtils.readDCRPathFile(dcrFileListPath);
		}

		ArrayList<CSAreaRelativePath> dcrPathList=new ArrayList<CSAreaRelativePath>();
		for(String referencedDCRFile:DCRPaths){
			attachDependenciesTaskLogger.debug("Converting file path "+referencedDCRFile +" to CSAreaRelativePath");
			CSAreaRelativePath areaRelativePath=new CSAreaRelativePath(referencedDCRFile);
			dcrPathList.add(areaRelativePath);	
		}
		
		CSAreaRelativePath[] dcrPaths = dcrPathList.toArray(new CSAreaRelativePath[dcrPathList.size()]);
		task.detachFiles(dcrPaths);
		
		attachDependenciesTaskLogger.debug("Detached all DCR Files from workflow after writing data on temp " + Arrays.asList(dcrPaths));
		
		
		// Add all the files after validation processing
		CSAreaRelativePath[] paths = filesToAttach.toArray(new CSAreaRelativePath[filesToAttach.size()]);
		task.attachFiles(paths);
		attachDependenciesTaskLogger.debug("Attached all files and dependencies to workflow: " + Arrays.asList(paths));
	}
	
	/**
	 * 
	 * @param dependency
	 * @param task
	 * @throws CSException
	 */

	private static void isDCRFile(FileDependency dependency,CSTask task) throws  CSException {
		attachDependenciesTaskLogger.debug("File passed form page dependencies "+task.getArea ().getFile (dependency.getPath()));
	if(((CSSimpleFile) task.getArea ().getFile (dependency.getPath())).getContentKind () == CSSimpleFile.kDCR){
		attachDependenciesTaskLogger.debug("Attached file is a DCR");
			referencedDCRFileList.add(dependency.getPath().toString());
		}
		
	}

	/**
	 * This function writes the DCR file list to be used by Opendeploy to
	 * deploy the image files associated with the DCR on the page deployed.
	 * @param aFileName name of the file list
	 * @param referencedDCRPathsForDCRFile paths for the DCR 
	 * @throws IOException
	 */
	private static void writeDCRFileList (String aFileName, Set<String> referencedDCRPathsForDCRFile) throws IOException {
		try (BufferedWriter writer = Files.newBufferedWriter (Paths.get (aFileName), StandardCharsets.UTF_8)) {
			for (String csa : referencedDCRPathsForDCRFile) {
				writer.write (csa);
				writer.newLine ();
			}
			//	writer.close();
		}
	}
	
	
	private static List<CSSimpleFile> getAllFilesInDirectory(CSTask task, CSDir directory, Set<String> blacklist) throws CSException {
		List<CSSimpleFile> paths = new ArrayList<>();
		List<CSDir> queue = new ArrayList<>();
		queue.add(directory);
		
		while (!queue.isEmpty()) {
			CSDir curr = queue.remove(0);
			
			for (CSNode child : curr.getChildren()) {
				CSAreaRelativePath path = child.getVPath().getAreaRelativePath();
				if (isInBlacklist(blacklist, path)) {
					attachDependenciesTaskLogger.debug("EXCLUDING: Path " + path + " is on blacklist");
					continue;
				}
				
				if (CSDir.KIND == child.getKind()) {
					queue.add((CSDir) child);
				} else if (CSSimpleFile.KIND == child.getKind()) {
					paths.add((CSSimpleFile) child);
				}
			}
		}
		
		return paths;
	}
	
	private static boolean isInBlacklist(Set<String> blacklist, CSAreaRelativePath path) {
		String item = path.toString();
		attachDependenciesTaskLogger.debug("Looking for path: " + item + " in blacklist");
		for (String regex : blacklist) {
			attachDependenciesTaskLogger.debug("Blacklist pattern: " + regex + " => " + item);
			if (item.matches(regex)) {
				attachDependenciesTaskLogger.debug("Match found in blacklist");
				return true;
			}
		}
		
		return false;
	}
	
	private static Set<String> loadBlacklistFile(CSClient client, CSVPath path) throws CSException {
		attachDependenciesTaskLogger.debug("Loading BlackList: " + path);
		CSFile file = client.getFile(path);
		
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile simpleFile = (CSSimpleFile) file;
			
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(simpleFile.getInputStream(true)))) {
				Set<String> lines = new TreeSet<>();
				String line = null;
				
				while ((line = reader.readLine()) != null) {
					attachDependenciesTaskLogger.debug("Blacklist Path: " + line);
					lines.add(line);
				}
				
				attachDependenciesTaskLogger.debug("Blacklist: " + lines);
				return lines;
			} catch (IOException ioe) {
				throw new CSException(ioe);
			}
		}
		
		return Collections.emptySet();
	}
	
	
	/**
	 * Read the page paths data from temp file and delete the temp file after that : start
	 * @param pagePathsfile
	 * @param serverInstance
	 * @return
	 */
	private static ArrayList<String> readDCRPathFile(String pagePathsfile) {
		BufferedReader pagePathBReader = null;
	//	FileReader pagePathFReader = null;
		ArrayList<String> dcrFileListFromTmpFile = new ArrayList<String>();
		try {

			String pagePathline;

			pagePathBReader = Files.newBufferedReader(Paths.get(pagePathsfile), Charset.defaultCharset());

			while ((pagePathline = pagePathBReader.readLine()) != null && !"".equals(pagePathline)) {
				attachDependenciesTaskLogger.debug("Reading Temporary file for page paths is started in AttachDependenciesTask file :"
						+ pagePathline);
				dcrFileListFromTmpFile.add(pagePathline);
			}

			attachDependenciesTaskLogger.debug("file name for page path in AttachDependenciesTask is " + pagePathsfile);

		} catch (IOException ioe) {
			attachDependenciesTaskLogger.error ("Caught IOException in readDCRPathFile method  for AttachDependenciesTask : " + ioe + ioe.getMessage ());
		} finally {

			try {

				if (pagePathBReader != null)
					pagePathBReader.close();

			/*	if (pagePathFReader != null)
					pagePathFReader.close();
			*/
				/*
				 * if(serverInstance.equalsIgnoreCase(PIMContsants.
				 * PROD_SERVER_INSTANCE)&&(tempFile.isFile())) {
				 * LOGGER.info("server instance is"+serverInstance); LOGGER.
				 * info("In AsynchronousTask, temporary page path file deletion started and its path is"
				 * +tempFile.getAbsolutePath()); boolean deletdFile =
				 * tempFile.delete(); LOGGER.
				 * info("In AsynchronousTask, temporary page path file deletion completed "
				 * +deletdFile); }
				 */

			} catch (IOException | SecurityException ioex) {
				attachDependenciesTaskLogger.error ("Caught IOException/SecurityException in readDCRPathFile method  for AttachDependenciesTask : " + ioex + ioex.getMessage ());
			}

		}

		return dcrFileListFromTmpFile;
	}
}
