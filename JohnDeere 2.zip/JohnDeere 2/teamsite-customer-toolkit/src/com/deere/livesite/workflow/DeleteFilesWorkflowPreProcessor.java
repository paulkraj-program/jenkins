package com.deere.livesite.workflow;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.modeler.workflow.WFMGroupTask;
import com.interwoven.modeler.workflow.WFMTask;
import com.interwoven.modeler.workflow.WFMWorkflow;
import com.interwoven.modeler.workflow.commands.InProcessJavaCommand;
import com.interwoven.modeler.workflow.exceptions.WFMException;

public class DeleteFilesWorkflowPreProcessor implements InProcessJavaCommand {
	private static String PROP_CSFACTORY = "com.interwoven.cssdk.factory.CSFactory";
	private static String PROP_CSFACRORY_IMPL = "com.interwoven.cssdk.factory.CSJavaFactory";
	private static String ASSETS = "Assets";
	private static String WORKAREA = "workarea";
	private static String GLOBAL_GROUP = "iwEveryone";
	private static String APPROVAL_TASK = "Approval Task";
	private static final transient Logger LOGGER = Logger.getLogger(DeleteFilesWorkflowPreProcessor.class);

	public WFMWorkflow execute(WFMWorkflow workflow, Map<String, String> parameters) {

		try {
			String reviewerGroup = null;
			List<String> groups = new ArrayList<String>();
			String workarea = parameters.get(WORKAREA);
			LOGGER.debug("Workarea Path: " + workarea);
			CSClient client = getCSClient();
			Pattern assetsBranchNamePattern = Pattern.compile(ASSETS);
			if (!assetsBranchNamePattern.matcher(workarea).find()) {
				String groupName = client.getWorkarea(new CSVPath(workarea), false).getGroup().getDisplayName();
				LOGGER.debug("Workarea group retrieved: " + groupName);
				reviewerGroup = StringUtils.replace(groupName, "-shared", "-reviewer");
			} else {
				reviewerGroup = GLOBAL_GROUP;
			}
			LOGGER.debug("Reviewer group updated to: " + reviewerGroup);
			
			groups.add(reviewerGroup);
			WFMTask[] tasks = workflow.getTasks();
			for (WFMTask task : tasks) {
				if (task.getName().equals(APPROVAL_TASK)) {
					LOGGER.debug("Approval task found : " + task.getName());
					WFMGroupTask groupTask = (WFMGroupTask) task;
					groupTask.addSharedByGroups(groups);
					LOGGER.debug("Approval task owner set to : " + reviewerGroup);
					break;
				}
			}

		} catch (WFMException | CSException e) {
			throw new RuntimeException(e);

		}

		return workflow;

	}

	private static CSClient getCSClient() throws CSException {
		Properties properties = new Properties(System.getProperties());
		LOGGER.debug("Getting CSClient instance");

		if (properties.getProperty(PROP_CSFACTORY) == null) {
			properties.setProperty(PROP_CSFACTORY, PROP_CSFACRORY_IMPL);
		}
		CSFactory factory = CSFactory.getFactory(properties);
		return factory.getClientForCurrentUser(Locale.getDefault(), "WorkflowContext", null);
	}

}
