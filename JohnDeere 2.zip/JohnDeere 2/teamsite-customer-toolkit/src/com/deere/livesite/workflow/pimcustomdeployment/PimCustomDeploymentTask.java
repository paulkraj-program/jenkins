package com.deere.livesite.workflow.pimcustomdeployment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileCleaningTracker;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSNameValuePair;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.deployapi.deploy.IWDeployService;
import com.interwoven.deployapi.service.IWODService;
import com.interwoven.serverutils100.InstalledLocations;
import com.interwoven.ui.teamsite.workflow.task.urltask.DeployURLExternalTask;
import com.interwoven.deployapi.service.IWODServiceLocator.UnknownDescriptorException;
import com.interwoven.deployapi.service.IWODServiceLocator.UnknownServiceException;
import com.interwoven.livesite.workflow.WorkflowUtils;
import java.util.Date;
import java.sql.Timestamp;

/**
 * This is a TeamSite workflow Deployment task which creates a file list used by
 * an OpenDeploy deployment to send the attached files to a target server. <br/>
 * The attached file paths are modified to remove "/sites" from the start of any
 * file path such that both generated HTML and dependent fragment HTML and JSON
 * files are deployed to the proper document root on the web server. <br/>
 * Unfortunately, the OOTB DeployURLExternalTask is not very extensible, so many
 * of its methods have to be duplicated here.
 * 
 * @author Klish Group, INC. [AG] updated to append task id to odDeploymentInst,
 *         please refer JDW-532 Updated for deployment file list pattern to fix
 *         the 'sites' issue - QC1108
 **/
public class PimCustomDeploymentTask extends DeployURLExternalTask {
	private static final Logger LOGGER = Logger.getLogger(PimCustomDeploymentTask.class);

	private FileCleaningTracker fileCleaningTracker = new FileCleaningTracker();

	/**
	 * This function has been overridden from the parent DeployURLExternalTask
	 * class to create the custom file list for the deployment.
	 * 
	 * @param task
	 *            the workflow deployment task
	 * @param params
	 *            parameters passed into the task
	 * @param csSessionString
	 *            the TeamSite authorization session string
	 * @return
	 */
	@Override
	protected void startDeployment(CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable params,
			String csSessionString) throws CSException {
		LOGGER.debug("CustomDeploymentTask.startDeployment");
		Date date =new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		LOGGER.debug("Current timestamp is "+ts);
		CustomStartDeployHelper start = new CustomStartDeployHelper();

		// StartDeploy
		String taskOwner = task.getOwner().getName();
		start.setUserName(taskOwner);

		start.setDeploymentName(task.getVariable(DEPLOY_TASKVAR_DEPLOYNAME));
		start.setExtTaskID(task.getId());
		start.setOdHost(task.getVariable(DEPLOY_TASKVAR_HOSTNAME));
		start.setSessionString(csSessionString);
		String portVar = task.getVariable(DEPLOY_TASKVAR_PORTNUM);
		if ((portVar == null) || (portVar.length() < 0)) {
			portVar = "9173";
		}
		start.setOdPort(Integer.parseInt(portVar));

		String instName = task.getVariable("odDeploymentInst");
		if ((instName != null) && (instName.length() > 0)) {
			// updated to append task ID to deployment - JDW-532
			int taskID = task.getId();
			LOGGER.debug("CustomDeploymentTask - task id:" + taskID);
			if (taskID > 0) {
				start.setInst(instName + "_" + taskID);
			} else {
				start.setInst(instName);
			}

		}

		File tempFile = createTempFilelistFile(task);
		@SuppressWarnings("rawtypes")
		Vector keyValuePairs = getSubstKeyValuePairs(task, tempFile);
		start.setSubsKeyValue(keyValuePairs);

		String status = task.getVariable(DEPLOY_TASKVAR_STATUS);
		String mt = "";
		if ((status == null) || (mt.equals(status))) {
			status = "Started";
		} else {
			status = "Restarted";
		}

		task.setVariable(DEPLOY_TASKVAR_STATUS, status);
		LOGGER.debug("OD Deployment Status set " + status);

		StringBuffer resultBuffer = new StringBuffer();
		try {
			start.runIt(resultBuffer, task.getVariable(DEPLOY_TASKVAR_HOSTNAME), Integer.parseInt(portVar));
		} catch (Exception e) {
			LOGGER.warn("caught this from start.runIt(): ", e);
			if (getCaught() == null) {
				setCaught(e);
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("StartDeploy result buffer: " + resultBuffer.toString());
		}

		String uuid = start.getUuid();
		if (uuid != null) {
			task.setVariable(DEPLOY_TASKVAR_UUID, uuid);
		}

		status = start.getDeploymentStatus();
		if (status != null) {
			task.setVariable(DEPLOY_TASKVAR_STATUS, status);
		} else {
			status = "";
		}
		String code = start.getDeploymentStatusCode();
		if (code == null) {
			code = "";
		}
LOGGER.debug("OpenDeploy Code value is :: "+code);
		String[] transitions = task.getTransitions();
		String successTransition = getSuccessTransitionName(params, transitions);
		String failureTransition = getFailureTransitionName(params, transitions);
		String targetRetryTask = WorkflowUtils.findVariable(task, "TargetRetryDeployment");
		 LOGGER.debug("Target Retry task is ::: "+targetRetryTask);
		LOGGER.debug("previewDeploy retry count value is :: "+task.getWorkflow().getVariable("PreviewDeploy_retryCount"));
		int PreviewDeploy_retryCount = Integer.parseInt(task.getWorkflow().getVariable("PreviewDeploy_retryCount"));
		int ProdDeploy_retryCount = Integer.parseInt(task.getWorkflow().getVariable("ProdDeploy_retryCount"));
		int max_retries = 2;
		String taskName = task.getName().toString();
LOGGER.debug("Current Task name is :: "+taskName);
LOGGER.debug("Max Retries configured :: "+max_retries);
LOGGER.debug("Task owner is+++++++++++++  "+task.getWorkflow().getOwner().toString().equalsIgnoreCase("otadm82dusr"));
		// Prod Deployment
if (taskName.equalsIgnoreCase("Preview Deployment")) {
	LOGGER.debug("Entered into Preview deployment if block");
                    if (getCaught() != null) {
						LOGGER.debug("");
                          if (PreviewDeploy_retryCount < max_retries) {
                                 PreviewDeploy_retryCount = PreviewDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("PreviewDeploy_retryCount", String.valueOf(PreviewDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition, getCaught().getLocalizedMessage());
                          }
                    } else if (code.equals("S_COMPLETED_WITH_ERROR")) {
						LOGGER.debug("");
                          if (PreviewDeploy_retryCount < max_retries) {
                                 PreviewDeploy_retryCount = PreviewDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("PreviewDeploy_retryCount", String.valueOf(PreviewDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition, resultBuffer.toString());
                          }

                    } else if ((code.equals("S_FAILED")) || (code.equals("S_ROLLED_BACK")) || (code.equals("S_ABORTED"))) {
                          if (PreviewDeploy_retryCount < max_retries) {
                                 PreviewDeploy_retryCount = PreviewDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("PreviewDeploy_retryCount", String.valueOf(PreviewDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition, resultBuffer.toString());
                          }

                    } else if ("S_COMPLETED".equals(code)) {
                          task.chooseTransition(successTransition, resultBuffer.toString());
                    } else {
                          if (PreviewDeploy_retryCount < max_retries) {
                                 PreviewDeploy_retryCount = PreviewDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("PreviewDeploy_retryCount", String.valueOf(PreviewDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
							  LOGGER.debug("previewDeploy retry count reached to  "+PreviewDeploy_retryCount);
                                 task.chooseTransition(failureTransition,
                                              "OpenDeploy Status Unknown. FAILED. " + resultBuffer.toString());
                          }
                    }
             } else if (taskName.equalsIgnoreCase("Prod Deployment")&&(task.getWorkflow().getOwner().toString().equalsIgnoreCase("otadm82dusr"))){
                    if (getCaught() != null) {
                          if (ProdDeploy_retryCount < max_retries) {
                                 ProdDeploy_retryCount = ProdDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("ProdDeploy_retryCount", String.valueOf(ProdDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition, getCaught().getLocalizedMessage());
                          }
                    } else if (code.equals("S_COMPLETED_WITH_ERROR")) {
                          if (ProdDeploy_retryCount < max_retries) {
                                 ProdDeploy_retryCount = ProdDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("ProdDeploy_retryCount", String.valueOf(ProdDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition, resultBuffer.toString());
                          }

                    } else if ((code.equals("S_FAILED")) || (code.equals("S_ROLLED_BACK")) || (code.equals("S_ABORTED"))) {
                          if (ProdDeploy_retryCount < max_retries) {
                                 ProdDeploy_retryCount = ProdDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("ProdDeploy_retryCount", String.valueOf(ProdDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition, resultBuffer.toString());
                          }

                    } else if ("S_COMPLETED".equals(code)) {
                          task.chooseTransition(successTransition, resultBuffer.toString());
                    } else {
                          if (ProdDeploy_retryCount < max_retries) {
                                 ProdDeploy_retryCount = ProdDeploy_retryCount + 1;
                                 task.getWorkflow().setVariable("ProdDeploy_retryCount", String.valueOf(ProdDeploy_retryCount));
                                 task.chooseTransition(targetRetryTask, targetRetryTask);
                          } else {
                                 task.chooseTransition(failureTransition,
                                              "OpenDeploy Status Unknown. FAILED. " + resultBuffer.toString());
                          }
                    }
             }else{
                    if (getCaught() != null) {
                                 task.chooseTransition(failureTransition, getCaught().getLocalizedMessage());
                    } else if (code.equals("S_COMPLETED_WITH_ERROR")) {
                                 task.chooseTransition(failureTransition, resultBuffer.toString());

                    } else if ((code.equals("S_FAILED")) || (code.equals("S_ROLLED_BACK")) || (code.equals("S_ABORTED"))) {
                                 task.chooseTransition(failureTransition, resultBuffer.toString());
                    } else if ("S_COMPLETED".equals(code)) {
                          task.chooseTransition(successTransition, resultBuffer.toString());
                    } else {
                                 task.chooseTransition(failureTransition,
                                              "OpenDeploy Status Unknown. FAILED. " + resultBuffer.toString());
                    }
             }
	}

	/**
	 * Function to remove the prefix from the file path
	 * 
	 * @param original
	 *            File Path
	 * @param patternString
	 *            Pattern to be removed
	 * @return File Path with removed pattern.
	 */
	private String removePrefix(String original, String patternString) {
		Pattern pattern = Pattern.compile(patternString);
		Matcher matcher = pattern.matcher(original);
		if (matcher.find()) {
			String updated = original.substring(matcher.end());
			LOGGER.debug("Pattern removed: " + updated);
			return updated;
		}

		return original;
	}

	/**
	 * This function creates a temp file list for the deployment. It checks each
	 * of the files attached to the workflow and removes '/sites' from the start
	 * of the path if found.
	 * 
	 * @param task
	 * @return Temp File having the list of files to be deployed
	 **/
	private File createTempFilelistFile(CSExternalTask task) throws CSException {
		File tempFile = null;
		String tempDeployDir = "/opentext/OpenDeployNG/tmp/AssetData/";
		File tempDirPath = new File(tempDeployDir);
		try {
			tempFile = File.createTempFile("deploytask-filelist-", ".txt", tempDirPath);
			fileCleaningTracker.track(tempFile, this);

			try (Writer writer = new BufferedWriter(new FileWriter(tempFile))) {
				CSAreaRelativePath[] paths = task.getFiles();
				for (CSAreaRelativePath path : paths) {
					if (!FilenameUtils.isExtension(path.toString(), "page")) {
						String pageLink = removePrefix(path.toString(), "^/sites|^sites");
						writer.write(pageLink + "\n");
					}
				}
			}
		} catch (IOException e) {
			throw new CSException(e);
		}
		return tempFile;
	}

	/**
	 * Creates a mapping of all workflow task variables that start with
	 * "odSubst" which are defined as deployment task variables within the
	 * workflow model. Additionally, area and file list parameters are added to
	 * the set of available deployment parameters.
	 * 
	 * @param task
	 *            workflow model deployment task
	 * @param filelistFile
	 *            file containing the list of file paths for all of the
	 *            workflow's attached files
	 * @return Vector containing a mapping of parameter name and value to be
	 *         sent to the deployment execution
	 * @throws CSException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static Vector getSubstKeyValuePairs(CSExternalTask task, File filelistFile) throws CSException {
		CSNameValuePair[] vars = task.getVariables(null);
		Vector keyValuePairs = new Vector(vars == null ? 4 : 4 + vars.length);

		String workarea = task.getArea().getVPath().getPathNoServer().toString();

		String areaPath = InstalledLocations.getIwmount() + workarea;
		keyValuePairs.add("area=" + areaPath);
		try {
			keyValuePairs.add("filelist=" + filelistFile.getCanonicalPath());
		} catch (IOException e) {
			throw new CSException(e);
		}

		String archivalRunID = task.getWorkflow().getVariable("archival_run_id");

		if ((archivalRunID != null) && (archivalRunID.length() > 0)) {
			keyValuePairs.add("edition_name=" + task.getArea().getName());
			keyValuePairs.add("areavpath=" + workarea);
		}

		if (vars != null) {
			for (int i = 0; i < vars.length; i++) {
				String name = vars[i].getName();
				if ((name != null) && (name.startsWith("odSubst_"))) {
					String value = vars[i].getValue();
					String realName = name.substring("odSubst_".length());

					keyValuePairs.add(realName + "=" + value);
				}
			}
		}

		return keyValuePairs;
	}

	/**
	 * Function to get Success Transition Name
	 * 
	 * @param params
	 * @param taskTransitions
	 * @return
	 */
	private static String getSuccessTransitionName(@SuppressWarnings("rawtypes") Hashtable params,
			String[] taskTransitions) {
		return getTransitionName(params, "successTransition", taskTransitions, 0);
	}

	/**
	 * Function to get Failure transition Name
	 * 
	 * @param params
	 * @param taskTransitions
	 * @return
	 */
	private static String getFailureTransitionName(@SuppressWarnings("rawtypes") Hashtable params,
			String[] taskTransitions) {
		return getTransitionName(params, "failureTransition", taskTransitions, 1);
	}

	/**
	 * Function to get the name of the transition
	 * 
	 * @param params
	 * @param transitionNameParam
	 * @param taskTransitions
	 * @param transitionArrayIndex
	 * @return
	 */
	private static String getTransitionName(@SuppressWarnings("rawtypes") Hashtable params, String transitionNameParam,
			String[] taskTransitions, int transitionArrayIndex) {
		String transitionToReturn = null;

		Object value = params.get(transitionNameParam);
		if (value != null) {

			assert ((value instanceof String[]));
			String[] paramValues = (String[]) value;
			if (paramValues.length >= 1) {
				transitionToReturn = paramValues[0];
			}
		}

		if ((transitionToReturn == null) && (taskTransitions != null)
				&& (taskTransitions.length >= transitionArrayIndex + 1)) {

			transitionToReturn = taskTransitions[transitionArrayIndex];
		}

		return transitionToReturn;
	}

	/**
	 * This is helper class to execute deployments via OpenDeploy web services
	 * 
	 * @author Klish Group, INC.
	 *
	 */
	protected class CustomStartDeployHelper extends StartDeploy {

		/**
		 * This function runs the deployment task.
		 * 
		 * @param resBuff
		 *            buffer that holds the output of the deployment execution
		 * @param fOdHost
		 *            OpenDeploy Base server host name
		 * @param fOdPort
		 *            OpenDeploy Base server web services connection port
		 * @return execution code
		 */
		int runIt(StringBuffer resBuff, String fOdHost, int fOdPort) {
			int exitCode = 0;
			this.fResultBuff = resBuff;
			LOGGER.debug("Custom RunIt");

			try {

				IWDeployService deployService = null;

				String serviceName = getDeployServiceName();
				if ((fOdHost == null) || (fOdHost.length() <= 0)) {
					fOdHost = "localhost";
					fOdPort = 9173;
				} else if (fOdPort <= 0) {
					fOdPort = 9173;
				}
				serviceName = "//" + fOdHost + ":" + fOdPort + "/IWDeployService";
				LOGGER.debug("Service Name " + serviceName);

				if (this.fDoDeploy) {
					deployService = (IWDeployService) IWODService.locate(serviceName);
				}
				LOGGER.debug("Start deploy ");
				int rc = startDeploy(deployService);
				if (rc != 0) {
					return rc;
				}
			} catch (UnsupportedOpenDeployServerVersionException | RemoteException | UnknownDescriptorException
					| UnknownServiceException eVers) {
				LOGGER.debug(eVers.getMessage());
				eVers.printStackTrace();
				exitCode = 1;
			} catch (Exception eDflt) {
				LOGGER.debug("Caught exception in runIt(). Details: " + eDflt.getMessage());
				LOGGER.error("Caught exception in runIt(). Details: " + eDflt + eDflt.getMessage());
				exitCode = 1;
			}

			return exitCode;
		}

	}

}

