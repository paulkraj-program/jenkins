package com.deere.livesite.workflow;

import java.util.*;
import org.apache.log4j.Logger;

import com.deere.livesite.workflow.WorkflowServices;
import com.deere.teamsite.template.TemplateServices;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

/**
 * Provides the file generation implementation for DCRs.
 * 
 * 
 * @author Klish Group, Inc.
 *
 */

public class GenerateFilesUrlTask implements CSURLExternalTask {

	static final transient Logger LOGGER = Logger.getLogger(GenerateFilesUrlTask.class);

	private static final String SUCCESS_TRANSITION = "Generate Files Success";
	private static final String FAILURE_TRANSITION = "Generate Files Failure";

	private static final String ARG_GENERATE_PROPERTY_PATH = "generatePropertyPath";
	private static final String ARG_ATTACH_GENERATED_FILES = "attachGeneratedFiles";

	@Override
	public void execute(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable parameters) throws CSException {

		LOGGER.debug("Start Generate Files task");
		String successTransitionComment = "COMPLETED generating all the files.";
		String generatePropertyFile = task.getVariable(ARG_GENERATE_PROPERTY_PATH);
		boolean attachGeneratedFiles = Boolean.parseBoolean(task.getVariable(ARG_ATTACH_GENERATED_FILES));

		LOGGER.debug("Attach Generated Files? : " + attachGeneratedFiles);
		List<CSAreaRelativePath> filesToAttach = new LinkedList<CSAreaRelativePath>();

		if (generatePropertyFile == null || generatePropertyFile.isEmpty()) {
			LOGGER.error("Generate properties task variable not set.");
			task.chooseTransition(FAILURE_TRANSITION, "SKIPPING generate files. Generate properties task variable not set.");
		} else {

			try {
				//Get DCRs from the attached files in the workflow
				List<CSSimpleFile> attachedDCRList = WorkflowServices.getAttachedDCRs(task);

				if (attachedDCRList.size() > 0) {
					LOGGER.debug("Generate Property File : " + generatePropertyFile);
					TemplateServices templateService = new TemplateServices(client, generatePropertyFile, false);
					if (templateService.isValidProperties()) {
						//Get all the dcrs attached to the task that can be generated
						List<CSSimpleFile> generateFiles = templateService.getFilesToGenerate(task, attachedDCRList);

						//Generate attached DCRs 
						for (CSSimpleFile file : generateFiles) {
							LOGGER.debug("File about to generate: " + file.getVPath().getPathNoServer().toString());
							CSVPath outputVpath = templateService.generateFile(file);

							if (outputVpath != null && client.getFile(outputVpath) != null && attachGeneratedFiles) {
								filesToAttach.add(outputVpath.getAreaRelativePath());
							}
						}

						//Attach generated files to the task.
						if (filesToAttach.size() > 0 && attachGeneratedFiles) {
							LOGGER.info("Attaching " + filesToAttach.size() + " generated files to task.");
							task.attachFiles(filesToAttach.toArray(new CSAreaRelativePath[0]));
						} else if (!attachGeneratedFiles) {
							LOGGER.info("Skipping attaching generated files to task.");
						} else {
							LOGGER.info("No Generated files to attach.");
						}

					} else {
						successTransitionComment = "SKIPPING generate files. Generation properties file does not exist.";
					}

				} else {
					successTransitionComment = "SKIPPING generate files. No DCRs attached to the task to generate.";
				}

				LOGGER.info(successTransitionComment);
				task.chooseTransition(SUCCESS_TRANSITION, successTransitionComment);

			} catch (CSException csex) {
				LOGGER.error("Error generating files.", csex);
				task.chooseTransition(FAILURE_TRANSITION, "ERROR generating DCRs attached to the task.");
			}
		}
	}

}

