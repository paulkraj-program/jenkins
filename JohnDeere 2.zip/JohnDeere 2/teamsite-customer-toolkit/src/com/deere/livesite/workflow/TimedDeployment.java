package com.deere.livesite.workflow;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

/**
 * This class is used for timed deployment of special offers. If allowed special
 * offers path matches with attached file path it parses the .page and gets the
 * offer start date meta-data. It converts start date to date (24 hrs format)
 * and sets that as deployment date i.e. task timeout so that it can transition
 * to production deployment task after the specified time out is elapsed.
 * 
 */
public class TimedDeployment implements CSURLExternalTask {

	private static final transient Logger LOGGER = Logger.getLogger(TimedDeployment.class);
	private static final String DEFAULT_TRANSITION = "Deployment Timeout Not Required";
	private static final String TIMED_DEPLOYMENT_TASK = "Timed Deployment";
	private static final String TIMEOUT_TRANSITION = "Set Deployment Date and Time";
	private static final String FAILURE_EMAIL_TRANSITION = "Failure Email";
	private static final String IWMNT = "/iwmnt/";
	// private static final String INDEX_HTML = "index.html";
	private static final String FAILURE_MESSAGE = "FailureMessage";
	private static final String OFFER_START_DATE_METADATA = "offer-start-date";
	// private static final String OFFER_END_DATE_METADATA = "offer-end-date";
	private static final String OFFER_LISTING_TEMPLATE = "Offers List.template";

	/**
	 * This method checks if it is special offers, gets the start date meta data and
	 * sets the deployment date to start date.
	 *
	 * @param CSClient
	 * @param CSExternalTask
	 * @param parameters
	 */
	public void execute(CSClient client, CSExternalTask currentTask, @SuppressWarnings("rawtypes") Hashtable parameters)
			throws CSException {
		LOGGER.info("Inside execute -- ");
		String timeOutLinkComment = "Setting Start offer date as timeout.";
		String defaultLinkComment = "Transition to default.";
		String failureEmailLinkComment = "Transition to failure email.";
		Boolean timeOutLinkFlag = false;
		Date offerStartDate = null;
		Document doc = null;

		// Get the timeout File path WF variable
		String timeOutFolderAllowed = currentTask.getVariable("SpecialOffersFolderPath");
		LOGGER.info("Value of SpecialOffersFolderPath WF variable is -- " + timeOutFolderAllowed);

		if (timeOutFolderAllowed == null || timeOutFolderAllowed.isEmpty()) {
			timeOutLinkFlag = false;
			failureEmailLinkComment = "SpecialOffersFolderPath task variable not set!, Please contact System Administrator.";
			LOGGER.error("SKIPPING. SpecialOffersFolderPath task variable not set -- ");
			// transition to failure email and end the WF
			transitionToFailureEmail(currentTask, FAILURE_EMAIL_TRANSITION, failureEmailLinkComment);
		} else {
			// get attached files from WF
			LOGGER.info("Getting attached files from WF -- ");
			// e.g.
			// default/main/deere/us/en/WORKAREA/shared/html/deere/us/en/website/finance/offers-discounts
			CSAreaRelativePath[] files = currentTask.getFiles();
			if (null != files && files.length != 0) {
				for (CSAreaRelativePath file : files) {
					String filePath = file.getParentPath().toString();
					String fileName = file.getName();
					LOGGER.info("File path is -- " + filePath);
					// e.g.
					// html/deere/us/en/website/finance/offers-discounts/quebec-offers/shared/tractors/row-crop-tractors
					LOGGER.info("File name is - " + fileName);
					// e.g. index.html, fragment file
					if (!StringUtils.isBlank(filePath)) {
						if (filePath.contains(timeOutFolderAllowed)) {
							LOGGER.info("File path contains the allowed folder -- " + timeOutFolderAllowed);
							// Check if the HTML file is present for reading the start date meta data
							// if ((null != fileName && fileName.equalsIgnoreCase(INDEX_HTML))) {
							if ((null != fileName && fileName.endsWith(".page"))) {
								// if ((null != fileName)) {
								LOGGER.info("Looking for offer start date meta data -- " + fileName);

								// Get the start date of the offers from meta data
								// e.g. 2017-11-24 05:01:00

								String branchPath = currentTask.getArea().getVPath().toString();
								String[] branchPaths = branchPath.split("WORKAREA/");
								branchPaths[0] = branchPaths[0].split(client.getContext().getServerName() + "/")[1];
								StringBuffer finalPath = new StringBuffer();
								finalPath.append(IWMNT);
								finalPath.append(branchPaths[0]);
								finalPath.append("WORKAREA/");
								finalPath.append(branchPaths[1]).append("/");
								branchPath = finalPath.toString();
								LOGGER.info("Value of Final BranchPath for the file is -- " + branchPath);
								String docPath = branchPath + filePath + "/" + fileName;
								LOGGER.info("File path is -- " + docPath);

								StringBuilder contentBuilder = new StringBuilder();
								try {
									BufferedReader in = new BufferedReader(new FileReader(docPath));
									String str;
									while ((str = in.readLine()) != null) {
										contentBuilder.append(str);
									}
									in.close();
								} catch (IOException e) {
									LOGGER.error("Exception in reading file!" + e.getMessage());
								}
								String contentHtml = null;
								if (null != contentBuilder) {
									contentHtml = contentBuilder.toString();
								}
								if (LOGGER.isDebugEnabled()) {
									LOGGER.debug("Content HTML --  " + contentHtml);
								}

								if (null != contentHtml) {
									doc = Jsoup.parse(contentHtml);
								}

								// Elements metaTags = doc.getElementsByTag("meta");
								Elements metaTags = doc.getElementsByTag("MetaTag");
								String startDate = null;
								boolean offerListingTemplate = false;
								// Get the offer start date meta data
								for (org.jsoup.nodes.Element metaTag : metaTags) {
									// String content = metaTag.attr("content");
									String value = metaTag.text();
									// String name = metaTag.attr("name");

									// not using offer end date - for future purpose
									/*
									 * if (OFFER_END_DATE_METADATA.equals(name)) {
									 * LOGGER.info("Offer End Date is -- " + content); }
									 */
									if (value.contains(OFFER_START_DATE_METADATA) && !value.contains("epoch")) {
										String[] e = value.split("date");
										startDate = e[1];
										LOGGER.info("Offer Start Date is -- " + startDate);
									}
									/*
									 * if (OFFER_START_DATE_METADATA.equals(name)) { startDate = content;
									 * LOGGER.info("Offer Start Date is -- " + startDate); }
									 */
									// check if offer listing template is used
									/*
									 * if (content.contains(OFFER_LISTING_TEMPLATE)) { offerListingTemplate = true;
									 * }
									 */
									// check if offer listing template is used
									if (value.contains(OFFER_LISTING_TEMPLATE)) {
										LOGGER.info("Offers Listing template used -- ");
										offerListingTemplate = true;
									}
								}
								// if it is offer listing page ignore it for timed deployment
								if (offerListingTemplate) {
									timeOutLinkFlag = false;
									defaultLinkComment = "Skipping as the file uses Offer Listing template and not allowed for timed deployment.";
									LOGGER.error(
											"Skipping as the file uses Offer Listing template and not allowed for timed deployment.");
									break;
								}
								if (null != startDate || !"".equals(startDate)) {
									// Date formating for time out
									DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
									try {
										df.setLenient(false);
										offerStartDate = df.parse(startDate);
									} catch (ParseException e) {
										timeOutLinkFlag = false;
										failureEmailLinkComment = "Date Parse error! Offer Start Date not set in proper format - yyyy-MM-dd HH:mm:ss.";
										LOGGER.error(
												"Date Parse error! Date not in proper format -- " + e.getMessage());
										// transition to failure email and end the WF
										transitionToFailureEmail(currentTask, FAILURE_EMAIL_TRANSITION,
												failureEmailLinkComment);
									} catch (Exception e) {
										timeOutLinkFlag = false;
										failureEmailLinkComment = "Date Parse error! Either Offer Start Date is not set or is empty.";
										LOGGER.error(
												"Date Parse error! Either Offer Start Date is not set or is empty -- "
														+ e.getMessage());
										// transition to failure email and end the WF
										transitionToFailureEmail(currentTask, FAILURE_EMAIL_TRANSITION,
												failureEmailLinkComment);
									}
									LOGGER.info(
											"Date from meta data using the Date Format (yyyy-MM-dd HH:mm:ss) is --  "
													+ offerStartDate);
									/*if (null != offerStartDate) {
									timeOutLinkFlag = true;
									timeOutLinkComment = "Start date for offer set as depolyment date.";
								} */
								// disabling scheduler for Offers US8482
								if (null != offerStartDate) {
									timeOutLinkFlag = false;
									timeOutLinkComment = "Start date for offer set as depolyment date.";
								}
									break;
								} else {
									timeOutLinkFlag = false;
									failureEmailLinkComment = "No offer start date metadata found! Timeout will not be set.";
									LOGGER.error("No Start offer date found! Timeout will not be set -- ");
									// transition to failure email and end the WF
									transitionToFailureEmail(currentTask, FAILURE_EMAIL_TRANSITION,
											failureEmailLinkComment);
								}
							} else {
								timeOutLinkFlag = false;
								defaultLinkComment = "Skipping as the file is not a .page and unable to read the start offer date.";
								LOGGER.error(
										"Skipping as the file is not a .page and unable to read the start offer date -- "
												+ file.getExtension());
							}
						} else {
							timeOutLinkFlag = false;
							defaultLinkComment = "Skipping as the file is not allowed for timed deployment.";
							LOGGER.error("Skipping as the file is not allowed for timed deployment.");
						}
					}
				}
			}
		}
		LOGGER.info("Time Out Tranisiton Link Flag is -- " + timeOutLinkFlag.toString());
		if (true == timeOutLinkFlag) {
			if (null != offerStartDate) {
				if (currentTask.isActive()) {
					CSTask[] tasks = currentTask.getWorkflow().getTasks();
					for (CSTask task : tasks) {
						/*
						 * if (LOGGER.isDebugEnabled()) { LOGGER.debug(" Task[" + task.getKindName() +
						 * "] -- " + task.getName()); }
						 */
						if (TIMED_DEPLOYMENT_TASK != null && TIMED_DEPLOYMENT_TASK.equals(task.getName())) {
							try {
								LOGGER.info("Timed Deployment Task -- ");
								LOGGER.info("Default scheduled Date & Time from WF variable is -- "
										+ task.getAbsoluteTimeout());
								task.setTimeout(offerStartDate);
								LOGGER.info("Updated scheduled Date & Time as per Offer Start Date is  -- "
										+ task.getAbsoluteTimeout());
								LOGGER.info("Transitioning to Timed Deployment -- ");
								currentTask.chooseTransition(TIMEOUT_TRANSITION, timeOutLinkComment);
							} catch (CSException cse) {
								timeOutLinkComment = "Failed in setting Deployment Date and Time,Please contact System Administrator";
								LOGGER.error("Failed in setting timeout -- " + cse);
								transitionToFailureEmail(currentTask, FAILURE_EMAIL_TRANSITION, timeOutLinkComment);
							} catch (Exception e) {
								timeOutLinkComment = "Failed in setting Deployment Date and Time,Please contact System Administrator";
								LOGGER.error("Failed in setting timeout -- " + e);
								transitionToFailureEmail(currentTask, FAILURE_EMAIL_TRANSITION, timeOutLinkComment);
							}
						}
					}
				}
			}
		} else {
			if (currentTask.isActive()) {
				LOGGER.info("Transitioning to Default link -- ");
				try {
					currentTask.chooseTransition(DEFAULT_TRANSITION, defaultLinkComment);
				} catch (CSException cse) {
					LOGGER.error("Exception in transitioning to default link -- " + cse);
				} catch (Exception e) {
					LOGGER.error("Exception in transitioning to default link -- " + e);
				}
			}
		}
	}

	/**
	 * This method sets the failure description for the task and transitions to
	 * failure email task.
	 *
	 * @param CSExternalTask
	 * @param String
	 * @param String
	 */
	private void transitionToFailureEmail(CSExternalTask task, String transistionLink, String description)
			throws CSException {
		if (task.isActive()) {
			try {
				// set the error message
				task.getWorkflow().setVariable(FAILURE_MESSAGE, description);
				LOGGER.debug(
						"Error message set for failure email -- " + task.getWorkflow().getVariable(FAILURE_MESSAGE));
				task.chooseTransition(transistionLink, description);
			} catch (CSException cse) {
				LOGGER.error("Exception in transitioning to failure email -- " + cse);
			} catch (Exception e) {
				LOGGER.error("Exception in transitioning to failure email -- " + e);
			}
		}
	}
}
