package com.deere.livesite.workflow.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;

public class CommonUtil {

	private static final transient Logger LOGGER = Logger.getLogger(CommonUtil.class);
	
	public static String getServerTime(String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		return sdf.format(cal.getTime());
	}
	
	public static Date convertStringToDate(String date, String format) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		Date dateObject = new Date();
		try {
			dateObject = dateFormatter.parse(date);
		} catch (Exception e) {
			LOGGER.error("Error while converting String to Date -- " + e.getMessage());
		}
		return dateObject;
	}
	
	public static String formatDateToString(Date date, String format, String timeZone) {
		if (date == null)
			return null;
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
			timeZone = Calendar.getInstance().getTimeZone().getID();
			LOGGER.info("formatDateToString timezone : " + timeZone);
		}
		dateFormatter.setTimeZone(TimeZone.getTimeZone(timeZone));
		LOGGER.info("In method formatDateToString : " + dateFormatter.format(date));
		return dateFormatter.format(date);
	}
}
