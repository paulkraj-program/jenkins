package com.deere.livesite.workflow;

import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

public class POIServices {
	
	/**
	 * Gets the value for a cell from excel sheet
	 * @param cell
	 * @return
	 */
	public static String getCellValue(Cell cell) {
		if(cell!=null){
			DataFormatter formatter = new DataFormatter();
			return formatter.formatCellValue(cell);	
		}
		
		return "";
	}

	/**
	 * Gets the row values as String array 
	 * @param row
	 * @return
	 */
	public static String[] getRowValues(Row row) {
		List<String> dcrValues = new ArrayList<String>();
		
		if(row!=null){
			for (int i = 1; i < row.getLastCellNum(); i++) {
				dcrValues.add(getCellValue(row.getCell(i)));
			}	
		}
		
		return (String[]) dcrValues.toArray(new String[0]);
	}
}
