package com.deere.livesite.workflow; 


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.deere.livesite.workflow.translation.TranslationTask;

import org.apache.log4j.Logger; 



public class UrlMappingDataRead {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationTask.class);
	public String CreateXML(HashSet<String> listOfValidURLData,HashSet<String> listOfInvalidURLData,LinkedHashSet<String> listOfSourcedURLData,String localeName) throws IOException 
	{
		Date date = new Date() ;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		String[] locale=localeName.split("/");
		File file=null;
		String outputFile="/opentext/TeamSite/local/bin/custom/urlMappingUtility/UrlMapping_utilityReport_"+locale[0]+"_"+locale[1]+"_"+dateFormat.format(date) + ".xlsx";
		LOGGER.debug("Output File path " + outputFile); 
		file = new File(outputFile) ;
		if(file.createNewFile())
			file = new File(outputFile) ;
			LOGGER.debug("File created successfully");
			
		XSSFWorkbook workbook = new XSSFWorkbook();
               
        
        XSSFSheet validUrlSheet = workbook.createSheet("Valid URL's");
        XSSFSheet inValidUrlSheet = workbook.createSheet("Invalid URL's");
        XSSFSheet reviewedUrlSheet= workbook.createSheet("URL's To Be Reviewed");  
        

        int rowCount = 0,rowCount1 = 0,rowCount2 = 0;
        
        for (String valid : listOfValidURLData) {
            Row row1 = validUrlSheet.createRow(++rowCount);
            writeBook(valid, row1);
        
         }
        for (String invalid : listOfInvalidURLData) {
            Row row1 = inValidUrlSheet.createRow(++rowCount1);
            writeBook(invalid, row1);
        
         }
        for (String review : listOfSourcedURLData) {
            Row row1 = reviewedUrlSheet.createRow(++rowCount2);
            writeBook(review, row1);
        
         }
        
        FileOutputStream out = new FileOutputStream(
           new File(outputFile));
        
        workbook.write(out);
       
        out.close();
        workbook.close();
        LOGGER.debug("Writing to file successful : "); 
    return outputFile;   
}
	private void writeBook(String aURL, Row row) {
		for(int i=0;i<aURL.length();i++)
		{
	    Cell cell = row.createCell(1);
	    
	    cell.setCellValue(aURL);
		}
	    
	}
}