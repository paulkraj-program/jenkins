package com.deere.livesite.workflow.notification;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.xml.transform.TransformerException;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.transform.XSLTransformer;
import com.interwoven.serverutils100.IWConfig;

public abstract class BaseMail {

    public static final String MAIL_SERVER = IWConfig.getConfig().getString("iwsend_mail", "mailserver");

    public static final  Logger logger = Logger.getLogger(BaseMail.class);

    public static final boolean DEBUG_MAIL_SESSION  = true;
    
     

    public void sendMail(Address from, String addresses, String subject, DataSource mailDataSource, String noReplyToAddress,String ccRecipients) throws MessagingException {
        logger.debug("Executing sendMail with Below Paramters: ");
        logger.debug(" from "+from);
        logger.debug(" addresses "+addresses);
        logger.debug(" subject "+subject);
        logger.debug(" mailDataSource "+mailDataSource);
        logger.debug(" noReplyToAddress "+noReplyToAddress);
        

        Properties props = new Properties();
        logger.debug(" MAIL_SERVER "+MAIL_SERVER);
        props.put("mail.smtp.host", MAIL_SERVER);
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(DEBUG_MAIL_SESSION);
        logger.debug("MAIL SERVER: " + MAIL_SERVER + " Address: " + from.toString() + " To Addresses: " + addresses);

        MimeMessage msg = new MimeMessage(session);
        msg.setHeader("X-Mailer", "com.deere.livesite.workflow.notification.MailNotification");

        msg.setFrom(from);
        msg.setReplyTo(new javax.mail.Address[]{new javax.mail.internet.InternetAddress(noReplyToAddress)});
        msg.setRecipients(Message.RecipientType.TO, addresses);
        
        if(!(ccRecipients.equalsIgnoreCase("")) || !(ccRecipients.isEmpty())) {
        StringTokenizer st = new StringTokenizer(ccRecipients,",");
        while(st.hasMoreTokens()) {
        msg.addRecipients(Message.RecipientType.CC, InternetAddress.parse(st.nextToken(),false));
        }
        }
        msg.setSubject(subject);
        msg.setSentDate(new Date());

        msg.setDataHandler(new DataHandler(mailDataSource));

        Transport.send(msg);
    }

    /**
     * Close a XMLWriter quietly
     */
    public static void closeQuietly(XMLWriter writer) {
        if (writer != null) {
            try {
                writer.close();
            }
            catch (IOException ioex) {
                // quiet
            }
        }
    }

    /**
     * Serialize an Element to String
     */
    @SuppressWarnings("deprecation")
	public static String serializeDomElementToString(Element ele, String encoding, boolean compactXml) {

        OutputFormat format = null;
        if (compactXml) {
            format = OutputFormat.createCompactFormat();
        }
        else {
            format = OutputFormat.createPrettyPrint();
        }
        format.setEncoding(encoding);

        Writer out = null;
        XMLWriter writer = null;
        String xml = null;
        try {
            out = new StringWriter();
            writer = new XMLWriter(out, format);
            writer.write(ele);
            writer.flush();
            xml = out.toString();
        }
        catch (IOException ioex) {
        	logger.error ("Caught IOException in serializeDomElementToString in sendMail for BaseMail : " ,ioex);
        }
        finally {
            closeQuietly(writer);
            IOUtils.closeQuietly(out);
        }
        return xml;
    }

    /**
     * Perform XSL Transformation on the mail content to construct a mail DataSource.
     */
    public DataSource transformToMailDataSource(String xmlMailContent, CSSimpleFile xslTemplateFile) throws CSException, TransformerException, UnsupportedEncodingException {
        logger.debug("Executing transformToMailDataSource .....xmlMailContent" + xmlMailContent + " xslTemplateFile " + xslTemplateFile);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        logger.debug( "WorkFlowConstants.MAIL_ENCODING..."+ WorkFlowConstants.MAIL_ENCODING );
        logger.debug( "WorkFlowConstants.MAIL_MIME_TYPE..."+ WorkFlowConstants.MAIL_MIME_TYPE );
        ByteArrayInputStream inputStream = new ByteArrayInputStream(xmlMailContent.getBytes(StandardCharsets.UTF_8));
        logger.debug( "inputStream..."+ inputStream );
        XSLTransformer.transform(inputStream, xslTemplateFile, outputStream);
        logger.debug("END of  transformToMailDataSource .....");

        return new javax.mail.util.ByteArrayDataSource(outputStream.toByteArray(), WorkFlowConstants.MAIL_MIME_TYPE);
    }
}

