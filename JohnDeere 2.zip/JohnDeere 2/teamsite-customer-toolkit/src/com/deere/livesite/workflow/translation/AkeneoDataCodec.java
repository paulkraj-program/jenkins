package com.deere.livesite.workflow.translation;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.deere.livesite.workflow.common.Utlis;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;

/**
 * AkeneoDataCodec is an encoder/decoder class that converts the content files
 * from Akeneo from JSON to XML and back during various portions of the the
 * translation submission and retrieval process.
 * 
 * @author Klish Group, Inc. [ND]
 */
public class AkeneoDataCodec {
	private static final Logger LOGGER = Logger.getLogger(AkeneoDataCodec.class);

	/** The default location of the Akeneo property black list configuration file */
	public static final String PATH_BLACK_LIST = "/iwadmin/main/deere/syndication/STAGING/templatedata/Akeneo/JSONToXML/data/black_list.xml";
	private static final String CUSTOM_RETRIEVAL = "/iwadmin/main/deere/syndication/STAGING/configuration/custom-retrieval.properties";
	public static final String PRODUCTS = "products";
	public static final String CATEGORIES = "categories";
	public static final String ATTRIBUTES = "attributes";
	public static final String VALUES = "values";
	public static final String PRODUCT = "product";
	public static final String ATTRIBUTE = "attribute";
	public static final String CATEGORY = "category";
	public static final String PRODUCTSUMMARY_PRIMARYCTAURL = "productsummary_primaryctaurl";
	public static final String METADATA_PAGE_TITLE = "metadata_page_title";
	public static final String SPACE = " ";
	public static final String PIPE = "|";
	public static final String QUESTION = "?";
	public static final String UNDERSCORE = "_";
	private final List<String> blackList;

	/**
	 * Create a new AkeneoDataCodec instance with the provided black list
	 * configuration file path.
	 * 
	 * @param blackListPath The full path to the black list configuration file
	 */
	public AkeneoDataCodec(CSClient client, String blackListPath) throws CSException {
		if (blackListPath == null || "".equals(blackListPath)) {
			blackListPath = PATH_BLACK_LIST;
		}

		blackList = loadAttributeBlackList(client, blackListPath);
	}

	AkeneoDataCodec(List<String> blackList) {
		this.blackList = (blackList == null) ? Collections.<String>emptyList() : blackList;
	}

	/**
	 * Filter the JSON file according to the black list and return the filtered
	 * content. This is for comparison of JSON file versions.
	 * 
	 * @param client The current CSClient instance
	 * @param file   The JSON file
	 * @return The filtered JSON file content converted to a String
	 * @throws CSException
	 */
	public String filterJSON(CSSimpleFile file) throws CSException {
		return filterJSON(read(file));
	}

	public String filterJSON(String json) throws CSException {
		try {
			JSONObject object = new JSONObject(json);

			object = filter(object);

			return object.toString();
		} catch (JSONException jsone) {
			throw new RuntimeException(jsone);
		}
	}

	/**
	 * Encode the provided file from JSON to XML. This method removes the properties
	 * from the JSON object that appear on the black list configured in TeamSite.
	 * 
	 * @param file The JSON document do encode
	 * @return The encoded JSON content as XML
	 * @throws CSException
	 */
	public String encodeToXML(CSSimpleFile file) throws CSException {
		return encodeToXML(read(file));
	}

	String encodeToXML(String json) throws CSException {
		try {
			JSONObject object = new JSONObject(json);

			object = filter(object);

			Document document = XmlConverter.toXml(object);
			return document.asXML();
		} catch (JSONException jsone) {
			throw new CSException(jsone);
		}
	}

	/**
	 * Decode the provided file from XML to JSON. This method restores the
	 * properties on the JSON object the appear on the black list configured in
	 * TeamSite. The properties are restored from the file specified by the provided
	 * document path.
	 * 
	 * @param client       The current CSClient instance
	 * @param documentPath The JSON original file document path
	 * @param document     The XML document to decode
	 * @return The decoded XML content as JSON
	 * @throws CSException
	 */
	public String decodeToJSON(CSClient client, CSSimpleFile targetFile, Document document,
			SyndicationTarget syndicationTargetObj, SyndicationTarget syndicationSourceObj)
			throws CSException, IOException {
		String target = null;
		if (targetFile != null) {
			target = read(targetFile);
		}

		return decodeToJSON(client, target, document, syndicationTargetObj, syndicationSourceObj);
	}

	String decodeToJSON(CSClient client, String json, Document document, SyndicationTarget syndicationTargetObj,
			SyndicationTarget syndicationSourceObj) throws CSException, IOException {
		try {
			JSONObject object = XmlConverter.toJson(document);
			LOGGER.debug("before merging the source and target(teamsite pim.json) " + object.toString());
			if (json != null) {
				JSONObject source = new JSONObject(json);
				LOGGER.debug("Source json from across " + source.toString());
				// Restore the original properties from the black list
				merge(client, source, object, syndicationTargetObj, syndicationSourceObj);
			}

			return object.toString();
		} catch (JSONException jsone) {
			throw new CSException(jsone);
		}
	}

	/**
	 * Determine if the file is a product file
	 * 
	 * @param file The specified file
	 * @return Flag indicating if the file is a product file
	 * @throws CSException
	 */
	public boolean isProduct(CSSimpleFile file) throws CSException {
		return isProduct(read(file));
	}

	boolean isProduct(String json) throws CSException {
		try {
			JSONObject object = new JSONObject(json);

			if (object.has(PRODUCTS)) {
				return true;
			}
		} catch (JSONException jsone) {
			throw new CSException(jsone);
		}

		return false;
	}

	/**
	 * Determine if the file is a category file
	 * 
	 * @param file The specified file
	 * @return Flag indicating if the file is a category file
	 * @throws CSException
	 */
	public boolean isCategory(CSSimpleFile file) throws CSException {
		return isCategory(read(file));
	}

	boolean isCategory(String json) throws CSException {
		try {
			JSONObject object = new JSONObject(json);

			if (object.has(CATEGORIES)) {
				return true;
			}
		} catch (JSONException jsone) {
			throw new CSException(jsone);
		}

		return false;
	}

	/**
	 * Get the identifier of the file.
	 * 
	 * @param file The pim_data.json file
	 * @return The identifier of the provided file
	 * @throws CSException
	 */
	public String getJSONId(CSSimpleFile file) throws CSException {
		return getJSONId(read(file));
	}

	String getJSONId(String json) throws CSException {
		try {
			JSONObject object = new JSONObject(json);

			if (object.has(PRODUCTS)) {
				JSONArray typeArray = object.getJSONArray(PRODUCTS);
				if (typeArray != null) {
					for (int i = 0; i < typeArray.length(); ++i) {
						JSONObject outerType = typeArray.getJSONObject(i);

						if (outerType != null) {
							JSONObject type = outerType.getJSONObject(PRODUCT);

							if (type != null) {
								JSONArray attributes = type.getJSONArray(ATTRIBUTES);

								if (attributes != null) {
									for (int j = 0; j < attributes.length(); ++j) {
										JSONObject attribute = attributes.getJSONObject(j);

										if (attribute != null) {
											JSONObject value = attribute.getJSONObject(ATTRIBUTE);

											if (value != null) {
												String id = value.getString("id");

												if ("sku".equals(id)) {
													JSONArray array = value.getJSONArray(VALUES);
													JSONObject item0 = array.getJSONObject(0);
													return item0.getString("default");
												}
											}
										}
									}
								}
							}
						}
					}
				}
			} else if (object.has(CATEGORIES)) {
				JSONArray typeArray = object.getJSONArray(CATEGORIES);
				if (typeArray != null) {
					for (int i = 0; i < typeArray.length(); ++i) {
						JSONObject outerType = typeArray.getJSONObject(i);

						if (outerType != null) {
							JSONObject type = outerType.getJSONObject(CATEGORY);

							if (type != null) {
								JSONArray attributes = type.getJSONArray(ATTRIBUTES);

								if (attributes != null) {
									for (int j = 0; j < attributes.length(); ++j) {
										JSONObject attribute = attributes.getJSONObject(j);

										if (attribute != null) {
											JSONObject value = attribute.getJSONObject(ATTRIBUTE);

											if (value != null) {
												String id = value.getString("id");

												if ("id".equals(id)) {
													return value.getString("value");
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			return null;
		} catch (JSONException jsone) {
			throw new CSException(jsone);
		}
	}

	/**
	 * Get the identifier of the file.
	 * 
	 * @param file The pim_data.json file
	 * @return The identifier of the provided file
	 * @throws CSException
	 */
	public String getJSONUserId(CSSimpleFile file) throws CSException {
		return getJSONId(read(file));
	}

	String getJSONUserId(String json) throws CSException {
		try {
			JSONObject object = new JSONObject(json);

			if (object.has(PRODUCTS)) {
				JSONArray typeArray = object.getJSONArray(PRODUCTS);
				if (typeArray != null) {
					for (int i = 0; i < typeArray.length(); ++i) {
						JSONObject outerType = typeArray.getJSONObject(i);

						if (outerType != null) {
							JSONObject type = outerType.getJSONObject(PRODUCT);

							if (type != null) {
								JSONArray attributes = type.getJSONArray(ATTRIBUTES);

								if (attributes != null) {
									for (int j = 0; j < attributes.length(); ++j) {
										JSONObject attribute = attributes.getJSONObject(j);

										if (attribute != null) {
											JSONObject value = attribute.getJSONObject(ATTRIBUTE);

											if (value != null) {
												String id = value.getString("id");

												if ("racfId".equals(id)) {
													JSONArray array = value.getJSONArray(VALUES);
													JSONObject item0 = array.getJSONObject(0);
													return item0.getString("default");
												}
											}
										}
									}
								}
							}
						}
					}
				}
			} else if (object.has(CATEGORIES)) {
				JSONArray typeArray = object.getJSONArray(CATEGORIES);
				if (typeArray != null) {
					for (int i = 0; i < typeArray.length(); ++i) {
						JSONObject outerType = typeArray.getJSONObject(i);

						if (outerType != null) {
							JSONObject type = outerType.getJSONObject(CATEGORY);

							if (type != null) {
								JSONArray attributes = type.getJSONArray(ATTRIBUTES);

								if (attributes != null) {
									for (int j = 0; j < attributes.length(); ++j) {
										JSONObject attribute = attributes.getJSONObject(j);

										if (attribute != null) {
											JSONObject value = attribute.getJSONObject(ATTRIBUTE);

											if (value != null) {
												String id = value.getString("id");

												if ("racfId".equals(id)) {
													return value.getString("value");
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			return null;
		} catch (JSONException jsone) {
			throw new CSException(jsone);
		}
	}

	// Remove the attributes on the black list
	private JSONObject filter(JSONObject object) throws JSONException {
		String typeArrayName = PRODUCTS;
		String typeName = PRODUCT;

		if (object.has(PRODUCTS)) {
			typeArrayName = PRODUCTS;
			typeName = PRODUCT;
		} else if (object.has(CATEGORIES)) {
			typeArrayName = CATEGORIES;
			typeName = CATEGORY;
		}

		JSONArray typeArray = object.getJSONArray(typeArrayName);
		if (typeArray != null) {
			for (int i = 0; i < typeArray.length(); ++i) {
				JSONObject outerType = typeArray.getJSONObject(i);

				if (outerType != null) {
					JSONObject type = outerType.getJSONObject(typeName);

					if (type != null) {
						JSONArray attributes = type.getJSONArray(ATTRIBUTES);
						JSONArray filteredAttributes = new JSONArray();

						if (attributes != null) {
							for (int j = 0; j < attributes.length(); ++j) {
								JSONObject attribute = attributes.getJSONObject(j);

								if (attribute != null) {
									JSONObject value = attribute.getJSONObject(ATTRIBUTE);

									if (value != null) {
										String id = value.getString("id");

										if (!blackList.contains(id)) {
											filteredAttributes.put(attribute);
										}
									}
								}
							}

							type.put(ATTRIBUTES, filteredAttributes);
						}
					}
				}
			}
		}

		return object;
	}

	private static String read(CSSimpleFile file) throws CSException {
		LOGGER.debug("Reading text file contents: " + file.getVPath().getAreaRelativePath());

		byte[] content = file.read(0, -1);
		if (content == null || content.length == 0) {
			return "{}";
		}

		try {
			String text = new String(content, "UTF-8");

			if ("".equals(text)) {
				return "{}";
			}

			return text;
		} catch (UnsupportedEncodingException uee) {
			LOGGER.warn("Failed attempting to create content string with UTF-8 encoding.  Using default encoding.",
					uee);
			String text = new String(content);

			if ("".equals(text)) {
				return "{}";
			}

			return text;
		}
	}

	private static List<String> loadAttributeBlackList(CSClient client, String path) throws CSException {
		CSFile configuration = client.getFile(new CSVPath(path));
		if (configuration == null || CSSimpleFile.KIND != configuration.getKind()) {
			throw new CSException(-1, "Unable to find black list configuration file: " + path);
		}

		try (InputStream input = new BufferedInputStream(((CSSimpleFile) configuration).getInputStream(true))) {
			return loadAttributeBlackList(input);
		} catch (IOException ioe) {
			throw new CSException(ioe);
		}
	}

	static List<String> loadAttributeBlackList(InputStream input) throws CSException {
		try {
			Document document = new org.dom4j.io.SAXReader().read(input);
			Element root = document.getRootElement();

			/*
			 * <black-list> <attribute>...</attribute> ... </black-list>
			 */
			@SuppressWarnings("unchecked")
			List<Element> properties = root.elements("attribute");
			List<String> list = new ArrayList<String>(properties.size());

			for (Element element : properties) {
				String property = element.getText();
				list.add(property);
			}

			return list;
		} catch (DocumentException de) {
			throw new CSException(de);
		}
	}

	private static JSONObject merge(CSClient client, JSONObject source, JSONObject target,
			SyndicationTarget syndicationTargetObj, SyndicationTarget syndicationSourceObj)
			throws JSONException, IOException, CSException {
		Properties retrievalProperties = null;
		String targetLocale = syndicationTargetObj.getLocale();
		String sourceLocale = syndicationSourceObj.getLocale();
		Pattern pattern = Pattern.compile("([0-9a-zA-Z]*)(-|_)([0-9a-zA-Z]*)");
		Matcher targetMatcher = pattern.matcher(targetLocale);
		Matcher sourceMatcher = pattern.matcher(sourceLocale);
		String targetLanguage = "";
		String targetCountry = "";
		String sourceLanguage = "";
		String sourceCountry = "";
		if (targetMatcher.find()) {
			targetLanguage = targetMatcher.group(1).toLowerCase();
			targetCountry = targetMatcher.group(3).toLowerCase();
		}
		if (sourceMatcher.find()) {
			sourceLanguage = sourceMatcher.group(1).toLowerCase();
			sourceCountry = sourceMatcher.group(3).toLowerCase();
		}
		LOGGER.debug("In Merge Method() Source Obj details -- Country: " + sourceCountry + ", Language: "
				+ sourceLanguage + ", Locale: " + sourceLocale);
		LOGGER.debug("In Merge Method() Target Obj details -- Country: " + targetCountry + ", Language: "
				+ targetLanguage + ", Locale: " + targetLocale);
		retrievalProperties = Utlis.loadProperties(client, CUSTOM_RETRIEVAL);
		String R2Countries = retrievalProperties.getProperty("Region_2_Countries");
		LOGGER.debug("R2 Countries are :: " + R2Countries);
		String[] Region2Countries = R2Countries.split(",");
		LOGGER.debug("Number of R2 Countries are:: " + Region2Countries.length);
		if (source.has(PRODUCTS) && target.has(PRODUCTS)) {
			JSONArray sourceTypeArray = source.getJSONArray(PRODUCTS);
			JSONArray targetTypeArray = target.getJSONArray(PRODUCTS);

			for (int i = 0; i < sourceTypeArray.length() && i < targetTypeArray.length(); ++i) {
				JSONObject sourceOuterType = sourceTypeArray.getJSONObject(i);
				JSONObject targetOuterType = targetTypeArray.getJSONObject(i);

				if (sourceOuterType != null && targetOuterType != null) {
					JSONObject sourceType = sourceOuterType.getJSONObject(PRODUCT);
					JSONObject targetType = targetOuterType.getJSONObject(PRODUCT);

					if (sourceType != null && targetType != null) {
						JSONArray sourceAttributes = sourceType.getJSONArray(ATTRIBUTES);
						JSONArray targetAttributes = targetType.getJSONArray(ATTRIBUTES);
						List<JSONObject> list = new ArrayList<>();

						if (sourceAttributes != null && targetAttributes != null) {
							for (int j = 0; j < sourceAttributes.length(); ++j) {
								JSONObject sourceAttribute = sourceAttributes.getJSONObject(j);

								if (sourceAttribute != null) {
									JSONObject value = sourceAttribute.getJSONObject(ATTRIBUTE);

									if (value != null) {
										String id = value.getString("id");
										LOGGER.debug("Checking attribute: " + id);

										if (!findAttribute(id, targetAttributes)) {
											//LOGGER.debug("Adding attribute: " + id);
											LOGGER.debug("Adding attribute: " + id+ "and attribute object is:: "+sourceAttribute);
											list.add(sourceAttribute);
										}
									}
								}
							}
						for (JSONObject attribute : list) {
							targetAttributes.put(attribute);
						}
						smartMetadataRetrieval(Region2Countries, targetCountry, targetAttributes, targetLocale,
								sourceCountry, sourceLanguage);
						}
					}
				}
			}
		} else if (source.has(CATEGORIES) && target.has(CATEGORIES)) {
			JSONArray sourceTypeArray = source.getJSONArray(CATEGORIES);
			JSONArray targetTypeArray = target.getJSONArray(CATEGORIES);

			for (int i = 0; i < sourceTypeArray.length() && i < targetTypeArray.length(); ++i) {
				JSONObject sourceOuterType = sourceTypeArray.getJSONObject(i);
				JSONObject targetOuterType = targetTypeArray.getJSONObject(i);

				if (sourceOuterType != null && targetOuterType != null) {
					JSONObject sourceType = sourceOuterType.getJSONObject(CATEGORY);
					JSONObject targetType = targetOuterType.getJSONObject(CATEGORY);

					if (sourceType != null && targetType != null) {
						JSONArray sourceAttributes = sourceType.getJSONArray(ATTRIBUTES);
						JSONArray targetAttributes = targetType.getJSONArray(ATTRIBUTES);
						List<JSONObject> list = new ArrayList<>();

						if (sourceAttributes != null && targetAttributes != null) {
							for (int j = 0; j < sourceAttributes.length(); ++j) {
								JSONObject sourceAttribute = sourceAttributes.getJSONObject(j);

								if (sourceAttribute != null) {
									JSONObject value = sourceAttribute.getJSONObject(ATTRIBUTE);

									if (value != null) {
										String id = value.getString("id");
										LOGGER.debug("Checking attribute: " + id);

										if (!findAttribute(id, targetAttributes)) {
											LOGGER.debug("Adding attribute: " + id+ "and attribute object is:: "+sourceAttribute);
											list.add(sourceAttribute);
										}
									}
								}
							}
						}

						for (JSONObject attribute : list) {
							targetAttributes.put(attribute);
						}
					}
				}
			}
		}

		return target;
	}

	private static void smartMetadataRetrieval(String[] region2Countries, String targetCountry,
			JSONArray targetAttributes, String targetLocale, String sourceCountry, String sourceLanguage)
			throws JSONException {
		try {
			String key = targetLocale.replace("-", "_");
			for (String R2Country : region2Countries) {
				if (R2Country.equalsIgnoreCase(targetCountry)) {
					if (targetAttributes != null) {
						for (int k = 0; k < targetAttributes.length(); ++k) {
							JSONObject targetAttribute = targetAttributes.getJSONObject(k);
							if (targetAttribute != null) {
								JSONObject value = targetAttribute.getJSONObject(ATTRIBUTE);
								if (value != null) {
									String id = value.getString("id");
									LOGGER.debug("Checking attribute: " + id);
									if (id.equalsIgnoreCase(METADATA_PAGE_TITLE)) {
										LOGGER.debug("Got target attribute :: " + id);
										JSONArray attrValues = value.getJSONArray(VALUES);
										LOGGER.debug("attribute values array is " + attrValues.length());
										if (attrValues != null) {
											for (int j = 0; j < attrValues.length(); ++j) {
												JSONObject attrValueObj = attrValues.getJSONObject(j);
												if (attrValueObj != null) {
													String attrValue = attrValueObj.getString(key);
													if ((!attrValue.isEmpty()) || (attrValue != null)) {
														int index = attrValue.lastIndexOf(PIPE);
														String firstStr = attrValue.substring(0, index - 1);
														String res = attrValue.substring(index + 1, attrValue.length());
														String secondStr = res.replaceAll(
																SPACE + sourceCountry.toUpperCase(),
																SPACE + targetCountry.toUpperCase());
														String finalStr = firstStr + SPACE + PIPE + secondStr;
														LOGGER.debug("Before modifing metadata_page_title value: "
																+ attrValue);
														LOGGER.debug("After modifing metadata_page_title value: "
																+ finalStr);
														attrValueObj.put(key, finalStr);
													} else {
														LOGGER.debug("Got target attribute :: " + id + " Value Empty");
													}

												}
											}
										}
									} else if (id.equalsIgnoreCase(PRODUCTSUMMARY_PRIMARYCTAURL)) {
										LOGGER.debug("Got target attribute :: " + id);
										JSONArray attrValues = value.getJSONArray(VALUES);
										LOGGER.debug("attribute values array is " + attrValues.length());
										if (attrValues != null) {
											for (int j = 0; j < attrValues.length(); ++j) {
												JSONObject attrValueObj = attrValues.getJSONObject(j);
												if (attrValueObj != null) {
													LOGGER.debug(attrValueObj.toString() + " is not null");
													String attrValue = attrValueObj.getString(key);
													if ((!attrValue.isEmpty()) || (attrValue != null)) {
														int index = attrValue.indexOf("country");
														if (index > 0) {
															String firstHalfStr = attrValue.substring(0, index);
															String secondHalfStr = attrValue.substring(index);
															int index1 = secondHalfStr.indexOf('?');
															String countrySubStr = secondHalfStr.substring(0, index1);
															int localeStrIndex = secondHalfStr.indexOf("locale");
															if (localeStrIndex > 0) {
																String localeSubStr = secondHalfStr
																		.substring(localeStrIndex);
																LOGGER.debug("In the string>>"+countrySubStr+"  Replacing sourceCountry >>  "+sourceCountry.toUpperCase()+" with targetCountry>>> "+targetCountry.toUpperCase());
																String replacedCountrySubStr = countrySubStr
																		.replace(sourceCountry.toUpperCase(), targetCountry.toUpperCase());
																LOGGER.debug("Replacing in localeSubStr >>"+localeSubStr+" replacing >>"+sourceLanguage + UNDERSCORE + sourceCountry+" with >>"+ key);
																String replacedlocaleSubStr = localeSubStr.replace(
																		sourceLanguage + UNDERSCORE + sourceCountry.toUpperCase(), key);
																String finalReplacedFullStr = firstHalfStr
																		+ replacedCountrySubStr + QUESTION
																		+ replacedlocaleSubStr;
																LOGGER.debug(
																		"Before modifing productsummary_primaryctaurl value: "
																				+ attrValue);
																LOGGER.debug(
																		"After modifing productsummary_primaryctaurl value: "
																				+ finalReplacedFullStr);
																attrValueObj.put(key, finalReplacedFullStr);
															}

														} else {
															LOGGER.debug("Wrong Format CTA URL " + attrValue);
														}

													} else {
														LOGGER.debug("Got target attribute:: " + id + "Value empty");
													}

												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while parsing pim_data.json" + e.getMessage());
		}

	}

	private static boolean findAttribute(String id, JSONArray attributes) throws JSONException {
		for (int i = 0; i < attributes.length(); ++i) {
			JSONObject outerObject = attributes.getJSONObject(i);

			if (outerObject != null) {
				JSONObject attribute = outerObject.getJSONObject(ATTRIBUTE);
				String attributeId = attribute.getString("id");

				if (id.equals(attributeId)) {
					return true;
				}
			}
		}

		return false;
	}

}
