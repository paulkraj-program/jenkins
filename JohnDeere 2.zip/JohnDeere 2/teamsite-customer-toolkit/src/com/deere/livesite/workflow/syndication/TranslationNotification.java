package com.deere.livesite.workflow.syndication;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import org.dom4j.Element;
import com.deere.livesite.authoring.workflow.acpw.task.AutomatedDeploymentSuccessNotification;
import com.deere.livesite.workflow.translation.TranslationJob;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.livesite.workflow.WorkflowUtils;

/**
 * TranslationNotification is an extension of the AutomatedDeploymentSuccessNotification
 * e-mail task that has specific implementation details for the various Deere
 * translation workflows.
 * @author Klish Group, Inc. [ND]
 */
public class TranslationNotification extends AutomatedDeploymentSuccessNotification {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationNotification.class);
	
	/* The name of the workflow variable that indicates if this workflow content was sent for translation */
	private static final String VAR_TRANSLATE_CONTENT = "TranslateContent";
	/* The name of the workflow translation task that contains the translation configuration information */
	private static final String VAR_TRANSLATION_TASK_NAME = "translation_task_name";
	
	/* SimpleDateFormat format for the translation project deadline date */
	private static final String FORMAT_DEADLINE = "MM/dd/yyyy";
	
	private static class TranslationInfo {
		public final SyndicationTarget source;
		public final Set<SyndicationTarget> targets;
		public final TranslationJob translationJob;
		
		public TranslationInfo(SyndicationTarget source, Set<SyndicationTarget> targets, TranslationJob translationJob) {
			this.source = source;
			this.targets = targets;
			this.translationJob = translationJob;
		}
		
	}
	
	private TranslationInfo translationInfo = null;
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.authoring.workflow.acpw.task.DeploymentNotification#getSubject(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSTask)
	 */
	@Override
	protected String getSubject(CSClient client, CSTask task) throws CSException {
		return "TeamSite Job #" + task.getWorkflowId() + " " + getBaseSubject(client, task);
	}

	/* (non-Javadoc)
	 * @see com.deere.livesite.authoring.workflow.acpw.task.AutomatedDeploymentSuccessNotification#createXmlMailContent(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSTask)
	 */
	@Override
	protected Element createXmlMailContent(CSClient client, CSTask task) throws CSException {
		LOGGER.debug("Building email XML content");
		
		Element element = super.createXmlMailContent(client, task);
		
		TranslationInfo translationInfo = getTranslationInfo(client, task);
		if (translationInfo == null) {
			LOGGER.error("Failed to obtain translation information from translation task");
			return element;
		}
		
		Element translationDetails = element.addElement("translation-details");
		
		translationDetails.addElement("source-locale").setText(translationInfo.source.getLocale());
		
		for (SyndicationTarget target : translationInfo.targets) {
			translationDetails.addElement("target-locale").setText(target.getLocale());
			translationDetails.addElement("target-branch").setText(target.getBranch());
		}
		LOGGER.debug("Added locale information");
		
		if (isTranslateContent(task)) {
			LOGGER.debug("Translation enabled; adding translation job details");
			translationDetails.addElement("performer").setText(translationInfo.translationJob.getTranslationTask().getPerformer());
			ArrayList<String> managerList = translationInfo.translationJob.getProjectDetails().getManager();
			LOGGER.debug("Manager List :" +managerList.toString());
			//translationDetails.addElement("project-manager").setText(translationInfo.translationJob.getProjectDetails().getManager());
			for(String manager : managerList) {
				translationDetails.addElement("project-manager").setText(manager);
			}
			String deadline = new SimpleDateFormat(FORMAT_DEADLINE).format(translationInfo.translationJob.getProjectDetails().getDeadline());
			translationDetails.addElement("delivery-date").setText(deadline);
			LOGGER.debug("Added project information");
			
			element.add(translationInfo.translationJob.toElement());
		} else {
			LOGGER.debug("Translation is not enabled on this workflow; skipping translation details");
		}
		
		LOGGER.debug("Added control XML");
		
		return element;
	}

	@Override
	protected String getToEmailAddress (CSClient client, CSTask task) throws CSException {
		if (!isTranslateContent(task)) {
			LOGGER.debug("Translation Not Enabled; returning standard to address");
			return super.getToEmailAddress(client, task);
		}
		
		TranslationInfo translationInfo = getTranslationInfo(client, task);
		String toAddress = translationInfo.translationJob.getInitiatorEmail();
		if (toAddress != null) {
			return toAddress;
		}
		
		return super.getToEmailAddress(client, task);
	}
	
	@Override
	protected List<String> getCCEmailAddress(CSClient client, CSTask task) throws CSException {
		if (!isTranslateContent(task)) {
			LOGGER.debug("Translation Not Enabled; returning standard cc address");
			return super.getCCEmailAddress(client, task);
		}
		
		TranslationInfo translationInfo = getTranslationInfo(client, task);
		String toAddress = translationInfo.translationJob.getJobContact();
		if (toAddress == null) {
			return Arrays.asList(super.getToEmailAddress(client, task));
		}
		
		return Arrays.asList(super.getToEmailAddress(client, task), toAddress);
	}
	
	private static boolean isTranslateContent(CSTask task) throws CSException {
		String translateContent = null;
		try {
			translateContent = WorkflowUtils.findVariable(task, VAR_TRANSLATE_CONTENT);
		} catch (RuntimeException re) {
			// For some unknown reason the above method wraps CSExceptions as RuntimeExceptions
			throw new CSException(re);
		}
		LOGGER.debug("VAR TranslateContent: " + translateContent);
		
		if ("false".equalsIgnoreCase(translateContent)) {
			LOGGER.debug("Translation Not Enabled; skipping translation details");
			return false;
		} else {
			LOGGER.debug("Translation Enabled; adding translation details");
		}
		
		return true;
	}
	
	private TranslationInfo getTranslationInfo(CSClient client, CSTask task) throws CSException {
		// If the cached object is not null return it instead
		if (translationInfo != null) {
			return translationInfo;
		}
		
		String translationTaskName = task.getVariable(VAR_TRANSLATION_TASK_NAME);
		CSWorkflow workflow = task.getWorkflow();
		CSTask targetTask = null;
		for (CSTask curr : workflow.getTasks()) {
			if (translationTaskName.equals(curr.getName())) {
				targetTask = curr;
				break;
			}
		}
		
		if (targetTask == null) {
			LOGGER.warn("Translation Task Name not set");
			return null;
		}
		
		// Get the set of target branches from the workflow task (from the variable on the task)
		Set<String> targetBranches = SyndicationTask.getTargetBranches(targetTask);
		
		// Load the syndication configuration and filter to the desired items
		Set<SyndicationTarget> configuration = SyndicationUtilities.loadSyndicationConfiguration(client);
		
		SyndicationTarget source = AbstractSendForTranslationTask.getSourceLocaleFromTask(client, targetTask, configuration);
		if (source == null) {
			throw new CSException(-1, "Source locale not specified or unavailable");
		}
		
		// Filter the configuration to only the selected target syndication targets (branches)
		Set<SyndicationTarget> targets = SyndicationTarget.filterByBranches(configuration, targetBranches);
		LOGGER.debug("SyndicaitonTarget Targets: " + targets);
		
		TranslationJob translationJob = null;
		if (isTranslateContent(task)) {
			LOGGER.debug("Translation enabled; pulling translation information");
			String ownerId = task.getWorkflow().getOwner().getName();
			// Create the Across control.xml file for the translation project
			translationJob = new TranslationJob(client, targetTask, ownerId, source, targets);
		}
		
		// Set the translationInfo object as the cache of this information
		translationInfo = new TranslationInfo(source, targets, translationJob);
		return translationInfo;
	}
	
}
