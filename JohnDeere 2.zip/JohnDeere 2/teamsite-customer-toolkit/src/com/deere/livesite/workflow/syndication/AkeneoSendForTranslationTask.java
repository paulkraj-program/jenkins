package com.deere.livesite.workflow.syndication;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.deere.livesite.workflow.translation.AkeneoDataCodec;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.ui.teamsite.filesys.blc.BranchConfigException;
import com.interwoven.ui.teamsite.g11n.blc.BranchConfigProviderIfc;

/**
 * AkeneoSendForTranslationTask is an CSURLExternalTask implementation that is
 * responsible for packaging and deploying a project to the Across FTP server.
 * This external builds the control.xml file based on the selected user settings
 * and then builds the archive containing the content.  Once the archive is
 * built it is then uploaded to the Across FTP server.
 * @author Klish Group, Inc. [ND]
 */
public class AkeneoSendForTranslationTask extends AbstractSendForTranslationTask {
	
	private static final String PARAM_BLACK_LIST_PATH = "BlackListPath";
	private static final String PARAM_AUTO_PUBLISH = "AutoPublish";
	private static final String EXCEPTION_EN_TT = "en-TT";
	private static final String REPLACE_EXCEPTION_EN_US = "en-US";
	private static final String ARCHIVE_FILENAME_PREFIX = "Deere.com_PIM_";
	
	private static String ERROR_NOT_MODIFIED = "The selected file ({0}) is not modified";
	
	@Override
	protected SyndicationTarget getSourceLocale(CSClient client, CSTask task, Set<SyndicationTarget> configuration) throws CSException {
		BranchConfigProviderIfc provider = com.interwoven.ui.teamsite.g11n.blc.BranchConfigProviderFactory.getProvider();
		try {
			String isTargetNotSelected = task.getWorkflow().getVariable("isTargetNotSelected");
			Set<Locale> locales = provider.getAllowedLocales(client, task.getArea().getBranch());
			Locale masterLocale = provider.getMasterLocale(client, task.getArea().getBranch());
			LOGGER.debug("Master Locale: " + masterLocale);
			LOGGER.debug("isTargetNotSelected Flag: " + isTargetNotSelected);
			//Flag to identify if user has not selected any target branch - Setting secondary locale(us-EN) for the respective branch
			if (isTargetNotSelected != null && isTargetNotSelected.equalsIgnoreCase("true")) {
				for (Locale locale : locales) {
					if (masterLocale.equals(locale)) {
						// LOGGER.debug("Available locale is master locale");
						continue;
					}

					// LOGGER.debug("Source Locale: " + locale.toString());

					// Filter the configuration to only the source syndication
					// target (branch)
					SyndicationTarget source = SyndicationTarget.filterByLocale(configuration, locale.toString());
					if (source == null) {
						String localeStr = locale.toString().replace('_', '-');
						source = SyndicationTarget.filterByLocale(configuration, localeStr);
					}
					// LOGGER.debug("SyndicationTarget Source: " + source);
					LOGGER.debug("Return Source getSourceLocale:" + source);
					return source;
				}
			}
			if (masterLocale != null && isTargetNotSelected!=null && isTargetNotSelected.equalsIgnoreCase("false")) {
				SyndicationTarget source = SyndicationTarget.filterByLocale(configuration, masterLocale.toString());
				if (source == null) {
					String localeStr = masterLocale.toString().replace('_', '-');
					//Quick fix for R2 default source locale 
					if(localeStr!=null && localeStr.equals(EXCEPTION_EN_TT)) {
						source = SyndicationTarget.filterByLocale(configuration, REPLACE_EXCEPTION_EN_US);
					}
					else {
					source = SyndicationTarget.filterByLocale(configuration, localeStr);
					}
				}
				LOGGER.debug("SyndicationTarget Source getSourceLocale: " + source);

				return source;

			}

			// Filter the configuration to only the source syndication target (branch)
			SyndicationTarget source = SyndicationTarget.filterByBranch(configuration, task.getArea().getBranch().getVPath().getPathNoServer().toString());
			// LOGGER.debug("SyndicationTarget Source: " + source);
			
			return source;
		} catch (BranchConfigException bce) {
			throw new CSException(bce);
		}
	}	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.syndication.AbstractSendForTranslationTask#getOwnerId(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSTask)
	 */
	protected String getOwnerId(CSClient client, CSTask task) throws CSException {
		// Determine if this workflow was initiated from Akeneo automatically
		String autoPublish = task.getVariable(PARAM_AUTO_PUBLISH);
		if (autoPublish != null && !"".equals(autoPublish)) {
			LOGGER.debug("Auto Publish: " + autoPublish);
		} else {
			LOGGER.debug("NOT Auto Publish");
		}
		
		// Assert the file is not the same as the previous version
		// Compare the file against the previous version before sending for translation
		String blackListPath = task.getVariable(PARAM_BLACK_LIST_PATH);
		
		AkeneoDataCodec codec = new AkeneoDataCodec(client, blackListPath);
		
		CSFile[] files = task.getArea().getFiles(task.getFiles());
		if (files.length != 1) {
			LOGGER.info("Multiple files attached to the workflow");
			return super.getOwnerId(client, task);
		}
		
		for (CSFile curr : files) {
			if (CSSimpleFile.KIND != curr.getKind()) {
				LOGGER.info("File was not of type CSSimpleFile: " + curr.getVPath().getAreaRelativePath());
				return super.getOwnerId(client, task);
			}
			
			CSSimpleFile file = (CSSimpleFile) curr;
			// Assert the file is not the same as the previous version
			if (!file.isModified()) {
				String message = MessageFormat.format(ERROR_NOT_MODIFIED, file.getVPath().getAreaRelativePath());
				LOGGER.info(message);
				
				return super.getOwnerId(client, task);
			}
			
			String ownerId = codec.getJSONUserId(file);
			LOGGER.debug("Akeneo Owner ID: " + ownerId);
			if(ownerId != null) {
				return ownerId;
			}
		}
		
		return super.getOwnerId(client, task);
	}
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.syndication.AbstractSendForTranslationTask#sendForTranslation(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSTask, com.deere.livesite.workflow.syndication.SyndicationTarget, java.util.Set)
	 */
	@Override
	protected boolean sendForTranslation(CSClient client, CSTask task, SyndicationTarget source, Set<SyndicationTarget> targets) throws CSException {
		// Assert the file is not the same as the previous version
		// Compare the file against the previous version before sending for translation
		String blackListPath = task.getVariable(PARAM_BLACK_LIST_PATH);
		
		AkeneoDataCodec codec = new AkeneoDataCodec(client, blackListPath);
		
		CSFile[] files = task.getArea().getFiles(task.getFiles());
		/*if (files.length != 1) {
			LOGGER.info("Multiple files attached to the workflow");
			return false;
		}*/
		
		List<CSAreaRelativePath> filesToBeRemoved = new ArrayList<CSAreaRelativePath> ();
		for (CSFile curr : files) {
			/*if (CSSimpleFile.KIND != curr.getKind()) {
				LOGGER.info("File was not of type CSSimpleFile: " + curr.getVPath().getAreaRelativePath());
				return false;
			}*/
			
			CSSimpleFile file = (CSSimpleFile) curr;
			// Assert the file is not the same as the previous version
		/*	if (!file.isModified()) {
				String message = MessageFormat.format(ERROR_NOT_MODIFIED, file.getVPath().getAreaRelativePath());
				LOGGER.info(message);
				
				return false;
			}*/
			
			String current = codec.filterJSON(file);
			LOGGER.debug("Current Content: " + current);
			LOGGER.debug("Revision Number: " + file.getRevisionNumber());
			if (file.getRevisionNumber() > 0L) {
				CSFile[] last = file.getFileRevisionHistory(2);
				if (last != null && last.length > 1) {
					LOGGER.debug("Checking previous revisions");
					CSFile version = last[1];
					LOGGER.debug("Previous Revision Number: " + version.getRevisionNumber());
					if (version != null && CSSimpleFile.KIND == version.getKind()) {
						LOGGER.debug("Checking last submitted version");
						String previous = codec.filterJSON((CSSimpleFile) version);
						LOGGER.debug("Previous Content: " + previous);
						
						if (current.equals(previous)) {
							String message = MessageFormat.format(ERROR_NOT_MODIFIED, file.getVPath().getAreaRelativePath());
							LOGGER.info(message);
							filesToBeRemoved.add(file.getVPath().getAreaRelativePath());
						}
					}
				}
			}
		}
		if(files.length == filesToBeRemoved.size() ){
			LOGGER.debug("No files were modified");
			return false;
		}else{
			CSAreaRelativePath[] areaRelativePath = new CSAreaRelativePath[filesToBeRemoved.size()];
			for(int i=0;i<areaRelativePath.length;i++){
				areaRelativePath[i]=filesToBeRemoved.get(i);
			}
			task.detachFiles(areaRelativePath);
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.syndication.AbstractSendForTranslationTask#getArchiveFilenamePrefix()
	 */
	@Override
	protected String getArchiveFilenamePrefix() {
		return ARCHIVE_FILENAME_PREFIX;
	}
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.syndication.AbstractSendForTranslationTask#preprocessFileForArchive(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSTask, com.interwoven.cssdk.filesys.CSSimpleFile)
	 */
	@Override
	protected InputStream preprocessFileForArchive(CSClient client, CSTask task, CSSimpleFile file) throws CSException {
		String blackListPath = task.getVariable(PARAM_BLACK_LIST_PATH);
		
		AkeneoDataCodec codec = new AkeneoDataCodec(client, blackListPath);
		
		// Filter the JSON file and encode the content to XML
		String encoded = codec.encodeToXML(file);
		
		return new ByteArrayInputStream(encoded.getBytes(Charset.forName("UTF-8")));
	}
	
}
