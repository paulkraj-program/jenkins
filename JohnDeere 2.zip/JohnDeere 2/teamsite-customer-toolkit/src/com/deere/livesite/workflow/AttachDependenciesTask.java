package com.deere.livesite.workflow;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * AttachDependenciesTask is an implementation of CSURLExternalTask that
 * processes the files attached to the workflow adding all files under
 * directories that are attached and processing all primary associations of the
 * processed files.  This task does the following items in order:
 * 	1) Add all child files of all directory files to the working list
 * 	2) Add all primary associations to the working list
 * 	3) Filter all files in the working list based on the filter criteria
 * 		*) Black list
 * 		*) Exclusion filter (regular expression) case-insensitive on relative file path
 * 	4) Detach all files from the workflow
 *  5) Attach remaining files in working list to workflow
 * @author Klish Group, Inc. [ND]
 */
public class AttachDependenciesTask extends AbstractURLExternalTask {
	private static final transient Logger attachedDependenciesLogger = Logger.getLogger(AttachDependenciesTask.class);
	
	
	private static final String PATH_GLOBAL_BLACKLIST = "/iwadmin/main/deere/syndication/STAGING/configuration/blacklist.txt";

	private static final String VAR_DISABLE_GLOBAL_BLACKLIST = "DisableGlobalBlacklist";
	
	// iw/config/Syndication_Exclusionfilelist.cfg
	private static final String VAR_BLACKLIST_PATH		= "BlackListPath";
	
	/**
	 * Iterate through all the attached files to the task. Check if there are any .page files attached 
	 * if yes then first find any XML, CSS or JS filename references available in .page file 
	 * if yes then see if there are any DCRs if any DCRs found then again try to find file references in DCR, 
	 * Do this for all attached .page files and referenced DCR files. 
	 * At last attached all unique files to the task and make sure all attached files do exist in TeamSite.
	 * Make a valid transition based on success and failure 
	 */
	@Override
	public void execute(CSClient client, CSExternalTask task) throws CSException {
		execute(client, (CSTask) task);
	}
	
	public static void execute(CSClient client, CSTask task) throws CSException {
		Set<String> blacklist = new TreeSet<>();
		
		// Check if the global black list is disabled
		if (!Boolean.parseBoolean(task.getVariable(VAR_DISABLE_GLOBAL_BLACKLIST))) {
			blacklist.addAll(loadBlacklistFile(client, new CSVPath(PATH_GLOBAL_BLACKLIST)));
		}
		
		// Load the blacklist file to filter out anything like default.site
		String blacklistPath = task.getVariable(VAR_BLACKLIST_PATH);
		attachedDependenciesLogger.debug("Blacklist Path: " + blacklistPath);
		
		if (blacklistPath != null && !"".equals(blacklistPath)) {
			CSVPath staging = task.getArea().getBranch().getStaging().getVPath().concat(blacklistPath);
			blacklist.addAll(loadBlacklistFile(client, staging));
		}
		attachedDependenciesLogger.debug("Black List: " + blacklist);
		
		// Build a list of CSSimpleFile with the files to process, expanding all
		// directories on the attached files list
		List<CSSimpleFile> filesToProcess = new ArrayList<>();
		
		for (CSAreaRelativePath areaRelativePath : task.getFiles()) {
			attachedDependenciesLogger.info("Processing Default Attached File : " + areaRelativePath);
			if (isInBlacklist(blacklist, areaRelativePath)) {
				attachedDependenciesLogger.info("EXCLUDING: Path " + areaRelativePath + " is on blacklist");
				continue;
			}
			
			CSFile file = task.getArea().getFile(areaRelativePath);
			
			if (file == null) {
				attachedDependenciesLogger.info("File " + areaRelativePath + " does not exist in workarea");
				continue;
			}
			
			if (CSDir.KIND == file.getKind()) {
				attachedDependenciesLogger.debug("Expanding contents of directory: " + areaRelativePath);
				filesToProcess.addAll(getAllFilesInDirectory(task, (CSDir) file, blacklist));
			} else if (CSSimpleFile.KIND == file.getKind()) {
				attachedDependenciesLogger.debug("Adding file to processing list: " + areaRelativePath);
				filesToProcess.add((CSSimpleFile) file);
			}
		}
		
		// Build a list of files to attach to the workflow
		List<CSAreaRelativePath> filesToAttach = new ArrayList<>();
		CSAreaRelativePath[] attachedPaths = task.getFiles();
		
		String filterPattern = FileDependencyAnalyzer.getFilterPatternString(task);
		FileDependencyAnalyzer analyzer = new FileDependencyAnalyzer(client, task.getArea(), filterPattern);
		
		// Find the all dependencies of the files to process
		for (CSSimpleFile file : filesToProcess) {
			attachedDependenciesLogger.info("DEPENDENCY: " + file.getVPath().getAreaRelativePath());
			filesToAttach.add(file.getVPath().getAreaRelativePath());
			
			// Find and attache dependencies for SitePublisher page files only
			// the analyzer will work for both DCRs and SitePublisher pages, so
			// we want to filter at this point instead.
			if ("page".equals(file.getVPath().getExtension())) {
				List<FileDependency> dependencies = analyzer.analyze(file);
				
				for (FileDependency dependency : dependencies) {
					if (isInBlacklist(blacklist, dependency.getPath())) {
						attachedDependenciesLogger.info("EXCLUDING: Path " + dependency.getPath() + " is on blacklist");
						continue;
					}
					
					attachedDependenciesLogger.info("DEPENDENCY: " + dependency.getPath());
					filesToAttach.add(dependency.getPath());
				}
			}
		}
		
		// Remove all files currently attached to the workflow
		// This removed anything that might be originally attached and filtered
		// out by the blacklist, etc. (default.site, etc.) 
		task.detachFiles(attachedPaths);
		attachedDependenciesLogger.debug("Detached all files from workflow after dependency processing: " + Arrays.asList(attachedPaths));
		
		// Add all the files after validation processing
		CSAreaRelativePath[] paths = filesToAttach.toArray(new CSAreaRelativePath[filesToAttach.size()]);
		task.attachFiles(paths);
		attachedDependenciesLogger.debug("Attached all files and dependencies to workflow: " + Arrays.asList(paths));
	}
	
	private static List<CSSimpleFile> getAllFilesInDirectory(CSTask task, CSDir directory, Set<String> blacklist) throws CSException {
		List<CSSimpleFile> paths = new ArrayList<>();
		List<CSDir> queue = new ArrayList<>();
		queue.add(directory);
		
		while (!queue.isEmpty()) {
			CSDir curr = queue.remove(0);
			
			for (CSNode child : curr.getChildren()) {
				CSAreaRelativePath path = child.getVPath().getAreaRelativePath();
				if (isInBlacklist(blacklist, path)) {
					attachedDependenciesLogger.debug("EXCLUDING: Path " + path + " is on blacklist");
					continue;
				}
				
				if (CSDir.KIND == child.getKind()) {
					queue.add((CSDir) child);
				} else if (CSSimpleFile.KIND == child.getKind()) {
					paths.add((CSSimpleFile) child);
				}
			}
		}
		
		return paths;
	}
	
	private static boolean isInBlacklist(Set<String> blacklist, CSAreaRelativePath path) {
		String item = path.toString();
		attachedDependenciesLogger.debug("Looking for path: " + item + " in blacklist");
		for (String regex : blacklist) {
			attachedDependenciesLogger.debug("Blacklist pattern: " + regex + " => " + item);
			if (item.matches(regex)) {
				attachedDependenciesLogger.debug("Match found in blacklist");
				return true;
			}
		}
		
		return false;
	}
	
	private static Set<String> loadBlacklistFile(CSClient client, CSVPath path) throws CSException {
		attachedDependenciesLogger.debug("Loading BlackList: " + path);
		CSFile file = client.getFile(path);
		
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile simpleFile = (CSSimpleFile) file;
			
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(simpleFile.getInputStream(true)))) {
				Set<String> lines = new TreeSet<>();
				String line = null;
				
				while ((line = reader.readLine()) != null) {
					attachedDependenciesLogger.debug("Blacklist Path: " + line);
					lines.add(line);
				}
				
				attachedDependenciesLogger.debug("Blacklist: " + lines);
				return lines;
			} catch (IOException ioe) {
				throw new CSException(ioe);
			}
		}
		
		return Collections.emptySet();
	}
	
}
