package com.deere.livesite.workflow.translation;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import javax.mail.util.ByteArrayDataSource;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;
import javax.xml.transform.stream.StreamSource;
import org.apache.commons.lang3.SystemUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.transform.XSLTransformer;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.sharedutils100.mail.MailConfigException;
import com.interwoven.sharedutils100.mail.Mailer;
import com.interwoven.sharedutils100.mail.MailerConfig;
import com.interwoven.sharedutils100.xml.ElementableUtils;
import com.interwoven.ui.teamsite.workflow.task.urltask.MailNotificationTask;

/**
 * Email Task for the Across Translation retrieval process.  This task sends an
 * e-mail based on the provided parameters (send from, send to, e-mail template).
 * @author Klish Group, Inc. [ND]
 */
public class AcrossRetrievalEmailTask extends MailNotificationTask {
	private static final transient Logger LOGGER = Logger.getLogger(AcrossRetrievalEmailTask.class);
	
	private static final String MIME_TYPE = "text/html";
	
	private static class MailTemplateURIResolver implements URIResolver {
		
		private final String templatePath;
		
		public MailTemplateURIResolver(String path) {
			this.templatePath = path;
		}
		
		@Override
		public Source resolve(String href, String base) {
			String parentPath = (new CSVPath(templatePath)).getParentPath().toString();
			File file = null;
			
			if (SystemUtils.IS_OS_LINUX || SystemUtils.IS_OS_SOLARIS || SystemUtils.IS_OS_UNIX) {
				file = new File("/iwmnt" + parentPath + CSVPath.PATH_DELIMITER + href);
				LOGGER.info("Referenced Template File: " + file);
			} else if (SystemUtils.IS_OS_WINDOWS) {
				file = new File("Y:" + parentPath + CSVPath.PATH_DELIMITER + href);
				LOGGER.info("Referenced Template File: " + file);
			}
			
			if (null != file) {
				return new StreamSource(file);
			}
			return null;
		}
		
	}
	
	private final String subject;	
	private final String senderAddress;
	
	private List<String> toAddressList;
	private List<String> ccAddressList;
	
	private final String templatePath;
	
	/**
	 * Crate a new instance of this e-mail task to send an e-mail according to
	 * the provided parameters.
	 * @param subject The e-mail subject
	 * @param senderAddress The e-mail sender address
	 * @param templatePath The e-mail XSL templat path in TeamSite
	 */
	public AcrossRetrievalEmailTask(String subject, String senderAddress, String templatePath) {
		this.subject = subject;
		this.senderAddress = senderAddress;
		
		this.toAddressList = new ArrayList<String>();
		this.ccAddressList = new ArrayList<String>();
		
		this.templatePath = templatePath;
	}
	
	/**
	 * Add the provided addresses to the e-mail TO list
	 * @param addresses The e-mail address to send to
	 */
	public void addToAddress(String... addresses) {
		for (String address : addresses) {
			toAddressList.add(address);
		}
	}
	
	/**
	 * Add the provided addresses to the e-mail CC list
	 * @param addresses The e-mail address to send to
	 */
	public void addCCAddress(String... addresses) {
		for (String address : addresses) {
			ccAddressList.add(address);
		}
	}
	
	/**
	 * Send the e-mail using the provided CSClient instance and RetrievalInfo
	 * instance to generate the e-mail content.
	 * @param client The CSClient instance
	 * @param retrievalInfo The RetrievalInfo instance
	 * @throws CSException
	 */
	public void execute(CSClient client, RetrievalInfo retrievalInfo) throws CSException {
		MailerConfig configuration = new MailerConfig();
		configuration.setHost(MailNotificationTask.MAIL_SERVER);
		configuration.setSubject(subject);
		LOGGER.debug("Email Subject: " + subject);
		
		configuration.setSender(senderAddress);
		LOGGER.debug("Email Sender Address: " + senderAddress);
		
		configuration.setToRecipients(toAddressList);
		LOGGER.debug("To Address List: " + toAddressList);
		if (ccAddressList.size() > 0) {
			configuration.setCcRecipients(ccAddressList);
			LOGGER.debug("CC Address List: " + toAddressList);
		}
		
		String content = createContentXml(client, retrievalInfo);
		
		InputStream input = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		
		try {
			CSFile file = client.getFile(new CSVPath(templatePath));
			
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				CSSimpleFile templateFile = (CSSimpleFile) file;
				
				XSLTransformer.transform(input, templateFile, output, new MailTemplateURIResolver(templatePath));
			} else {
				LOGGER.error("Invalid email template file: " + templatePath);
				throw new CSException(1, "Invalid email template file: " + templatePath);
			}
		} catch (TransformerException te) {
			throw new CSException(te);
		}
		
		configuration.addDataSource(new ByteArrayDataSource(output.toByteArray(), MIME_TYPE));
		
		if (configuration != null) {
			Mailer mailer = new Mailer(configuration);
			
			try {
				mailer.send();
			} catch (Exception e) {
				LOGGER.error("Failed to send e-mail notification", e);
			}
		}
	}
	
	private String createContentXml(CSClient client, RetrievalInfo retrievalInfo) {
		Document document = DocumentHelper.createDocument();
		Element mailContentElement = document.addElement("MailContent");
		
		mailContentElement.addElement("WebHost").addText(IWWEBD_HOST + IWWEBD_PORT);
		
		mailContentElement.add(retrievalInfo.toElement());
		
		String content = ElementableUtils.toString(mailContentElement, false);
		LOGGER.debug("Mail Content: " + content);
		return content;
	}
	
	/*
	 * This class is an implementation of MailNotificationTask to take advantage
	 * of its prepared constants; however, it is not used in that manner.
	 */
	@Override
	protected MailerConfig createMailConfig(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable parameters) throws MailConfigException, CSException {
		return null;
	}

}
