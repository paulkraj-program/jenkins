package com.deere.livesite.workflow;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSArea;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * FileDependencyAnalyzer is a class that searches through DCR and SitePublisher
 * page files to find the dependencies contained within the file and return a
 * reference to the XML element that contained the reference as well as the path
 * to the dependent file.
 * @author Klish Group, Inc. [ND]
 */
public class FileDependencyAnalyzer {
	private static final transient Logger LOGGER = Logger.getLogger(FileDependencyAnalyzer.class);
	
	private static final String VAR_FILTER_PATTERN = "DependencyFilterPattern";
	
	private final CSClient client;
	private final CSArea area;
	private final Pattern filterPattern;
	
	/**
	 * Create a new FileDependencyAnalyzer instance with the provided
	 * CSExtneralTask instance.
	 * @param t The CSExternalTask instance
	 * @throws CSException
	 */
	public FileDependencyAnalyzer(CSClient c, CSArea a, String filterPatternString) {
		client = c;
		area = a;
		
		if (filterPatternString != null && !"".equals(filterPatternString)) {
			filterPattern = Pattern.compile(filterPatternString, Pattern.CASE_INSENSITIVE);
		} else {
			filterPattern = null;
		}
	}
	
	/**
	 * Analyze the provided CSSimpleFile DCR or SitePublisher page instance for
	 * any potential dependency path instances. 
	 * @param task The current CSExternalTask instance
	 * @param file The CSSimpleFile to analyze
	 * @return The list of dependencies from the DCR file
	 * @throws CSException
	 */
	public List<FileDependency> analyze(CSSimpleFile file) throws CSException {
		LOGGER.info("Analyzing File Dependencies: " + file.getVPath().getAreaRelativePath());
		
		String extension = file.getVPath().getExtension();
		LOGGER.info("File Extension: " + extension);
		
		if (CSSimpleFile.kDCR == file.getContentKind()) {
			return analyzeXmlFile(file);
		} else if ("page".equalsIgnoreCase(extension)) {
			return analyzeXmlFile(file);
		}
		
		LOGGER.info("File contains no dependencies");
		return Collections.emptyList();
	}
	
	private List<FileDependency> analyzeXmlFile(CSSimpleFile file) throws CSException {
		try (InputStream input = new BufferedInputStream(file.getInputStream(true))) {
			Document document = new org.dom4j.io.SAXReader().read(input);
			Element root = document.getRootElement();
			LOGGER.debug("Loaded DCR XML content: " + file.getVPath().getAreaRelativePath());
			
			return searchXmlElement(root);
		} catch (DocumentException | IOException e) {
			throw new CSException(e);
		}
	}
	
	private List<FileDependency> searchXmlElement(Element element) throws CSException {
		List<FileDependency> dependencies = new ArrayList<>();
		LOGGER.debug("Traversing XML Element: " + element.getName());
		
		// Check the element attributes for any potential valid paths
		@SuppressWarnings("unchecked")
		List<Attribute> attributes = element.attributes();
		
		for (Attribute attr : attributes) {
			FileDependency dependency = checkNodeTextForPath(attr);
			if (dependency != null) {
				dependencies.add(dependency);
			}
		}
		
		// Check the child elements for any potential valid paths
		@SuppressWarnings("unchecked")
		List<Element> children = element.elements();
		
		if (!children.isEmpty()) {
			for (Element child : children) {
				LOGGER.debug("Traversing Child Element: " + element.getName() + " => " + element.getTextTrim());
				dependencies.addAll(searchXmlElement(child));
			}
		} else {
			FileDependency dependency = checkNodeTextForPath(element);
			if (dependency != null) {
				dependencies.add(dependency);
			}
		}
		
		LOGGER.debug("Paths from element: " + element.getName() + " => " + dependencies);
		return dependencies;
	}
	
	private FileDependency checkNodeTextForPath(Node node) throws CSException {
		// Check the text content of this element for and potential valid paths
		LOGGER.debug("Checking Node: " + node.getUniquePath());
		String path = node.getText();
		if (LOGGER.isDebugEnabled()) {
			if (path.length() > 256) {
				LOGGER.debug("Node Text: " + path.substring(0, 256) + " ...");
			} else {
				LOGGER.debug("Node Text: " + path);
			}
		}
		
		Pattern pathPattern = Pattern.compile("^/?/?([^/]+/)*([^/]+)$");
		Matcher pathMatcher = pathPattern.matcher(path);
		
		Pattern linkPattern = Pattern.compile("\\$PAGE_LINK\\[([^\\]]+)\\]");
		Matcher linkMatcher = linkPattern.matcher(path);
		
		if (pathMatcher.matches()) {
			LOGGER.debug("Path matches pattern: " + pathPattern.pattern());
			if (path.startsWith("/")) {
				path = path.substring(1, path.length());
			}
			LOGGER.debug("Potential Path: " + path);
			
			if (filterPattern != null && filterPattern.matcher(path).matches()) {
				LOGGER.debug("Filtered path: " + path);
			}
			
			CSFile file = null;
			try {
				file = client.getFile(area.getVPath().concat(path));
			} catch (CSException cse) {
				LOGGER.warn("An error occured retrieving file: " + path);
			}
			
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				FileDependency dependency = new FileDependency(node.getUniquePath(),
						file.getVPath().getAreaRelativePath());
				LOGGER.info("Added Dependency: " + dependency);
				return dependency;
			}
		} else if (linkMatcher.matches()) {
			path = linkMatcher.group(1);
		} else {
			LOGGER.debug("Path DOES NOT match pattern: " + pathPattern.pattern());
			return null;
		}

		return null;
	}
	
	/**
	 * Get the filter pattern String from the provided CSExternalTask instance
	 * @param task The CSExternalTask instance
	 * @return The filter pattern String
	 */
	public static String getFilterPatternString(CSTask task) throws CSException {
		String filterPatternString = task.getVariable(VAR_FILTER_PATTERN);
		LOGGER.debug("Filter Pattern: " + filterPatternString);
		return filterPatternString;
	}
	
}
