package com.deere.livesite.workflow.common;

import com.deere.livesite.workflow.constants.MaintenanceReminderConstants;
import com.deere.livesite.workflow.CommonServices;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

public class Parts {
	
	static final transient Logger LOGGER = Logger.getLogger(Parts.class);
	
	
	private CSClient client = null;
	private List<String[]> parts = new ArrayList<String[]>();
	private String workareaPath = "";
	private Map<String, String[]> generatedParts = new HashMap<String, String[]>();
	private Map<CSSimpleFile, String[]> partDcrs = new HashMap<CSSimpleFile, String[]>();
	
	public Parts(CSClient client, String workareaPath, String fileName, List<String[]> parts, Map<String, String[]> generatedParts) {
		this.client = client;
		this.workareaPath = workareaPath;
		this.parts = parts;
		this.generatedParts=generatedParts;
	}

	/**
	 * Generates the parts DCR with an option to overwrite 
	 * @param overwrite
	 * @return
	 * @throws CSException
	 * @throws IOException
	 */
	public Map<String, String[]> generate(boolean overwrite) throws CSException, IOException {
		
		for (String[] part : parts) {
			String partNum = part[5];
			String targetDcrPath = getDcrPath(part[4] + "/" + partNum);
			CSFile targetFile = client.getFile(new CSVPath(targetDcrPath));
			
			if(targetFile != null && targetFile.isLocked() && 
					!targetFile.getLockOwner().getName().equalsIgnoreCase(client.getCurrentUser().getName())){
				LOGGER.warn("Skipping file as locked by other user : " + targetFile.getVPath().getAreaRelativePath().toString());
			}else if( !generatedParts.containsKey(partNum) && 
					(targetFile == null || targetFile.getKind() == CSHole.KIND || (targetFile != null && targetFile.isLocked()))
					|| overwrite){
				targetFile = createDcr(part, targetDcrPath);		
			}else{
				targetFile = updateDcr(part, targetDcrPath);
			}
			
			if(targetFile!=null && targetFile.getKind() == CSSimpleFile.KIND){
				partDcrs.put((CSSimpleFile)targetFile, part);	
			}
		}
		
		return generatedParts;
	}
	
	/**
	 * Creates new Parts DCR
	 * @param part
	 * @param targetDcrPath
	 * @return CSSimpleFile instance of created DCR
	 * @throws CSException
	 * @throws IOException
	 */
	private CSSimpleFile createDcr(String[] part, String targetDcrPath) throws CSException, IOException{
		LOGGER.debug("CREATING : " + targetDcrPath);
		Document document = DocumentHelper.createDocument();
		Element root = document.addElement("Parts");

		String partNum = part[5];
		String partGroup = part[4];
		String partName = CommonServices.toCamelCase(part[6]);
		String partSplNotes = part[11];
		String shopUrl = part[12];
		String shopUrlText = part[13];
		String avaiblityText = part[14];
		if ((partSplNotes != null) && (!partSplNotes.isEmpty())) {
			partName = partName + " (" + fixSpecialNotes(partSplNotes) + ")";
		}
		root.addElement("Name").setText(partName);
		root.addElement("Group").setText(partGroup);
		
		createPartInfo(root, part);
		createLinks(root.addElement("Link"),partGroup, shopUrl,shopUrlText, avaiblityText);
		
		CSSimpleFile targetFile = CommonServices.createDcr(client, document, new CSVPath(targetDcrPath.trim()));
		if (targetFile != null) {
			generatedParts.put(partNum, part);
		} else {
			LOGGER.error("Error Creating " + targetDcrPath);
		}
		
		return targetFile;
	}
	
	/**
	 * Updates existing Parts DCR
	 * @param part
	 * @param targetDcrPath
	 * @return CSSimpleFile instance of updated DCR
	 * @throws CSException
	 * @throws IOException
	 */
	private CSSimpleFile updateDcr(String[] part, String targetDcrPath) throws CSException, IOException{
		LOGGER.debug("UPDATING : " + targetDcrPath);
		CSFile targetFile = client.getFile(new CSVPath(targetDcrPath.trim()));
		
		if(targetFile!=null && targetFile.getKind() == CSSimpleFile.KIND && targetFile.isValid()){
			Document dcrDocument = CommonServices.readDcr((CSSimpleFile)targetFile);
			
			if(dcrDocument!=null){
				Element root = (Element) dcrDocument.selectSingleNode("Parts");
				String partGroup = part[4];
				String partNum = part[5];
				String partName = CommonServices.toCamelCase(part[6]);
				String partSplNotes = part[11];
				String shopUrl = part[12];
				String shopUrlText = part[13];
				String avaiblityText = part[14];
				
				if (partSplNotes != null && !partSplNotes.isEmpty()) {
					partName = partName + " (" + fixSpecialNotes(partSplNotes) + ")";
				}
				
				CommonServices.checkAndUpdateElement((Element)dcrDocument.selectSingleNode("/Parts/Name"), partName, false);
				CommonServices.checkAndUpdateElement((Element)dcrDocument.selectSingleNode("/Parts/Group"), partGroup, false);
				updatePartInfo(root, part);
				updateLinks((Element)root.selectSingleNode("Link"),partGroup, shopUrl,shopUrlText, avaiblityText);

				targetFile = CommonServices.createDcr(client, dcrDocument, new CSVPath(targetDcrPath.trim()));
				if (targetFile != null) {
					generatedParts.put(partNum, part);
				} else {
					LOGGER.error("Error Updating " + targetDcrPath);
				}
			}
			
			return (CSSimpleFile)targetFile;
		}else{
			LOGGER.error("Error Reading : " + targetDcrPath + ":");
		}

		return null;
		
	}

	/**
	 * Gets the list of all the parts referenced in the products DCR.
	 * @return
	 */
	public Map<CSSimpleFile, String[]> getPartsReference(){
		return partDcrs;
	}
	
	/**
	 * Gets the parts details for each part referenced DCR
	 * @param partRef
	 * @return
	 */
	public String[] getParts(String partRef){
		return partDcrs.get(partRef);
	}
	
	/**
	 * Creates Parts Info element in the parts DCR.
	 * @param root
	 * @param part
	 */
	private static void createPartInfo(Element root, String[] part){
		
		if(root!=null){
			Element partNum = root.addElement("PartInfo");
			partNum.addElement("Label").setText(MaintenanceReminderConstants.PART_NUMBER_LABEL);
			partNum.addElement("Value").setText(part[5]);
			if(!part[4].isEmpty() && !part[4].equalsIgnoreCase("HMK")){
				Element qty = root.addElement("PartInfo");
				qty.addElement("Label").setText(MaintenanceReminderConstants.PART_QTY);
				qty.addElement("Value").setText(part[8]);
				
				Element changeInt = root.addElement("PartInfo");
				changeInt.addElement("Label").setText(MaintenanceReminderConstants.PART_CHANGE_INTERVAL);
				changeInt.addElement("Value").setText(part[9]);
			}
		}
	}
	
	/**
	 * Updates Parts Info element in the parts DCR.
	 * @param root
	 * @param part
	 */
	private static void updatePartInfo(Element root, String[] part){
		
		if(root!=null){
			@SuppressWarnings("unchecked")
			List<? extends Node> partInformation = root.selectNodes("PartInfo");
			
			for(Node partInfoNode: partInformation){
				Element partInfo = (Element)partInfoNode;
				Element partName= (Element) partInfo.selectSingleNode("Label");
				if(partName!=null && partName.getText().equalsIgnoreCase(MaintenanceReminderConstants.PART_NUMBER_LABEL)){
					CommonServices.checkAndUpdateElement((Element) partInfo.selectSingleNode("Value"), part[5], false);
				}else if(partName!=null && partName.getText().equalsIgnoreCase(MaintenanceReminderConstants.PART_QTY)){
					CommonServices.checkAndUpdateElement((Element) partInfo.selectSingleNode("Value"), part[8], false);
				}else if(partName!=null && partName.getText().equalsIgnoreCase(MaintenanceReminderConstants.PART_CHANGE_INTERVAL)){
					CommonServices.checkAndUpdateElement((Element) partInfo.selectSingleNode("Value"), part[9], false);
				}
			}
		}
		
	}
	
	
	/**
	 * Creates a availability link element for each part 
	 * @param root
	 * @param partGroup
	 * @param url
	 */
	private static void createLinks(Element root, String partGroup, String url, String urlText, String availabilityText){
		
		if(root!=null){
			root.addElement("AvailabilityInformation").setText(availabilityText);

			if(!partGroup.equalsIgnoreCase("BAT")){
				root.addElement("LinkLabel").setText(urlText);
				root.addElement("LinkURL").setText(url);
				root.addElement("OpenNewWindow").setText("yes");
			}
		}
	}
	
	/**
	 * Updates availability link element for each part 
	 * @param root
	 * @param partGroup
	 * @param url
	 */
	private static void updateLinks(Element root, String partGroup, String url, String urlText, String availabilityText){

		if(root!=null){
			Element availablityInfo = (Element) root.selectSingleNode("AvailabilityInformation");
			if(availablityInfo!=null){
				CommonServices.checkAndUpdateElement(availablityInfo, availabilityText, false);	
			}else{
				root.addElement("AvailabilityInformation").setText(availabilityText);	
			}

			if(!partGroup.equalsIgnoreCase("BAT")){
				
				Element linkLabel = (Element) root.selectSingleNode("LinkLabel");
				if(linkLabel!=null){
					CommonServices.checkAndUpdateElement(linkLabel, urlText, false);	
				}else{
					root.addElement("LinkLabel").setText(urlText);	
				}
				
				
				Element linkURL = (Element) root.selectSingleNode("LinkURL");
				if(linkURL!=null){
					CommonServices.checkAndUpdateElement(linkURL, urlText, false);	
				}else{
					root.addElement("LinkURL").setText(url);	
				}

				Element newWindow = (Element) root.selectSingleNode("OpenNewWindow");
				if(newWindow!=null){
					CommonServices.checkAndUpdateElement(newWindow, "yes", false);	
				}else{
					root.addElement("OpenNewWindow").setText("yes");
				}
			}
		}
		
	}
	
	
	/**
	 * Gets the path of the DCR for specific part number.
	 * @param partNum
	 * @return
	 */
	public String getDcrPath(String partNum) {
		return workareaPath + MaintenanceReminderConstants.PART_DCT_PATH + partNum;
	}

	/**
	 * Normalize the Special/Additional information for each part label.
	 * @param notes
	 * @return
	 */
	private String fixSpecialNotes(String notes) {
		String updatedNotes = notes;
		updatedNotes = updatedNotes.replaceAll("ENGINE MARKED", "Eng");
		updatedNotes = updatedNotes.replaceAll("Serial Number", "SN -");
		updatedNotes = updatedNotes.replaceAll(";", " /");

		return updatedNotes;
	}
}
