package com.deere.livesite.workflow.translation;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.log4j.Logger;
import com.deere.livesite.workflow.translation.FileTransfer.IFTPProcessor;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;

/**
 * TranslationArchiveDeleter is an implementation of IFTPProcessor that deletes
 * a given list of archives from the FTP file system. This is used typically
 * after successfully processing a set of translation archives and only after a
 * successful process of the archive.
 * 
 * @author Klish Group, Inc. [ND]
 */
class TranslationArchiveDeleter implements IFTPProcessor<Boolean> {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationArchiveDeleter.class);

	private final List<File> archives;
	private final String workingDirectory;

	/**
	 * Create a new instance of the TranslationArchiveDeleter which deletes the
	 * provided files from the remote system if they exist.
	 * 
	 * @param archives
	 *            The list of translation archives to delete on the remote
	 * @param workingDirectory
	 *            The FTP working directory
	 */
	TranslationArchiveDeleter(List<File> archives, String workingDirectory) {

		if (archives == null) {
			throw new IllegalArgumentException("Archive list cannot be null");
		}

		this.archives = archives;
		this.workingDirectory = workingDirectory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.deere.livesite.workflow.translation.FileTransfer.IFTPProcessor#process(
	 * org.apache.commons.net.ftp.FTPClient)
	 */
	@Override
	public Boolean process(ChannelSftp channelSftp) throws IOException {
		Boolean isComplete = false;
		LOGGER.info("Starting for to delete From SFTP for Files : " + archives);

		try {
			for (File file : archives) {
				try {
					channelSftp.rm(workingDirectory + "/" + file.getName());
					isComplete = true;
					LOGGER.info("Successfully deleted: " + file.getName() + " from remote");
				} catch (SftpException e) {
					LOGGER.error("Failed deleting: " + file.getName() + " from remote" + e);
					throw new IOException();
				}
			}
		} catch (Exception e) {
			throw new IOException();
		} finally {
			try {
				if (channelSftp != null && channelSftp.isConnected() && !channelSftp.isClosed()) {
					channelSftp.disconnect();
					LOGGER.info(
							"ChanneSFTP is close for the com.deere.livesite.workflow.translation.TranslationArchiveDeleter.process(ChannelSftp)");
				}
			} catch (Exception e) {
				channelSftp = null;
				LOGGER.error("Exception during closing channelSftp" + e);
			}
		}
		return isComplete;
	}
}
