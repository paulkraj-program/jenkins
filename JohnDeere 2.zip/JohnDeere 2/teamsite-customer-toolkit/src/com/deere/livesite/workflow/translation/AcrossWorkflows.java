package com.deere.livesite.workflow.translation;

import java.io.BufferedInputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;

/**
 * AcrossWorkflows is a class that load the workflow information for Across
 * for targets from a DCR configuration file contained in TeamSite.
 * @author Klish Group, Inc. [ND]
 */
public class AcrossWorkflows {
	private static final transient Logger LOGGER = Logger.getLogger(AcrossWorkflows.class);

	private static final String PATH_WORKFLOWS = "/iwadmin/main/deere/STAGING/templatedata/Translation/AcrossWorkflow/data/workflows.xml";
	
	private static final String DEFAULT_PERFORMER_TYPE = "crowd";
	
	private Document document;
	private Map<String, Element> workflows;
	
	/**
	 * Create a new AcrossWorkflow instance
	 * @param client The current CSClient instance
	 * @throws CSException
	 */
	public AcrossWorkflows(CSClient client) throws CSException {
		CSFile file = client.getFile(new CSVPath(PATH_WORKFLOWS));
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			try {
				document = new org.dom4j.io.SAXReader().read(new BufferedInputStream(((CSSimpleFile) file).getInputStream(true)));
				LOGGER.debug("Workflows: " + document.asXML());
				workflows = new LinkedHashMap<>();
				
				Element root = document.getRootElement();
				
				@SuppressWarnings("unchecked")
				List<Element> children = root.elements("workflow");
				for (Element child : children) {
					String name = child.elementText("acrossWorkflowNm");
					
					workflows.put(name, child);
				}
			} catch (DocumentException de) {
				throw new CSException(de);
			}
		}
	}
	
	/**
	 * Add the specified workflows to the tasks provided parent element
	 * @param parent The parent Element instance
	 * @param name The name of the workflow instance
	 * @param performer The performer
	 * @param performerType The performer type
	 * @param reportingTemplate The reporting template
	 * @param packagingTemplate The packaging template
	 * @param sourceLocale The source locale for the current area
	 */
	public boolean addWorkflowTasks(Element parent, String name, String performer, String performerType, String reportingTemplate, String packagingTemplate, String sourceLocale) {
		LOGGER.debug("Workflow: " + name);
		Element element = workflows.get(name);
		
		if (element != null) {
			LOGGER.debug("Found workflow");
			
			@SuppressWarnings("unchecked")
			List<? extends Node> regTasks = element.selectNodes("workflowTasks/workflowTask/regularTask");
			for (Node taskNode : regTasks) {
				Element task = (Element) taskNode;
				Element taskElement = parent.addElement("workflowTask");
				
				@SuppressWarnings("unchecked")
				List<Element> children = task.elements();
				for (Element child : children) {
					LOGGER.debug("Adding task: " + child.getName() + " => " + child.getText());
					taskElement.add((Element) child.clone());
				}
				
				taskElement.addElement("performerType").setText(performerType);
				taskElement.addElement("performer").setText(performer);
				if (!DEFAULT_PERFORMER_TYPE.equals(performerType)) {
					LOGGER.debug("Adding reportingTemplate => " + reportingTemplate);
					taskElement.addElement("reportingTemplate").setText(reportingTemplate);
					
					LOGGER.debug("Adding packagingTemplate => " + packagingTemplate);
					taskElement.addElement("packagingTemplate").setText(packagingTemplate);
				}
			}
			
			@SuppressWarnings("unchecked")
			List<? extends Node> revTasks = element.selectNodes("workflowTasks/workflowTask/reviewTask");
			for (Node taskNode : revTasks) {
				Element task = (Element) taskNode;
				Element taskElement = parent.addElement("workflowTask");
				
				@SuppressWarnings("unchecked")
				List<Element> children = task.elements();
				for (Element child : children) {
					LOGGER.debug("Adding task: " + child.getName() + " => " + child.getText());
					
					if ("performer".equals(child.getName())) {
						if (sourceLocale != null && !"".equals(sourceLocale)) {
							String value = child.getText();
							// We are hard coding this group in here which is
							// a terrible hack, but there are many other
							// performer groups that do not follow this pattern
							// foisted upon us
							if ("R2 Reviewers".equals(value)) {
								String locale = sourceLocale.toUpperCase();
								locale = locale.replace('-', '_');
								LOGGER.debug("Master locale for review task performer: " + locale);
								
								taskElement.addElement(child.getName()).setText(child.getText() + " " + locale);
							} else {
								LOGGER.debug("Adding task: " + child.getName() + " => " + child.getText());
								taskElement.add((Element) child.clone());
							}
						} else {
							LOGGER.debug("Adding task: " + child.getName() + " => " + child.getText());
							taskElement.add((Element) child.clone());
						}
					} else {
						LOGGER.debug("Adding task: " + child.getName() + " => " + child.getText());
						taskElement.add((Element) child.clone());
					}
				}
			}
			
			return true;
		}
		
		LOGGER.warn("Workflow not found");
		return false;
	}
	
}
