package com.deere.livesite.workflow.translation;

import org.apache.log4j.Logger;

import com.jcraft.jsch.SftpProgressMonitor;

public class SFTPProgressManager implements SftpProgressMonitor {
	private static Logger LOGGER = Logger.getLogger(SFTPProgressManager.class);
	private long max = 0;
	private long count = 0;
	private long percent = 0;

	public SFTPProgressManager() {
		;
	}

	public void init(int op, java.lang.String src, java.lang.String dest, long max) {
		this.max = max;
		LOGGER.info("Starting of Uploading/Downloading data via Across SFTP");
		LOGGER.info("Origin Path : " + src);
		LOGGER.info("Destination Path : " + dest);
		LOGGER.info("Total File size : " + max);
	}

	public boolean count(long bytes) {
		this.count += bytes;
		long percentNow = this.count * 100 / max;
		if (percentNow > this.percent) {
			this.percent = percentNow;
			LOGGER.info("Total " + this.percent + "% Completed (" + this.count + " Bytes )");
		}

		return (true);
	}

	public void end() {
		LOGGER.info(this.percent + " Completed , Total File Size :" + max + "(In Bytes-" + this.count + ")");
	}
}