package com.deere.livesite.workflow;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.workflow.CSExternalTask;

/**
 * This class is used in Delete Workflow to delete the files associated with the workflow.
 * Updated to write all HTML file paths to tmp file and set tmp file path as a global variable for Velocity Search Update - QC1035
 * @author Klish Group, INC. [AG]
 *
 */
public class DeleteFilesTask extends AbstractURLExternalTask {

	private static final String HTML_FILE_LIST_PATH = "HtmlFileListPath";
	private static final Pattern EXCLUDED_FILE_PATTERN =  Pattern.compile ("[^/]*\\.taxonomy");
	public static final String DELETE_FLAG = "Delete";

	@Override
	protected void execute (CSClient client, CSExternalTask task) throws CSException {
		Set<String> htmlFiles = new HashSet<String>();
		//Process all files attached to workflow		
		//Setting global variable for delete workflow
		task.getWorkflow().setVariable(DELETE_FLAG, "true");
		for (CSAreaRelativePath areaRelativePath : task.getFiles ()) {
			LOGGER.info ("Processing File : " + areaRelativePath);

			CSFile file = task.getArea ().getFile (areaRelativePath);
			
			if(!isFileExcluded(areaRelativePath.getName(), EXCLUDED_FILE_PATTERN))	{
				LOGGER.info ("File " + areaRelativePath.getName() + " is a white listed file.Process to delete");
			if (file == null) {
				LOGGER.info ("File " + areaRelativePath + " does not exist in workarea");
				continue;
			}
			
			if (CSHole.KIND == file.getKind ()) {
				LOGGER.debug ("File is already deleted: " + file.getVPath ().toString ());
			} else {
				if(areaRelativePath != null && areaRelativePath.getExtension() != null && "html".equals(areaRelativePath.getExtension()) && !areaRelativePath.toString().startsWith("sites")){
					htmlFiles.add(areaRelativePath.toString());
				}
				file.delete();
			}			
		}
		}
		//create tmp file for html paths
		setHtmlPaths(task,htmlFiles);
		
	}

	
	/**
	 * This method writes the HTML paths to tmp file and set the tmp file path to global variable
	 * @param task CSTask
	 * @param htmlFiles attached file paths
	 */
	private void setHtmlPaths(CSExternalTask task, Set<String> htmlFiles) {
		
		String fileListPath;
		try {
			fileListPath = task.getVariable("FileListPath");
			String htmlFileListPath;
			if (fileListPath != null && !"".equals (fileListPath)) {
				htmlFileListPath = fileListPath+File.separator + task.getWorkflowId () + "_htmlPaths.txt";
			} else {
				htmlFileListPath = File.separator + task.getWorkflowId () + "_htmlPaths.txt";
			}

			//write html paths to temp file
			if(!htmlFiles.isEmpty()){
				if(WorkflowServices.writeFileList(htmlFileListPath,htmlFiles)){
					task.getWorkflow().setVariable(HTML_FILE_LIST_PATH, htmlFileListPath);
					LOGGER.debug("HTML File list path set to global variable:"+task.getWorkflow().getVariable(HTML_FILE_LIST_PATH));
				}
				
			}

		} catch (CSException e) {
			LOGGER.error("Error while setting html file paths to global variable",e);
		}

		
	}
	
	/**
	 * This functions checks if the page is excluded from being deleted
	 * by doing pattern matching.
	 * @param link The file path
	 * @param pattern The excluded file pattern 
	 * @return 
	 */
	private boolean isFileExcluded (String link, Pattern pattern) {
		Matcher matcher = pattern.matcher (link);
		if (matcher.find ()) {
			return true;
		}
		return false;
	}
}
