package com.deere.livesite.workflow.common;

import com.deere.livesite.workflow.constants.MaintenanceReminderConstants;
import com.deere.livesite.workflow.CommonServices;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.ui.teamsite.dependency.DependencyConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

/**
 * Generates ProductDCR and add references to parts DCRs
 */
public class Product {
	static final transient Logger LOGGER = Logger.getLogger(Product.class);
	
	private CSClient client = null;
	private String fileName = "";
	private String workareaPath = "";
	private String productName = "";
	private String machineName = "";
	private String modelNumber = "";
	private String partGroup = "";
	private Map<CSSimpleFile, String[]> partsRef = new HashMap<CSSimpleFile, String[]>();
	private Map<String,String> partsCategory = new HashMap<String,String>();
	
	public Product(CSClient client, String workareaPath, String fileName,String modelNumber, String machineName, String productName, Map<CSSimpleFile, String[]> partsRef, Map<String,String> partsCategory) {
		this.client = client;
		this.workareaPath = workareaPath;
		this.fileName = fileName;
		this.partsRef = partsRef;
		this.partsCategory = partsCategory;
		this.productName=productName;
		this.machineName=machineName;
		this.modelNumber=modelNumber;
	}

	/**
	 * Generates the Product DCR for Maintenance Reminder
	 * @throws CSException
	 * @throws IOException
	 */
	public void generate() throws CSException, IOException {
		Document document = DocumentHelper.createDocument();
		String targetDcr = workareaPath + MaintenanceReminderConstants.PRODUCT_DCT_PATH + fileName;
		CSVPath targetDcrPath = new CSVPath(targetDcr.trim());
		
		Map<CSSimpleFile, Integer> keySort = new HashMap<CSSimpleFile, Integer>();
		
		for (Entry<CSSimpleFile, String[]> entry: partsRef.entrySet()) {
			int key = 100;
			String keyValue = entry.getValue()[7];
			try {
			    if(keyValue != null && !keyValue.isEmpty())
			    	key = Integer.parseInt(keyValue);
			} catch (NumberFormatException e) {
				key = 100;
			}
			keySort.put(entry.getKey(), key);
			
		}
		
		Map<CSSimpleFile, Integer> sortedMap  = CommonServices.sortMapByIntegerValue(keySort);
		CSFile targetCSFile = client.getFile(targetDcrPath);
		
		if(targetDcrPath != null && targetCSFile!=null && targetCSFile.getKind() != CSHole.KIND ){
			document = updateDcr(sortedMap, targetDcrPath);
		}else{
			createDcr(sortedMap, document);	
		}

		if (!fileName.isEmpty()) {
			CSSimpleFile targetFile = CommonServices.createDcr(client, document, targetDcrPath);
						
			if (targetFile != null) {
				LOGGER.debug("Generated " + targetDcrPath);
				for (CSSimpleFile file: sortedMap.keySet()) {
					CommonServices.createChildAssociation(targetFile, file, DependencyConstants.IMAGE_DCR_ASSOCIATION_TYPE);
				}
			} else {
				LOGGER.error("Error Generating " + targetDcrPath);
			}
		} else {
			LOGGER.warn("Failed getting filename for the DCR. ");
		}
	}

	/**
	 * Gets the generated Product DCR Path.
	 * @return
	 */
	public String getDcrPath() {
		return workareaPath + MaintenanceReminderConstants.PRODUCT_DCT_PATH + fileName;
	}

	/**
	 * Creates a new DCR with the values stored in the map.
	 * @param sortedMap
	 * @param document
	 * @throws CSException
	 */
	private void createDcr(Map<CSSimpleFile, Integer> sortedMap, Document document) throws CSException{
		Element productElement = document.addElement("Product");
		productElement.addElement("Name").setText(modelNumber + " - " + normalizeLabel(productName));
		createImages(productElement);

		for (CSSimpleFile file: sortedMap.keySet()) {
			String[] part = partsRef.get(file);
			String dcrPath = file.getVPath().getAreaRelativePath().toString();
			partGroup = part[4];
			String partKey = part[7];
			
			
			String partCategory="MaintenancePart";
			if(partsCategory.get(partGroup)!=null && !partsCategory.get(partGroup).isEmpty()){
				partCategory=partsCategory.get(partGroup);
			}
			
			Element partDetail = productElement.addElement(partCategory);
			partDetail.addElement("PartInfo").setText(dcrPath);
			if(!partCategory.equalsIgnoreCase("Kits")){
				partDetail.addElement("Key").setText(partKey);
				partDetail.addElement("Qty");
			}
		}
	}
	
	/**
	 * Updates the empty DCR fields with the new values. 
	 * @param sortedMap
	 * @param targetDcrPath
	 * @return
	 * @throws CSException
	 */
	private Document updateDcr(Map<CSSimpleFile, Integer> sortedMap, CSVPath targetDcrPath) throws CSException{
		
		CSFile dcrFile = client.getFile(targetDcrPath);
		
		if(dcrFile!=null && dcrFile.getKind()== CSSimpleFile.KIND){
			Document document = CommonServices.readDcr((CSSimpleFile)dcrFile);
			Element productElement = (Element) document.selectSingleNode("Product");
			
			LOGGER.debug("Updating Product DCR.");
			
			if(document != null){
				CommonServices.checkAndUpdateElement((Element)document.selectSingleNode("/Product/Name"), modelNumber + " - " + normalizeLabel(productName), true);
	
				for (CSSimpleFile file: sortedMap.keySet()) {
					
					String[] part = partsRef.get(file);
					String dcrPath = file.getVPath().getAreaRelativePath().toString();
					partGroup = part[4];
					String partKey = part[7];
					
					String partCategory="MaintenancePart";
					if(partsCategory.get(partGroup)!=null && !partsCategory.get(partGroup).isEmpty()){
						partCategory=partsCategory.get(partGroup);
					}
					
					@SuppressWarnings("unchecked")
					List<? extends Node> allDcrs= document.selectNodes("//PartInfo");
					List<String> dcrs = new ArrayList<String>();
					for(Node elemNode : allDcrs){
						Element elem = (Element) elemNode;
						dcrs.add(elem.getText());
					}
					Element partsInfoDcr= (Element) document.selectSingleNode("//PartInfo[text()='" + dcrPath + "']");
					
					if(partsInfoDcr != null){
						Element partDetail = DocumentHelper.createElement(partCategory);
						partDetail.addElement("PartInfo").setText(dcrPath);
						productElement.add(partsInfoDcr.getParent().detach());
					}else if (partsInfoDcr == null && !dcrs.contains(dcrPath)){
						LOGGER.debug("Adding New Part : " + dcrPath );
						Element partDetail = productElement.addElement(partCategory);
						partDetail.addElement("PartInfo").setText(dcrPath);
						if(!partCategory.equalsIgnoreCase("Kits")){
							partDetail.addElement("Key").setText(partKey);
							partDetail.addElement("Qty");
						}	
					}
					
				}
				
				@SuppressWarnings("unchecked")
				List<? extends Node> partInfoDcrs = document.selectNodes("//PartInfo");
				for(Node partInfoNode: partInfoDcrs){
					Element partInfo = (Element) partInfoNode;
					CSSimpleFile partDcr = (CSSimpleFile) client.getFile(new CSVPath(workareaPath + "/" + partInfo.getText())); 
					
					if(partDcr!=null && 
							partDcr instanceof CSSimpleFile && 
							!sortedMap.containsKey(partDcr)){
						LOGGER.debug("Removing Part: " + partDcr.getVPath().getPathNoServer());
						partInfo.getParent().detach();
					}
				}
			}
			
			return document;
		}

		return null;
	}
	

	/**
	 * Creates the Images for Product DCR.
	 * @param root
	 * @throws CSException 
	 */
	private void createImages(Element root) throws CSException {
		String machineTypeLabel = modelNumber + " " + machineName; 
		String machineImage = MaintenanceReminderConstants.DEFAULT_ASSET_BASE_PATH + modelNumber + "/" + modelNumber + "_" + machineName.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
		createImages(root,  machineTypeLabel, machineTypeLabel, machineImage);
		
		String partsImage = MaintenanceReminderConstants.DEFAULT_ASSET_BASE_PATH + modelNumber + "/" + fileName.split("/")[1] + ".jpg";
		createImages(root, productName, productName, partsImage);
		
		CSFile file = client.getFile(new CSVPath(getDcrPath()));
		
		if(file != null && file.getKind() == CSSimpleFile.KIND){
			CommonServices.createChildAssociation((CSSimpleFile)file, client.getFile(new CSVPath(workareaPath+"/"+machineImage)), DependencyConstants.IMAGE_DCR_ASSOCIATION_TYPE);
			CommonServices.createChildAssociation((CSSimpleFile)file, client.getFile(new CSVPath(workareaPath+"/"+partsImage)), DependencyConstants.IMAGE_DCR_ASSOCIATION_TYPE);	
		}
	}
	
	/**
	 * Created the Image Element for product DCR.
	 * @param root
	 * @param title
	 * @param alt
	 * @param imagePath
	 */
	private void createImages(Element root, String title, String alt, String imagePath) {
		Element imageList = root.addElement("ImageList");
		imageList.addElement("Title").setText(normalizeLabel(title));
		imageList.addElement("ImagePath").setText(imagePath);
		imageList.addElement("AltText").setText(normalizeLabel(alt));
	}
	
	
	
	/**
	 * Normalizes the Label/text
	 * @param label
	 * @return
	 */
	private String normalizeLabel(String label){
		if(label.contains("-in.")){
			return label.replace("-in.", "\"");
		}else if(label.contains("M Deck")){
			return label.replace("M Deck", "\" Mulching Deck");
		}
		
		return label;
	}
	
	
}
