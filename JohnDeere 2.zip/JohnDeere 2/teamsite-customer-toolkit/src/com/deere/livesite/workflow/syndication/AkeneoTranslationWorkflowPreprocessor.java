package com.deere.livesite.workflow.syndication;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.access.CSUser;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.modeler.workflow.WFMFile;
import com.interwoven.modeler.workflow.WFMWorkflow;
import com.interwoven.modeler.workflow.commands.InProcessJavaCommand;
import com.interwoven.modeler.workflow.exceptions.WFMException;

public class AkeneoTranslationWorkflowPreprocessor implements InProcessJavaCommand {
	private static final transient Logger LOGGER = Logger.getLogger(AkeneoTranslationWorkflowPreprocessor.class);
	
	private static String PROP_CSFACTORY = "com.interwoven.cssdk.factory.CSFactory";
	private static String PROP_CSFACRORY_IMPL = "com.interwoven.cssdk.factory.CSJavaFactory";
	
	private static String ERROR_LOCK_OWNER = "The selected file ({0}) is locked to TeamSite user {1}";
	private static String ERROR_ACTIVE_WORKFLOWS = "The selected file ({0}) is already attached to TeamSite workflow job #{1}";
	private static String ERROR_FILES_ATTACHED = "No files to be attached. Either there is no PIM_DATA.json file or it is attached to another workflow or locked by another user.";
	private static Pattern jsonFilePattern = Pattern.compile ("(.*[^/]+/[^/]+/website/products/).*/pim_data.json?");
	/* (non-Javadoc)
	 * @see com.interwoven.modeler.workflow.commands.InProcessJavaCommand#execute(com.interwoven.modeler.workflow.WFMWorkflow, java.util.Map)
	 */
	@Override
	public WFMWorkflow execute(WFMWorkflow workflow, Map<String, String> parameters) {
		// Assert there is only a single file attached to the workflow
		WFMFile[] files = workflow.getFiles();
		if (files.length < 1) {
			LOGGER.error("No files attached to the workflow: " + files.length);
			LOGGER.error(ERROR_FILES_ATTACHED);
			throw new RuntimeException(ERROR_FILES_ATTACHED);
		}
		
		String workareaPath = parameters.get("workarea");
		LOGGER.debug("Workarea Path: " + workareaPath);
		
		try {
			CSClient client = getCSClient();
			List<CSAreaRelativePath> filesToBeAttached = new ArrayList<CSAreaRelativePath> ();
			
			for(WFMFile wfmFile:files){
				Matcher m = jsonFilePattern.matcher(wfmFile.getFilePath());
				if(m.find()){
					CSSimpleFile file = getSimpleFile(client, wfmFile, workareaPath);
					
					// Assert the filename matches pim_data.json
					if (file == null) {
						LOGGER.error("Invalid file attached to the workflow: " + wfmFile.getFilePath());
						continue;
					}
					
					// Assert the file is not locked by another user
					if (file.isLocked()) {
						CSUser lockOwner = file.getLockOwner();
						String flowOwner = workflow.getOwner();
						LOGGER.info("Lock Owner: " + lockOwner.getName() + " => " + lockOwner.getDisplayName());
						LOGGER.info("Workflow Owner: " + flowOwner);
						
						if (!flowOwner.equals(lockOwner.getName())) {
							String message = MessageFormat.format(ERROR_LOCK_OWNER, file.getVPath().getAreaRelativePath(), lockOwner.getDisplayName());
							LOGGER.debug(message + file.getName());
							continue;
						}
					}
					
					// Assert the file is not attached to another workflow
					int workflowId = -1;
					if ((workflowId = isFileAttachedToWorkflows(client, file)) != -1) {
						String message = MessageFormat.format(ERROR_ACTIVE_WORKFLOWS, file.getVPath().getAreaRelativePath(), workflowId);
						LOGGER.debug(message + file.getName());
						continue;
					}
					filesToBeAttached.add(file.getVPath().getAreaRelativePath());
				}
			}
			if(filesToBeAttached.size() < 1 ){
				LOGGER.error("No files attached to the workflow: " + filesToBeAttached.size());
				LOGGER.error(ERROR_FILES_ATTACHED);
				throw new RuntimeException(ERROR_FILES_ATTACHED);
			}else{			
					LOGGER.debug("Adding files to workflow");
					workflow.addVariable("AttachedFileList", filesToBeAttached.toString());			
			}
		} catch (WFMException | CSException e) {
			LOGGER.error("Error in Preprocessor");
			throw new RuntimeException (e);
		}
		
		return workflow;
	}
	
	private static CSClient getCSClient() throws CSException {
		Properties properties = new Properties(System.getProperties());
		LOGGER.debug("Getting CSClient instance");
		
		if (properties.getProperty(PROP_CSFACTORY) == null) {
			properties.setProperty(PROP_CSFACTORY, PROP_CSFACRORY_IMPL);
		}
		
		CSFactory factory = CSFactory.getFactory(properties);
		return factory.getClientForCurrentUser(Locale.getDefault(), "WorkflowContext", null);
	}
	
	private static CSSimpleFile getSimpleFile(CSClient client, WFMFile file, String workareaPath) throws CSException {
		LOGGER.debug("Workflow File Path: " + file.getFilePath());
		CSVPath path = new CSVPath(file.getFilePath());
		if (path.getAreaType() == CSVPath.NO_AREA) {
			path = new CSVPath(workareaPath).concat(path.toString());
		}
		
		LOGGER.debug("File Path: " + path);
		
		CSFile csfile = client.getFile(path);
		if (CSSimpleFile.KIND == csfile.getKind()) {
			return (CSSimpleFile) csfile;
		}
		
		LOGGER.error("File is not of kind CSSimpleFile");
		return null;
	}
	
	private static int isFileAttachedToWorkflows(CSClient client, CSFile file) throws CSException {
		int[] taskIds = file.getRelatedTaskIds();
		
		if (taskIds != null && taskIds.length > 0) {
			LOGGER.debug("File has related tasks: " + Arrays.asList(taskIds));
			
			for (int taskId : taskIds) {
				CSTask task = client.getTask(taskId);
				LOGGER.debug("Checking " + taskId + " for activity");
				
				if (task != null && task.isValid()) {
					LOGGER.debug("Task " + taskId + " is active");
					return task.getWorkflowId();
				}
			}
		}
		
		return -1;
	}
	
}
