package com.deere.livesite.workflow;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.dom4j.Document;
import org.dom4j.Element;
import org.jsoup.select.Elements;

import com.deere.livesite.workflow.constants.GenericConstants;
import com.deere.livesite.workflow.utils.ReportSetings;
import com.deere.livesite.workflow.utils.TeamSiteCommonUtils;
import com.deere.livesite.workflow.utils.SitemapPages;
import com.deere.teamsite.ui.utils.UiUtils;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.livesite.dom4j.Dom4jUtils;




public class AssetReport {
private static final Logger LOGGER = Logger.getLogger(AssetReport.class.getName());
	
    private static List<String> pageList;
    private static List<String> fragmentPageList = new ArrayList<String>();
    private static Set<String> dcrListLocale ;
   
    public static final String HTML_DIR = "html/deere/";
	public static final String WEBSITE_DIR = "/website/";
	public static final String SITEMAP_XML = "sitemap.xml";
	private static final String DOMAIN_NAME_PATTERN = "(https://)*(([^/])+)";
	private static final String DEFAULT_PROPERTIES_FILE_PATH = "iw/config/johndeere/constants.properties";
	
	private static String imageFileValidExtension = "gif|jpg|swf|png|ipx|mov|mvr|jpeg|jpe|tif|eps|bmp|pcx|flv|xml|mp3|pdf";
	private static String extensionFilesToAttachFromDCR = "json";
	private static String originalUrl;
	private static String languageMeta = new String();
	private static Set<String> allFilesMap = new HashSet<String>();
	private static Set<String> finalImageList ;
	private static Set<String> referencedFilePaths = new HashSet<String>();
	private static Set<String> referencedFilePathsSP = new HashSet<String>();
	private static Set<String> templatedataFiles = new HashSet<String>();
	private static Set<String> assetBranchList ;
	private static Set<String> unUtilizedAssets ;
	private static Set<String> unUtilizedDCRs;
	private static BufferedReader br;
	private static CSWorkarea vPath ;
	private static CSWorkarea workarea;
	private static String workareaPathAsset = "/default/main/deere/Assets/WORKAREA/shared";
	private static List<String> Sitemapurls = new ArrayList<String>(); 
	private static List<SitemapPages> httpstatusNotVlid = new ArrayList<SitemapPages>();
	private static List<SitemapPages> teamsitePageNotVlid = new ArrayList<SitemapPages>();
	private static List<String> pageNotLive ;
	private static List<SitemapPages> translatedSitemapurls = new ArrayList<SitemapPages>(); 
	private static String iwmnt = "/iwmnt";
	private static Map<String, String> htmlMap = new HashMap<String, String>();
	private static Map<String, String> pageMap = new HashMap<String, String>();
	private static String htmlFolder = new String();
	private static String sitesFolder = new String();
	
	public static void getReport(String workareaPath,CSClient csclient) {
		
Properties prop = new Properties();
FileInputStream fis = null;
		try {
			fis = new FileInputStream(new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties"));
			prop.load(fis);
				
			
					final String regex = "(.*)(\\/deere\\/)(.*)(\\/WORKAREA\\/shared)(.*)";
					// final String string = "/default/main/deere/us/en/WORKAREA/shared";

					final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
					final Matcher matcher = pattern.matcher(workareaPath);
					while (matcher.find()) {
					   
					    String [] arrayLocale = matcher.group(3).split("/");
					    if(arrayLocale.length > 1) {
							languageMeta = arrayLocale[1];
						}
						else {
							languageMeta = "";
							}
					    }
				
					LOGGER.debug("Language Meta : >>>>>>>" + languageMeta); 
					vPath = csclient.getWorkarea(new CSVPath(workareaPath), false);
					LOGGER.debug("V Asset branch Path :>>>"+vPath.getBranch().getName());
					languageMeta = vPath.getBranch().getName();
					  CSFile filesinSites = csclient.getFile(new CSVPath(workareaPath));
					  CSFile filesinSitesAsset = csclient.getFile(new CSVPath(workareaPathAsset+"/assets/"));
					 if (CSDir.KIND == filesinSites.getKind()) {
						  getUnusedAssets((CSDir) filesinSitesAsset);
				         }
					  LOGGER.debug("Size of Assets in Image Branch List >>"+assetBranchList.size()); 
			
				
			   if (CSDir.KIND == filesinSites.getKind()) {
		           getAllFilesInDirectory((CSDir) filesinSites);
		         
		         }
			   
workarea = csclient.getWorkarea(new CSVPath(workareaPath), true);
Properties siteProperties = UiUtils.readPropertiesFile(workarea, DEFAULT_PROPERTIES_FILE_PATH);
if (null == siteProperties) {
	LOGGER.error("Unable to find site properties. exiting ...");
	return;
}
ReportSetings settings = new ReportSetings();
httpstatusNotVlid = new ArrayList<SitemapPages>();
teamsitePageNotVlid = new ArrayList<SitemapPages>();
pageNotLive=new ArrayList<>();
Boolean httpStatus = true;
LOGGER.debug("workareaPath is >>"+workareaPath);
settings.setWorkareaPath(AssetReport.iwmnt+workareaPath);
String parentBranch = csclient.getWorkarea(new CSVPath(workareaPath), false).getBranch().getParentBranch().getName().toString();
String locale = csclient.getWorkarea(new CSVPath(workareaPath), false).getBranch().getName().toString();
settings.setLocale(locale);
LOGGER.debug("Branch is >>>>"+parentBranch+File.separator+locale);
settings.setBranches(parentBranch+File.separator+locale);
htmlFolder = AssetReport.iwmnt+workareaPath+File.separator+"html/deere"+File.separator+parentBranch+File.separator+locale+File.separator+"website";
sitesFolder = AssetReport.iwmnt+workareaPath+File.separator+"sites/deere"+File.separator+parentBranch+File.separator+locale+File.separator+"website";
Instant start = Instant.now();
htmlMap = TeamSiteCommonUtils.getFolderMap(htmlFolder);
pageMap = TeamSiteCommonUtils.getFolderMap(sitesFolder);

LOGGER.debug("Size of htmlMap is >>>>>>################"+htmlMap.size());
LOGGER.debug("Size of htmlMap is >>>>>>################"+pageMap.size());
Instant end = Instant.now();

Duration interval = Duration.between(start, end);

LOGGER.debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    Execution time in seconds: >>>>>>>>>>>>>>>>>>>>>>>>>>" +interval.getSeconds());
LOGGER.debug("Locale is >>>>>>"+locale);
String sitemapFile = TeamSiteCommonUtils.getSiteMap(settings);
settings.setSitemapFile(sitemapFile);
LOGGER.debug("sitemapFile  is >>>>>>"+sitemapFile);
originalUrl = UiUtils.replaceRegex(siteProperties.getProperty("prodNode"), DOMAIN_NAME_PATTERN);
LOGGER.debug("Original URL :" + originalUrl);
LOGGER.debug("Prod Node from constant property :" + originalUrl);
LOGGER.debug("Original URL :" + originalUrl);

if(sitemapFile.isEmpty() || sitemapFile != null || !"".equals(sitemapFile)) {
	Sitemapurls = new ArrayList<String>();
	Sitemapurls= TeamSiteCommonUtils.getSiteMapUrls(settings);
	settings.setSitemapurls(Sitemapurls);
	LOGGER.debug("Size of Sitemapurls is >>"+Sitemapurls.size());
   String DictionaryFile = TeamSiteCommonUtils.getSiteDictionary(settings);
   settings.setDictionaryFile(DictionaryFile);
   if(locale.equals("en")) {
	   translatedSitemapurls= TeamSiteCommonUtils.getSiteMapUrlsEnglish(settings,true);
	   
   }else {
	   translatedSitemapurls= TeamSiteCommonUtils.getSiteMapUrls(settings,true);
   }
  
   
  // LOGGER.debug("translatedSitemapurls............>>>>>"+translatedSitemapurls.toString());
   LOGGER.debug("Size of translatedSitemapurls is >>"+translatedSitemapurls.size());
   List<Future<SitemapPages>> SiteMapDetails = TeamSiteCommonUtils.getPageDetails(translatedSitemapurls);
   
   LOGGER.debug( "SiteMapDetails.size()   >>>"+SiteMapDetails.size());
  
   translatedSitemapurls.clear();
	for (Future<SitemapPages> f : SiteMapDetails) {
		try {
			SitemapPages u = f.get();
				translatedSitemapurls.add(u);
           } catch (Exception e) {
        	   LOGGER.error("Error occuered in the method getConfigurations",e);
			
		}
	}
	 LOGGER.debug( "translatedSitemapurls size after Clear  >>>"+translatedSitemapurls.size());
	 LOGGER.debug( "SiteMapDetails values  >>>"+translatedSitemapurls.toString());
	 for (SitemapPages sp :translatedSitemapurls) {
			if(sp.getTeamsitePage()==null) {
				String pagePathFromTeamSite=pageMap.get(sp.getKeyTranslatedSiteMapPagePath());
				 LOGGER.debug("pagePathFromTeamSite........>>>>>>>"+pagePathFromTeamSite);
				if(pagePathFromTeamSite != null) {
					String[] pagePathFromTeamSiteArray = pagePathFromTeamSite.split(workareaPath);
					sp.setTeamsitePage(pagePathFromTeamSiteArray[1]);
					LOGGER.debug("pagePathFromTeamSite >>>>>"+pagePathFromTeamSiteArray[1]);
					sp.setContainsIndexPage(Boolean.TRUE);
					referencedFilePathsSP.add(pagePathFromTeamSite);
					getAssociation(csclient,workareaPath,pagePathFromTeamSiteArray[1]);
				}
				else {
					sp.setTeamsitePage("No TeamSite Page Found");
					teamsitePageNotVlid.add(sp);
				}
				
			}
			
			if(sp.getKeySiteMapPagePath()!= null){
				LOGGER.debug("><=========================================================================================================");
				
				String strKeySiteMapPagePath = sp.getKeySiteMapPagePath().replaceAll("\\s+", "");
				strKeySiteMapPagePath = strKeySiteMapPagePath.replaceAll("//", "/");
				LOGGER.debug("Checkin->"+strKeySiteMapPagePath);
				String htmlPathFromTeamSite=htmlMap.get(strKeySiteMapPagePath);
				LOGGER.debug("Got "+htmlPathFromTeamSite);
				LOGGER.debug("=========================================================================================================");
				
				
				if(htmlPathFromTeamSite !=null) {
			   LOGGER.debug("htmlPathFromTeamSite >>>>>"+htmlPathFromTeamSite);
				sp.setContainsIndexHTML(Boolean.TRUE);
				LOGGER.debug("Contain index File is >>>>>>"+sp.toString());
				}
				else {
					LOGGER.debug("Contain index File is >>>>>>"+sp.toString());
					httpstatusNotVlid.add(sp);
				}
			}
			
			
			}
	 
	 settings.setSitemapPages(translatedSitemapurls);
	//TeamSiteCommonUtils.generateAssetReport(settings);
		
		
		
	 	LOGGER.debug("><=====================================Start============================================================");
		LOGGER.debug("><====================================================================");
		LOGGER.debug("><=======================================================");
		LOGGER.debug("><=========================================");
		LOGGER.debug("Referece file path values : >>>>> "+referencedFilePaths);
		LOGGER.debug("Referece file path size : >>>>>"+referencedFilePathsSP.size());
		LOGGER.debug("><=========================================");
		LOGGER.debug("><=========================================");
		LOGGER.debug("><=========================================");
		LOGGER.debug("Teamsite not valid values : >>>>> "+teamsitePageNotVlid);
		LOGGER.debug("Teamsite not valid size : >>>>>"+teamsitePageNotVlid.size());
		LOGGER.debug("><=========================================");
		LOGGER.debug("><=========================================");
		LOGGER.debug("><=========================================");
		LOGGER.debug("HTTPStatus not valid values : >>>>> "+httpstatusNotVlid);
		LOGGER.debug("HTTPStatus not valid size : >>>>>"+httpstatusNotVlid.size());
		LOGGER.debug("><=========================================");
		LOGGER.debug("><=======================================================");
		LOGGER.debug("><====================================================================");
		LOGGER.debug("><====================================End================================================================");
}

finalImageList = new HashSet<String>();
unUtilizedDCRs = new HashSet<String>();
unUtilizedAssets = new HashSet<String>();
unUtilizedAssets.addAll(assetBranchList);
unUtilizedDCRs.addAll(dcrListLocale);

for(String allFilesMapWOSalesManual : allFilesMap) {
	if((!allFilesMapWOSalesManual.contains("/sales/salesmanual/")) && (!allFilesMapWOSalesManual.contains("http"))) {
		finalImageList.add(allFilesMapWOSalesManual);
	}
}
for(String usedImage : finalImageList) {
	
	if(assetBranchList.contains("/default/main/deere/Assets/WORKAREA/shared"+usedImage)) {
		
		unUtilizedAssets.remove("/default/main/deere/Assets/WORKAREA/shared"+usedImage);
	}
}
for(String usedDCR : templatedataFiles) {
	if(dcrListLocale.contains(usedDCR)) {
		unUtilizedDCRs.remove(usedDCR);
	//	LOGGER.debug("Removing DCR............>>"+usedDCR);
	}
}

EmailTemplateImpl emailTemp=new EmailTemplateImpl();
String EmailSender=GenericConstants.EMAIL_FROM;
String Email_CC=GenericConstants.EMAIL_CC;

Date date = new Date() ;
String branchName = parentBranch+File.separator+locale;
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
String[] localeValue=branchName.split("/");
int rownum = 0;
int assetRow = 0;
int assetBranchRow = 0;
int unutilisedAssetRow = 0;
int unutilisedDCRRow = 0;
int totalDCRRow = 0;
//XSSFRow row;
String outputFile="/tmp/AssetReport_"+localeValue[0]+"_"+localeValue[1]+"_"+dateFormat.format(date) + ".xlsx";
LOGGER.debug("Output File path " + outputFile); 
XSSFWorkbook workbook = new XSSFWorkbook();
XSSFSheet sheet = workbook.createSheet("Valid Assets");
XSSFSheet dcrList = workbook.createSheet("Valid DCR Files List");
XSSFSheet imageAssetBranch = workbook.createSheet("AssetBranch Assets");
XSSFSheet unUtilDCR = workbook.createSheet("Unutilized DCR for "+localeValue[0]+"_"+localeValue[1]);
XSSFSheet unUtilImage = workbook.createSheet("Unutilized Assets for "+localeValue[0]+"_"+localeValue[1]);
XSSFSheet totalDCRList = workbook.createSheet("Total DCR List for "+localeValue[0]+"_"+localeValue[1]);
	for(String dcrItems : templatedataFiles) {
		XSSFRow row = dcrList.createRow(rownum++);
		int cellnum = 0;
		 XSSFCell cell = row.createCell(cellnum++);
		    if(dcrItems instanceof String)
		     cell.setCellValue((String)dcrItems);
	}
	for(String imagedata : finalImageList)
	{
		 XSSFRow row = sheet.createRow(assetRow++);
		 int cellnum = 0;
		 XSSFCell cell = row.createCell(cellnum++);
		    if(imagedata instanceof String)
		     cell.setCellValue((String)imagedata);
	}
	for(String assetBranch : assetBranchList) {
		XSSFRow row = imageAssetBranch.createRow(assetBranchRow++);
		int cellnum = 0;
		 XSSFCell cell = row.createCell(cellnum++);
		    if(assetBranch instanceof String)
		     cell.setCellValue((String)assetBranch);
	}
	for(String unUtilImg : unUtilizedAssets) {
		XSSFRow row = unUtilImage.createRow(unutilisedAssetRow++);
		int cellnum = 0;
		 XSSFCell cell = row.createCell(cellnum++);
		    if(unUtilImg instanceof String)
		     cell.setCellValue((String)unUtilImg);
	}
	for(String unUtilDCRVal : unUtilizedDCRs) {
		XSSFRow row = unUtilDCR.createRow(unutilisedDCRRow++);
		int cellnum = 0;
		 XSSFCell cell = row.createCell(cellnum++);
		    if(unUtilDCRVal instanceof String)
		     cell.setCellValue((String)unUtilDCRVal);
	}
	for(String totalDCR : dcrListLocale) {
		XSSFRow row = totalDCRList.createRow(totalDCRRow++);
		int cellnum = 0;
		 XSSFCell cell = row.createCell(cellnum++);
		    if(totalDCR instanceof String)
		     cell.setCellValue((String)totalDCR);
	}

try
  {
   //Write the workbook in file system
   FileOutputStream out = new FileOutputStream(new File(outputFile));
   workbook.write(out);
   out.close();
   LOGGER.debug("assetReport.xlsx has been created successfully");
  } 
  catch (Exception e) 
  {
	  LOGGER.error("Error occuered in the method getRport while writing the output to a excel file",e);
  }
  finally {
   workbook.close();
  }

//String filePathOfOutput= AssetReportDataRead.CreateXML(templatedataFiles,finalImageList,assetBranchList,unUtilizedAssets,unUtilizedDCRs,dcrListLocale,branchName);

EmailTemplateImpl.getInstance();
emailTemp.getMailSession();

String receiverString=csclient.getCurrentUser().getEmailAddress();

String subject="Asset Report for - "+branchName+" "+dateFormat.format(date);
emailTemp.sendEmail(EmailSender,receiverString ,branchName, Email_CC, subject, outputFile);
csclient.endSession();

		} catch (IOException e) {
			LOGGER.error("Error occuered in the method getReport",e); 
		}  catch (CSException e1) {
			LOGGER.error("CSException occuered in the method getReport",e1); 
			
		}
		finally {
			if(fis != null) {
	            try {
	            	fis.close();
				} catch (IOException e) {
					LOGGER.error("Error occuered while closing the fileInputStram the method getReport",e); 
				}
			}
	    }
		
		
	}
	
	public static List<SitemapPages> getSiteMapUrls(ReportSetings settings,Boolean getSiteMapUrls) {

		List<String> Urls;
		List<SitemapPages>listPages = new ArrayList<SitemapPages>();
		Urls = new ArrayList<String>();
		Map<String, String> map;
		File file = new File(settings.getDictionaryFile());
		
		try {
			map = new HashMap<String, String>();
			InputStream is = new FileInputStream(file);
			Document doc = Dom4jUtils.newDocument(is);
			if (null != doc) {
				Element root = doc.getRootElement();
				Iterator<Element> elements = root.elementIterator("ListItem");
				
				while (elements.hasNext()) {
					Element urlEle = elements.next();
					Element Target = urlEle.element("Target");
					Element Source = urlEle.element("Source");
					map.put(Target.getText(), Source.getText());
					}
				} 
			
			
			LOGGER.debug("Map size is >>>"+map.size());
			for (String sitemapurl:settings.getSitemapurls()) {
				LOGGER.debug("<<<<<<<<<<<<<<< START >>>>>>>>>>>>>>>>>>>>>>");
				SitemapPages pagesAttributes = new SitemapPages();
				String domainNameFromURL = new String();
				try {
					java.net.URL u = new URL(sitemapurl);
					 domainNameFromURL="https://"+u.getHost();
				} catch (MalformedURLException e) {
					LOGGER.error("MalformedURLException Error occuered in the method getSiteMapUrls",e); 
				}
				pagesAttributes.setSitemapUrl(sitemapurl);
				LOGGER.debug("domainNameFromURL >>>>>>"+domainNameFromURL);
				String []urlPath = sitemapurl.split(domainNameFromURL);
				LOGGER.debug("sitemapurl >>"+sitemapurl);
				LOGGER.debug("urlPath Size >> "+urlPath.length);
				String[] urlPathArray  = urlPath[1].split("/");
				String htmlFile = new String();
				String htmlFileTranslated = new String();
				String toReplace = File.separator+settings.getLocale()+File.separator;
				htmlFile = getKeyPattern(urlPath[1],toReplace,"html");
				htmlFile = htmlFile.replaceAll("\\s+", "");
				LOGGER.debug("Converted toString from >>"+urlPath[1] +"to >>>>>"+htmlFile);
                List<String>pathFromDictionaryList = new ArrayList<>();
				for(int i =1 ;i<urlPathArray.length;i++) {
					LOGGER.debug("urlPathArray split is >>"+urlPathArray[i]);
					
					String h=map.get(urlPathArray[i]);
					if(h!=null) {
						LOGGER.debug("found in dictionary >> "+urlPathArray[i] +">> "+h);
						pathFromDictionaryList.add(h);
					}
					else {
						pathFromDictionaryList.add(urlPathArray[i]);
					}
					
				}
				
				String pathFromDictionary = String.join("/",pathFromDictionaryList);
				htmlFileTranslated = getKeyPattern(File.separator+pathFromDictionary,toReplace,"page");
				
				
				LOGGER.debug("Converted toString from >>"+pathFromDictionary +"to >>>>>"+htmlFileTranslated);
				pagesAttributes.setConvertedSitemapUrl(domainNameFromURL+File.separator+pathFromDictionary);
				pagesAttributes.setKeySiteMapPagePath(htmlFile);
				pagesAttributes.setKeyTranslatedSiteMapPagePath(htmlFileTranslated);
				pagesAttributes.setWorkAreaVPath(settings.getWorkareaPath());

				listPages.add(pagesAttributes);
			
			}
			} catch (FileNotFoundException e) {
				LOGGER.error("FileNotFoundException Error occuered in the method getSiteMapURLs",e); 
		}
		
		
		return listPages;
	}

	private static String getKeyPattern(String UrlPathwithoutDomain,String toReplace,String type) {
		// TODO Auto-generated method stub
		LOGGER.debug("Printing All UrlPathwithoutDomain >>>>>>>>>>>>>>>>>>>>>>>>"+UrlPathwithoutDomain);
		UrlPathwithoutDomain = UrlPathwithoutDomain.replaceFirst(toReplace, "");
		String tempurlPath= UrlPathwithoutDomain;
		String paramaterhtmlFile = new String();
		tempurlPath = tempurlPath.replaceAll("\\s+", "");
		if(tempurlPath.endsWith("/")) {

			tempurlPath= tempurlPath.substring(0, tempurlPath.length() - 1);
		 }
		LOGGER.debug("Printing All tempurlPath >>>>>>>>>>>>>>>>>>>>>>>>"+tempurlPath);
		
		if(!tempurlPath.contains(".html")) {
			tempurlPath = tempurlPath+File.separator+"index.html";
		}
		String[] tempurlPathArray =tempurlPath.split("/");
		if(tempurlPathArray.length>4) {
			paramaterhtmlFile = tempurlPathArray[tempurlPathArray.length -4]+File.separator+tempurlPathArray[tempurlPathArray.length -3]+File.separator+tempurlPathArray[tempurlPathArray.length -2]+File.separator+tempurlPathArray[tempurlPathArray.length -1];
    		}
		else {
			paramaterhtmlFile =tempurlPath;
		}
		if(type.equalsIgnoreCase("page")) {
			paramaterhtmlFile = paramaterhtmlFile.replaceFirst(".html", ".page");
		}
		LOGGER.debug("Printing All paramaterhtmlFile >>>>>>>>>>>>>>>>>>>>>>>>"+paramaterhtmlFile);
		return paramaterhtmlFile;
	}
	 static String getMetaTag(org.jsoup.nodes.Document document, String attr) {
		 String s = "";
		 try {
		 if(attr != null && !"".equals(attr) && !attr.equals("null")) {
		    Elements elements = document.select("meta[name=" + attr + "]");
		    for (org.jsoup.nodes.Element element : elements) {
		         s = element.attr("content");
		        if (s == null) {
		        	s = "" ;
		        	} 
		       
		    }
		 } 
		 
		 }catch(Exception e)
		 {
			 LOGGER.debug("null");
		 }
		
	 return s;
	}
	public static CSFile getSiteMapFile(CSWorkarea workarea) {
		CSFile csFile = null;
		if (null != workarea) {
			String workareaStr = workarea.getVPath().getPathNoServer().toString();
			String locale = UiUtils.getLocale(workareaStr);
			String sitemapFilePath = HTML_DIR + locale + WEBSITE_DIR + SITEMAP_XML;
			LOGGER.debug("Workarea :" + workarea + ", Sitemap Path :" + sitemapFilePath);
			csFile = UiUtils.getCSFile(workarea, sitemapFilePath);
		}
		return csFile;
	}

	private static void getAssociation(CSClient csClient, String workareaPath,String prodPathURl) {
		
		
		String pageFolderPath = null;
		List<String> pageURLList = new ArrayList<String>();
		try {
			String indexPagePath = workareaPath+prodPathURl;
			if(indexPagePath.contains("/index.page")) {
				int indexofPage = indexPagePath.indexOf("/index.page");
				if(indexofPage != -1)
				{
					pageFolderPath = indexPagePath.substring(0 , indexofPage);
				}
			
			
			LOGGER.debug("Fragment page folder path : >>>>>>> "+ pageFolderPath);
			CSFile filesinSites = csClient.getFile(new CSVPath(pageFolderPath));
			 if (CSDir.KIND == filesinSites.getKind()) {
				 fragmentPageList.clear();
				  getAllFragmentFilesInDirectory((CSDir) filesinSites);
				  pageURLList = fragmentPageList ;
		         }
				}
			 else
				{
					pageURLList.add(indexPagePath);
				}
			 LOGGER.debug("Size of Fragment Pages List >>"+pageURLList.size());
			 LOGGER.debug("Values of Fragment Pages List >>"+fragmentPageList);
			 for (String pageURLpath : pageURLList ) {
			CSVPath pagePath = new CSVPath(pageURLpath);
			CSSimpleFile cs = (CSSimpleFile) csClient.getFile(pagePath);
			CSAssociation[] ca = cs.getParentAssociations(null);
			for(CSAssociation caaFile :ca) {
				String dcrFiles = caaFile.getParent().getUAI();
				LOGGER.debug("Associated Parent file :>>>>>>"+ dcrFiles);
				
				if(caaFile.getParent().getUAI().contains("/templatedata/"))
				{
					if(dcrFiles.contains("/STAGING/")) {
					dcrFiles = dcrFiles.replace("STAGING", "WORKAREA/shared");
					}
					templatedataFiles.add(dcrFiles);
					
					File f = new File("/iwmnt"+dcrFiles);
					
					if(f.exists()) {
						
						CSVPath pagePathImage = new CSVPath(dcrFiles);
						
						
						if(!pagePathImage.equals(null)) {
						LOGGER.debug("Page Path Found for DCR..............>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+pagePathImage);
						CSSimpleFile csImage = (CSSimpleFile) csClient.getFile(pagePathImage);
						if(csImage.getKind() != 3)
						{
							referencedFilePaths = getFileReferences ((CSSimpleFile) csImage);
						}
					}
					
					
					//CSAssociation[] caImage = csImage.getParentAssociations(null);
					
					
					}
					else
					{
						LOGGER.debug("Page not found..............>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
					}
				}
				
				
			}
			
			}
		//	 LOGGER.debug("Fragment URLs :=>>>>>>>>"+fragmentPageList);
		//	 LOGGER.debug("Total URLS :=>>>>>>>>"+pageURLList);
			 LOGGER.debug("Fragment URLs Size :=>>>>>>>>"+fragmentPageList.size());
			 LOGGER.debug("Total URLS Size :=>>>>>>>>"+pageURLList.size());
			LOGGER.debug("Total templatedata file count := >>>>>>>"+ templatedataFiles.size());
		//	LOGGER.debug("Templatedata file lists"+ templatedataFiles);
			LOGGER.debug("Referenced Image count:=>>>>>>>>"+referencedFilePaths.size());
		//	LOGGER.debug("Images associated with DCR file is :=>>>>>>>>"+referencedFilePaths);
			
		}
		catch(CSException e)
		{
			LOGGER.error("CSException  occuered in the method getAssociation",e); 
		}
		
		
	}
	private static Set<String> getUnusedAssets(CSDir directory) throws CSException, IOException {
		assetBranchList = new HashSet<String>();
		 List<CSDir> queue = new ArrayList<CSDir>();
		 Pattern validFilesPattern = Pattern.compile ("(\\/([a-zA-Z_0-9-\\s\\/]*\\/[^/]+\\.(" + imageFileValidExtension + "))?)");
			
			Matcher matcher;
	        queue.add(directory);
	        while (!queue.isEmpty()) {
	            CSDir curr = queue.remove(0);
	            try {
	            	 for (CSNode child : curr.getChildren()) {
	            		 if (CSDir.KIND == child.getKind()) {
                             queue.add((CSDir) child);
                     } else if (CSSimpleFile.KIND == child.getKind()) {
	            			
	                     		try {
	                    				matcher = validFilesPattern.matcher (child.toString());
	                    				while (matcher.find ()) {
	                    					
	                    					assetBranchList.add (matcher.group ());
	                    				
	                    				}
	                    			
	                     		}catch(Exception ce) {
	                    			LOGGER.error ("Failed in getting children of path"+ce);
	                    		}
	            		 }
	            	 }
	            	 assetBranchList.remove("/");
	            	 
	        }catch (CSException e) {

	        	LOGGER.error("Error occuered in the method getUnusedAssets",e); 
			}
	     }
	        return assetBranchList;
	}
	private static Set<String> getFileReferences (CSSimpleFile file) {
		
		LOGGER.debug("Getting References from File : " + file.getVPath ());
		Pattern validFilesPattern = Pattern.compile ("(\\/([a-zA-Z_0-9-\\s\\/]*\\/[^/]+\\.(" + imageFileValidExtension + "|" + extensionFilesToAttachFromDCR + "))?)");
		
		Matcher matcher;
		String line;
	//	allFilesMap = new HashSet<String> ();

		
		try {
			br = new BufferedReader (new InputStreamReader (((CSSimpleFile) file).getInputStream (true)));
			while ((line = br.readLine ()) != null) {
				//logger.debug("Image Pattern URL : >>>>>>>"+line);
				matcher = validFilesPattern.matcher (line);
				while (matcher.find ()) {
					allFilesMap.add (matcher.group ());
				}
			}
			allFilesMap.remove("/");
		} catch (CSException csex) {
			LOGGER.error ("Failed retrieving file references: ", csex);
		} catch (IOException ioex) {
			LOGGER.error ("Failed retrieving file references: ", ioex);
		} finally {
			if (br != null) {
				try {
					br.close ();
				} catch (Exception ex) {
					LOGGER.error ("Failed closing reader ", ex);
				}
			}
		}

	//	logger.debug ("File contains " + allFilesMap.size () + " reference(s)");
	//	logger.debug("Asset FIle value >>>>>>>> "+ allFilesMap );
		return allFilesMap;
	}
	
	private static void getAllFragmentFilesInDirectory(CSDir directory)
	{
        List<CSDir> queue = new ArrayList<CSDir>();
        queue.add(directory);
        
        while (!queue.isEmpty()) {
            CSDir curr = queue.remove(0);
            
            try {
            	 for (CSNode child : curr.getChildren()) {
            		if (CSSimpleFile.KIND == child.getKind()) {
                	 LOGGER.debug("Procressing >>>>>>>>>>>>>>"+child.getUAI());
                	 if (child.toString().contains(".page")  && child.toString().contains("/sites/")){
                 		//LOGGER.debug("Fragment Page is >>>"+child.getUAI().toString());
                 		
                		 fragmentPageList.add(child.getUAI().toString());
                 	}
                	 else {}
                	 
                 }
            	 }
            	
            }  catch (CSException e) {

            	LOGGER.error("Error occuered in the method getAllFragmentFileInDiectory",e); 
			}
        }
        
	}
	private static void getAllFilesInDirectory(CSDir directory) {
         // TODO Auto-generated method stub
		pageList = new ArrayList<String>();
		dcrListLocale = new HashSet<String>();
         List<CSDir> queue = new ArrayList<CSDir>();
         queue.add(directory);
         while (!queue.isEmpty()) {
                         CSDir curr = queue.remove(0);
                         
                         try {
                                         for (CSNode child : curr.getChildren()) {
                                                         if (CSDir.KIND == child.getKind()) {
                                                                 queue.add((CSDir) child);
                                                         } else if (CSSimpleFile.KIND == child.getKind()) {
                                                        	 	if ( child.toString().contains(".page")  && child.toString().contains("/sites/")){
                                                        		//LOGGER.debug("Page is >>>"+child.getUAI().toString());
                                                        		pageList.add(child.getUAI().toString());
                                                        	}
                                                        	else if (child.toString().contains("/templatedata/")) {
                                                        		//LOGGER.debug("DCR is >>>"+child.getUAI().toString());
                                                        		dcrListLocale.add(child.getUAI().toString());
                                                        	} 
                                                        	else {}
                                                                        
                                                                         
                                               
                                                                         
                                                         }
                                                         else {}
                                         }
                         }catch (CSException e) {
                        	 LOGGER.error("Error occuered in the method getAllFilesInDirectory",e); 
                         }
         }
         
        
}

	

	
}
