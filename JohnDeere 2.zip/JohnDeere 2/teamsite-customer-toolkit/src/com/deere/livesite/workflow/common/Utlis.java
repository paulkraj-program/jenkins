package com.deere.livesite.workflow.common;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;

import com.deere.livesite.workflow.constants.TranslationConstants;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.impl.Utils;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;


public class Utlis {
	private static final Logger LOGGER = Logger.getLogger (Utils.class);
	private static final String ROOT_ELEMENT = "ListItem";
	private static final String KEY_ELEMENT = "Name";
	private static final String VALUE_ELEMENT = "Value";
	private static Properties properties = null;
	
	public Map<String, String> generateURLsMap(CSFile csFile) {
		Map<String,String> urlMap = new HashMap<String,String>();	
		
		try {
			if(csFile!=null && CSSimpleFile.KIND == csFile.getKind()){
				LOGGER.debug("Reading webserver URL Mapping file "+csFile.getName ());    		
				try {
					CSSimpleFile simpleFile = (CSSimpleFile) csFile;
					Document doc = loadFile(simpleFile);
					if(doc != null){
						urlMap = generateMap (doc,ROOT_ELEMENT,KEY_ELEMENT,VALUE_ELEMENT);
					}
				} catch (CSException e) {
					LOGGER.debug ("Reading webserver URL Mapping Document threw exception ");
				}    
			}
		}  catch (CSException e) {
			LOGGER.debug ("Error Generating webserver URL Map ");
			LOGGER.error("Error generating  webserver URL Map ", e);
		}
		return urlMap;
	}
	
	
	public Map<String, String> generateMap(Document doc, String rootElementName, String elementName,
			String elementValue) {
		Map<String,String> urlMapping = new HashMap<String,String>();
		Element root = doc.getRootElement();
		@SuppressWarnings("unchecked")
		List<Element> children = root.elements(rootElementName);
		for (Element element : children) {
			// The option display value
			String name = element.elementText(elementName);
			
			if (element.element(elementValue) != null) {
				// The option value
				String value = element.elementText(elementValue);				
				LOGGER.debug("Entry: " + name + " => " + value);
				urlMapping.put(name, value);
			} else {
				LOGGER.debug("Entry: " + name + " => " + name);
				urlMapping.put(name, name);
			}
		}
		
		return urlMapping;
	}
	
	public Document loadFile(CSSimpleFile simpleFile) throws CSException{
		LOGGER.debug("Loading File: " + simpleFile.getName ());	
		InputStreamReader fis = null;
		try {
			if (simpleFile != null && simpleFile.isReadable ()) {
				 fis = new InputStreamReader(simpleFile.getInputStream(true));
				Document document = new org.dom4j.io.SAXReader().read(fis);				
				fis.close ();
				return document;
			}
		} catch (Exception e) {
			LOGGER.debug ("Exception while reading the file "+simpleFile.getName ());
			LOGGER.error ("Unable to read File "+simpleFile.getName (), e);
		}
		finally {
			if(fis != null) {
	            try {
					fis.close();
				} catch (IOException e) {
					LOGGER.error ("Caught Exception in closing the InputStreamReader in loadFile for Utils : " ,e);
				}
			}
		}
		
		return null;
	}
	
	

	public static Properties loadProperties(CSClient client, String configurationPath) throws CSException {
		CSFile file = client.getFile(new CSVPath(configurationPath));
		properties=new Properties();
		InputStream input = null;
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			input  = new BufferedInputStream(((CSSimpleFile) file).getInputStream(true));
			try {
				properties.load(input);
			} catch (IOException ioe) {
				throw new CSException(ioe);
			}
			finally {
				if(input != null) {
		            try {
						input.close();
					} catch (IOException e) {
						LOGGER.error ("Caught Exception in closing the InputStreamReader in loadProperties for Utils : " ,e);
					}
				}
			}
		}

		return properties;
	}
	
	/**
	 * Method to fetch Extended attribute of CSSimple file 
	 * @param fileToUpdate
	 * @return Array of Extended attribute
	 */
	public static ArrayList<String>  getExistingExtendedAttribute(CSSimpleFile fileToUpdate) {
		ArrayList<String> existingExtendedAttrList=new ArrayList<String>();
		String existingExtendedAttrVal=null;
		try {
			 existingExtendedAttrVal=fileToUpdate.getExtendedAttribute(TranslationConstants.LOCALE_SENDFORTRANSLATION_EXT_ATTR).value;
			LOGGER.debug("Value fetched from file "+existingExtendedAttrVal);
			if (existingExtendedAttrVal!=null && !StringUtils.isBlank(existingExtendedAttrVal) ) {
				if(existingExtendedAttrVal.contains(",")) {
					//To tackle java.lang.UnsupportedOperationException for List.asArrayList
					existingExtendedAttrList=new ArrayList<String>(Arrays.asList(existingExtendedAttrVal.split(",")));
					LOGGER.debug("existingExtendedAttrList "+existingExtendedAttrList.toString());
					return existingExtendedAttrList;
				}
				else {
					existingExtendedAttrList.add(existingExtendedAttrVal);
					return existingExtendedAttrList;
				}
			} 
		} catch (Exception ex) {
			
			LOGGER.error("Error while fetching extended attribute of the file",ex);
		}
		return new ArrayList<String>();
	}
	
	

}
