package com.deere.livesite.workflow.constants;

public class TranslationConstants {

	public static final String METATAGS = "MetaTags";
	public static final String COMPONENT = "Component";
	public static final String DISPLAY_NAME_ATTR = "DisplayName";
	public static final String SEGMENTS = "Segments";
	public static final String SEGMENTS_TAGS = "Segment";
	public static final String METATAG = "MetaTag";
	public static final String NAME = "name";
	public static final String INDUSTRY_TAGNAME="industry";
	public static final String CONTENT="content";
	public static final String PAGE="page";
	public static final String JSON_EXT="json";
	//public static final String CUSTOM_RETRIEVAL = "/iwadmin/main/deere/syndication/STAGING/configuration/custom-retrieval.properties";
	public static final String LOCALE_SENDFORTRANSLATION_EXT_ATTR="LocaleSendForTranslation";
	public static final String NEXT_LINE_DELIMITER="\n";
	
}
