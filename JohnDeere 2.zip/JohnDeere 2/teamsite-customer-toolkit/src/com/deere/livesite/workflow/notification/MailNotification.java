package com.deere.livesite.workflow.notification;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Element;

import com.deere.livesite.authoring.common.constants.PIMContsants;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.common.xml.ElementableUtils;
import com.interwoven.cssdk.filesys.CSArea;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.livesite.workflow.WorkflowUtils;


public class MailNotification extends BaseMail implements CSURLExternalTask {
	
	private static final String MAIL_SUBJECT_TASK_VARIABLE = "mail_subject";
    private static final String MAIL_SENDER_VARIABLE = "mail_sender";
    private static final String RECIPIENTS_CC = "recipients";
    private static final String MAIL_TEMPLATE_TASK_VARIABLE = "mail_template";
    private static final String MAILCONTENT_XMLTAG = "MailContent";
    private static final String JOB_XMLTAG = "Job";
    private static final String JOBDETAILS_XMLTAG = "JobDetails";
    private static final String JOBID_XMLTAG = "jobid";
    private static final String REQUESTEDBY_XMLTAG = "JobOwner";
    private static final String DATE_XMLTAG = "Date";
    private static final String NOTIFY_REVIEWER = "notify_reviewer";
    private static final String SCHEDULE_TASK = "schedule_task";
    private static final String TIMEZONE = "timezone";  
    private static final String PUBLISH_TYPE = "publishtype";
    private static final String REVIEWER_TASK = "review_task";
    private static final String ASSIGNEDTO_XMLTAG = "reviewer";
    private static final Pattern[] INDEX_PAGE_LINK_PATTERNS = { Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/products(/.*/)index\\.html"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/industries(/.*/)index\\.html"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website(/.*/)index\\.html") };
	private static final Pattern[] NON_INDEX_PAGE_LINK_PATTERNS = { Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/products(/.*)"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website/industries(/.*)"), Pattern.compile("[html|sites]/[^/]+/[^/]+(/[^/]+)/website(/.*)") };

    String reviewer;
    Boolean emailReviewer;
    public static final Logger LOGGER_MAIL = Logger.getLogger(MailNotification.class);
    Properties properties = new Properties();

    @SuppressWarnings("unused")
	@Override
    public void execute(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable hash) throws CSException
    {
        String transitionComment = "";
        String ccRecipients = "";
        
                
        try {
        	readPropertiesFile(task);
        	ccRecipients = task.getVariable(RECIPIENTS_CC);
        	emailReviewer = Boolean.parseBoolean(task.getVariable(NOTIFY_REVIEWER));
        	if(Boolean.TRUE.equals(emailReviewer)) {
        		String reviewTask = task.getVariable(REVIEWER_TASK);
        		CSTask reviewCSTask = getTaskByName(task, reviewTask);
        		if(reviewCSTask != null) {
        		String reviewerEmail = reviewCSTask.getOwner().getEmailAddress();
        		ccRecipients = reviewerEmail;
        		reviewer = reviewCSTask.getOwner().getDisplayName();
        		}
        		
        	}
        	if (ccRecipients == null) {
        		LOGGER_MAIL.debug(">>>ccRecipients Task Variable is null, hence setting to a empty string");
				ccRecipients = "";
			}
        	LOGGER_MAIL.debug("ccRecipients is >>"+ ccRecipients);
            String mailTemplate = task.getVariable(MAIL_TEMPLATE_TASK_VARIABLE);
        	String strTemplate = StringUtils.trim(mailTemplate);
            if (StringUtils.isBlank(strTemplate)) {

                transitionComment = "Required mail variable \"mail_template\" is missing. Mail is not sent.";
            }
            DataSource mailDataSource = null;
        	Element mailContent = null;
            mailContent = createContentXml(task);
        	CSVPath templateVpath = new CSVPath(strTemplate);
            CSSimpleFile xslTemplateFile = (CSSimpleFile)(client.getFile(templateVpath));
            String mailContentXml = serializeDomElementToString(mailContent, WorkFlowConstants.MAIL_ENCODING, true);
            String recipientAddresses = task.getWorkflow().getOwner().getEmailAddress();
            String fromAddress = task.getVariable(MAIL_SENDER_VARIABLE);
        	CSWorkflow job = task.getWorkflow();
        	String timezone = job.getVariable("TimeZones");
        	if (timezone == null) {
        		LOGGER_MAIL.debug(">>>timezone Job Variable is null, hence setting to a empty string");
				timezone = "";
			}
        	

        	String noReplyToAddress = WorkFlowConstants.NO_REPLY_TO_ADDRESS;
        	String mailSubject = task.getVariable(MAIL_SUBJECT_TASK_VARIABLE) + job.getId();
        	LOGGER_MAIL.debug( "noReplyToAddress: " + noReplyToAddress);
        	LOGGER_MAIL.debug( "Calling transformToMailDataSource...." );
            mailDataSource = transformToMailDataSource(mailContentXml, xslTemplateFile);
            LOGGER_MAIL.debug( "Return form  transformToMailDataSource....recived MailDataSource"+ mailDataSource );
            LOGGER_MAIL.debug( "Sending Email....fromAddress "+fromAddress+"  recipientAddresses:"+recipientAddresses+"  mailSubject:"+mailSubject+"  mailDataSource:"+mailDataSource+"  noReplyToAddress:"+noReplyToAddress );
           
            	 if (!"".equalsIgnoreCase(timezone)) {
				
					sendMail(new InternetAddress(fromAddress), recipientAddresses, mailSubject, mailDataSource, noReplyToAddress ,ccRecipients);
				
				 transitionComment = "Job Owner has been Notified";
            	 }
            	 else {
            		 transitionComment = "No need to notify the Job Owner as the workflow is not of type Schedule";
            	 }
            	 
		} catch (UnsupportedEncodingException |TransformerException |MessagingException e) {
			LOGGER_MAIL.error ("Caught Exception in MailNotifction Task: " ,e);
               
		} 
        task.chooseTransition(task.getTransitions()[0], transitionComment);
        
    }

    /**
     * Create the mail content XML which will work with the corresponding XSLT
     * mail template.
     */
    private Element createContentXml(CSExternalTask task) throws CSException {
        CSWorkflow job = task.getWorkflow();

        
        String timezone = job.getVariable("TimeZones");
        Element mailContentRoot = ElementableUtils.newElement(MAILCONTENT_XMLTAG);

        Element jobElement = mailContentRoot.addElement(JOB_XMLTAG);
        Element jobDetails = jobElement.addElement(JOBDETAILS_XMLTAG);
        jobDetails.addElement(JOBID_XMLTAG).setText(String.valueOf(job.getId()));
        jobDetails.addElement(PUBLISH_TYPE).setText(job.getVariable("PublishTime"));
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date currentDate = new Date();
        jobDetails.addElement(DATE_XMLTAG).setText(dateFormat.format(currentDate));
        String targetServer = getTargetServer(task);
		if (targetServer == null) {
			targetServer = "";
		}
		jobDetails.addElement("targetServer").addText(targetServer);
        jobDetails.addElement(REQUESTEDBY_XMLTAG).setText(job.getOwner().getDisplayName());
        if(Boolean.TRUE.equals(emailReviewer)) {
        jobDetails.addElement(ASSIGNEDTO_XMLTAG).setText(reviewer);
        }
        CSAreaRelativePath[] csarp = task.getFiles();
        StringBuilder filePath = new StringBuilder();
        Element attachedFilesElement = jobElement.addElement("AttachedFiles");
        for (CSAreaRelativePath attachedFile: csarp) {
        	filePath.append(targetServer).append("/").append(attachedFile.toString()).append("\n");
        	CSFile csfile = task.getArea().getFile(attachedFile);
            if (csfile != null) {
              
              if (!(WorkFlowConstants.PAGE_EXTENSION.equalsIgnoreCase(attachedFile.getExtension())) && ((CSSimpleFile) csfile).getContentKind() != CSSimpleFile.kDCR) {
					Element fileElement = attachedFilesElement.addElement("File");
					fileElement.addText(updateURL(attachedFile.toString()));
				}
            }
        }
       
		Element currentTaskElement = task.toElement("CurrentTask");
		jobElement.add(currentTaskElement);
        
        if (timezone != null && !timezone.equalsIgnoreCase("")) {

        	
        	LOGGER_MAIL.debug("<<<<<<<<<<<<<<<<timezone  is Valid >>>>>>>>>>>>>>");
            Element timeZones = jobDetails.addElement("scheduledtimezones");
            ZoneId istZoneId = ZoneId.of("Asia/Kolkata");
            ZoneId estZoneId = ZoneId.of("America/New_York");
            ZoneId cstZoneId = ZoneId.of("America/Chicago");
            ZoneId cestZoneId = ZoneId.of("Europe/Berlin");
            ZoneId aestZoneId = ZoneId.of("Australia/Melbourne");
            ZoneId nzdtZoneId = ZoneId.of("Pacific/Auckland");
            ZoneId currentZoneId = istZoneId;

            if (timezone.trim().equalsIgnoreCase("Asia/Kolkata")) {
            	currentZoneId = istZoneId;
            } else if (timezone.trim().equalsIgnoreCase("America/Chicago")) {
            	currentZoneId = cstZoneId;
            } else if (timezone.trim().equalsIgnoreCase("America/New_York")) {
            	currentZoneId = estZoneId;
            } else if (timezone.trim().equalsIgnoreCase("Europe/Berlin")) {
            	currentZoneId = cestZoneId;
            } else if (timezone.trim().equalsIgnoreCase("Australia/Melbourne")){
            	currentZoneId = aestZoneId;
            }else if (timezone.trim().equalsIgnoreCase("Pacific/Auckland")){
            	currentZoneId = nzdtZoneId;
            }else {
            	LOGGER_MAIL.debug("<<<<<<<<<<<<<<<<timezone  is not Valid >>>>>>>>>>>>>>");
            }
            
            LOGGER_MAIL.debug("ZoneId is >>"+currentZoneId.getDisplayName(TextStyle.SHORT, Locale.ENGLISH));
            String dateInString = job.getVariable("DeployDate");
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
            OffsetDateTime date = LocalDateTime.parse(dateInString, dtf).atZone(currentZoneId).toOffsetDateTime();

            String istTime = date.atZoneSameInstant(istZoneId).format(dtf);
            timeZones.addElement(TIMEZONE).setText(istTime + " | Asia/Kolkata");


            String estTime = date.atZoneSameInstant(estZoneId).format(dtf);
            timeZones.addElement(TIMEZONE).setText(estTime + " | America/New_York");


            String cstTime = date.atZoneSameInstant(cstZoneId).format(dtf);
            timeZones.addElement(TIMEZONE).setText(cstTime + " | America/Chicago");


            String cestTime = date.atZoneSameInstant(cestZoneId).format(dtf);
            timeZones.addElement(TIMEZONE).setText(cestTime + " | Europe/Berlin");


            String aestTime = date.atZoneSameInstant(aestZoneId).format(dtf);
            timeZones.addElement(TIMEZONE).setText(aestTime + " | Australia/Melbourne");
            
            String nzTime = date.atZoneSameInstant(nzdtZoneId).format(dtf);
            timeZones.addElement(TIMEZONE).setText(nzTime + " | Pacific/Auckland");
            
            String dummyTask = task.getVariable(SCHEDULE_TASK);
    		CSTask dummyCSTask = getTaskByName(task, dummyTask);
    		if(dummyTask != null && dummyCSTask != null) {
    			
    			SimpleDateFormat dateFt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    			Date date1 = null;
    			
					try {
						date1 = dateFt.parse(estTime);
						LOGGER_MAIL.debug("Date to set in DummyTask is  >>>>>>>>>>>>>>>>>>>>>>> " + date1.toString());
						if(date1 != null) {
						dummyCSTask.setTimeout(date1);
						dummyCSTask.setDescription("The Deployment is Scheduled at "+dateInString+" | "+timezone);
						
						}
					} catch (ParseException e) {
						
						LOGGER_MAIL.error ("Caught Exception in createContentXml in MailNotification Task : " ,e);
					}
					
				
    		}


        } 
        LOGGER_MAIL.debug("XML Source for email is >>>>>>>>>>>>>>>>>>>>>>> " + mailContentRoot.asXML());



        return mailContentRoot;
    }


	protected final String getTargetServer(CSTask task) {
		return properties.getProperty(getServerName(task) + WorkFlowConstants.NODE);
	}
    protected final String getServerName(CSTask task) {
		return WorkflowUtils.findVariable(task, properties.getProperty(WorkFlowConstants.SERVER_NAME));
	}

	private void readPropertiesFile(CSTask task) throws CSException {
		LOGGER_MAIL.debug("Reading Properties File");
		CSArea area = task.getArea();
		CSFile file = area.getFile(new CSAreaRelativePath(PIMContsants.DEFAULT_PROPERTIES_FILE_PATH));
		
		if (file != null && file.getKind() == CSSimpleFile.KIND) {
			try (InputStream input = new BufferedInputStream(((CSSimpleFile) file).getInputStream(true))) {
				properties.load(input);
				LOGGER_MAIL.debug("Successfully loaded properties file");
			} catch (Exception e) {
				LOGGER_MAIL.debug("Entered in Catch Block as there are some issues with loading properties file!!");
				LOGGER_MAIL.error("Unable to read properties file ", e);
			}
		} else {
			LOGGER_MAIL.error("Properties file for area " + area.getVPath().toString() + " does NOT exist");
		}
	}
	/**
	 * This method matches the URL patterns against the attached pages
	 * and updates it to match the page URL pattern used in production and preview servers.
	 * @param pageLink The URL of the page
	 * @return Updated URL 
	 */
	private String updateURL(String pageLink) {
		for (Pattern pattern : INDEX_PAGE_LINK_PATTERNS) {
			Matcher matcher = pattern.matcher(pageLink);
			if (matcher.find()) {
				return matcher.group(1) + matcher.group(2);
			}
		}

		for (Pattern pattern : NON_INDEX_PAGE_LINK_PATTERNS) {
			Matcher matcher = pattern.matcher(pageLink);
			if (matcher.find()) {
				return matcher.group(1) + matcher.group(2);
			}
		}

		if (!(pageLink.startsWith("/"))) {
			pageLink = "/" + pageLink;
		}

		return pageLink;
	}
	private CSTask getTaskByName(CSExternalTask currentTask, String taskName) throws CSAuthorizationException, CSRemoteException, CSObjectNotFoundException, CSExpiredSessionException, CSException {
        CSTask requiredTask = null;
        CSTask[] cstask = currentTask.getWorkflow().getTasks();

        for (CSTask task: cstask) {
            if (taskName.equalsIgnoreCase(task.getName())) {
                requiredTask = task;
                break;
            }
        }
        return requiredTask;
    }

}