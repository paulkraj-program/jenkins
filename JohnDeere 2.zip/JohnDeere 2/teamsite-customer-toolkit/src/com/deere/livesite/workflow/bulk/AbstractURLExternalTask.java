package com.deere.livesite.workflow.bulk;

import java.util.Hashtable;
import org.apache.log4j.Logger;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSTransitionableTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

/**
 * AbstractWorkflowTask is an implementation of CSURLExternalTask that contains
 * some generic error handling code to handle any exceptions that might be
 * thrown when processing a workflow task.  This allows the workflow to enter
 * into a failure state rather than hang when there is a failure during
 * processing.
 * @author Klish Group, Inc. [ND]
 */
public abstract class AbstractURLExternalTask implements CSURLExternalTask {
	protected final transient Logger LOGGER = Logger.getLogger(getClass());
	
	private static final String VAR_SUCCESS_TRANSITION = "SuccessTransition";
	private static final String VAR_FAILURE_TRANSITION = "FailureTransition";
	
	private static final String DEFAULT_SUCCESS = "Success";
	private static final String DEFAULT_FAILURE = "Failure";

	/* (non-Javadoc)
	 * @see com.interwoven.cssdk.workflow.CSURLExternalTask#execute(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSExternalTask, java.util.Hashtable)
	 */
	@Override
	public void execute(CSClient client, CSExternalTask task, @SuppressWarnings("rawtypes") Hashtable parameters) throws CSException {
		try {
			WorkflowServices.setupWorkflowLogging(task);
			
			execute(client, task);
			
			chooseSuccessTransition(task);
		} catch (Throwable t) {
			LOGGER.error("Failed processing workflow task: " + t.getLocalizedMessage(), t);
			chooseFailureTransition(task, t);
		}
	}
	
	/**
	 * Method overridden by child class implementations that contain the bulk of
	 * the workflow task processing code.
	 * @param client The current CSClient instance
	 * @param task The current CSExternalTask instance
	 * @throws CSException
	 */
	protected abstract void execute(CSClient client, CSExternalTask task) throws CSException;
	
	/**
	 * Choose the success transition for the provided transitionable task instance
	 * @param task The CSTransitionableTask instance to transition
	 * @return The newly activated task or null if the provided task is not active
	 * @throws CSException
	 */
	public static CSTask chooseSuccessTransition(CSTransitionableTask task) throws CSException {
		// Pull the success transition from the current task or use the default
		String successTransition = task.getVariable(VAR_SUCCESS_TRANSITION);
		if (successTransition == null || "".equals(successTransition)) {
			successTransition = DEFAULT_SUCCESS;
		}
		
		// Choose the success transition on the workflow; make sure the task is still active
		if (task.isActive()) {
			return task.chooseTransition(successTransition, "Workflow task completed processing successfully");
		}
		
		return null;
	}
	
	/**
	 * Choose the failure transition for the provided transitionable task instance
	 * @param task The CSTransitionableTask instance to transition
	 * @return The newly activated task or null if the provided task is not active
	 * @throws CSException
	 */
	public static CSTask chooseFailureTransition(CSTransitionableTask task, Throwable t) throws CSException {
		// Pull the failure transition from the current task or use the default
		String failureTransition = task.getVariable(VAR_FAILURE_TRANSITION);
		if (failureTransition == null || "".equals(failureTransition)) {
			failureTransition = DEFAULT_FAILURE;
		}
		
		// This should be the only place we can throw an exception in this method
		if (task.isActive()) {
			task.getWorkflow().setVariable("ErrorTaskName", task.getName());
			return task.chooseTransition(failureTransition, "Workflow Task failed: " + t.getLocalizedMessage());
		}
		
		return null;
	}
	
	protected static CSTask chooseTransition(CSTransitionableTask task, String transitionVariableName, String defaultValue) throws CSException {
		// Pull the transition from the current task or use the default
		String transition = task.getVariable(transitionVariableName);
		if (transition == null || "".equals(transition)) {
			transition = defaultValue;
		}
		
		// Choose the success transition on the workflow; make sure the task is still active
		if (task.isActive()) {
			return task.chooseTransition(transition, "Workflow task completed processing successfully");
		}
		
		return null;
	}
	
}
