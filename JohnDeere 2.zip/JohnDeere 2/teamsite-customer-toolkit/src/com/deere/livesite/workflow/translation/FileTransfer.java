package com.deere.livesite.workflow.translation;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * FileTransfer is a class that transfers files using FTP from the local system
 * to the FTP server. Server properties are read in from a properties file and
 * and specify the connection settings that are used to connect and upload
 * files.
 * 
 * @author Klish Group, Inc. [ND]
 */
public class FileTransfer {
	private static final transient Logger LOGGER = Logger.getLogger(FileTransfer.class);
	//private static final org.owasp.esapi.Logger ESAPI_LOGGER = ESAPI.getLogger(FileTransfer.class);

	/**
	 * IFTPProcessor is an interface that defines a method for processing with an
	 * FTPClient instance allowing implementations to access an active FTP server
	 * connection that has already been connected and authenticated.
	 * 
	 * @author Klish Group, Inc. [ND]
	 */
	public interface IFTPProcessor<T> {

		/**
		 * Perform the desired activities with the ChannelSftp instance that is
		 * connected and authenticated to the SFTP server already.
		 * 
		 * @param client
		 *            The current active ChannelSftp instance
		 * @return Flag indicating if the operation completed successfully
		 * @throws IOException
		 */
		public T process(ChannelSftp channelSftp) throws IOException;

	}

	/**
	 * FTPUloadProcessor is an implementation of IFTPProcessor that uploads a given
	 * InputStream to the FTP server as the provided named file on the remote
	 * server.
	 * 
	 * @author Klish Group, Inc. [ND]
	 */
	private class FTPUploadProcessor implements IFTPProcessor<Boolean> {

		private String name;
		private InputStream input;

		/**
		 * Create a new instance of FTPUloadProcessor to upload the provided InputStream
		 * instance as the named file on the remote server.
		 * 
		 * @param name
		 *            The remote name of the file
		 * @param input
		 *            The InputStream instance to upload
		 */
		public FTPUploadProcessor(String name, InputStream input) {
			this.name = name;
			this.input = input;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.deere.livesite.workflow.translation.FileTransfer.IFTPProcessor#process(
		 * org.apache.commons.net.ftp.FTPClient)
		 */
		@Override
		public Boolean process(ChannelSftp channelSftp) throws IOException {
			Boolean isCompleted = false;
			LOGGER.info("Uploading file: " + name);
			// Upload the local file to the remote system
			try {
				channelSftp.put(input, name, new SFTPProgressManager(), ChannelSftp.OVERWRITE);
				isCompleted = true;
				LOGGER.info("Translation Archive SFTP upload successful");
			} catch (Exception e) {
				LOGGER.error("Translation Archive SFTP upload failed" + e);
				throw new IOException();
			} finally {
				try {
					if (channelSftp != null && channelSftp.isConnected() && !channelSftp.isClosed()) {
						channelSftp.disconnect();
						LOGGER.info(
								"ChanneSFTP is close for the com.deere.livesite.workflow.translation.FileTransfer.FTPUploadProcessor.process(ChannelSftp)");
					}
				} catch (Exception e) {
					channelSftp = null;
					LOGGER.error("Exception during closing connection" + e);
					// throw new IOException();
				}
			}
			return isCompleted;
		}
	}

	/**
	 * FTP Protocol enumeration
	 * 
	 * @author Klish Group, Inc. [ND]
	 */
	public enum Protocol {
		/** Standard FTP protocol */
		FTP,
		/** FTP over HTTP proxy */
		HTTP_PROXY,
		/** SFTP protocol or FTP over SSH */
		sftp;
	}

	

	private static final String PROP_PROTOCOL = "ftp.protocol";
	private static final String PROP_HOSTNAME = "ftp.hostname";
	private static final String PROP_PORT = "ftp.port";
	private static final String PROP_USERNAME = "ftp.username";
	private static final String PROP_TRUST_MANAGER = "ftp.trust.manager";
	private static final String PROP_RETRY_COUNT = "ftp.retry.count";
	private static final String PROP_PHRASE = "ftp.propphrase";
	private static final String INPUT_PATH_PREFIX = "ftp.input.path";
	private static final String OUTPUT_PATH = "ftp.output.path";

	private String hostname;
	private int port;
	private String username;
	
	public static String inputPath;
	public static String outputPath;

	private Protocol protocol;
	private String identityKeyPath;
	private int MAX_TRIES;
	Properties properties = new Properties();

	/**
	 * Create a new FileTransfer instance using the properties from the specified
	 * resource to connect to the server.
	 * 
	 * @param resourceId
	 *            The resource properties file from which to load the FTP settings
	 */
	public FileTransfer(String resourceId) {
		LOGGER.info("Loading properties: " + resourceId);
		
		try(InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceId))
		{
	
			properties.load(input);
		hostname = properties.getProperty(PROP_HOSTNAME);
		username = properties.getProperty(PROP_USERNAME);
		protocol = Protocol.valueOf(properties.getProperty(PROP_PROTOCOL));
		port = Integer.parseInt(properties.getProperty(PROP_PORT));
		identityKeyPath = properties.getProperty(PROP_TRUST_MANAGER);
		MAX_TRIES = Integer.valueOf(properties.getProperty(PROP_RETRY_COUNT));
		inputPath=properties.getProperty(INPUT_PATH_PREFIX);
		outputPath=properties.getProperty(OUTPUT_PATH);
		 if(LOGGER.isDebugEnabled()) {
			 LOGGER.debug("hostname: " + hostname + " username: " + username + " protocol: " + protocol + " port: " + port
				+ " identityKeyPath: " + identityKeyPath );
		 }
		}
		 catch (IOException ioe) {
			 LOGGER.error("Error while loading properties file");
			}

		}

	/**
	 * Transfer the provided InputStream to the server with the specified name
	 * 
	 * @param name
	 *            The file to write to on the remote (it need not exist)
	 * @param input
	 *            The InputStream of the content to write to the remote
	 * @return Flag indicating successful completion status
	 * @throws IOException
	 */
	public boolean transfer(String name, InputStream input) throws IOException {
		return process(new FTPUploadProcessor(name, input));
	}

	/**
	 * Perform the FTP operations as defined by the provided IFTPProcessor instance
	 * after connecting and authenticating with the FTP server.
	 * 
	 * @param processor
	 *            The IFTPProcessor instance
	 * @return Flag indicating successful completion status
	 * @throws IOException
	 */
	public <T> T process(IFTPProcessor<T> processor) throws IOException {
		
		Session session = null;
		ChannelSftp channelSftp = null;

		switch (protocol) {
		default:

		case sftp:
			LOGGER.info("Initializing SFTP client");
			session = createSession();
			break;
		}
		
		try {
			if(session != null) {
			if (session.isConnected()) {

				for (int retrySFTPCnt = 0; retrySFTPCnt < MAX_TRIES; retrySFTPCnt++) {
					try {
						if(session != null) {
							channelSftp = (ChannelSftp) session.openChannel(Protocol.sftp.name());
	
							LOGGER.info("is SFTP Channel Connected ? : " + channelSftp.isConnected());
								
								channelSftp.connect();
							LOGGER.info("is SFTP Channel Connected ? : " + channelSftp.isConnected());
	
							break;
						}
					} catch (Exception ex) {

						if (retrySFTPCnt == MAX_TRIES - 1) {

							LOGGER.info("Unable to conenct session after " + MAX_TRIES + " attempt");

							throw ex;
						}
						
						LOGGER.info("Exception occured while connecting Channel Sftp");
						
						channelSftpDisconnect(channelSftp);

						sessionDisconnect(session);
						
						LOGGER.info("Reconnecting " + (retrySFTPCnt + 1) + " Times");
						
						TimeUnit.SECONDS.sleep(10);
						
						session = createSession();
						
							continue;
						
						
					}
				}
			}
			}
			return processor.process(channelSftp);
			
		} catch (Exception e) {
			LOGGER.error(e);
			throw new IOException();
		} finally {
			try {
				channelSftpDisconnect(channelSftp);
				sessionDisconnect(session);
			} catch (Exception e) {
				LOGGER.error(e);
			}
		}
		
		
	}

	private void channelSftpDisconnect(ChannelSftp channelSftp) {
		if (channelSftp != null && channelSftp.isConnected() && !channelSftp.isClosed()) {
			try {
				channelSftp.exit();
				LOGGER.info("channelSftp is Clsoed");
			} catch (Exception e) {
				LOGGER.error("Exception during closing channelSftp" + e);
			}
		}
	}

	private void sessionDisconnect(Session session) {
		if (session != null && session.isConnected()) {
			try {
				session.disconnect();
				LOGGER.info("session is Disconnected");
			} catch (Exception e) {
				LOGGER.error("Exception during closing channel" + e);
			}
		}
	}

	private Session createSession() throws IOException {
		
		Session session = null;
		JSch jSch = new JSch();
	 Pattern whitelist = Pattern.compile("(.*/*.ppk)");
	
	try {
			if (null != identityKeyPath && !identityKeyPath.isEmpty() && whitelist.matcher(identityKeyPath).matches())
			{
			
				jSch.addIdentity(new File(identityKeyPath).getAbsolutePath(), properties.getProperty(PROP_PHRASE));
				session = jSch.getSession(username, hostname, port);
				
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				session.setConfig(config);
			}
			if(session != null)
			{
				for (int retryCount = 0; retryCount < MAX_TRIES; retryCount++) {
					try {
						session.connect();
						LOGGER.info("Is session connected " + session.isConnected());
						break;
					}catch (NullPointerException | JSchException ex) {
						if (retryCount == MAX_TRIES - 1) {
							LOGGER.info("Unable to conenct session after " + MAX_TRIES + " attempt");
							throw ex;
						}
						LOGGER.info("Reconnecting " + (retryCount + 1) + " Times");
						TimeUnit.SECONDS.sleep(10);
						continue;
					}
				}
				LOGGER.info("Is SFTP session connected? : " + session.isConnected());
			}
		}catch (Exception e) {
			LOGGER.error("Exeception while creating SFTP session" + e);
			throw new IOException();
		}
		return session;
	}
	
}