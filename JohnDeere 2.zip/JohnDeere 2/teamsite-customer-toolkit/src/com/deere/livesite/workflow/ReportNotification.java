package com.deere.livesite.workflow;

import java.io.File;
import java.util.Date;
import java.util.Hashtable;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.serverutils100.IWConfig;

import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class ReportNotification implements CSURLExternalTask  {

	private static final  Logger LOGGER = Logger.getLogger(ReportNotification.class);
	String messageSet =new String();
	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		// TODO Auto-generated method stub
		
		  String from = task.getVariable("from");
          String to = task.getWorkflow().getOwner().getEmailAddress().toString();
          LOGGER.debug("ReportNotification :: Sending report to >> "+to);
          //task.getWorkflow().setVariable("subject", task.getVariable("subject"));
		  String subject = task.getWorkflow().getVariable("subject");
				  if("".equals(subject) || subject== null) {
					  subject=task.getVariable("subject");
				  }
		 
		  String ReportStatus = task.getWorkflow().getVariable("ReportStatus");
		  
		  LOGGER.debug("ReportNotification :: ReportStatus is >> "+ReportStatus);

		  String headerMessage="<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:\"Calibri\",sans-serif;'><span style=\"font-family: Calibri, sans-serif; font-size: 14px;\">Hi "+task.getWorkflow().getOwner().getDisplayName().toString()+",</span></p>\r\n" + 
		  		"<p><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\"><br></span></span></p>";
		  String footerMessage="<p><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\"><br></span></span></p>\r\n" + 
		  		"<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:\"Calibri\",sans-serif;'><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">Thanks &amp; Regards,</span></span></p>\r\n" + 
		  		"<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:\"Calibri\",sans-serif;'><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">Deere.com Tech Team</span></span></p>\r\n" + 
		  		"<p><br></p>";
		 
		  Properties properties = System.getProperties();
		 
		  properties.put("mail.smtp.host",task.getVariable("mail_server"));
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  
		  try
		  {
		      // create a message
		      MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress[] address = {new InternetAddress(to)};
		      msg.setRecipients(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		 
		      // create and fill the first message part
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();
		     
		      String msgText1 = new String();
		      if(ReportStatus.equalsIgnoreCase("yes")) {
		    	  messageSet="<p><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">The "+subject+" is attached with this email, Additional details are below.</span></span></p>\r\n" + 
		    	  		"<p><span style=\"font-family: Calibri, sans-serif;\"><br></span></p>\r\n" + 
		    	  		"<table style=\"width: 100%;\">\r\n" + 
		    	  		"    <tbody>\r\n" + 
		    	  		"        <tr>\r\n" + 
		    	  		"            <td style=\"width: 22.4181%;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Job Owner </strong></span></span></td>\r\n" + 
		    	  		"            <td style=\"width: 77.456%;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">&nbsp;"+task.getWorkflow().getOwner().getName()+"</span></span></td>\r\n" + 
		    	  		"        </tr>\r\n" + 
		    	  		"        <tr>\r\n" + 
		    	  		"            <td style=\"width: 22.4181%;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Workarea Path</strong></span></span></td>\r\n" + 
		    	  		"            <td style=\"width: 77.456%;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">&nbsp;"+task.getArea().getVPath().toString()+"</span></span></td>\r\n" + 
		    	  		"        </tr>\r\n" + 
		    	  		"        <tr>\r\n" + 
		    	  		"            <td style=\"width: 22.4181%;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>Date</strong></span></span></td>\r\n" + 
		    	  		"            <td style=\"width: 77.456%;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">"+task.getWorkflow().getActivationDate().toString()+"<br></span></span></td>\r\n" + 
		    	  		"        </tr>\r\n" + 
		    	  		"    </tbody>\r\n" + 
		    	  		"</table>";
		    	  File filename = new File(task.getWorkflow().getVariable("ReportPath"));
				  MimeBodyPart mbp2 = new MimeBodyPart();
			      FileDataSource fds = new FileDataSource(filename);
			      mbp2.setDataHandler(new DataHandler(fds));
			      mbp2.setFileName(fds.getName());
			      mp.addBodyPart(mbp2);
		      }
		      else { 
		    	  messageSet="<p><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 14px;\">There is no assets or files deleted in the workarea ,to show in the report .</span></span></p>";
		    	  }
		      
		      String bodyMessage = headerMessage + messageSet + footerMessage;
			  
			  mbp1.setContent(bodyMessage,"text/html");
			  mp.addBodyPart(mbp1);

		      // add the Multipart to the message
		      msg.setContent(mp);
		 
		      // set the Date: header
		      //msg.setSentDate(new Date());
		       
		      // send the message
		      LOGGER.debug("ReportNotification :: Sending Message .......");
		      Transport.send(msg);
		       
		  } 
		  catch (MessagingException mex) 
		  {
		      mex.printStackTrace();
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    	  LOGGER.error ("Caught exception in reportNotification Task : " + ex + ex.getMessage ());
		      }
		  }

		
		task.chooseTransition(task.getTransitions()[0], "Email Sent");
	}
	
}






