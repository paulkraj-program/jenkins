package com.deere.livesite.workflow.syndication;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import com.deere.livesite.authoring.utils.DocumentUtils;
import com.deere.livesite.dws.parser.PageParser;
import com.deere.livesite.dws.taxonomy.constant.TaxonomyConstants;
import com.deere.livesite.workflow.AbstractURLExternalTask;
import com.deere.livesite.workflow.common.Utlis;
import com.deere.livesite.workflow.translation.AcrossRetrievalTask;
import com.deere.livesite.workflow.translation.FileTransfer;
import com.deere.livesite.workflow.translation.TranslationJob;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.livesite.file.impl.CsFileDal;
import com.interwoven.ui.teamsite.filesys.blc.BranchConfigException;
import com.interwoven.ui.teamsite.g11n.blc.BranchConfigProviderIfc;
import com.deere.livesite.workflow.constants.TranslationConstants;

/**
 * AbstractSendForTranslationTask is an CSURLExternalTask implementation that is
 * responsible for packaging and deploying a project to the Across FTP server.
 * This external builds the control.xml file based on the selected user settings
 * and then builds the archive containing the content. Once the archive is built
 * it is then uploaded to the Across FTP server.
 * 
 * @author Klish Group, Inc. [ND]
 */
public abstract class AbstractSendForTranslationTask extends AbstractURLExternalTask {

	/* Location of the Across FTP server connection properties */
	private static final String RESOURCE_ID = "com/deere/syndication/across.properties";



	private static final String PATH_SUFFIX = "deere/";

	private static final String ENTRY_PREFIX = "input/SourceFiles/";
	private static final String ENTRY_CONTROL_FILE = "control.xml";

	private static final String DATE_FILENAME = "yyyyMMdd_HH.mm.ss.SSS";

	private static final String VAR_NO_TRANSLATION_TRANSITION = "NoTranslationTransition";

	private static final String DEFAULT_NO_TRANSLATION = "Translation Not Needed";
	private static final String DEFAULT_INDUSTRY_MAPPING = "/iwadmin/main/deere/syndication/STAGING/templatedata/CustomData/NameValueList/data/industry_mapping.xml";

	private String industryAbbreviated = "";
	


	private Utlis utils = new Utlis();

	/**
	 * This method returns the identifier for the owner of the translation
	 * workflow.
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @return The identifier for the owner of the translation workflow.
	 * @throws CSException
	 */
	protected String getOwnerId(CSClient client, CSTask task) throws CSException {
		String ownerId = task.getWorkflow().getOwner().getName();
		LOGGER.debug("Workflow Owner ID: " + ownerId);
		return ownerId;
	}

	/**
	 * This method controls if the project is sent for translation. If this
	 * method returns null then the entire project is not sent for translation,
	 * and this task proceeds as if successful. The default implementation
	 * always returns true.
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param source
	 *            The syndication source
	 * @param targets
	 *            The syndication targets
	 * @return Flag indicating if the project should be sent for translation
	 * @throws CSException
	 */
	protected boolean sendForTranslation(CSClient client, CSTask task, SyndicationTarget source,
			Set<SyndicationTarget> targets) throws CSException {
		return true;
	}

	/**
	 * Get the source locale for the translation task. This involves looking up
	 * the current branches configuration in the syndication configuration and
	 * returning that locale as the current source locale for the translation
	 * project.
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param configuration
	 *            The Set&lt;SyndicationTarget&gt; of configured locales
	 * @return The source locale for the current translation request
	 * @throws CSException
	 */
	protected SyndicationTarget getSourceLocale(CSClient client, CSTask task, Set<SyndicationTarget> configuration)
			throws CSException {
		return getSourceLocaleFromTask(client, task, configuration);
	}

	/**
	 * Get the source locale for the translation task. This involves looking up
	 * the current branches configuration in the syndication configuration and
	 * returning that locale as the current source locale for the translation
	 * project.
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param configuration
	 *            The Set&lt;SyndicationTarget&gt; of configured locales
	 * @return The source locale for the current translation request
	 * @throws CSException
	 */
	public static SyndicationTarget getSourceLocaleFromTask(CSClient client, CSTask task,
			Set<SyndicationTarget> configuration) throws CSException {
		BranchConfigProviderIfc provider = com.interwoven.ui.teamsite.g11n.blc.BranchConfigProviderFactory
				.getProvider();
		try {
			Set<Locale> locales = provider.getAllowedLocales(client, task.getArea().getBranch());
			Locale masterLocale = provider.getMasterLocale(client, task.getArea().getBranch());
		

			for (Locale locale : locales) {
				if (masterLocale.equals(locale)) {
					continue;
				}

				// Filter the configuration to only the source syndication
				// target (branch)
				SyndicationTarget source = SyndicationTarget.filterByLocale(configuration, locale.toString());
				if (source == null) {
					String localeStr = locale.toString().replace('_', '-');
					source = SyndicationTarget.filterByLocale(configuration, localeStr);
				}
				
				return source;
			}

			// Filter the configuration to only the source syndication target
			// (branch)
			SyndicationTarget source = SyndicationTarget.filterByBranch(configuration,
					task.getArea().getBranch().getVPath().getPathNoServer().toString());
			

			return source;
		} catch (BranchConfigException bce) {
			throw new CSException(bce);
		}
	}

	/**
	 * Return a string with the translation archive filename prefix. This is
	 * typically something like 'Deere.com_TeamSite_' for standard translations.
	 * 
	 * @return The archive filename prefix
	 */
	protected abstract String getArchiveFilenamePrefix();

	/**
	 * Return an InputStream instance for the content from the provided
	 * CSSimpleFile instance. This implementation of this method returns the
	 * InputStream of the file from TeamSite.
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param file
	 *            The CSSimpleFile instance to process
	 * @return The InputStream with the file content to add to the translation
	 *         archive
	 * @throws CSException
	 */
	protected InputStream preprocessFileForArchive(CSClient client, CSTask task, CSSimpleFile file) throws CSException {
		return file.getInputStream(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.deere.livesite.workflow.AbstractURLExternalTask#execute(com.
	 * interwoven.cssdk.common.CSClient,
	 * com.interwoven.cssdk.workflow.CSExternalTask)
	 */
	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {
		// Get the set of target branches from the workflow task (from the
		// variable on the task)
		Set<String> targetBranches = SyndicationTask.getTargetBranches(task);

		// Load the syndication configuration and filter to the desired items
		Set<SyndicationTarget> configuration = SyndicationUtilities.loadSyndicationConfiguration(client);

		SyndicationTarget source = getSourceLocale(client, task, configuration);
		if (source == null) {
			throw new CSException(-1, "Source locale not specified or unavailable");
		}

		// Filter the configuration to only the selected target syndication
		// targets (branches)
		Set<SyndicationTarget> targets = SyndicationTarget.filterByBranches(configuration, targetBranches);
		LOGGER.debug("SyndicaitonTarget Targets: " + targets);

		if (!sendForTranslation(client, task, source, targets)) {
			LOGGER.info("Not sending content for translation");

			chooseTransition(task, VAR_NO_TRANSLATION_TRANSITION, DEFAULT_NO_TRANSLATION);

			return;
		}

		// Create the Across control.xml file for the translation project
		CSFile[] files = task.getArea().getFiles(task.getFiles());
		String metaTag = getIndustryMetaData(client, task, files);
		TranslationJob translationJob = new TranslationJob(client, task, getOwnerId(client, task), source, targets,
				metaTag);
		if (translationJob.getJobContact() == null || "".equals(translationJob.getJobContact())) {
			throw new CSException(-1,
					"Missing Job Contact e-mail address; please configure the workflow with this value");
		}
		
		for (CSFile curr : files) {
			LOGGER.debug("Processing file : " + curr.getVPath().getAreaRelativePath().toString());
			// Update TranslationSend extended attribute with the target locale
			if (CSSimpleFile.KIND == curr.getKind()
					&& curr.getVPath().getAreaRelativePath().toString().endsWith(".json")) {
				CSSimpleFile fileToUpdate = (CSSimpleFile) curr;
				fileToUpdate.getExtendedAttribute(TranslationConstants.LOCALE_SENDFORTRANSLATION_EXT_ATTR);
				ArrayList<String> extendedAttributes=new ArrayList<String>();
				extendedAttributes=Utlis.getExistingExtendedAttribute(fileToUpdate);
				if(!extendedAttributes.isEmpty()) {
					for(SyndicationTarget target:targets) {
						if(!isTargetPresent(target.getLocale(),extendedAttributes)) {
							LOGGER.debug("Adding target locale with existing locales : " + target.getLocale());
							extendedAttributes.add(target.getLocale());
						}
					
					}
				}
				else {
					for(SyndicationTarget target:targets) {
						LOGGER.debug("Adding target locale : " + target.getLocale());
						extendedAttributes.add(target.getLocale());
						
					}
				}
				
				fileToUpdate.setExtendedAttributes(new CSExtendedAttribute[] {
						new CSExtendedAttribute(TranslationConstants.LOCALE_SENDFORTRANSLATION_EXT_ATTR, getTargetLocales(extendedAttributes)) });
			}
		}
		Element controlRoot = translationJob.toElement();
		Document controlFile = DocumentHelper.createDocument(controlRoot);

		File archiveFile = createTranslationArchive(client, task, controlFile);

		LOGGER.debug("Control File: " + controlFile.asXML());

		FileTransfer transfer = new FileTransfer(RESOURCE_ID);

		try (InputStream input = new FileInputStream(archiveFile)) {
			LOGGER.debug("InputPath Prefix value"+FileTransfer.inputPath);
			String name = FileTransfer.inputPath + archiveFile.getName();
			transfer.transfer(name, input);
		} catch (IOException ioe) {
			throw new CSException(ioe);
		}

		archiveFile.delete();
	}

	private String getTargetLocales(List<String> extendedAttributes) {
		StringBuilder targetLocalBuilder=new StringBuilder();
		for(String attr :extendedAttributes) {
		targetLocalBuilder.append(attr).append(",");
		}
		String targetLocales=targetLocalBuilder.toString();
		if(targetLocales.length()>0) {
			LOGGER.debug("Setting LocaleSendForTranslation Attribute :"+targetLocales.substring(0, targetLocales.length()-1));
			return targetLocales.substring(0, targetLocales.length()-1);
		}
		return null;
	}

	/**
	 * Method to check if target is present extended attribute
	 * @param target
	 * @param extendedAttributes
	 * @return
	 */
	private boolean isTargetPresent(String target, List<String> extendedAttributes) {
		for (String attr : extendedAttributes) {
			if (target.equalsIgnoreCase(attr)) {
				LOGGER.debug("Target Locale is present in extended attribute");
				return true;
			}
		}
		return false;
	}

	

	private File createTranslationArchive(CSClient client, CSTask task, Document controlFile) throws CSException {

		
		CSFile[] files = task.getArea().getFiles(task.getFiles());
		
		String path = System.getProperty("java.io.tmpdir") + "/" + PATH_SUFFIX;

		String zipFilename = archiveFilename(task, industryAbbreviated);
		LOGGER.debug("Final Zip path" + zipFilename);
		String archive = path + zipFilename + ".zip";
		LOGGER.debug("Archive Path: " + archive);
		File file = new File(archive);

		try {
			if (!file.exists()) {
				file.getParentFile().mkdirs();
				file.createNewFile();
			}
		} catch (IOException ioe) {
			throw new CSException(ioe);
		}

		try (ZipOutputStream output = new ZipOutputStream(new FileOutputStream(file))) {
			
			LOGGER.debug("ARCHIVE ENTRY: " + ENTRY_CONTROL_FILE);
			output.putNextEntry(new ZipEntry(ENTRY_CONTROL_FILE));

			Writer stream = new StringWriter();
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("UTF-8");
			XMLWriter writer = new XMLWriter(stream, format);
			writer.write(controlFile);
			writer.close();

			InputStream input = new ByteArrayInputStream(stream.toString().getBytes("UTF-8"));

			streamToArchive(output, input);

			output.closeEntry();

			// Write the attached files into the archive

			for (CSFile curr : files) {
				if (CSSimpleFile.KIND != curr.getKind()) {
					LOGGER.info("SKIPPING: " + curr.getVPath().getAreaRelativePath()
							+ "; file is not of kind CSSimpleFile");
					continue;
				}

				String filename = curr.getVPath().getAreaRelativePath().toString();
				
				String entryName = ENTRY_PREFIX + filename;
				LOGGER.debug("ARCHIVE ENTRY: " + entryName);
				ZipEntry entry = new ZipEntry(entryName);
				output.putNextEntry(entry);

				streamToArchive(output, preprocessFileForArchive(client, task, (CSSimpleFile) curr));

				output.closeEntry();
			}
		} catch (IOException ioe) {
			throw new CSException(ioe);
		}

		return file;
	}

	private String archiveFilename(CSTask task, String industryAbbreviated) throws CSException {
		String zipFilename;

		zipFilename = getArchiveFilenamePrefix() + AcrossRetrievalTask.buildArchiveFilenameEnvironment()
				+ (industryAbbreviated != null && !"".equals(industryAbbreviated) ? industryAbbreviated + "_" : "")
				+ task.getWorkflowId() + "_" + new SimpleDateFormat(DATE_FILENAME).format(new Date());

		return zipFilename;
	}
	
	

	private void streamToArchive(ZipOutputStream output, InputStream stream) throws IOException {
		try (InputStream input = new BufferedInputStream(stream)) {
			byte[] buffer = new byte[4096];
			int count = 0;
			while ((count = input.read(buffer)) > 0) {
				output.write(buffer, 0, count);
			}
		}
	}

	/**
	 * Generic method to retrieve Industry metatag
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param file
	 *            CSFile object (Sitepublisher page files)
	 * @return String Tag name
	 * @throws CSException
	 */

	private String getIndustryMetaData(CSClient client, CSTask task, CSFile[] files) throws CSException {
		StringBuilder  finalIndustryTagValue = new StringBuilder();
		String industryShortName = "";
		String[] industryShortNameArray = null;
		for (CSFile csFile : files) {
			LOGGER.debug("Start processing for : " + csFile.getVPath().getName());
			String industryTagValue = "";
			if ((null != csFile.getVPath().getExtension())
					&& (csFile.getVPath().getExtension().equalsIgnoreCase(TranslationConstants.PAGE))) {
				industryTagValue = getMetaTagFromPage(csFile, client, task, TranslationConstants.INDUSTRY_TAGNAME);
				LOGGER.debug("Industry Tag value " + industryTagValue);
			}
			if (industryTagValue != null && !"".equals(industryTagValue)) {
				finalIndustryTagValue.append(industryTagValue).append(",");
				LOGGER.debug("Final Industry Tag value " + finalIndustryTagValue);
			}
		}
			
			LOGGER.debug("Industry Tag Value fetched from pages: " + finalIndustryTagValue.toString());
			if (finalIndustryTagValue.toString() != null && !"".equals(finalIndustryTagValue.toString())) {
				industryShortNameArray = finalIndustryTagValue.toString().split(",");
				LOGGER.debug("industryShortNameArray : " + industryShortNameArray.length);
				CSFile file = client.getFile(new CSVPath(DEFAULT_INDUSTRY_MAPPING));
				Map<String, String> industryMappingMap = new HashMap<String, String>();
				industryMappingMap = utils.generateURLsMap(file);
				LOGGER.debug("industryMappingMap : " + industryMappingMap.toString());
				if (industryMappingMap.size() > 0 && industryShortNameArray.length > 0) {
					for (String industryShortForm : industryShortNameArray) {
						industryShortName = industryMappingMap.get(industryShortForm);
						if (industryShortName != null && !"".equals(industryShortName)) {
							LOGGER.debug("inside industryAbbreviated check");
							industryAbbreviated += industryShortName + "-";

						}
					}
				}
				// Removing Trailing "-" from the generated industryAbbreviated
				// String
				industryAbbreviated = (industryAbbreviated != null && !"".equals(industryAbbreviated)
						? industryAbbreviated.substring(0, industryAbbreviated.length() - 1) : "");
			}
			LOGGER.debug("industryAbbreviated Form " + industryAbbreviated);
	
		

		return industryAbbreviated;

	}

	/**
	 * Generic method to retrieve metatag by parsing a sitepublisher page
	 * 
	 * @param client
	 *            The current CSClient instance
	 * @param task
	 *            The current CSTask instance
	 * @param file
	 *            CSFile object (Sitepublisher page file)
	 * @return String Tag name
	 * @throws CSException
	 */

	private String getMetaTagFromPage(CSFile csFile, CSClient client, CSTask task, String tagName) {
		String metaTagValue = null;
		try {
			Document document = new DocumentUtils(
					new CsFileDal(((CSWorkarea) task.getArea()).getVPath().toString(), client))
							.retrieveDocument(csFile.getVPath().getAreaRelativePath().toString());
			@SuppressWarnings("unchecked")
			List<Node> nodes = document.selectNodes("/" + document.getRootElement().getName() + "//*");
			for (Node node : nodes) {
				if (node.getName() == TranslationConstants.METATAGS) {
					@SuppressWarnings("unchecked")
					List<Node> metaTags = node.selectNodes(TranslationConstants.METATAG);
					for (Node metaTag : metaTags) {
						Element metaTagName = (Element) metaTag.selectSingleNode(TranslationConstants.NAME);
						if (metaTagName.getText() != null && metaTagName.getText().equalsIgnoreCase(tagName)) {
							Element metaTagContent = (Element) metaTag.selectSingleNode(TranslationConstants.CONTENT);
							metaTagValue = metaTagContent.getText();
							LOGGER.debug("Metatag value retrieved " + metaTagValue);
						}

					}

				}

			}
		} catch (Exception e) {
			LOGGER.error("Exception occured in the method getMetaTagFromPage for AbstractSendForTranslationTask",e);
			LOGGER.debug("Error during fetching MetaTag from attached page" + csFile.getVPath().toString());
		}
		return metaTagValue;
	}

}
