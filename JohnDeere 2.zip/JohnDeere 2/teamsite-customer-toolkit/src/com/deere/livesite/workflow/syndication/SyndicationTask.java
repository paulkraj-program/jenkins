package com.deere.livesite.workflow.syndication;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import com.deere.livesite.workflow.AbstractURLExternalTask;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * SyndicationTask is an CSURLExtenralTask implementation that syndicates
 * content from one branch to another branch.
 * @author Klish Group, Inc. [ND]
 */
public class SyndicationTask extends AbstractURLExternalTask {
	
	private static final String VAR_SYNDICATION_MODE = "SyndicationMode";
	private static final String VAR_TARGET_BRANCHES = "TargetBranches";
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.AbstractURLExternalTask#execute(com.interwoven.cssdk.common.CSClient, com.interwoven.cssdk.workflow.CSExternalTask)
	 */
	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {
		String modeString = task.getVariable(VAR_SYNDICATION_MODE);
		LOGGER.debug("Syndication Mode Variable: " + modeString);
		SyndicationMode mode = SyndicationMode.OVERWRITE_NONE;
		if (modeString != null && !"".equals(modeString)) {
			try {
				mode = SyndicationMode.valueOf(modeString);
			} catch (IllegalArgumentException iae) {
				// Ignore this exception and use the default value
				LOGGER.warn("Invalid syndicatoin mode: " + modeString);
			}
		}
		LOGGER.info("Syndication Mode: " + mode);
		
		Syndicator syndicator = mode.getSyndicator();
		
		CSFile[] attached = task.getArea().getFiles(task.getFiles());
		List<CSSimpleFile> files = new ArrayList<>(attached.length);
		for (CSFile file : attached) {
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				files.add((CSSimpleFile) file);
			}
		}
		
		// Get the set of target branches from the workflow task (from the variable on the task)
		Set<String> targetBranches = getTargetBranches(task);
		
		// Load the syndication configuration and filter to the desired items
		Set<SyndicationTarget> configuration = SyndicationUtilities.loadSyndicationConfiguration(client);
		
		// Filter the configuration to only the source syndication target (branch)
		SyndicationTarget source = SyndicationTarget.filterByBranch(configuration, task.getArea().getBranch().getVPath().getPathNoServer().toString());
		LOGGER.debug("SyndicationTarget Source: " + source);
		
		// Filter the configuration to only the selected target syndication targets (branches)
		Set<SyndicationTarget> targets = SyndicationTarget.filterByBranches(configuration, targetBranches);
		LOGGER.debug("SyndicaitonTarget Targets: " + targets);
		
		String donotSynd = new String();
		LOGGER.debug("SyndicaitonTarget Targets: " + targets);
		String[] attributesArray = task.getWorkflow().getVariable("Attributes").split(",");
		LOGGER.debug("attributesArray size is "+attributesArray.length+"attributesArray>>>>>>>>>>>>>>>"+Arrays.toString(attributesArray));
		if(task.getWorkflow().getVariable("PageAttributes").isEmpty() || task.getWorkflow().getVariable("PageAttributes").equalsIgnoreCase("") ) {
			donotSynd=task.getWorkflow().getVariable("Attributes");
		}else {
			String pageattr = task.getWorkflow().getVariable("PageAttributes");
			pageattr = pageattr.replaceAll("\\s","");
			String[] pageAttributes = pageattr.split(",");
			HashSet<String> hashAttributesArray = new HashSet<String>(Arrays.asList(attributesArray));
			hashAttributesArray.removeAll(Arrays.asList(pageAttributes));
			donotSynd = String.join(",", hashAttributesArray);
		}
		LOGGER.debug("Do not Syndicate these parameters in Target Page =>: " + donotSynd);
		SyndicationResults results = syndicator.process(client, files, source, targets,donotSynd);
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Syndication Results:");
			for (CSFile file : results.getSyndicated()) {
				LOGGER.debug("Result SYNDICATED: " + file.getVPath());
			}
			for (CSFile file : results.getExisting()) {
				LOGGER.debug("Result EXISTING: " + file.getVPath());
			}
			for (CSFile file : results.getModified()) {
				LOGGER.debug("Result MODIFIED: " + file.getVPath());
			}
		}
	}
	
	/**
	 * Get the target branches on the specified task or workflow.
	 * @param task The CSTask instance to check for the variable
	 * @return A Set of the target branches set on the workflow task
	 * @throws CSException
	 */
	public static Set<String> getTargetBranches(CSTask task) throws CSException {
		final Logger logger = Logger.getLogger(SyndicationTask.class);
		
		String targetBranchesString = task.getVariable(VAR_TARGET_BRANCHES);
		if (targetBranchesString == null || "".equals(targetBranchesString)) {
			logger.debug("Target Branches Var not set on task checking workflow");
			targetBranchesString = task.getWorkflow().getVariable(VAR_TARGET_BRANCHES);
		}
		
		logger.debug("Target Branches Var: " + targetBranchesString);
		
		if (targetBranchesString != null && !"".equals(targetBranchesString)) {
			String[] branches = targetBranchesString.split(",");
			Set<String> targetBranches = new HashSet<>(Arrays.asList(branches));
			
			logger.info("Target Branches: " + targetBranches);
			return targetBranches;
		}
		
		logger.warn("Target Branches variable was not set or empty");
		return Collections.emptySet();
	}
	
	/**
	 * Get the list of files attached to the workflow.
	 * @param task The CSTask instance to check for the variable
	 * @return A List of the files attached to the workflow
	 * @throws CSException
	 */
	
	public static List<CSSimpleFile> getAttachedFiles(CSTask task) throws CSException {

		CSFile[] attachedFiles = task.getArea().getFiles(task.getFiles());
		List<CSSimpleFile> files = new ArrayList<>();
		for (CSFile file : attachedFiles) {
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				files.add((CSSimpleFile) file);
			}
		}
		
	return files;	

	}
	
}
