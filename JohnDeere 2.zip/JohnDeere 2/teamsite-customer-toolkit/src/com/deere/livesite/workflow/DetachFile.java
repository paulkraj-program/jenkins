package com.deere.livesite.workflow;

public class DetachFile {
	private String path;
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getFiletype() {
		return file;
	}
	public void setFiletype(String file) {
		this.file = file;
	}
	private String file;

	
}
