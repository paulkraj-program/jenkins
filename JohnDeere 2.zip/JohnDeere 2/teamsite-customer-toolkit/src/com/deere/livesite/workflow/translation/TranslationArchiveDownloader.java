package com.deere.livesite.workflow.translation;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import com.deere.livesite.workflow.translation.FileTransfer.IFTPProcessor;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
   
/**    
 * TranslationArchiveDownloader is an implementation of IFTPProcessor that
 * downloads specified translation archives from the FTP server that match the
 * provided name regular expression from the provided working directory.  Files
 * are downloaded to the specified download path appended to the working temp
 * directory path.
 * @author Klish Group, Inc. [ND]
 */

class TranslationArchiveDownloader implements IFTPProcessor<List<File> > {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationArchiveDownloader.class);
	
	private final String workingDirectory;
	private final String archiveNamePattern;
	private final String downloadPath; 
	
	
	
	/**
	 * Create a new instance of TranslationArchiveDownloader
	 * @param workingDirectory The FTP working directory
	 * @param archiveNamePattern Regular expression to match archive file names
	 * @param downloadPath The download path directory (appended to the temp directory)
	 */
	TranslationArchiveDownloader(String workingDirectory, String archiveNamePattern, String downloadPath) {
		this.workingDirectory = workingDirectory;
		this.archiveNamePattern = archiveNamePattern;
		this.downloadPath = downloadPath;
	}
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.translation.FileTransfer.IFTPProcessor#process(org.apache.commons.net.ftp.FTPClient)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<File> process(ChannelSftp channelSftp) throws IOException {

		Vector<ChannelSftp.LsEntry> remoteFiles;
		try {
			LOGGER.info("Executing ls command in following Direcotry : " + workingDirectory);
			
			remoteFiles = channelSftp.ls(workingDirectory);
			
		} catch (SftpException e1) {
			LOGGER.error("Exeception while executing channelSftp.ls command for direcotry : " + workingDirectory + e1);
			throw new IOException();
		}
		List<File> projects = new ArrayList<File>(remoteFiles.size());

		LOGGER.info("Number of remote Files" + remoteFiles.size());

		for (ChannelSftp.LsEntry entry : remoteFiles) {
			LOGGER.info("Inspecting Archive: " + entry.getFilename());
			if (!entry.getAttrs().isDir()
					&& doDownload(entry.getFilename(), archiveNamePattern, AcrossRetrievalServlet.getEnvironment())) {
				
				String path = System.getProperty("java.io.tmpdir") + downloadPath;
				String archive = path + entry.getFilename();

				LOGGER.info("Archive Path : " + archive);
				
				File local = new File(archive);

				if (!local.exists()) {
					local.getParentFile().mkdirs();
					local.createNewFile();
				}

				LOGGER.info("File Name  " + entry.getFilename() + " File Properties " + entry.getAttrs().toString());

				try (OutputStream output = new FileOutputStream(local);
						BufferedOutputStream bos = new BufferedOutputStream(output)) {

					channelSftp.cd(workingDirectory);
					
					LOGGER.info("Current Location after cd command  : " + channelSftp.pwd());
					
					channelSftp.get(entry.getFilename(), bos, new SFTPProgressManager(), 0, 0);

					projects.add(local);
					
				} catch (SftpException sftpException) {
					
					LOGGER.error("Failed to download the file from sftp folder location. " + sftpException.toString());
					
					if (sftpException.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
						
						local.delete();
						
						LOGGER.error("Local File deleted successfully");
						
					}
				} catch (Exception e) {
					
					LOGGER.error("Failed to download the file the sftp folder location.Please check the local folder");
					
				}
			}
		}
		
			try {
				
				if (channelSftp != null && channelSftp.isConnected() 
						&& !channelSftp.isClosed()) {
					
					channelSftp.disconnect();
					
					LOGGER.info("ChanneSFTP is close for the com.deere.livesite.workflow.translation.TranslationArchiveDownloader.process(ChannelSftp)");
					
					}
			} catch (Exception e) {
				
				channelSftp=null;
				
				LOGGER.error("Exception during closing channelSftp : " + e);
				
			}

		return projects;
	}
	
	public static boolean doDownload(String filename, String regex, String environment) {
		LOGGER.info("Checking archive: " + filename);
		LOGGER.info("Pattern: " + regex);
		LOGGER.info("Environment: " + environment);
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(filename);
		
		if (matcher.matches()) {
			if (matcher.groupCount() > 1) {
				LOGGER.info("Checking for environment: " + environment);
				String env = matcher.group(1);
				LOGGER.info("Environment Matcher Group: " + env);
				
				if ((environment == null || "".equals(environment))
					&& (env == null || "".equals(env))) {
					LOGGER.info("No environment specified; pattern matched");
					return true;
				}
				
				if (env != null && !"".equals(env)) {
					Pattern p = Pattern.compile(AcrossRetrievalTask.REGEX_ENVIRONMENT);
					Matcher m = p.matcher(env);
					env = m.matches() ? m.group(1) : env;
					LOGGER.info("Archive Environment: " + env);
					
					LOGGER.info("Environment specified; pattern " + (env.equals(environment) ? "matched" : "does NOT match"));
					return env.equals(environment); // "env-" + environment + "_");
				}
			} else if (environment == null || "".equals(environment)) {
				LOGGER.info("No environment specified; pattern matched");
				return true;
			}
		}
		
		LOGGER.info("Filename does not match pattern");
		return false;
	}
	
}
