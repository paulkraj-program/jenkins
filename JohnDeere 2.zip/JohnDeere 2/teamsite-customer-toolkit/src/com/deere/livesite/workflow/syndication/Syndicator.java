package com.deere.livesite.workflow.syndication;

import java.util.List;
import java.util.Set;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSSimpleFile;

/**
 * Syndicator is an interface that defines a series of methods for
 * implementations to use when processing content migration from a single
 * syndication source to multiple syndication targets.  This allows multiple
 * syndication implementations for various needs, such as non-overwriting,
 * non-modified, and overwrite all implementations to be represented as a single
 * type and invoked regardless of the underlying implementation details of the
 * actual Syndicator instance.
 * @author Klish Group, Inc [ND]
 */
public interface Syndicator {
	
	/**
	 * Process is the main method for a Syndicator instance.  This method is
	 * responsible for completing the migration process of the content using the
	 * given CSClient instance with the list of CSSimpleFile instances to migrate.
	 * The provided SyndicationTarget instances indicate the source as well as
	 * the set of target locations for the content.
	 * @param client The current CSClient instance
	 * @param files A List of CSSimpleFile instance containing the content to migrate
	 * @param source The SyndicationTarget source area
	 * @param targets A Set of SyndicationTarget instances for the target areas
	 * @return The SyndicationResults instance containing information about the
	 * 		results of the migration process
	 * @throws CSException
	 */
	public SyndicationResults process(CSClient client, List<CSSimpleFile> files, SyndicationTarget source, Set<SyndicationTarget> targets, String parameters) throws CSException;

}
