package com.deere.livesite.workflow.bulk;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSExtendedAttribute;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.workflow.CSExternalTask;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * This task will check if the file has been deployed to production. If the File
 * is deployed Through TeamSite then the task will go to success If the file is
 * deployed through anything other than TeamSite then we will check the
 * EA(IsDeployedProd) on the index.page attached to the workflow, if it is set
 * and has value true then the task will go to success otherwise task will go to
 * failure.
 * 
 * @author Klish Group, Inc. [AG]
 *
 */

public class ProductionDeploymentCheckTask extends AbstractURLExternalTask {

	private static final String DEFAULT_DEPLOYED_THROUGH = "TeamSite";
	private static final String EXTENDED_ATTRIBUTE_PROD_DEPLOYED = "IsDeployedProd";
	private static final String VAR_PREVIEW_ONLY = "PreviewOnly";

	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {
		
		
		LOGGER.debug("Production Deployment Check Task invoked");
		String deployedThrough = task.getVariable("DeployedThrough");
		if (task.getVariable(VAR_PREVIEW_ONLY) != null && task.getVariable(VAR_PREVIEW_ONLY).equalsIgnoreCase("true")) {
			LOGGER.debug("Preview flag is true :::");
			String imageFileListPath = task.getWorkflow().getVariable("imageFileListPath");
			String pagePathsfile = task.getWorkflow().getVariable("PagePathsFile");
			String htmlFileListPath = task.getWorkflow().getVariable("HtmlFileListPath");
			if (imageFileListPath != null && !"".equals(imageFileListPath)) {
				LOGGER.debug("Image File List Path: Proceed for deletion " + imageFileListPath);
				try {
					Files.delete(Paths.get(imageFileListPath));
				} catch (IOException | SecurityException e) {
					LOGGER.error("Error Deleting Image list file ", e);
				}
			}
			if (pagePathsfile != null && !"".equals(pagePathsfile)) {
				LOGGER.debug("Page File List Path: Proceed for deletion " + pagePathsfile);
				try {
					Files.delete(Paths.get(pagePathsfile));
				} catch (IOException | SecurityException e) {
					LOGGER.error("Error Deleting Page paths file list ", e);
				}
			}
			if (htmlFileListPath != null && !"".equals(htmlFileListPath)) {
				LOGGER.debug("HTML File List Path: Proceed for deletion " + htmlFileListPath);
				try {
					Files.delete(Paths.get(htmlFileListPath));
				} catch (IOException | SecurityException e) {
					LOGGER.error("Error Deleting HTML paths file list ", e);
				}
			}
			task.chooseTransition("Deploy To Preview Only", "Successfully Deployed to Preview Enviornment");
		}

		else {
			if (deployedThrough != null && !deployedThrough.isEmpty()) {
				LOGGER.debug("Deployed Through " + deployedThrough);
				if (deployedThrough.equalsIgnoreCase(DEFAULT_DEPLOYED_THROUGH)) {
					LOGGER.debug("The files are deployed through Teamsite: " + deployedThrough);
					chooseSuccessTransition(task);
				} else {
					for (CSAreaRelativePath areaRelativePath : task.getFiles()) {
						LOGGER.info("Processing File : " + areaRelativePath + " " + areaRelativePath.getName() + " "
								+ areaRelativePath.getExtension());
						if (areaRelativePath.getName().equalsIgnoreCase("index.page")) {
							CSFile file = task.getArea().getFile(areaRelativePath);
							if (file != null && CSHole.KIND != file.getKind() && CSSimpleFile.KIND == file.getKind()) {
								CSSimpleFile csSimpleFile = (CSSimpleFile) file;
								CSExtendedAttribute exAttr = csSimpleFile
										.getExtendedAttribute(EXTENDED_ATTRIBUTE_PROD_DEPLOYED);
								if (exAttr != null) {
									if (exAttr.getName().equalsIgnoreCase(EXTENDED_ATTRIBUTE_PROD_DEPLOYED)
											&& exAttr.getValue() != null
											&& exAttr.getValue().equalsIgnoreCase("true")) {
										LOGGER.debug("Deployed to Production.");
										chooseSuccessTransition(task);
									} else {
										LOGGER.debug(
												"Deployed Through attribute Value is Null. File is not deployed to Production.");
										chooseFailureTransition(task,
												new CSException(0,
														"Failed because the workflow Originated from " + deployedThrough
																+ "  and the file was not deployed to Production"));
									}
								} else {
									LOGGER.debug(
											"Deployed Through attribute is Null. File is not deployed to production.");
									chooseFailureTransition(task,
											new CSException(0,
													"Failed because the workflow Originated from " + deployedThrough
															+ "  and the file was not deployed to Production"));
								}
							}
						}
					}
				}
			}
		}
	}
}
