package com.deere.livesite.workflow.syndication;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.deere.livesite.workflow.FileDependency;
import com.deere.livesite.workflow.FileDependencyAnalyzer;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.common.CSUnsupportedOpException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSReadOnlyFileSystemException;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;

/**
 * SyndicationUtilities contains utility methods that are used during the
 * syndication and translation process in order to migrate and update content
 * across branches and locales.
 * @author Klish Group, Inc. [ND]
 */
public final class SyndicationUtilities {
	private static final transient Logger LOGGER = Logger.getLogger(SyndicationUtilities.class);
	
	private static final String PATH_TARGETS = "/iwadmin/main/deere/syndication/STAGING/templatedata/syndication/configuration/data/targets.xml";
	
	// This class cannot be instantiated
	private SyndicationUtilities() {
	}
	
	/*
	 * 	<targets>
	 * 		<target>
	 * 			<branch>/default/main/deere/Development/deere.com/us/en/public</branch>
	 * 			<locale>en_US</locale>
	 * 			<site-path>us/en</site-path>
	 * 			<translation-enabled>false</translation-enabled>
	 * 		</target>
	 * 		<target>
	 * 			<branch>/default/main/deere/Development/deere.com/ca/en/public</branch>
	 * 			<locale>en_CA</locale>
	 * 			<site-path>ca/en</site-path>
	 * 			<translation-enabled>false</translation-enabled>
	 * 		</target>
	 * 		<target>
	 * 			<branch>/default/main/deere/Development/deere.com/ca/fr/public</branch>
	 * 			<locale>fr_CA</locale>
	 * 			<site-path>ca/fr</site-path>
	 * 			<translation-enabled>true</translation-enabled>
	 * 		</target>
	 * 		<target>
	 * 			<branch>/default/main/deere/Development/deere.com/china/ch/public</branch>
	 * 			<locale>zh_CH</locale>
	 * 			<site-path>china/ch</site-path>
	 * 			<translation-enabled>true</translation-enabled>
	 * 		</target>
	 * 	</targets>
	 */
	/**
	 * Load the SyndicationConfiguration content.
	 * @param client The CSClient instance
	 * @return A Set of SyndicationTarget instances containing the configuration information
	 * @throws CSException
	 */
	public static Set<SyndicationTarget> loadSyndicationConfiguration(CSClient client) throws CSException {
		Set<SyndicationTarget> targets = new HashSet<>();
		
		CSFile file = client.getFile(new CSVPath(PATH_TARGETS));
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile target = (CSSimpleFile) file;
			
			try {
				Document document = new org.dom4j.io.SAXReader().read(new BufferedInputStream(target.getInputStream(true)));
				Element root = document.getRootElement();
				
				@SuppressWarnings("unchecked")
				List<Element> targetElements = root.elements("target");
				
				for (Element element : targetElements) {
					String branch = element.elementText("branch");
					String locale = element.elementText("locale");
					String sitePath = element.elementText("site-path");
					boolean translationEnabled = Boolean.parseBoolean(element.elementText("translation-enabled"));
					// added for locale such as es-ES. TeamSite locale is es-ES whereas Across needs
					// es-ES-Traditional : QC 1168
					String acrossOverrideLocale = element.elementText("across-locale");

					targets.add(new SyndicationTarget(branch, locale, sitePath, translationEnabled, acrossOverrideLocale));
				}
			} catch (DocumentException de) {
				throw new CSException(de);
			}
		}
		
		return targets;
	}
	
	/**
	 * Create parent any non-existing parent directories for the provided path
	 * @param client The current CSClient instance
	 * @param workarea The target CSWorkarea instance
	 * @param path The path on which to operate creating nonexistent parent directories
	 * @throws CSException
	 */
	public static void createParentDirectories(CSClient client, CSWorkarea workarea, CSAreaRelativePath path) throws CSException {
		LOGGER.debug("Creating path: " + path + " in " + workarea.getVPath().getPathNoServer());
		
		CSAreaRelativePath parent = path.getParentPath();
		LOGGER.debug("Parent Path: " + parent + " " + parent.isEmpty());
		
		if (!parent.isEmpty()) {
			createParentDirectories(client, workarea, parent);
		}
		
		CSVPath vpath = workarea.getVPath().concat(path.toString());
		CSFile file = client.getFile(vpath);
		
		if (file == null || CSHole.KIND == file.getKind()) {
			LOGGER.debug("Creating parent path: " + path);
			workarea.createDirectory(path);
		} else {
			if (CSDir.KIND != file.getKind()) {
				LOGGER.error("Parent file exists; but, is not a directory: " + path);
				throw new CSException(0, "Parent directory exists; but is not a directory: " + path);
			}
		}
	}
	
	/**
	 * Update the file content for DCRs and SitePublisher page files.  This
	 * method updates the source locale to the target locale in the content of
	 * the provided file.
	 * @param client The current CSClient instance
	 * @param workarea The target CSWorkarea instance
	 * @param file The file on which to operate updating its content
	 * @param source The source locale
	 * @param target The target locale
	 * @param mParameters 
	 * @param parameters 
	 * @throws CSException
	 */
	public static void updateFileContent(CSClient client, CSWorkarea workarea, CSFile file, SyndicationTarget source, SyndicationTarget target, String parameters, Map<String, String> mParameters) throws CSException {
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			String extension = file.getVPath().getExtension();
			LOGGER.info("File Extension: " + extension);
			
			CSSimpleFile simpleFile = (CSSimpleFile) file;
			
			if (CSSimpleFile.kDCR == simpleFile.getContentKind()
					|| "page".equalsIgnoreCase(extension)) {
				Document document = null;
				
				// Load the DCR or LiveSite page document from TeamSite
				try (InputStream input = new BufferedInputStream(simpleFile.getInputStream(true))) {
					document = new org.dom4j.io.SAXReader().read(input);
				} catch (DocumentException | IOException e) {
					throw new CSException(e);
				}
				
				if (document != null) {
					Element root = document.getRootElement();
					LOGGER.debug("Loaded DCR XML content: " + file.getVPath().getAreaRelativePath());
					
					FileDependencyAnalyzer analyzer = new FileDependencyAnalyzer(client, workarea, null);
					List<FileDependency> dependencies = analyzer.analyze(simpleFile);
					
					// Update the file dependencies
					for (FileDependency dependency : dependencies) {
						Node element = root.selectSingleNode(dependency.getXPath());
						if (element != null) {
							CSAreaRelativePath targetPath = source.getTargetPath(dependency.getPath(), target);
							element.setText(targetPath.toString());
							
						}
					}
					
					// Update additional file content (non-dependencies)
					updateAdditionalFileContent(document, source, target);
					
					// Write the XML document back out to TeamSite
					if("page".equalsIgnoreCase(extension)) {
						     
						updateAdditionalPageSettingsContent(document, source ,target);
						   	if(parameters.isEmpty() || parameters.equalsIgnoreCase("") ) {
						   		writeXmlDocument(simpleFile, document);
						   	}else {
						   	    writeXmlDocument(simpleFile, document,parameters,mParameters);
						   	}
				     	
					}
					else {
						writeXmlDocument(simpleFile, document);
					}
					}
					
			}
		}
	}
	
	private static void updateAdditionalPageSettingsContent(Document document, SyndicationTarget source, SyndicationTarget target) {
		
		LOGGER.debug(" <<<<  Start of updateAdditionalPageSettingsContent method >>>");
		
		
		List<Node> resourcesNodes = document.selectNodes("/Page/Page_Display_Properties/Resources/Resource");
		for (Node resource : resourcesNodes) {
           String assetResource = resource.selectSingleNode("Path").getText();
			String regex ="(html/deere/)(.*)(/website/)(.*)";
			Pattern patternToFind = Pattern.compile(regex);
		    Matcher match = patternToFind.matcher(assetResource);
		    Boolean isMatched = match.matches();
		    if(Boolean.TRUE.equals(isMatched)) {
				String m = StringUtils.substringBetween(assetResource, "html/deere/", "/website");
				String srcCountryLocale = source.getSitePath();
				String tgtCountryLocale = target.getSitePath();
				if(m.equals("us/en")) {
					assetResource = assetResource.replaceFirst("us/en", tgtCountryLocale.toLowerCase());
				}
				else if(m.equals(srcCountryLocale)){
					assetResource = assetResource.replaceFirst(srcCountryLocale, tgtCountryLocale.toLowerCase());
				}
				LOGGER.debug("assetResource after replacing with target Country and Locale is > "+assetResource);
				resource.selectSingleNode("Path").setText(assetResource);
				LOGGER.debug("srcCountryLocale is >> "+srcCountryLocale +" and tgtCountryLocale is >> "+tgtCountryLocale);
		     }
		
		}

		LOGGER.debug(" <<<<  End of updateAdditionalPageSettingsContent method >>>");
	}

	/**
	 * Update the file content for DCRs and SitePublisher page files.  This
	 * method updates the source locale to the target locale in the content of
	 * the provided file.
	 * @param client The current CSClient instance
	 * @param workarea The target CSWorkarea instance
	 * @param file The file on which to operate updating its content
	 * @param source The source locale
	 * @param target The target locale
	 * @param mParameters 
	 * @param parameters 
	 * @throws CSException
	 */
	public static void updateFileContent(CSClient client, CSWorkarea workarea, CSFile file, SyndicationTarget source, SyndicationTarget target) throws CSException {
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			String extension = file.getVPath().getExtension();
			LOGGER.info("File Extension: " + extension);
			
			CSSimpleFile simpleFile = (CSSimpleFile) file;
			
			if (CSSimpleFile.kDCR == simpleFile.getContentKind()
					|| "page".equalsIgnoreCase(extension)) {
				Document document = null;
				
				// Load the DCR or LiveSite page document from TeamSite
				try (InputStream input = new BufferedInputStream(simpleFile.getInputStream(true))) {
					document = new org.dom4j.io.SAXReader().read(input);
				} catch (DocumentException | IOException e) {
					throw new CSException(e);
				}
				
				if (document != null) {
					Element root = document.getRootElement();
					LOGGER.debug("Loaded DCR XML content: " + file.getVPath().getAreaRelativePath());
					
					FileDependencyAnalyzer analyzer = new FileDependencyAnalyzer(client, workarea, null);
					List<FileDependency> dependencies = analyzer.analyze(simpleFile);
					
					// Update the file dependencies
					for (FileDependency dependency : dependencies) {
						Node element = root.selectSingleNode(dependency.getXPath());
						if (element != null) {
							CSAreaRelativePath targetPath = source.getTargetPath(dependency.getPath(), target);
							element.setText(targetPath.toString());
							
						}
					}
					
					// Update additional file content (non-dependencies)
					updateAdditionalFileContent(document, source, target);
					
					// Write the XML document back out to TeamSite

						writeXmlDocument(simpleFile, document);
					
					}
					
			}
		}
	}
	public static void updatePageAttributeContent(CSClient client, CSFile file, String parameters, Map<String, String> mParameters, SyndicationTarget source, SyndicationTarget target) throws CSException {
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			String extension = file.getVPath().getExtension();
			LOGGER.info("File Extension: " + extension);
			CSSimpleFile simpleFile = (CSSimpleFile) file;
			if ("page".equalsIgnoreCase(extension)) {
				Document document = null;
				try (InputStream input = new BufferedInputStream(simpleFile.getInputStream(true))) {
					document = new org.dom4j.io.SAXReader().read(input);
				} catch (DocumentException | IOException e) {
					throw new CSException(e);
				}
				
				if (document != null) {
					Element root = document.getRootElement();
					LOGGER.debug("Loaded DCR XML content: " + file.getVPath().getAreaRelativePath());
					if("page".equalsIgnoreCase(extension)) {
						updateAdditionalPageSettingsContent(document, source ,target);
						   	if(parameters.isEmpty() || parameters.equalsIgnoreCase("") ) {
						   		
						   	}else {
						   	    writeXmlDocument(simpleFile, document,parameters,mParameters);
						   	}
				     	
					}
					else {
						
					}
					}
					
			}
		}
	}
	private static void writeXmlDocument(CSSimpleFile file, Document document, String parameters,Map<String, String> mParameters)throws CSException {

		try (OutputStream output = new BufferedOutputStream(file.getOutputStream(true))) {
			LOGGER.debug("writeXmlDocument mParameters map is  >>>>>"+mParameters.toString());
			XMLWriter writer = new XMLWriter(output, OutputFormat.createPrettyPrint());
			String[] attrParameters = parameters.split(",");
			List<Node> nodes = document.selectNodes("/Page/Page_Display_Properties");
		    List<Node> metatagNodes = document.selectNodes("/Page/Page_Display_Properties/MetaTags/MetaTag");
			List<String> listParameters = Arrays.asList(attrParameters);
			for (Node node : nodes) {
	            Element element = (Element)node;
	            for(int i=0 ; i<attrParameters.length;i++) {
	            	LOGGER.debug("---------------Looking for the the Parameters -------------");
		            	LOGGER.debug("<<< Checking for >>> "+attrParameters[i]);
			            	if(attrParameters[i].equals("Title")||attrParameters[i].equals("Keywords")||attrParameters[i].equals("Description")) {
			            		LOGGER.debug("The Above Attribute matches the Parameters, which should not be syndicated");
			                    Iterator<Element> iterator = element.elementIterator(attrParameters[i]);
		                              while(iterator.hasNext()) {
						               Element pageElement = (Element)iterator.next();
						               if(mParameters.get(attrParameters[i])!=null || !(mParameters.get(attrParameters[i])).equals("null")) {
						            	   LOGGER.debug("<< Setting the Value >>");
						            	   LOGGER.debug(attrParameters[i]+" => "+mParameters.get(attrParameters[i]));
						            	   pageElement.setText(mParameters.get(attrParameters[i]));
						            	   LOGGER.debug("The Parameter >> "+attrParameters[i]+ " has been set");
						               }else {
						            	  pageElement.setText("");
						               }
						            }
			           }
			            	else {
			            		
			            	}
		            }
	         } 
			for (Node metaNode : metatagNodes) {
	            
				String nameAttribute = metaNode.selectSingleNode("name").getText();
				
				LOGGER.debug("---------------Looking for the the Parameters -------------");
				LOGGER.debug("<<< Checking for >>> "+nameAttribute);
		               if(listParameters.contains(nameAttribute)) {
		            	  
		            	   LOGGER.debug("The Above Attribute matches the Parameters, which should not be syndicated");
		            	   LOGGER.debug("<< Setting the Value >>");
		            	   
		            	   metaNode.selectSingleNode("content").setText(mParameters.get(nameAttribute));
		            	   LOGGER.debug(" The Parameter => "+nameAttribute+" has been set with "+mParameters.get(nameAttribute));
		               }
		               else {
		            	   
		            	   
		            	   LOGGER.debug("The Parameter => "+nameAttribute+" need not be set");
		               }
		               
	             }

	           
			writer.write(document);
			} catch (IOException e) {
			throw new CSException(e);
		}
		
		
	}

	private static void updateAdditionalFileContent(Document document, SyndicationTarget source, SyndicationTarget target) throws CSException {
		List<String> xPaths = Arrays.asList(
				// Select PageLink type Datum elements from the source document
				// and update the content when it contains locale related content
				"//Datum[@Type='PageLink']",
				// Select any textual node that contains $PAGE_LINK in the text of that node
				"//text()[contains(., '$PAGE_LINK')]"
				// XXX: Select any additional elements from the XML document here.
				);
		Element root = document.getRootElement();
		
		for (String xPath : xPaths) {
			@SuppressWarnings("unchecked")
			List<Node> nodes = root.selectNodes(xPath);
			for (Node node : nodes) {
				String text = source.replacePath(node.getText(), target);
				node.setText(text);
			}
		}
	}
	
	private static void writeXmlDocument(CSSimpleFile file, Document document) throws CSException {
		try (OutputStream output = new BufferedOutputStream(file.getOutputStream(true))) {
			XMLWriter writer = new XMLWriter(output, OutputFormat.createPrettyPrint());
			
			writer.write(document);
		} catch (IOException e) {
			throw new CSException(e);
		}
	}

	public static Map<String, String> getParameterValues(String filePath) {
		// TODO Auto-generated method stub
		Map<String,String> mParameters = new HashMap<String,String>(); 
		mParameters = SyndicationUtilities.getDefaultParameterValues();
		File fXmlFile = new File("/iwmnt"+"/"+filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		try {
			dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);

			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			org.w3c.dom.Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("Page_Display_Properties");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				org.w3c.dom.Node nNode = nList.item(temp);

				

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
	                

					if(!((org.w3c.dom.Element) eElement).getElementsByTagName("Title").item(0).getTextContent().equalsIgnoreCase("")) {
					String title= ((org.w3c.dom.Element) eElement).getElementsByTagName("Title").item(0).getTextContent().toString();
					mParameters.replace("Title", title);
					}
					
					
					if(!((org.w3c.dom.Element) eElement).getElementsByTagName("Keywords").item(0).getTextContent().equalsIgnoreCase("")) {
						String keywords=((org.w3c.dom.Element) eElement).getElementsByTagName("Keywords").item(0).getTextContent().toString();
						mParameters.replace("Keywords", keywords);
					}
					
					
					if(!((org.w3c.dom.Element) eElement).getElementsByTagName("Description").item(0).getTextContent().equalsIgnoreCase("")) {
						String description =((org.w3c.dom.Element) eElement).getElementsByTagName("Description").item(0).getTextContent().toString();
						mParameters.replace("Description", description);
					}
					
					
					
					NodeList MetaNodeList = ((org.w3c.dom.Element) eElement).getElementsByTagName("MetaTags");
					for (int itemp = 0; itemp < MetaNodeList.getLength(); itemp++) {
						org.w3c.dom.Node MetaNode = MetaNodeList.item(itemp);
						if (MetaNode.getNodeType() == Node.ELEMENT_NODE) {
							
							org.w3c.dom.Element MetaNodeElement = (org.w3c.dom.Element) MetaNode;
							
							NodeList MetaList = ((org.w3c.dom.Element) MetaNodeElement).getElementsByTagName("MetaTag");
							for (int ntemp = 0; ntemp < MetaList.getLength(); ntemp++) {
								org.w3c.dom.Node MetatagNode =  MetaList.item(ntemp);
								org.w3c.dom.Element MetaElement = (org.w3c.dom.Element) MetatagNode;
								String name =((org.w3c.dom.Element) MetaElement).getElementsByTagName("name").item(0).getTextContent();
								if(name.equalsIgnoreCase("country")||name.equalsIgnoreCase("language")||name.equalsIgnoreCase("industry")) {
									String content= ((org.w3c.dom.Element) MetaElement).getElementsByTagName("content").item(0).getTextContent();
								    mParameters.replace(name, content);
								}
							}
						}
					}						
					
					
				}
			}
			
		} catch (ParserConfigurationException | SAXException | IOException e) {

			LOGGER.error("CSException occured  in the method getParameterValues for SyndicationUtilities",e);
		}  
		
		return mParameters;
	}

	public static Map<String, String> getDefaultParameterValues() {

		Map<String,String> mParameters = new HashMap<String,String>(); 
		mParameters.put("Title", "Title");
		mParameters.put("Keywords", "");
		mParameters.put("Description", "");
		mParameters.put("industry", "industry");
		mParameters.put("country", "country");
		mParameters.put("language", "language");
		return mParameters;
	}

	public static Map<String, String> getParametersMap(CSClient client, CSSimpleFile curr, CSVPath targetPath, String parameters) {

		Map<String,String> mParametersMap = new HashMap<String,String>();
		if("page".equalsIgnoreCase(curr.getVPath().getExtension())) {
			LOGGER.debug("The extension of the Page or Asset is >>"+curr.getVPath().getExtension());
			try {
				if(client.getFile(targetPath) !=null && !(client.getFile(targetPath) instanceof CSHole)) {
					CSFile fileObject =client.getFile(targetPath);
					String filePath = fileObject.getUAI().toString();
						if(!parameters.isEmpty() || !parameters.equalsIgnoreCase("")) {
							mParametersMap= SyndicationUtilities.getParameterValues(filePath);
							
							}
						else {
							mParametersMap= SyndicationUtilities.getDefaultParameterValues();
						}
					}
					else {
						mParametersMap= SyndicationUtilities.getDefaultParameterValues();
					}
			}  catch (CSException e) {
				LOGGER.error("CSException occured  in the method getParametersMap for SyndicationUtilities",e);
			}
			}
		else {
			
			mParametersMap= SyndicationUtilities.getDefaultParameterValues();
		}
		
		return mParametersMap;
	}
	
	
}
