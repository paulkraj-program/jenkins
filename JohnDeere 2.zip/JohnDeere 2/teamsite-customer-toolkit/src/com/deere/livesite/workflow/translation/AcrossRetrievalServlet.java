package com.deere.livesite.workflow.translation;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;

/**
 * AcrossRetrievalServlet is an implementation of HttpServlet that schedules the
 * translation project retrieval from the Across FTP server.  This class is
 * responsible for managing the scheduled task and allows for the rescheduling
 * as well as the immediate pull of the content on the FTP server.
 * @author Klish Group, Inc. [ND]
 */
public class AcrossRetrievalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final transient Logger LOGGER = Logger.getLogger(AcrossRetrievalServlet.class);
	
	private static final String PARAM_CSFACTORY = "csFactory";
	
	private static final String PARAM_PERIOD = "period";
	private static final String PARAM_START_HOUR = "start_hour";
	
	private static final String PARAM_AKENEO_HOST = "AkeneoHost";
	//private static final String PARAM_AKENEO_USER = "AkeneoUser";
	//private static final String PARAM_AKENEO_KEY = "AkeneoKey";
	//private static final String PARAM_AKENEO_SALT = "AkeneoSalt";
	private static final String PARAM_WSO2_HOST = "WSO2Host";
	private static final String PARAM_PIM_TOKEN_SVC = "WSO2TokenSvc";
	
	private static final String PARAM_ENVIRONMENT = "Environment";
	
	private static final long PERIOD			= 12L;
	private static final TimeUnit UNITS			= TimeUnit.HOURS;
	// Base the initial delay against the start time of 0800
	private static final long START_HOUR		= 8L;
	
	private static String environment = "";
	
	private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
	private ScheduledFuture<?> result;
	private IRetrievalTask retrievalTask;
	/*
	 * buildRetrievalTask method
	 */
	private IRetrievalTask buildRetrievalTask() {
		String csFactory = getServletConfig().getInitParameter(PARAM_CSFACTORY);
		LOGGER.debug("Setting REGEX_TEAMSITE_ARCHIVE_FILE: " + AcrossRetrievalTask.REGEX_TEAMSITE_ARCHIVE_FILE);
		return new AcrossMultiArchiveRetrievalTask(
				new AcrossRetrievalTask(AcrossRetrievalTask.REGEX_TEAMSITE_ARCHIVE_FILE,
						AcrossRetrievalTask.TEAMSITE_PATH_EMAIL_CONFIGURATION,
						csFactory, new IRetrievalPostProcessor.PassThroughPostProcessor()),
				new AcrossRetrievalTask(AcrossRetrievalTask.REGEX_TEAMSITE_TARGET_ARCHIVE_FILE,
						AcrossRetrievalTask.TEAMSITE_PATH_EMAIL_CONFIGURATION,
						csFactory, new IRetrievalPostProcessor.PassThroughPostProcessor()),
				new AcrossRetrievalTask(AcrossRetrievalTask.REGEX_AKENEO_ARCHIVE_FILE,
						AcrossRetrievalTask.AKENEO_PATH_EMAIL_CONFIGURATION,
						csFactory, new AkeneoRetrievalPostProcessor(getServletConfig().getInitParameter(PARAM_AKENEO_HOST),
								getServletConfig().getInitParameter(PARAM_WSO2_HOST),
								getServletConfig().getInitParameter(PARAM_PIM_TOKEN_SVC))));

				
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.GenericServlet#init()
	 */
	@Override
	
	
	public void init() throws ServletException {
		environment = getServletConfig().getInitParameter(PARAM_ENVIRONMENT);
		if (environment == null) {
			environment = "";
		}
		LOGGER.debug("Across Servlet Environment: " + environment);
		
		// Schedule the task for future processing
		retrievalTask = buildRetrievalTask();
		
		String periodString = getServletConfig().getInitParameter(PARAM_PERIOD);
		long period;
		try {
			period = Long.parseLong(periodString);
		} catch (NumberFormatException nfe) {
			// Ignore this exception and use the default value of 12 hours
			period = PERIOD;
		}
		LOGGER.debug("Across Retrieval Servlet Period: " + period);
		
		String startHourString = getServletConfig().getInitParameter(PARAM_START_HOUR);
		long startHour;
		try {
			startHour = Long.parseLong(startHourString);
		} catch (NumberFormatException nfe) {
			// Ignore this exception and use the default value of 12 hours
			startHour = START_HOUR;
		}
		if (startHour < 1 || startHour > 12) {
			LOGGER.warn("Invalid starting hour, must be between 1 and 12");
			startHour = START_HOUR;
		}
		LOGGER.debug("Across Retrieval Servlet Starting Hour: " + startHour);
		
		
		long delay = calculateInitialDelay(startHour, period);
		
		/**
		 * commenting below line as retrieval has been migrated to OD scheduler [PS-54 SP-4 User Story:US85271]
		 * result = scheduler.scheduleAtFixedRate(retrievalTask, delay, period, UNITS);
		 */
		
		LOGGER.debug("Skipping initializing schedular !!");
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetStatus(request, response);
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action == null || "".equals(action)) {
			LOGGER.debug("Null or missing servlet action");
			
			writeJSONErrorResponse(response, "Null or missing servlet action");
			
			return;
		} else {
			action = action.toLowerCase();
		}
		LOGGER.debug("Action: " + ESAPI.encoder().encodeForHTML(action));
		
		switch (action) {
		case "reschedule":
			doReschedule(request, response);
			break;
			
		case "status":
			doGetStatus(request, response);
			break;
			
		case "retrieve":
			doRetrieval(request, response);
			break;
			
		default:
			LOGGER.debug("Null or missing servlet action ");
			
			writeJSONErrorResponse(response, "Invalid servlet action:  " + action);
			
			break;
		}
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.GenericServlet#destroy()
	 */
	@Override
	public void destroy() {
		scheduler.shutdown();
		
		super.destroy();
	}
	
	private synchronized void doReschedule(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String periodString = request.getParameter("period");
		if (periodString == null || "".equals(periodString)) {
			LOGGER.error("Period parameter was null or missing");
			
			writeJSONErrorResponse(response, "A valid time period must be supplied in order to reschedule the retrieval task");
			
			return;
		}
		
		long period = 0L;
		try {
			period = Long.parseLong(periodString);
		} catch (NumberFormatException nfe) {
			LOGGER.error("Period parameter was not a valid number: " + ESAPI.encoder().encodeForHTML(periodString));
			
			writeJSONErrorResponse(response, "A valid time period must be supplied in order to reschedule the retrieval task");
			
			return;
		}
		
		String startHourString = getServletConfig().getInitParameter(PARAM_START_HOUR);
		long startHour;
		try {
			startHour = Long.parseLong(startHourString);
		} catch (NumberFormatException nfe) {
			// Ignore this exception and use the default value of 12 hours
			startHour = START_HOUR;
		}
		if (startHour < 1 || startHour > 12) {
			LOGGER.warn("Invalid starting hour, must be between 1 and 12");
			startHour = START_HOUR;
		}
		LOGGER.debug("Across Retrieval Servlet Starting Hour: " + startHour);
		
		
		long delay = calculateInitialDelay(startHour, period);
		
		LOGGER.info("Resheduling retrieval task for: " + period + " " + UNITS + " in " + delay + " " + UNITS);
		
		if (result != null) {
			result.cancel(true);
		}
		
		result = scheduler.scheduleAtFixedRate(retrievalTask, delay, period, UNITS);
		
		writeJSONResponse(response, "{ \"success\": \"Task successfully rescheduled\" }");
		LOGGER.debug("Task successfully rescheduled");
	}
	
	private void doGetStatus(HttpServletRequest request, HttpServletResponse response) throws IOException {
		long remainingDelay = result.getDelay(TimeUnit.SECONDS);
		long hours = remainingDelay / (60 * 60);
		long minutes = (remainingDelay / 60) % 60;
		long seconds = remainingDelay % 60;
		
		String period = String.format("%1d:%1$02d:%1$02d", hours, minutes, seconds);
		
		String status = result.isCancelled() ? "inactive" : "active";
		
		writeJSONResponse(response, "{ \"success\": \"Status request successful\", \"status\": \"" + status + "\", \"delay\": \"" + period + "\" }");
	}
	
	private void doRetrieval(HttpServletRequest request, HttpServletResponse response) throws IOException {
		IRetrievalTask task = buildRetrievalTask();
		
		try {
			task.doRetrieval();
			
			writeJSONResponse(response, "{ \"success\": \"Retrieval successful\" }");
		} catch (IOException ioe) {
			LOGGER.error("Failed on content retrieval", ioe);
			writeJSONErrorResponse(response, ioe.getLocalizedMessage());
		}
	}
	
	public static String getEnvironment() {
		return environment;
	}
	
	private static void writeJSONErrorResponse(HttpServletResponse response, String error) throws IOException {
		error = error.replaceAll("\"", "\\\"");
		writeJSONResponse(response, "{ \"error\": \"" + error + "\" }");
	}
	
	private static void writeJSONResponse(HttpServletResponse response, String json) throws IOException {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		PrintWriter writer = response.getWriter();
		writer.write(ESAPI.encoder().encodeForHTML(json));
		writer.flush();
	}

	// Calculate the initial period against a set time of the day (0800 hours)
	// This factors in server restarts so the retrieval happens at set intervals
	// during the day.
	private static long calculateInitialDelay(long startHour, long period) {
		Calendar calendar = new GregorianCalendar();
		long hour = calendar.get(Calendar.HOUR_OF_DAY);
		long distance = hour - startHour;
		
		long delay;
		if (distance <= 0) {
			delay = -distance;
			long remainder = (delay % period);
			delay = (remainder == 0) ? 0 : delay;
		} else {
			long remainder = (distance % period);
			delay = (remainder == 0) ? 0 : (period - remainder);
		}
		
		LOGGER.debug("Initial Delay Period: " + delay);
		return delay;
	}
	
}
