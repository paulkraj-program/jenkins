package com.deere.livesite.workflow.syndication;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSBranch;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSPathCommentPair;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;

/**
 * NonModifiedSyndicator is a implementation of the Syndicator interface that
 * overwrites the target content with the source content when the target content
 * is not modified since its last syndication.  The syndication timestamp is
 * checked against the content modification date to determine modification.
 * @author Klish Group, Inc. [ND]
 */
public class NonModifiedSyndicator extends AbstractSyndicator {
	
	/* (non-Javadoc)
	 * @see com.deere.livesite.workflow.syndication.Syndicator#process(com.interwoven.cssdk.common.CSClient, java.util.List, java.util.Set)
	 */
	@Override
	public SyndicationResults process(CSClient client, List<CSSimpleFile> files, SyndicationTarget source, Set<SyndicationTarget> targets,String parameters) throws CSException {
		Map<String,String> mParameters;
		SyndicationResults results = new SyndicationResults();
		
		for (SyndicationTarget target : targets) {
			CSBranch branch = client.getBranch(new CSVPath(target.getBranch()), true);
			CSWorkarea workarea = branch.getWorkareas()[0];
			
			for (CSSimpleFile curr : files) {
				CSAreaRelativePath path = curr.getVPath().getAreaRelativePath();
				CSVPath targetPath = workarea.getVPath().concat(path.toString());
				
				// Replace the source locale with the target locale in the path
				targetPath = source.getTargetPath(targetPath, target);
				
				CSFile file = client.getFile(targetPath);
				
				if (file == null || CSHole.KIND == file.getKind()) {
					LOGGER.info("Creating file: " + curr.getVPath() + " to " + targetPath);
					
					CSWorkarea targetArea = client.getWorkarea(targetPath.getArea(), true);
					
					SyndicationUtilities.createParentDirectories(client, targetArea, targetPath.getAreaRelativePath().getParentPath());
					LOGGER.info("Is file present in target location ? "+client.getFile(targetPath) !=null && !(client.getFile(targetPath) instanceof CSHole));
					//Submitting the file before updating the file
					if(client.getFile(targetPath) !=null && !(client.getFile(targetPath) instanceof CSHole)) {
					//checking if file has not been submitted to staging after any changes have been made or if it is new (non-versioned) file	
					LOGGER.info("File submit Record - "+client.getFile(targetPath).getSubmitRecord());	
					if(client.getFile(targetPath).getSubmitRecord()==null) {	
					CSPathCommentPair[] toBeSubmittedBeforeUpdation = new CSPathCommentPair[] { new CSPathCommentPair(client.getFile(targetPath).getVPath().getAreaRelativePath(), "Submitted by Syndication workflow before updation")};
					targetArea.submitDirect("Submitted by Syndication workflow before updation", "", toBeSubmittedBeforeUpdation, CSWorkarea.OVERWRITE_NONE);
					}
					}
					mParameters = new HashMap<String,String>();
					mParameters = SyndicationUtilities.getParametersMap(client,curr,targetPath,parameters);
					if(mParameters.isEmpty()) {
						mParameters= SyndicationUtilities.getDefaultParameterValues();
					}
					if("page".equalsIgnoreCase(curr.getVPath().getExtension())){
						LOGGER.debug("mParameters map with all the Page Scope Attribute values >>"+mParameters.toString());
						}
					curr.copy(targetPath, false);
					file = client.getFile(targetPath);
					file.setGroup (targetArea.getGroup ());
					SyndicationUtilities.updateFileContent(client, targetArea, file, source, target,parameters,mParameters);
					updateLocaleAttributes(client,targetArea,file, source.getLocale(), target.getLocale());
					setSyndicationTimestamp(file);
					//Submitting the file After updating the file
					CSPathCommentPair[] toBeSubmittedAfterUpdation = new CSPathCommentPair[] { new CSPathCommentPair(file.getVPath().getAreaRelativePath(), "Submitted by Syndication workflow from locale - "+source.getLocale())};
					targetArea.submitDirect("Submitted by Syndication workflow from locale - "+source.getLocale(), "", toBeSubmittedAfterUpdation, CSWorkarea.OVERWRITE_NONE);
					results.getSyndicated().add(file);
				} else {
					Date timestamp = getTimestamp(file);
					Date syndicationTimestamp = getSyndicationTimestamp(file);
					
					boolean modified = false;
					
					if (syndicationTimestamp == null) {
						// Treat non-syndicated files as if they were modified in the target area
						LOGGER.info("FILE NOT SYNDICATED: " + targetPath);
					} else {
						LOGGER.debug("Checking Syndication Timestamp: " + timestamp + " => " + syndicationTimestamp + " (" + timestamp.after(syndicationTimestamp) + ")");
						modified = !timestamp.after(syndicationTimestamp);
					}
					
					if (modified) {
						LOGGER.info("Copying file: " + curr.getVPath() + " to " + targetPath);
						
						CSWorkarea targetArea = client.getWorkarea(targetPath.getArea(), true);
						
						SyndicationUtilities.createParentDirectories(client, targetArea, targetPath.getAreaRelativePath().getParentPath());
						LOGGER.info("Is file present in target location ?"+client.getFile(targetPath) !=null && !(client.getFile(targetPath) instanceof CSHole));
						//Submitting the file before updating the file
						if(client.getFile(targetPath) !=null && !(client.getFile(targetPath) instanceof CSHole)) {
						//checking if file has not been submitted to staging after any changes have been made or if it is new (non-versioned) file	
						LOGGER.info("File submit Record - "+client.getFile(targetPath).getSubmitRecord());	
						if(client.getFile(targetPath).getSubmitRecord()==null) {	
						CSPathCommentPair[] toBeSubmittedBeforeUpdation = new CSPathCommentPair[] { new CSPathCommentPair(client.getFile(targetPath).getVPath().getAreaRelativePath(), "Submitted by Syndication workflow before updation")};
						targetArea.submitDirect("Submitted by Syndication workflow before updation", "", toBeSubmittedBeforeUpdation, CSWorkarea.OVERWRITE_NONE);
						}
						}
						mParameters = new HashMap<String,String>();
						mParameters = SyndicationUtilities.getParametersMap(client,curr,targetPath,parameters);
						if(mParameters.isEmpty()) {
							mParameters= SyndicationUtilities.getDefaultParameterValues();
						}
						if("page".equalsIgnoreCase(curr.getVPath().getExtension())){
						LOGGER.debug("mParameters map with all the Page Scope Attribute values >>"+mParameters.toString());
						}
						curr.copy(targetPath, true);
						file = client.getFile(targetPath);
						file.setGroup (targetArea.getGroup ());
						SyndicationUtilities.updatePageAttributeContent(client, file, parameters, mParameters,source,target);
						updateLocaleAttributes(client,targetArea,file, source.getLocale(), target.getLocale());
						setSyndicationTimestamp(file);
						//Submitting the file After updating the file
						CSPathCommentPair[] toBeSubmittedAfterUpdation = new CSPathCommentPair[] { new CSPathCommentPair(file.getVPath().getAreaRelativePath(), "Submitted by Syndication workflow from locale - "+source.getLocale())};
						targetArea.submitDirect("Submitted by Syndication workflow from locale - "+source.getLocale(), "", toBeSubmittedAfterUpdation, CSWorkarea.OVERWRITE_NONE);
						results.getSyndicated().add(file);
					} else {
						LOGGER.info("FILE MODIFIED: " + targetPath);
						
						results.getModified().add(file);
					}
					
					results.getExisting().add(file);
				}
			}
		}
		
		return results;
	}
	
}
