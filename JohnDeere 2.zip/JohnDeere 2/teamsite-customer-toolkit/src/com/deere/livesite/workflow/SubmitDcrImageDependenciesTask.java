package com.deere.livesite.workflow;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSPathCommentPair;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.livesite.workflow.WorkflowUtils;

/**
 * SubmitDcrImageDependenciesTask class read the filelist which contains the image dependencies 
 * of the DCR and submits them.
 * @author Klish Group, Inc. [AG]
 *
 */

public class SubmitDcrImageDependenciesTask extends AbstractURLExternalTask {

	private static String submitComment = "Image Files Submitted through Content Publish Workflow";
	private static String submitInfo = "Image File Submitted";

	@Override
	protected void execute(CSClient client, CSExternalTask task) throws CSException {

		String imageFileListPath = task.getWorkflow().getVariable("imageFileListPath");
		String imageWorkArea = WorkflowUtils.findVariable(task, "imageWorkArea");
		submitComment = WorkflowUtils.findVariable(task, "submitComment");
		submitInfo = WorkflowUtils.findVariable(task, "submitInfo");

		if (imageWorkArea != null && !"".equals(imageWorkArea) && imageFileListPath != null && !"".equals(imageFileListPath)) {
			LOGGER.debug("Image Workarea Path " + imageWorkArea);
			LOGGER.debug("Image File List Path " + imageFileListPath);
			CSWorkarea area = client.getWorkarea(new CSVPath(imageWorkArea), false);	
			
			if(area != null){
				LOGGER.debug("Area "+area.getName());
				List<String> imagePaths = readImageFileList(imageFileListPath, imageWorkArea);
				List<CSPathCommentPair> pathCommentPairList = new ArrayList<CSPathCommentPair>();
				try {
					if (imagePaths != null) {
						for (String imagePath : imagePaths) {
							try {
								CSFile file = client.getFile(new CSVPath(imagePath));
								if (file != null && file.isModified()) {
									pathCommentPairList.add(new CSPathCommentPair(file.getVPath().getAreaRelativePath(), submitComment));
									LOGGER.debug("added the image "+imagePath);
								} 
							} catch (CSException e) {
								LOGGER.error("Connectivity or permissions problem", e);
							}
						}
						if(pathCommentPairList!=null && pathCommentPairList.size()>0){
							area.submitDirect(submitInfo, null, pathCommentPairList.toArray(new CSPathCommentPair[pathCommentPairList.size()]), 0);
						}

						LOGGER.debug("Files submitted.skipped deleting the image file list " + imageFileListPath);
						/* Commenting this line as image file  list will be used by velocity search task 

						 * try { Files.delete(Paths.get(imageFileListPath)); } catch (IOException |
						 * SecurityException e) { LOGGER.error("Error Deleting File list file ", e); }
						 */
					}
	
				} catch (Exception e) {
					LOGGER.error("Error submitting the image file", e);
				}
			}
		}
	}

	/**
	 * This function reads the file containing the image paths
	 * and creates the list of image paths
	 * @param imageFileListPath File containing image paths.
	 * @param imageWorkarea Workarea containing the images.
	 * @return List of image paths.
	 */
	private List<String> readImageFileList(String imageFileListPath, String imageWorkarea) {
		List<String> imagePaths = new ArrayList<String>();
		BufferedReader reader = null;
		try {

			reader = Files.newBufferedReader(Paths.get(imageFileListPath), Charset.defaultCharset());

			String imagePath = null;
			while ((imagePath = reader.readLine()) != null) {
				imagePaths.add(imageWorkarea + File.separator + imagePath);
			}
			reader.close();
			return imagePaths;
		} catch (IOException e) {
			LOGGER.error("Exception Reading a image file list ", e);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception ex) {
					LOGGER.error("Failed closing image file list reader ", ex);
				}
			}
		}
		return null;
	}
}
