package com.deere.livesite.workflow.syndication;

/**
 * SyndicationMode is an enumeration that contains constants for the various
 * syndication modes that can be executed during the syndication process.  This
 * enumeration also provides the getSyndicator method which returns an
 * implementation of the Syndicator interface specific to the constant used to
 * invoke the method.
 * @author Klish Group, Inc. [ND]
 */
public enum SyndicationMode {
	/** Do not overwrite any existing target content with the source content during syndication */
	OVERWRITE_NONE {
		public Syndicator getSyndicator() {
			return new NonOverwritingSyndicator();
		}
	},
	/** Overwrite non-modified target content with the source content during syndication */
	OVERWRITE_NONMODIFIED {
		public Syndicator getSyndicator() {
			return new NonModifiedSyndicator();
		}
	},
	/** Overwrite all target content with the source content during syndication */
	OVERWRITE_ALL {
		public Syndicator getSyndicator() {
			return new OverwritingSyndicator();
		}
	},
	;
	
	/**
	 * Get the Syndicator instance for this SyndicationMode constant
	 * @return The Syndicator instance for this SyndicationMode constant
	 */
	public abstract Syndicator getSyndicator();
	
}
