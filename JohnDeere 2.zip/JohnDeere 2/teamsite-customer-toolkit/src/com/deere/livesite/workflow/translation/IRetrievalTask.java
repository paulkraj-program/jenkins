package com.deere.livesite.workflow.translation;

import java.io.IOException;

/**
 * IRetrievalTask is an interface that defines an Across translation content
 * retrieval task.  This interface implements the Runnable interface 
 * @author Klish Group, Inc. [ND]
 */
interface IRetrievalTask extends Runnable {
	
	/**
	 * Retrieve the content from Across and process it back into TeamSite
	 * @throws IOException
	 */
	public void doRetrieval() throws IOException;
	
	/*
	// Whenever the upgrade to Java 8 for TS8.2 is completed this method should be
	// uncommented and the implementation removed from each of the child classes.
	@Override
	default void run() {
		try {
			doRetrieval();
		} catch (IOException ioe) {
			LOGGER.error("Failed during translation project retrieval process", ioe);
		}
	}
	 */
	
}
