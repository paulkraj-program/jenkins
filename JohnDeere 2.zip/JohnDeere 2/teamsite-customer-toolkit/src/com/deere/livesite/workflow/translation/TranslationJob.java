package com.deere.livesite.workflow.translation;

import java.util.ArrayList;
import java.util.Set;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import com.deere.livesite.workflow.syndication.SyndicationTarget;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSTask;

/**
 * TranslationJob is a class that is responsible for building out the
 * translation job element of an Across control.xml file.
 * @author Klish Group, Inc. [ND]
 */
public class TranslationJob {
	private static final transient Logger LOGGER = Logger.getLogger(TranslationJob.class);
	
	private static final String VAR_JOB_CONTACT			= "JobContact";
	private static final String VAR_PROJECT_MANAGER		= "ProjectManager";
	private static final String VAR_POST_TO_AKENEO	= "PostToAkeneo";
	
	// CSTask owner id
	private String initiatorId;
	// CSTask owner e-mail
	private String initiatorEmail;
	
	// Selected on instantiation screen
	private String jobContact;
	
	// Across project details
	private ProjectDetails projectDetails;
	
	// Across translation task
	private TranslationTask translationTask;
	
	//Post Akeneo flag
	private String postToAkeneo;
	
	/**
	 * Create a new instance of the TranslationJob class using the provided
	 * task to pull the required information from.  This information includes
	 * the task owner name, the task owner e-mail address, and the job contact
	 * e-mail address.
	 * @param client The current CSClient instance
	 * @param task The current CSTask instance
	 * @param ownerId The translation job owner identifier
	 * @param source The SyndicationTarget source locale
	 * @param targets A Set of SyndicationTarget targets locales
	 * @param metaTag String retrieved by parsing list of pages
	 * @throws CSException
	 */
	public TranslationJob(CSClient client, CSTask task, String ownerId, SyndicationTarget source, Set<SyndicationTarget> targets, String metaTag) throws CSException {
		initiatorId = task.getOwner().getName();
		LOGGER.debug("Project Initiator: " + initiatorId);
		initiatorEmail = task.getOwner().getEmailAddress();
		LOGGER.debug("Project Initiator E-mail: " + initiatorEmail);
		
		jobContact = getJobContactEmail(task); 
		
		postToAkeneo=task.getVariable(VAR_POST_TO_AKENEO);
		
		LOGGER.debug("postToAkeneo flag from task variable: " + postToAkeneo);
		
		projectDetails = new ProjectDetails(task, client, ownerId, metaTag);
		
		translationTask = new TranslationTask(client, task, source, targets);
	}
	
	/**
	 * Create a new instance of the TranslationJob class using the provided
	 * task to pull the required information from.  This information includes
	 * the task owner name, the task owner e-mail address, and the job contact
	 * e-mail address.
	 * @param client The current CSClient instance
	 * @param task The current CSTask instance
	 * @param ownerId The translation job owner identifier
	 * @param source The SyndicationTarget source locale
	 * @param targets A Set of SyndicationTarget targets locales
	 * @throws CSException
	 */
	public TranslationJob(CSClient client, CSTask task, String ownerId, SyndicationTarget source, Set<SyndicationTarget> targets) throws CSException {
		initiatorId = task.getOwner().getName();
		LOGGER.debug("Project Initiator: " + initiatorId);
		initiatorEmail = task.getOwner().getEmailAddress();
		LOGGER.debug("Project Initiator E-mail: " + initiatorEmail);
		
		jobContact = getJobContactEmail(task); 
		
		postToAkeneo=task.getVariable(VAR_POST_TO_AKENEO);
		
		LOGGER.debug("postToAkeneo flag from task variable: " + postToAkeneo);
		
		projectDetails = new ProjectDetails(task, ownerId);
		
		translationTask = new TranslationTask(client, task, source, targets);
	}
	// We need this constructor for the builder method later
	private TranslationJob() { }
	
	/** Get the project initiator id */
	public String getInitiatorId() {
		return initiatorId;
	}
	
	/** Get the post To Akeneo flag value*/
	public String getpostToAkeneo() {
		return postToAkeneo;
	}
	/** Get the project initiator e-mail address */
	public String getInitiatorEmail() {
		return initiatorEmail;
	}
	/** Get the project contact */
	public String getJobContact() {
		return jobContact;
	}
	/** Get the project details */
	public ProjectDetails getProjectDetails() {
		return projectDetails;
	}
	/** Get the project translation task */
	public TranslationTask getTranslationTask() {
		return translationTask;
	}
	
	/**
	 * Build the translation job XML element for the Across control.xml file
	 * represented by the content of this instance.
	 * @return The XML element to be included in a control.xml file
	 */
	public Element toElement() {
		Element element = DocumentHelper.createElement("translationJob");
		
		element.addElement("initiatorId").setText(initiatorId);
		element.addElement("initiatorEmail").setText(initiatorEmail);
		
		element.addElement("jobContacts").addElement("jobContactEmail").setText(jobContact);
		
		Element projectElement = element.addElement("acrossPjt");
		
		LOGGER.debug("Before postToAkeneo flag during Control XML creation: " + postToAkeneo);
		
		if(postToAkeneo!=null && !postToAkeneo.isEmpty()) 		//Special Case handling for files with due date after Automating postToAkeneo implementation 
			{ 		
				element.addElement("postToAkeneo").setText(postToAkeneo);
				LOGGER.debug("Inside postToAkeneo flag during Control XML creation: " + postToAkeneo);
			}
		
		
		projectElement.add(projectDetails.toElement());
		
		projectElement.add(translationTask.toElement());
		
		return element;
	}
	
	/**
	 * Build a TranslationJob instance from the provided XML Element instance.
	 * @param element The XML Element instance from which to build a TranslationJob
	 * @param configuration The configured SyndicationTarget set
	 * @return The TranslationJob instance built from the provided XML Element instance
	 */
	static TranslationJob build(Document document, Set<SyndicationTarget> configuration) {
		String postToAkeneo=null; 
		Element root = document.getRootElement();
		String initiatorId = root.elementText("initiatorId");
		LOGGER.debug("Project Initiator ID: " + initiatorId);
		String initiatorEmail = root.elementText("initiatorEmail");
		LOGGER.debug("Project Initiator E-mail: " + initiatorEmail);
		String jobContact = root.selectSingleNode("jobContacts/jobContactEmail").getText();
		LOGGER.debug("Project Job Contact: " + jobContact);
			try{
				if((root.elementText("postToAkeneo")!=null) && (!root.elementText("postToAkeneo").isEmpty()))		//Special Case handling for files with due date after Automating postToAkeneo implementation 
				{
				postToAkeneo= root.elementText("postToAkeneo");
				LOGGER.debug("Post to Akeneo Flag Value: " + postToAkeneo);
				}
			}
			catch(Exception ex)
		        {
		               
		                LOGGER.error("Exception Occured while parsing control.xml -->Post to Akeneo Flag Missing",ex);
		                LOGGER.debug("Post to Akeneo Flag Value Not Set: " + postToAkeneo);
		
		        }	
		Element projectElement = root.element("acrossPjt");
		Element projectDetailsElement = projectElement.element("pjtDtls");
		Element translationTaskElement = projectElement.element("translationTask");
		Element simpleTaskElement = translationTaskElement.element("simpleTask");
		
		TranslationJob translationJob = new TranslationJob();
		translationJob.initiatorId = initiatorId;
		translationJob.initiatorEmail = initiatorEmail;
		translationJob.jobContact = jobContact;
		if(postToAkeneo!=null && !postToAkeneo.isEmpty())
			{	
				LOGGER.debug("Post to Akeneo Flag Value NOT Null setting in TranslationJob: " + postToAkeneo);
				translationJob.postToAkeneo=postToAkeneo;
			}
		translationJob.projectDetails = ProjectDetails.build(projectDetailsElement);
		translationJob.translationTask = TranslationTask.build(simpleTaskElement, configuration);
		
		return translationJob;
	}
	
	/* Get the job contact (or project manager) e-mail address from the provided CSTask instance */
	static String getJobContactEmail(CSTask task) throws CSException {
		String jobContact = task.getVariable(VAR_JOB_CONTACT);
		LOGGER.debug("Project Job Contact Variable: " + jobContact);
		String[] parts = jobContact.split(TranslationTask.DATASOURCE_DELIMITER);
		if (parts != null && parts.length > 0) {
			jobContact = parts[0];
		}
		LOGGER.debug("Project Job Contact Email: " + jobContact);
		return jobContact;
	}
	
	/* Get the job contact (or project manager) name from the provided CSTask instance */
	//static String getJobContactName(CSTask task) throws CSException {
	static ArrayList<String> getJobContactName(CSTask task) throws CSException {
		ArrayList<String> jobMultiContact = new ArrayList<String>();
		String jobContact = task.getVariable(VAR_JOB_CONTACT);
		LOGGER.debug("Project Job Contact Variable: " + jobContact);
		String[] parts = jobContact.split(TranslationTask.DATASOURCE_DELIMITER);
		if (parts != null && parts.length > 1) {
			jobMultiContact.add(parts[1]);
		} else {
			jobContact = task.getVariable(VAR_PROJECT_MANAGER);
			String jobContactArray[] = jobContact.split(",");
			for(String contact :jobContactArray) {
				jobMultiContact.add(contact);
			}
			
		}
		
		LOGGER.debug("Project Job Contact: " + jobContact);
		return jobMultiContact;
	}

}
