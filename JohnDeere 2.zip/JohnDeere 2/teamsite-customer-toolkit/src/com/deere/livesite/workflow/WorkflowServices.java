package com.deere.livesite.workflow;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.dom4j.Document;
import org.owasp.esapi.ESAPI;

import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.access.CSGroup;
import com.interwoven.cssdk.access.CSUser;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.filesys.*;
import com.interwoven.cssdk.workflow.CSGroupTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSTransitionableTask;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.cssdk.workflow.CSWorkflowEngine;
import com.interwoven.livesite.workflow.WorkflowUtils;
import com.interwoven.serverutils100.utild.UtildClient;
import com.interwoven.serverutils100.utild.UtildClientException;


/**
 * WorkflowServices is a class that provides common workflow utility methods
 * which are used to handle job and task interaction.
 *  Updated for content publish workflow locks and added utility methods for creating file paths to tmp file and reads the file paths from tmp file - QC1035 and QC1041
 * @author Klish Group, Inc. [ND, BA]
 */
public final class WorkflowServices {
	private static final transient Logger LOGGER = Logger.getLogger(WorkflowServices.class);
	
	/** HTTP Servlet Request Attribute name for the CSClient instance */
	public static final String ATTR_CSCLIENT = "iw.csclient";

	private static final String PATH_GLOBAL_BLACKLIST = "/iwadmin/main/deere/syndication/STAGING/configuration/blacklist.txt";

	private static final String VAR_DISABLE_GLOBAL_BLACKLIST = "DisableGlobalBlacklist";
	private static final String VAR_BLACKLIST_PATH		= "BlackListPath";

	private static final String ADMIN_USER_PREFIX = "otadm82";

	private static final String FILE_STRING = "File";

	private static final String ASSET_STRING = "Asset";

	private static final String WORKFLOW_LOCK = "Workflow Lock";

	private static final String USER_LOCK = "User Lock";

	private static final String DEPENDENCY_LOCK = "Dependency Lock";

   // Disallow instantiation of this class since all methods are public static
	public WorkflowServices() { }
	
	/**
	 * Get the current workflow task from the HTTP request context using the
	 * provided client instance
	 * @param request The HTTP request context
	 * @return The CSTask instanceon the request
	 * @throws CSException
	 */
	public static CSTask getTaskFromRequest(HttpServletRequest request) throws CSException {
		return getTaskFromRequest(request, (CSClient) request.getAttribute (ATTR_CSCLIENT));
	}
	/**
	 * Get the current workflow task from the HTTP request context using the
	 * provided client instance
	 * @param request The HTTP request context
	 * @param client The current CSClient instance
	 * @return The CSTask instanceon the request
	 * @throws CSException
	 */
	public static CSTask getTaskFromRequest(HttpServletRequest request, CSClient client) throws CSException {
		String taskId = request.getParameter("taskId");

		if (taskId == null || "".equals(taskId)) {
			taskId = request.getParameter("taskid");
		}
		if (taskId == null || "".equals(taskId)) {
			taskId = request.getParameter("iw_taskid");
		}
		
		LOGGER.debug("CSTask ID: " + ESAPI.encoder().encodeForHTML(taskId));
		
		try {
			CSTask task = client.getTask(Integer.parseInt(taskId));
			setupWorkflowLogging(task);
			return task;
		} catch (NumberFormatException nfe) {
			// TODO: Ignore this the if statement below will handle this case
		}

		return null;
	}
	
	/**
	 * Get the attached DCR files on the provided CSTask instance.
	 * @param task The CSTask instance
	 * @return A list of CSSimpleFile instances attached to the provided CSTask
	 * 		instance that are DCRs.
	 * @throws CSException
	 */
	public static List<CSSimpleFile> getAttachedDCRs(CSTask task) throws CSException {
		List<CSSimpleFile> attachedDCRList = new ArrayList<CSSimpleFile>();
		CSAreaRelativePath[] filePaths = task.getFiles();
		LOGGER.debug("Checking for DCRs among the " + filePaths.length + " attached files");

		for (CSAreaRelativePath filePath : filePaths) {
			CSFile file = task.getArea().getFile(filePath);

			if (file != null && CSSimpleFile.KIND == file.getKind() && CSSimpleFile.kDCR == ((CSSimpleFile) file).getContentKind()) {
				LOGGER.info("DCR File: " + filePath);
				attachedDCRList.add((CSSimpleFile) file);
			} else {
				LOGGER.warn("NOT DCR: " + filePath);
			}
		}

		LOGGER.debug("Found " + attachedDCRList.size() + " DCR(s) attached to the job");
		return attachedDCRList;
	}

	/**
	 * Get a Collection of the groups that are shared by the provided CSGroupTask
	 * @param client The current CSClient instance
	 * @param task The CSGroupTask to inspect
	 * @return A Collection of CSGroup instances shared by the provided task.
	 * @throws CSException
	 */
	public static Collection<CSGroup> getSharedByGroups(CSClient client, CSGroupTask task) throws CSException {
		return getSharedByCollection(client, task, "getSharedByGroups", "getGroup");
	}

	/**
	 * Get a Collection of the users that are shared by the provided CSGroupTask
	 * @param client The current CSClient instance
	 * @param task The CSGroupTask to inspect
	 * @return A Collection of CSUser instances shared by the provided task.
	 * @throws CSException
	 */
	public static Collection<CSUser> getSharedByUsers(CSClient client, CSGroupTask task) throws CSException {
		return getSharedByCollection(client, task, "getSharedByUsers", "getUser");
	}

	private static <T> Collection<T> getSharedByCollection(CSClient client, CSGroupTask task, String taskMethodName, String clientMethodName) throws CSException {
		Collection<T> collection = new ArrayList<>();

		try {
			java.lang.reflect.Method m = task.getClass().getMethod(taskMethodName);
			Object result = m.invoke(task);
			@SuppressWarnings("unchecked")
			T[] array = (T[]) result;

			for (T group : array) {
				collection.add(group);
			}
		} catch (java.lang.reflect.InvocationTargetException | IllegalAccessException ite) {
			throw new CSException(ite); 
		} catch (NoSuchMethodException e) {
			LOGGER.error("Unable to get shared by information.", e);
		}

		return collection;
	}
	
	/**
	 * Get a List of FileLock instances that are attached to the provided CSTask
	 * instance that are locked by a user that is not the current user of the
	 * provided CSClient instance or file locked by other workflow.
	 * @param client The current CSClient instance
	 * @param task The CSTask instance to inspect
	 * @return A List of CSFile instances that are attached to the provided
	 * 		CSTask instance that are locked by a user that is not the current
	 * 		user of the provided CSClient instance.
	 * @throws CSException
	 */
	public List<FileLock> getLockedFiles(CSClient client, CSTask task) throws CSException {
		CSUser user = client.getCurrentUser();
		LOGGER.debug("Checking file locks for: " + user.getName() + " => " + user.getDisplayName());
		//List<CSFile> lockedAndNotOwned = new ArrayList<CSFile>();
		List<FileLock> lockedFiles = new ArrayList<FileLock>();
		for (CSFile file : task.getArea().getFiles(task.getFiles())) {
			if (file != null && CSSimpleFile.KIND == file.getKind()) {
				// updating the logic to check for workflow locks as well
				if (hasUserLock(file,user.getName())){
					lockedFiles.add(addUserLock(file,file.getLockOwner(),FILE_STRING));	
				}else if(isFileAlreadyInWorkflow(task,file,client)){
					// check for workflow lock
					lockedFiles.add(addWorkflowLock(file,task,client,FILE_STRING));	
				}
				/*if (file.isLocked() && !user.equals(file.getLockOwner())) {
					lockedAndNotOwned.add(file);
				}*/
			}
		}
		
		return lockedFiles;
	}
	
	/**
	 * This method deletes the path from ImageList file
	 * @param client CSClient
	 * @param task CSTask
	 * @param path Relative path of the file to be deleted
	 */
	public static void removeAsset(CSClient client,CSTask task,String path){
		try {
			CSFile file = client.getFile(new CSVPath(path));
			if(file != null){
				String imageFileListPath = task.getWorkflow().getVariable("imageFileListPath");
				String imageWorkArea = WorkflowUtils.findVariable(task, "imageWorkArea");
				if (imageWorkArea != null && !"".equals(imageWorkArea) && imageFileListPath != null && !"".equals(imageFileListPath)) {
					CSWorkarea area = client.getWorkarea(new CSVPath(imageWorkArea), false);	
					
					if(area != null){
						LOGGER.debug("Area "+area.getName());
						Set<String> imagePaths = readFileList(imageFileListPath);
						if (imagePaths != null) {
							writeImageFileList(imageFileListPath,imagePaths,file.getVPath().getAreaRelativePath().toString());
						}
					}
				}
			}	
		}catch(Exception e){
			LOGGER.error("Error while removing the asset from image File list file",e);	
		}
		
	}
	
	/**
	 * This method writes the images paths to an imageList file by deleting the path from it. 
	 * @param fileName  path to image file name
	 * @param imagePaths set of image path
	 * @param path path of the file to be deleted
	 * @throws IOException
	 */
	private static void writeImageFileList (String fileName, Set<String> imagePaths, String path) throws IOException {
		BufferedWriter writer = null;
		try{
		writer = Files.newBufferedWriter (Paths.get (fileName), StandardCharsets.UTF_8);
			for (String csa : imagePaths) {
				if(!csa.equals(path)){
					writer.write ("/"+csa);
					writer.newLine ();
				}
				
			}
		}catch (IOException e) {
			LOGGER.error("Error while writing paths to file:"+fileName,e);
		}finally{
			if(writer != null){
				try {
					writer.close();
				} catch (IOException e) {
					LOGGER.error("Error while closing file :"+fileName,e);
				}
			}
		}
		
	}
	/**
	 * Get a List of FileLock instances that are attached to the provided CSTask
	 * instance that are locked by a user or other workflows or dependencies that is not the current user of the
	 * provided CSClient instance.
	 * - User Lock : File locked by other user
	 * - workflow Lock : File is locked by one or more other workflows
	 * - Dependency Lock : Page is locked by its dependencies(DCRs) if its dependencies has either user lock or workflow lock 
	 * @param client The current CSClient instance
	 * @param task The CSTask instance to inspect
	 * @return A List of CSFile instances that are attached to the provided
	 * 		CSTask instance that are locked by a user that is not the current
	 * 		user of the provided CSClient instance.
	 * @throws CSException
	 */
	public List<FileLock> getLockedFilesDetails(CSClient client, CSTask task) throws CSException {
		CSUser user = client.getCurrentUser();
		List<FileLock> lockedFiles = new ArrayList<FileLock>();
		FileLock fileLock = null;
		String filterPattern;
		FileDependencyAnalyzer analyzer = null;
		Set<String> blacklist = null;
		
		boolean analyzerLoaded=false;
		for (CSFile file : task.getArea().getFiles(task.getFiles())) {
			//process all attached Files for file locks
			LOGGER.debug("Inside getLockedFilesDetails processing file - "+file.getName());
			if (file != null && CSSimpleFile.KIND == file.getKind() && CSSimpleFile.kDCR != ((CSSimpleFile)file).getContentKind() ) {
				LOGGER.debug("Inside file kind check");
				if (hasUserLock(file,user.getName())){
					lockedFiles.add(addUserLock(file,file.getLockOwner(),FILE_STRING));	
				}else if(isFileAlreadyInWorkflow(task,file,client)){
					// check for workflow lock
					lockedFiles.add(addWorkflowLock(file,task,client,FILE_STRING));	
				}else if("page".equals(file.getVPath().getExtension()) && file.getVPath().toString().contains("/sites/")){
					// check for dependency lock
					if(!analyzerLoaded){
						blacklist = getBlackList(task,client);
						filterPattern = FileDependencyAnalyzer.getFilterPatternString(task);
						analyzer = new FileDependencyAnalyzer(client, task.getArea(), filterPattern);
					}
					List<FileDependency> dependencies = analyzer.analyze((CSSimpleFile) file);
					Set<CSAreaRelativePath> dependenciesList = new TreeSet<CSAreaRelativePath>();
					
					for (FileDependency dependency : dependencies) {
						if (!isInBlacklist(blacklist, dependency.getPath())) {
							dependenciesList.add(dependency.getPath());
							LOGGER.debug("Dependency file name:"+dependency.getPath());
						}
					}
					
					if(!dependenciesList.isEmpty()){
						List<FileLock> dependencyLocks =  getDependecyLocks(client,task,dependenciesList,user.getName());
						for (FileLock lockedFile : dependencyLocks) {
							if (!isFileAttached(task, lockedFile.getFile(), task.getArea())) {
							LOGGER.debug("File not found in running workflow's task,removing file :"+lockedFile.getFile().getVPath());	
							dependencyLocks.remove(lockedFile);
							}
						}
						if(dependencyLocks != null && !dependencyLocks.isEmpty()){
							fileLock = new FileLock();
							fileLock.setFilePath(file.getVPath().getAreaRelativePath().toString());
							fileLock.setLockMessage("One or more dependencies locked");
							fileLock.setLockType(DEPENDENCY_LOCK);
							fileLock.setDependencyLocks(dependencyLocks);
							fileLock.setFile(file);
							fileLock.setFileType(FILE_STRING);
							lockedFiles.add(fileLock);
							LOGGER.debug("File has Dependency Lock:"+fileLock.getFilePath());
						}
					}
					
				}
			}
			else{
				LOGGER.debug("File is DCR name : "+file.getName());
			}
		}
		//check for image locks
		List<FileLock> imageLocks = getImageLocks(task,client);
		if(!imageLocks.isEmpty()){
			lockedFiles.addAll(imageLocks);
		}
		
		return lockedFiles;
	}
	
	
	/**
	 * This method checks the locks for images which are being deployed through Content Publish workflow and gives the list of FileLocks instances if there are any locks on images files.
	 * @param task CSTask
	 * @param client CSClient
	 * @return
	 */
	private List<FileLock> getImageLocks(CSTask task, CSClient client) {
		List<FileLock> imageLocks = new ArrayList<FileLock>();
		try {
			String imageFileListPath = task.getWorkflow().getVariable("imageFileListPath");
			String imageWorkArea = WorkflowUtils.findVariable(task, "imageWorkArea");
			if (imageWorkArea != null && !"".equals(imageWorkArea) && imageFileListPath != null && !"".equals(imageFileListPath)) {
				CSWorkarea area = client.getWorkarea(new CSVPath(imageWorkArea), false);	
				
				if(area != null){
					Set<String> imagePaths = readFileList(imageFileListPath);
					if (imagePaths != null) {
						String userName = task.getOwner().getName();
						for (String imagePath : imagePaths) {
							try {
								CSFile file = area.getFile(new CSAreaRelativePath(imagePath));
								if (file != null && file.getKind() == CSSimpleFile.KIND) {
									if (hasUserLock(file,userName)){
										// check with Sarang if user don't have any display name like with uid
										imageLocks.add(addUserLock(file,file.getLockOwner(),ASSET_STRING));
										LOGGER.debug("Added Asset to User Lock List:"+file.getVPath().getAreaRelativePath().toString());
									}else if(isFileAlreadyInWorkflow(task,file,client)){
										// check for workflow lock
										imageLocks.add(addWorkflowLock(file,task,client,ASSET_STRING));
										LOGGER.debug("Added Asset to Workflow Lock List:"+file.getVPath().getAreaRelativePath().toString());
									}
								} 
							} catch (CSException e) {
								LOGGER.error("Connectivity or permissions problem", e);
							}
						}
					}
					
				}
			}
		} catch (CSException e) {
			LOGGER.error("Error while checking locks for images",e);
			
		
		}
				
		return imageLocks;
	}

	/** It reads the file and gives the set of files
	 * @param fileListPath Path of the file on the file system
	 * @return
	 */
	public static Set<String> readFileList(String fileListPath) {
		Set<String> paths = new TreeSet<String>();
		BufferedReader reader = null;
		try {
			//Checking if file exits
			LOGGER.debug("File List Path:"+fileListPath);
			if(new File(fileListPath).exists()){
			reader = Files.newBufferedReader(Paths.get(fileListPath), Charset.defaultCharset());

			String imagePath = null;
			while ((imagePath = reader.readLine()) != null) {
				if(imagePath.startsWith("/")){
					imagePath = imagePath.substring(1);
				}
				paths.add(imagePath);
				LOGGER.debug("Added to File List:"+imagePath);
			}
			reader.close();
			return paths;
			}
			} catch (IOException e) {
			LOGGER.error("Exception Reading a file list ", e);
			
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception ex) {
					LOGGER.error ("Caught Exception in closing the BufferReader in readFileList for WorkflowService : " ,ex);
				}
			}
		}
		return null;
	}

	/**
	 * This method gives the list of black list files
	 * @param task CSTask
	 * @param client CSClint
	 * @return
	 */
	private Set<String> getBlackList(CSTask task, CSClient client) {
		Set<String> blacklist = new TreeSet<>();
		
		// Check if the global black list is disabled
		try {
			if (!Boolean.parseBoolean(task.getVariable(VAR_DISABLE_GLOBAL_BLACKLIST))) {
				blacklist.addAll(loadBlacklistFile(client, new CSVPath(PATH_GLOBAL_BLACKLIST)));
			}
			// Load the blacklist file to filter out anything like default.site
			String blacklistPath = task.getVariable(VAR_BLACKLIST_PATH);
			LOGGER.debug("Blacklist Path: " + blacklistPath);
			
			if (blacklistPath != null && !"".equals(blacklistPath)) {
				CSVPath staging = task.getArea().getBranch().getStaging().getVPath().concat(blacklistPath);
				blacklist.addAll(loadBlacklistFile(client, staging));
			}
		} catch (CSException e) {
			LOGGER.error("Error whil eretreiving the black List",e);
			
		}
		LOGGER.debug("Black List: " + blacklist);
		
		return blacklist;
	}

	/**
	 * This method loads the black list file and returns the black list files
	 * @param client CSClient
	 * @param path Vpath of the black list configuration file
	 * @return
	 * @throws CSException
	 */
	private Set<String> loadBlacklistFile(CSClient client, CSVPath path) throws CSException {
		LOGGER.debug("Loading BlackList: " + path);
		CSFile file = client.getFile(path);
		
		if (file != null && CSSimpleFile.KIND == file.getKind()) {
			CSSimpleFile simpleFile = (CSSimpleFile) file;
			
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(simpleFile.getInputStream(true)))) {
				Set<String> lines = new TreeSet<>();
				String line = null;
				
				while ((line = reader.readLine()) != null) {
					LOGGER.debug("Blacklist Path: " + line);
					lines.add(line);
				}
				
				LOGGER.debug("Blacklist: " + lines);
				return lines;
			} catch (IOException ioe) {
				throw new CSException(ioe);
			}
		}
		
		return Collections.emptySet();
	}

	/** 
	 * This method add the workflow lock details and returns FileLock instance
	 * @param file CSFile
	 * @param task CSTask
	 * @param client CSClient
	 * @param fileType fileType is either Asset or File
	 * @return
	 */
	private FileLock addWorkflowLock(CSFile file, CSTask task, CSClient client,String fileType) {
		FileLock fileLock = new FileLock();
		fileLock.setFilePath(file.getVPath().getAreaRelativePath().toString());
		fileLock.setLockMessage("Locked by other workflows");
		fileLock.setJobIds(getWorkflowJobs(task,file,client));
		fileLock.setLockType(WORKFLOW_LOCK);
		fileLock.setFile(file);
		fileLock.setFileType(fileType);
		LOGGER.debug(fileLock.getFilePath()+" "+fileLock.getLockMessage()+":"+fileLock.getJobIds());
		return fileLock;
	}

	/**
	 * This method add the User lock details and returns FileLock instance
	 * @param file CSFile
	 * @param lockOwner CSUser
	 * @param fileType either Asset or File
	 * @return
	 */
	private FileLock addUserLock(CSFile file, CSUser lockOwner,String fileType) {
		FileLock fileLock = new FileLock();
		fileLock.setFilePath(file.getVPath().getAreaRelativePath().toString());
		String lockOwnerName = lockOwner.getName();
		String displayName = null;
		String emailId = null;
		boolean hasEmailId = false;
		String lockMessage = "";
		
		try{
			displayName = lockOwner.getDisplayName();
			emailId = lockOwner.getEmailAddress();
		}catch(CSException e){
			LOGGER.error("Error while retrieving Display Name or email address");
		}
		if(displayName == null || "".equals(displayName)){
			displayName = lockOwner.getName();
		}
		if(emailId != null && !"".equals(emailId)){
			hasEmailId = true;
		}
		
		if(lockOwnerName != null && !"".equals(lockOwnerName)){
			
			if(hasEmailId){
				lockMessage = " <span class=\"pull-left\">Locked by </span><a id=\"iw.ccpro.user_details.link\" class=\"iw-base-link pull-left\" title=\""+lockOwnerName+"("+emailId+")\" onclick=\"javascript:fw_widgets.open_new_window(this); return false;\" href=\"/iw-cc/command/iw.teamsite.view_user_details?userName="+lockOwnerName+"\" iw_wf=\"width=500,height=500,scrollbars=0,resizable=1,center=true,relative=true\" iw_enabled=\"true\" class=\"iw-base-link\" target=\"_blank\">"+displayName+"</a>";
			}else{
				lockMessage = " <span class=\"pull-left\">Locked by </span><a id=\"iw.ccpro.user_details.link\" class=\"iw-base-link pull-left\" title=\""+displayName+"\" onclick=\"javascript:fw_widgets.open_new_window(this); return false;\" href=\"/iw-cc/command/iw.teamsite.view_user_details?userName="+lockOwnerName+"\" iw_wf=\"width=500,height=500,scrollbars=0,resizable=1,center=true,relative=true\" iw_enabled=\"true\" class=\"iw-base-link\" target=\"_blank\">"+displayName+"</a>";
			}
		}
		fileLock.setLockMessage(lockMessage);
		fileLock.setLockType(USER_LOCK);
		fileLock.setFile(file);
		fileLock.setFileType(fileType);
		LOGGER.debug(fileLock.getFilePath()+"::"+fileLock.getLockMessage());
		return fileLock;
		
	}

	/**
	 * This method gives the list of FileLock instances for the dependency locks
	 * 
	 * @param client
	 *            CSClient
	 * @param task
	 *            CSTask
	 * @param dependenciesList
	 *            Dependencies List
	 * @param userName
	 *            user name of the task owner
	 * @return
	 */
	private List<FileLock> getDependecyLocks(CSClient client, CSTask task, Set<CSAreaRelativePath> dependenciesList,
			String userName) {
		List<FileLock> lockedFiles = new CopyOnWriteArrayList<>();
		List<FileLock> schedulerlockedFiles = new CopyOnWriteArrayList<>();
		try {
			schedulerlockedFiles = getAllWFScheduledFiles(client,task);
			LOGGER.debug("schedulerlockedFiles Object Size "+schedulerlockedFiles.size());
			LOGGER.debug("schedulerlockedFiles Object toString() "+schedulerlockedFiles.toString());
			CSArea area = task.getArea();
			for (CSAreaRelativePath file : dependenciesList) {
				CSFile csFile = area.getFile(file);
				if (csFile != null && csFile.getKind() == CSSimpleFile.KIND) {

					LOGGER.debug("File is  present in the task,processing to get lock on the file");
					if (hasUserLock(csFile, userName)) {
						lockedFiles.add(addUserLock(csFile, csFile.getLockOwner(), FILE_STRING));

					} else if (isFileAlreadyInWorkflow(task, csFile, client)) {
						lockedFiles.add(addWorkflowLock(csFile, task, client, FILE_STRING));
					}
                       else if(schedulerlockedFiles.size()>0) {
						
						for(FileLock schedulerlockedFile:schedulerlockedFiles) {
							
							String s = schedulerlockedFile.getFilePath();
							String csvapths = csFile.getVPath().getAreaRelativePath().toString();
							if(s.equalsIgnoreCase(csvapths)) {
								LOGGER.debug("Both are equal >>"+s+" and "+csvapths);
								lockedFiles.add(addScheduleLock(csFile.getVPath().getAreaRelativePath().toString(), Integer.parseInt(schedulerlockedFile.getJobIds()), schedulerlockedFile.getFile()));
							}
						}
						
					}
				}

				else {
					LOGGER.debug("File is not present in the task,not processing");
				}
			}

		

		} catch (CSException e) {
			LOGGER.error("Error while checking dependency Locks", e);
		}

		return lockedFiles;
	}
	private List<FileLock> getAllWFScheduledFiles(CSClient client, CSTask task) {
		
		LOGGER.debug(" Get all the WF Scheduled Files");
		List<FileLock> schedulerlockedFilesParameter = new CopyOnWriteArrayList<>();
		try {
			CSWorkarea waMain = client.getWorkarea(task.getArea().getVPath(), false);
			String countryCode = waMain.getBranch().getParentBranch().getName();
			String setLocale= waMain.getBranch().getName();
		
			
			List<FileLockCheck> scheduledWorkflowDetails = getScheduledWorkflowDetails(client,countryCode,setLocale);
			LOGGER.debug("scheduledWorkflowDetails "+scheduledWorkflowDetails.size());
			LOGGER.debug("scheduledWorkflowDetails to String is "+scheduledWorkflowDetails.toString());
			if(scheduledWorkflowDetails.size() > 0) {
				List<String> filesFromTask = new ArrayList<>();
				CSAreaRelativePath[] csareafiles = task.getFiles();
				for(CSAreaRelativePath csafile:csareafiles) {
					if(csafile.getParentPath().toString().contains("templatedata/") || csafile.getName().contains(".page") ) {
					filesFromTask.add(task.getArea().getUAI()+File.separator+csafile.getParentPath()+File.separator+csafile.getName());
					}
				}
				
			LOGGER.debug("Files attached in the Task is "+filesFromTask.toString());
			   for(FileLockCheck fileinWFCheck:scheduledWorkflowDetails) {
				   if(fileinWFCheck.getCountry().equalsIgnoreCase(countryCode) && fileinWFCheck.getLocale().equalsIgnoreCase(setLocale)) {
					   HashMap<String, String> finalMap =  fileinWFCheck.getMap();
					   for(String filetaken:filesFromTask) {
						   if(finalMap.get(filetaken) != null) {
							   CSFile csFile = client.getFile(new CSVPath(finalMap.get(filetaken)));
							   String fileToPass = finalMap.get(filetaken).replace(task.getArea().getUAI()+File.separator, "");
							   schedulerlockedFilesParameter.add(addScheduleLock(fileToPass,fileinWFCheck.getJobId(),csFile));
							   
						   }
						   
					   }
					   
				   }
			   }
	}
		} catch (CSException e) {

			LOGGER.error ("Caught exception in getAllWFScheduledFiles method  for WorkflowServices : " + e + e.getMessage ());
		}  

	return schedulerlockedFilesParameter;
		}
	private FileLock addScheduleLock(String fileToPass, int i, CSFile csFile) {
		
		FileLock fileLock = new FileLock();
		fileLock.setFilePath(fileToPass);
		fileLock.setLockMessage("Locked by Scheduled workflow");
		fileLock.setJobIds(Integer.toString(i));
		fileLock.setLockType(WORKFLOW_LOCK);
		fileLock.setFile(csFile);
		fileLock.setFileType(FILE_STRING);
		LOGGER.debug(fileLock.getFilePath()+" "+fileLock.getLockMessage()+":"+fileLock.getJobIds());
		return fileLock;
			
		}

	private List<FileLockCheck> getScheduledWorkflowDetails(CSClient client, String countryCode, String setLocale) {
		
		LOGGER.debug("Method tto Get all the WF Scheduled Details");
		List<FileLockCheck> flc = new ArrayList<>();
		try {
			CSWorkflow jobs[] = client.getWorkflowEngine().getWorkflowsByQuery("<wfquery><active/></wfquery>");
			for(CSWorkflow job:jobs) {
				CSTask[] tasks =job.getTasks();
			       for(CSTask cstask:tasks) {
				    if(cstask.getName().equalsIgnoreCase("ScheduleTask")) {
	                         if(cstask.getAbsoluteTimeout() != null) {
	                        	 
	                        	 List<String> filesToAdd = new ArrayList<String>();
	                        	 HashMap<String, String> filemap = new HashMap<>(); 
	                        	 CSTask[] checkingTask =job.getTasks();
	                 			  for(CSTask dependencyTask:checkingTask) {
	                 				
		                 				if(dependencyTask.getName().equalsIgnoreCase("Attach Page Dependencies")) {
		                 					
		                 					CSWorkarea wa  = client.getWorkarea(dependencyTask.getArea().getVPath(), false);
		                 					String countryCheck =wa.getBranch().getParentBranch().getName();
		                 					String localeCheck = wa.getBranch().getName();
		                 					if(countryCheck.equalsIgnoreCase(countryCode) && localeCheck.equalsIgnoreCase(setLocale) ) {
		                 					
		                 					FileLockCheck fCheck = new FileLockCheck();
		                 					fCheck.setCountry(wa.getBranch().getParentBranch().getName());
		                 					fCheck.setLocale(wa.getBranch().getName());
		                 					fCheck.setJobId(job.getId());
		                 					fCheck.setJobOwner(job.getOwner().getDisplayName());
		                 					
		                 					CSAreaRelativePath[] tt =dependencyTask.getFiles();
			                 					for(CSAreaRelativePath y:tt) {
			                 						String fileCSAR = dependencyTask.getArea().getUAI()+File.separator+y.getParentPath()+File.separator+y.getName();
			                 					filesToAdd.add(fileCSAR);
			                 					filemap.put(fileCSAR, fileCSAR);
			                 					}
			                 					fCheck.setFile(filesToAdd);
			                 					fCheck.setMap(filemap);
			                 					flc.add(fCheck);
			                 					LOGGER.debug("fCheck "+fCheck.toString());
		                 					}
		                 					
		                 					
		                 				}
	                 			}
	                 			 
	                 			  
				    		   }
				    		   
				    	   }
				    
				    	   
				       }
			}
		} catch (CSException e) {

			LOGGER.error ("Caught exception in getScheduledWorkflowDetails method  for WorkflowServices : " + e + e.getMessage ());
		}
		   LOGGER.debug("No of scheduled file Objects is "+flc.size());
		   LOGGER.debug("No of scheduled file Objects is  "+flc.toString());
			return flc;
		}


/**
 * Checks if file passed in argument is present in the task
 * @throws CSException 
 * @throws CSExpiredSessionException 
 * @throws CSObjectNotFoundException 
 * @throws CSRemoteException 
 * @throws CSAuthorizationException 
 */
private boolean	isFileAttached(CSTask task,CSFile dependentFile,CSArea area) throws CSAuthorizationException, CSRemoteException, CSObjectNotFoundException, CSExpiredSessionException, CSException{
	CSAreaRelativePath[] attachedFiles=task.getFiles();
	for(CSAreaRelativePath file:attachedFiles){
		CSFile csFile = area.getFile(file);
		LOGGER.debug("Attached file file name :"+csFile.getVPath().getAreaRelativePath());
		LOGGER.debug("Dependent file name :"+dependentFile.getVPath().getAreaRelativePath());
		 
		if(csFile.getVPath().getAreaRelativePath().equals(dependentFile.getVPath().getAreaRelativePath()))
		{
			LOGGER.debug("File is present in the attached list ::returning true");
			return true;
		}
		
	}
	LOGGER.debug("File is not present in the attached list ::returning false");
	return false;
		
	}

	/**
	 * It checks whether the CSFile  is locked by other user(other than userName) or not.
	 * @param file CSFile
	 * @param userName userName of the task owner
	 * @return true if CSFile is locked by other user, otherwise false 
	 */
	private boolean hasUserLock(CSFile file, String userName) {
		try {
			if(file.isLocked() && !userName.equals(file.getLockOwner().getName()) && !(file.getLockOwner().getName().startsWith("otadm"))){
				return true;
			}
		} catch (CSException e) {
			LOGGER.error("Error while checking User Lock :"+file.getVPath().getAreaRelativePath().toString(),e);
		}
		return false;
	}

	/**
	 * This checks whether the path is in black list files or not.
	 * @param blacklist set of blacklist files
	 * @param path relativepath of the file
	 * @return
	 */
	private boolean isInBlacklist(Set<String> blacklist, CSAreaRelativePath path) {
		if(blacklist != null){
			String item = path.toString();
			LOGGER.debug("Looking for path: " + item + " in blacklist");
			for (String regex : blacklist) {
				LOGGER.debug("Blacklist pattern: " + regex + " => " + item);
				if (item.matches(regex)) {
					LOGGER.debug("Match found in blacklist");
					return true;
				}
			}
		}
				
		return false;
	}

	/**
	 * This method gives the workflow job ids for a CSFile other than CSTask's workflow
	 * @param task CSTask
	 * @param file CSFIle
	 * @param client CSClient
	 * @return
	 */
	private String getWorkflowJobs(CSTask task, CSFile file, CSClient client) {
		String jobIds="";
		try {
			int[] taskIds = file.getRelatedTaskIds();
			int currenttaskId = task.getId();
			for(int i=0;i<taskIds.length;i++){
				if(currenttaskId != taskIds[i]){
					CSTask oldTask = client.getTask(taskIds[i]);
					if (null!=oldTask && oldTask.getWorkflow().isActive() && !(oldTask.getWorkflow().getOwner().getName().startsWith(ADMIN_USER_PREFIX)) && oldTask.getWorkflowId() != task.getWorkflowId()) {
						jobIds=jobIds+","+oldTask.getWorkflow().getId();
					}
					
				}
			}
		} catch (CSException e) {
			LOGGER.error("Error while retreiving the file releated tasks:"+file.getVPath().toString());
		}
		if(jobIds != null && jobIds.length()>0){
			jobIds = jobIds.substring(1);
		}
		
		return jobIds;
	}

	/**
	 * This methods checks CSFile is already in any other workflow other than CSTask's workflow 
	 * @param task CSTask
	 * @param file CSFile
	 * @param client CSClient
	 * @return
	 */
	private boolean isFileAlreadyInWorkflow(CSTask task, CSFile file, CSClient client) {
		try {
			int[] taskIds = file.getRelatedTaskIds();
			int currenttaskId = task.getId();
			for(int i=0;i<taskIds.length;i++){
				if(currenttaskId != taskIds[i]){
					CSTask oldTask = client.getTask(taskIds[i]);
					if (null!=oldTask && oldTask.getWorkflow().isActive() && oldTask.getWorkflowId() != task.getWorkflowId() && !(oldTask.getWorkflow().getOwner().getName().startsWith(ADMIN_USER_PREFIX))) {
						return true;
					}
					
				}
			}
		} catch (CSException e) {
			LOGGER.error("Error while retreiving the file releated tasks:"+file.getVPath().toString(),e);
		}
		
		return false;
	}

	/**
	 * Transition the workflow task using the transition name specified by value
	 * of the provided task variable otherwise use the provided default
	 * transition name.
	 * @param task The current CSTask instance
	 * @param variableName The name of the variable containing the transition
	 * @param defaultName The default transition name to use when none is specified on the task
	 * @return The next active CSTask instance
	 * @throws CSException
	 */
	public static CSTask chooseNamedTransition(CSTransitionableTask task, String variableName, String defaultName, String comment) throws CSException {
		// Pull the transition from the current task or use the default
		String transition = task.getVariable(variableName);
		if (transition == null || "".equals(transition)) {
			transition = defaultName;			
		}
		
		// Choose the transition on the workflow; make sure the task is still active
		if (task.isActive()) {
			return task.chooseTransition(transition, comment);
		}
		
		return null;
	}
	
	
	/**
	 * Setup Apache log4j MDC Workflow Identification information
	 * @param task The current workflow task
	 * @return Flag indicator if the workflow information was successfully setup
	 */
	public static boolean setupWorkflowLogging(CSTask task) {
		if (task != null) {
			String workflowId = "0";
			try {
				workflowId = Integer.toString(task.getWorkflowId());
			} catch (CSException cse) {
			}
			String taskId = Integer.toString(task.getId());
			LOGGER.debug("Workflow: " + workflowId + " >> " + taskId);
			MDC.put("WorkflowId", workflowId + ":" + taskId);
			
			return true;
		}
		
		return false;
	}

	/**
	 * This method will send the request to urladdress with data and request params
	 * @param urlAddress URL address
	 * @param postData body data
	 * @param params request params Map
	 */
	public static void sendRequest(String urlAddress, byte[] postData, Map<String, String> params) {
		OutputStream wr = null;
		URL url;
		try {
			url = new URL(urlAddress);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty ("Content-Type", "application/json");

			if(params != null && !params.isEmpty()){
				for(Map.Entry<String, String> entry:params.entrySet()){
					conn.setRequestProperty(entry.getKey(), entry.getValue());
					LOGGER.debug(entry.getKey()+":"+entry.getValue());
				}
			}
			
			wr = conn.getOutputStream();
			wr.write (postData);
			wr.flush();
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Successfully sent request to WSO2 end point:"+urlAddress);
			}	    
			
			BufferedReader responseBuffer = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("==============Output from WSO2 end point========================");
			}
			
			while ((output = responseBuffer.readLine()) != null) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(ESAPI.encoder().encodeForHTML(output));
				}
			}
				      
			if(wr != null){
				wr.close();
			}
			
		} catch (Exception e) {
			LOGGER.error("Error while sending request to wso2 end point:"+urlAddress,e);
		}
		
	}
	
	/**
	 * This methods creates file on the file system and writes file paths to the file
	 * @param fileName path of the file
	 * @param pathsSet set of file paths
	 * @return
	 */
	public static boolean writeFileList (String fileName, Set<String> pathsSet){
		boolean writtenToFile=false;
		BufferedWriter writer = null;
		try {
			writer = Files.newBufferedWriter (Paths.get (fileName), StandardCharsets.UTF_8);
			for (String path : pathsSet) {
				writer.write (path);
				writer.newLine ();
			}
			writtenToFile=true;
		} catch (IOException e) {
			LOGGER.error("Error while writing paths to file:"+fileName,e);
		}finally{
			if(writer != null){
				try {
					writer.close();
				} catch (IOException e) {
					LOGGER.error("Error while closing file :"+fileName,e);
				}
			}
		}
		return writtenToFile;
		
	}
	
	/**
	 * 
	 * This method checks the attached files and returns true if any of the file is other than DCR, otherwise return false.
	 * @param client
	 * @param task
	 * @return
	 */
	public boolean checkForOtherThanDCRs(CSClient client,CSTask task){
		try{
			for (CSFile file : task.getArea().getFiles(task.getFiles())) {
				if(file != null && CSSimpleFile.KIND == file.getKind() && CSSimpleFile.kDCR != ((CSSimpleFile)file).getContentKind()){
					LOGGER.debug("Found the file is other than DCR:"+file.getVPath().getAreaRelativePath().toString());
					return true;
				}
			}
		}catch(Exception e){
			LOGGER.error("Error while retrieving the attached Files",e);
		}
		
		return false;
		
	}
	
	public List<CSAreaRelativePath> getDependencies(String path,CSClient client,CSTask task){
		List<CSAreaRelativePath> dependenciesList = new ArrayList<CSAreaRelativePath>();
		try {
			CSFile file = client.getFile(new CSVPath(path));
			if(file != null && "page".equals(file.getVPath().getExtension()) && file.getVPath().toString().contains("/sites/")){
				Set<String> blacklist = getBlackList(task,client);
				String filterPattern = FileDependencyAnalyzer.getFilterPatternString(task);
				FileDependencyAnalyzer analyzer = new FileDependencyAnalyzer(client, task.getArea(), filterPattern);
				List<FileDependency> dependencies = analyzer.analyze((CSSimpleFile) file);
				for (FileDependency dependency : dependencies) {
					if (!isInBlacklist(blacklist, dependency.getPath()))
					{
						dependenciesList.add(dependency.getPath());
					}
				}
				return dependenciesList;
			}
		} catch (CSException e) {
			LOGGER.error("Erroe while retreiving page dependencies:"+path,e);
			
		}
		
		return dependenciesList;
		
	}
	
	public void unlock(String path, CSClient client,String csFactory){
		
		if (csFactory == null || "".equals(csFactory)) {
			csFactory = "com.interwoven.cssdk.factory.CSJavaFactory";
		}
		Properties properties = new Properties();
		properties.setProperty("com.interwoven.cssdk.factory.CSFactory", csFactory);
		CSFactory factory = CSFactory.getFactory(properties);
		try{
			CSClient adminClient = factory.getClientForTrustedUser((readDeployConfig("Deploy.bootStrapUserName")), "", Locale.getDefault(), client.getContext().toString(), null);
			if(adminClient != null){
				LOGGER.debug("Admin User Name:"+adminClient.getCurrentUser().getName());
				CSFile file = adminClient.getFile(new CSVPath(path));
				if(file != null){
					file.unlock();
					LOGGER.debug("Sucessfully unlocked the file:"+path);
				}
			}
		}catch(Exception e){
			LOGGER.error("Error while unlocking the file:"+path);
		}
	}
	
	public String readDeployConfig(String key)  {
		String iwHome;
		String value = null;
		InputStream inputStream = null;
		try {
			iwHome = UtildClient.getServerProperty("iwhome");
			iwHome = iwHome.substring(0, iwHome.lastIndexOf("/"));
			LOGGER.debug("Value of iwHome---" + "  " + iwHome);
			
			String fileName = iwHome + "/OpenDeployNG/etc/deploy.cfg";
			
			
			File configFile = new File(fileName);
			inputStream = new FileInputStream(configFile);

			if (configFile.exists()) {
				Properties prop = new Properties();
				prop.load(inputStream);
				value = prop.getProperty(key);
				LOGGER.debug("Value-----" + "   " + value);
			} else {
				LOGGER.debug("!! Deploy.cfg file does not exist !!");
			}

			if (null != inputStream) {
				inputStream.close();
			}
			if (null != value) {
				return value.trim();
			}
		} catch (UtildClientException  | IOException e) {

			LOGGER.error ("Caught exception in readDeploy method  for WorkflowServices : " + e + e.getMessage ());
		} 
		finally {
			if(inputStream != null) {
	            try {
	            	inputStream.close();
				} catch (IOException e) {
					LOGGER.error ("Caught IOException in readDeploy method  for WorkflowServices : " + e + e.getMessage ());
				}
			}
	    }
		
		
		return value;
	}

	public String getJobOwner(String jobId,CSClient client){
		try {
			CSWorkflow workflow = client.getWorkflow(Integer.parseInt(jobId), true);
			if(workflow != null){
				CSUser user = workflow.getOwner();
				if(user != null){
					String displayName = null;
					String emailId = null;
					String userName = user.getName();
					boolean hasEmailId = false;
					String message;
					try{
						displayName = user.getDisplayName();
						emailId = user.getEmailAddress();
					}catch(CSException e){
						LOGGER.error("Error while retrieving Display Name or email address");
					}
					if(displayName == null || "".equals(displayName)){
						displayName = user.getName();
					}
					if(emailId != null && !"".equals(emailId)){
						hasEmailId = true;
					}
					
					if(userName != null && !"".equals(userName)){
						
						if(hasEmailId){
							message = " <span>Initiated By 	:</span><a id=\"iw.ccpro.user_details.link\" class=\"iw-base-link\" title=\""+userName+"("+emailId+")\" onclick=\"javascript:fw_widgets.open_new_window(this); return false;\" href=\"/iw-cc/command/iw.teamsite.view_user_details?userName="+userName+"\" iw_wf=\"width=500,height=500,scrollbars=0,resizable=1,center=true,relative=true\" iw_enabled=\"true\" class=\"iw-base-link\" target=\"_blank\">"+displayName+"</a>";
						}else{
							message = " <span>Initiated By 	:</span><a id=\"iw.ccpro.user_details.link\" class=\"iw-base-link\" title=\""+displayName+"\" onclick=\"javascript:fw_widgets.open_new_window(this); return false;\" href=\"/iw-cc/command/iw.teamsite.view_user_details?userName="+userName+"\" iw_wf=\"width=500,height=500,scrollbars=0,resizable=1,center=true,relative=true\" iw_enabled=\"true\" class=\"iw-base-link\" target=\"_blank\">"+displayName+"</a>";
						}
						return message;
					}
				}
			}
		} catch (CSException e) {
			LOGGER.error("Error while retreiving the JOB owner:"+jobId);
		}
		
		return null;
		
	}
	
	/** It initiates workflow
	 * @param client CSClient 
	 * @param jobDocument workflow JOB XML Document
	 * @throws CSException
	 */
	public CSWorkflow startWorkflow(CSClient client,Document jobDocument) throws CSException {
		CSWorkflow csworkflow = null;
		if (jobDocument != null) {
			CSWorkflowEngine engine = client.getWorkflowEngine();
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("++++++++++++++++++Updated JOB XML:\n"+jobDocument.asXML());
			}
			csworkflow = engine.createWorkflow(jobDocument.asXML());
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Asynchronous Workflow Initiated - "+csworkflow.getId());
			}
			
		}
	return csworkflow;	
	}

	/** It initiates workflow
	 * @param client CSClient 
	 * @param jobDocument workflow JOB XML String
	 * @throws CSException
	 */
	public CSWorkflow startWorkflow(CSClient client,String jobDocument) throws CSException {
		CSWorkflow csworkflow = null;
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Workflow services called for starting workflow");
		}
		if (jobDocument != null) {
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Job Document used in Workflow Service: - "+jobDocument);
			}
			CSWorkflowEngine engine = client.getWorkflowEngine();
			csworkflow = engine.createWorkflow(jobDocument);
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Workflow Initiated with JOB ID - "+csworkflow.getId());
			}
			
		}
	return csworkflow;	
	}
}
