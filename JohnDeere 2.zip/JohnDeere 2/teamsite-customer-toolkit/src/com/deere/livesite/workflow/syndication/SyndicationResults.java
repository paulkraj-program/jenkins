package com.deere.livesite.workflow.syndication;

import java.util.ArrayList;
import java.util.List;
import com.interwoven.cssdk.filesys.CSFile;

/**
 * SyndicationResutls is a data class that contains the results of the
 * syndication process from a Syndicator instance.
 * @author Klish Group, Inc. [ND]
 */
public class SyndicationResults {
	
	private final List<CSFile> syndicated = new ArrayList<>();
	private final List<CSFile> existing = new ArrayList<>();
	private final List<CSFile> modified = new ArrayList<>();
	
	/**
	 * Get the list of syndicated files.
	 * @return The list of syndicated files.
	 */
	public List<CSFile> getSyndicated() {
		return syndicated;
	}
	
	/**
	 * Get the list of existing files.
	 * @return The list of existing files.
	 */
	public List<CSFile> getExisting() {
		return existing;
	}
	
	/**
	 * Get the list of modified files.
	 * @return The list of modified files.
	 */
	public List<CSFile> getModified() {
		return modified;
	}
	
}
