package com.deere.livesite.workflow.constants;

public class GenericConstants {
	
	public static final String EMAIL_CC="dce-cms-admin@JohnDeere.com";
	public static final String EMAIL_FROM = "TSAdmin@JohnDeere.com";

}
