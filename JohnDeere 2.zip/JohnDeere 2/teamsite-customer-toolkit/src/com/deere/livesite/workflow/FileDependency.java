package com.deere.livesite.workflow;

import com.interwoven.cssdk.filesys.CSAreaRelativePath;

/**
 * FileDependency is a class that contains an x-path value and a CSAreaRelativePath
 * instance for a file reference within an XML document such as a DCR file or a
 * SitePublisher page file.
 * @author Klish Group, Inc. [ND]
 */
public class FileDependency {
	
	private final String xpath;
	private final CSAreaRelativePath path;
	
	/**
	 * Create a new FileDependency instance
	 * @param xp The unique xpath to the source element in the original document
	 * @param p The CSAreaRelativePath to the dependency file
	 */
	public FileDependency(String xp, CSAreaRelativePath p) {
		xpath = xp;
		path = p;
	}
	
	/**
	 * Get the unique xpath to the element in the source document
	 * @return The xpath to the element in the source document
	 */
	public String getXPath() {
		return xpath;
	}
	
	/**
	 * Get the CSAreaRelativePath to the dependency file
	 * @return The CSAreaRelativePath to the dependency file
	 */
	public CSAreaRelativePath getPath() {
		return path;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FileDependency [xpath=").append(xpath).append(", path=").append(path).append("]");
		return builder.toString();
	}
	
}
