package com.deere.livesite.maintainence;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.dom4j.io.DOMReader;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.deere.livesite.authoring.utils.DocumentUtils;
import com.deere.livesite.authoring.workflow.acpw.task.DocumentUtilisMock;
import com.deere.livesite.dws.taxonomy.constant.TaxonomyConstants;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSPathCommentPair;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.livesite.dom4j.Dom4jUtils;
import com.interwoven.livesite.file.FileDal;

public class TaxonomyCleanupTask  implements CSURLExternalTask{
	ArrayList<String> jsonFileList = new ArrayList<String>();
	ArrayList<String> jsonFileListAll = new ArrayList<String>();

	
	
	FileDal fileDal;
	
	private static final Logger LOGGER = Logger.getLogger(TaxonomyCleanupTask.class.getName());
	final static String logConfig ="/iwmnt/iwadmin/main/deere/syndication/WORKAREA/shared/templatedata/TaxonomyClenaup/teamsite/data/tax_cleanup.xml";
	DocumentUtilisMock mockUtils=new DocumentUtilisMock();
	
	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
	
		try {
			File fXmlFile = new File(logConfig);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);

			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document docs = dBuilder.parse(fXmlFile);
			docs.getDocumentElement().normalize();
	              
			LOGGER.debug("Root element :" + docs.getDocumentElement().getNodeName());
			NodeList nList = docs.getElementsByTagName("LocaleDetails");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				ArrayList<String> parentNodeList = new ArrayList<String>();
				ArrayList<String> urlsToFind = new ArrayList<String>();
				ArrayList<String> allURLNodeList = new ArrayList<String>();
				String country = "";
				String language = "";
				String urlString = "";
				LOGGER.debug("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if(!eElement.getElementsByTagName("Country").item(0).getTextContent().equalsIgnoreCase("")) {
						country = eElement.getElementsByTagName("Country").item(0).getTextContent().toString();
					}
					if(!eElement.getElementsByTagName("Language").item(0).getTextContent().equalsIgnoreCase("")) {
						language = eElement.getElementsByTagName("Language").item(0).getTextContent().toString();
					}
					if(!eElement.getElementsByTagName("SearchQuery").item(0).getTextContent().equalsIgnoreCase("")) {
						urlString = eElement.getElementsByTagName("SearchQuery").item(0).getTextContent().toString();
					}
				}
				
				String taxonomy = country+"-"+language+".taxonomy";
				String workAreaName = "/default/main/deere/"+country+"/"+language+"/WORKAREA/shared";
				//String taxonomyPath = "/default/main/deere/"+country+"/"+language+"/WORKAREA/shared/html/deere/"+country+"/"+language+"/website/"+taxonomy;
				String taxonomyFilePath = "html/deere/"+country+"/"+language+"/website/"+taxonomy;
				URL	url = new URL(urlString);
				
				URLConnection conn = url.openConnection();

				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
				factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
				DocumentBuilder builder = factory.newDocumentBuilder();
				org.w3c.dom.Document doc = builder.parse(conn.getInputStream());
				
				  doc.getDocumentElement().normalize();
					 
					 
					 LOGGER.debug("----------------------------");
					 if (doc.hasChildNodes()) {

					        printNote(doc.getChildNodes(),task,country,language,parentNodeList,urlsToFind);

					    }
					
					 CSWorkarea area = client.getWorkarea(new CSVPath(workAreaName), false);
		
					//	boolean isTaxonomyExists = false;
					//	CSAreaRelativePath taxFilePath = new CSAreaRelativePath(taxonomyFilePath);
					//	CSFile csFile = area.getFile(taxFilePath);
						DocumentUtils documentUtils = mockUtils.getDocumentUtilis(area, client) ;
						 org.dom4j.Document taxonomyDocument=getTaxonomyXml(area,documentUtils,taxonomyFilePath,country,language);
			
					
						 removeNode(taxonomyFilePath,documentUtils,country,language,parentNodeList,urlsToFind,allURLNodeList);
						
						
							DocumentBuilderFactory factoryRem = DocumentBuilderFactory.newInstance();
							factoryRem.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
							factoryRem.setFeature("http://xml.org/sax/features/external-general-entities", false);
							  DocumentBuilder builderRem = factoryRem.newDocumentBuilder();
							  org.w3c.dom.Document docu =  builderRem.parse(new InputSource(new StringReader(taxonomyDocument.asXML())));
							
								for(String removeNode : parentNodeList) {
									org.w3c.dom.Element element = (org.w3c.dom.Element) docu.getElementsByTagName(removeNode).item(0);
									if(element != null) {
										((Node) element).getParentNode().removeChild((Node) element);

										LOGGER.debug("removing....");
									}
									else {

										LOGGER.debug("element value is null....");
									}
									
									
								}
								LOGGER.debug("Removed..........");
								docu.normalize();
					
								org.dom4j.io.DOMReader reader = new DOMReader();
								org.dom4j.Document document = reader.read(docu);
							
								 documentUtils.saveDocument(taxonomyFilePath, document);
						
								  LOGGER.debug("Taxonomy file has updated with removed expired offers...");
					 
					
						LOGGER.debug("Total Count of the Offer URL for locale "+country+"-"+language+" : ="+ allURLNodeList.size());
						LOGGER.debug("final Urls in arraylist count for locale "+country+"-"+language+" := "+urlsToFind.size());
						LOGGER.debug("Parent node list count for locale "+country+"-"+language+": "+parentNodeList.size());
						LOGGER.debug("Parent node list values for locale "+country+"-"+language+" : "+parentNodeList);
						List<String> emailRcr = TeamsiteLogsComonUtils.getEmailRcv(logConfig);
						TeamsiteLogsComonUtils.notifyTaxonomy(emailRcr,parentNodeList,urlsToFind,country,language,allURLNodeList);
						LOGGER.debug("EMAIL ADDRESS IS >>>>>>"+emailRcr);
			}
			task.chooseTransition(task.getTransitions()[0], "Expired Offers Deleted");
		}
			catch (MalformedURLException e) {
				LOGGER.error("Exception",e);
			} catch (IOException e) {
				LOGGER.error("Exception",e);
			} catch (ParserConfigurationException e) {
				LOGGER.error("Exception",e);
			} catch (SAXException e) {
				LOGGER.debug("Exception",e);
			} catch (NullPointerException e) {
				LOGGER.error("Exception",e);
			} /*catch (TransformerConfigurationException e) {
				LOGGER.debug("Exception",e);
			} catch (TransformerException e) {
				LOGGER.debug("Exception",e);
			}
		*/ 
			
	}
	public org.dom4j.Document getTaxonomyXml(CSWorkarea area, DocumentUtils documentUtils,String taxonomyFilePath,String country, String language) throws CSException {
		org.dom4j.Document taxonomyDoc = null;
		boolean isTaxonomyExists = false;
		CSAreaRelativePath taxFilePath = new CSAreaRelativePath(taxonomyFilePath);
		CSFile csFile = area.getFile(taxFilePath);
		
		if (csFile == null) {
			area.createSimpleFile(taxFilePath);		
		} else if (csFile instanceof CSSimpleFile) {
			isTaxonomyExists = true;
		}else if (csFile instanceof CSHole) {
			CSPathCommentPair[] toBeSubmitted = new CSPathCommentPair[] { new CSPathCommentPair(taxFilePath, "CSHole Submit")};
			area.submitDirect("CSHole Submit", "", toBeSubmitted, CSWorkarea.OVERWRITE_NONE);
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("CSHole submitted successfully - "+taxFilePath.toString());
			}
			//create File
			area.createSimpleFile(taxFilePath);
		}else if (csFile instanceof CSDir) {
			throw new RuntimeException("Directory exists in taxonomy location");
		}
		
		if( !(isTaxonomyExists)){
			// taxonomy file doesn't exist create
			taxonomyDoc = createInitialTaxonomy();	
			documentUtils.saveDocument(taxonomyFilePath, (org.dom4j.Document) taxonomyDoc);
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Created initial taxonomy document for the branch "+area.getBranch().getVPath().getPathNoServer().toString());
			}
		}
		else{
			// retrieve the existing taxonomy document
			taxonomyDoc = documentUtils.retrieveDocument(taxonomyFilePath);
			
		}
		 
		return taxonomyDoc;
	}
	/**
	 * This method creates initial taxonomy with root element as 'taxonomy'
	 * @return initial taxonomy document
	 */
	public org.dom4j.Document createInitialTaxonomy(){
		org.dom4j.Document doc = Dom4jUtils.newDocument();
		
		doc.addElement(TaxonomyConstants.TAXONOMY_TAG);
	    return doc;
	}
	/**
	 * Save document to given workarea path.
	 *
	 * @param relativePath the workarea path
	 * @param document the document to save
	 */
	public void saveDocument(String relativePath, Document document) {
		fileDal.write(relativePath, ((org.dom4j.Node) document).asXML());
	}
	
	public void printNote(NodeList nodeList, CSExternalTask task, String country, String language,ArrayList<String> parentNodeList,ArrayList<String> urlsToFind) {
		for (int count = 0; count < nodeList.getLength(); count++) {
			//String finalUrl = "/fr/finances";
			String endDate = "offer-end-date";
			Node tempNode = nodeList.item(count);
			 if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

			        // get node name and value
			       
			       try {
			       if(tempNode.getNodeName().contentEquals("content") ) {
			    	   		String key = tempNode.getAttributes().getNamedItem("name").getNodeValue();
			    	   		String urlValue = tempNode.getParentNode().getAttributes().getNamedItem("url").getNodeValue();
			    	   		
			    	   	if(key.contentEquals(endDate)) {
			    	   		String endDateVal = tempNode.getTextContent();
			    	   		dateCompare(endDateVal,urlValue,parentNodeList,urlsToFind);
			    		   LOGGER.debug("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
				    	   LOGGER.debug("\nParent Node Name =" + tempNode.getParentNode().getNodeName() + " [Parent Node]");
				    	   LOGGER.debug("\nParent Node URL =" + urlValue + " [Parent Node]");
				    	   String[] test = urlValue.split(language);
				    	   LOGGER.debug("\nParent Node URL in Array =" + test[1] + " [Parent Node]");
					       LOGGER.debug("Node Value =" + endDateVal);
					       LOGGER.debug("Node attribute Name =" + key);
				    	//   allURLNodeList.add(tempNode.getTextContent());
				    	 //  parentNodeList.add(tempNode.getParentNode().getNodeName());
				    	   LOGGER.debug("executed............");
			    	   }
			       }
			       
			    }catch(Exception ce) {
			    	LOGGER.debug("Exception",ce);
			    }
			    	
			    }
			 if (tempNode.hasChildNodes()) {

		            // loop again if has child nodes
		            printNote(tempNode.getChildNodes(),task,country,language,parentNodeList,urlsToFind);

		        }
	}
		
	}
	public void dateCompare(String endDate, String urlVal,ArrayList<String> parentNodeList,ArrayList<String> urlsToFind) {
		
		String dateExp = endDate.toString();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("CST"));
		try {
		Date date = new Date();
		//LOGGER.debug(dateFormat.format(date));
		String curentDate = dateFormat.format(date);
		
			long currDate = dateFormat.parse(curentDate).getTime();
			long expDate = dateFormat.parse(dateExp).getTime();
			if(currDate > expDate) {
				LOGGER.debug("offers has expired "+dateFormat.parse(dateExp));				
				urlsToFind.add(urlVal);
			}
			else {
				LOGGER.debug("Url not expired = "+ urlVal);
			}
			LOGGER.debug("Current Date "+curentDate);
			LOGGER.debug("End Date "+dateExp);
			LOGGER.debug("Current Date Long "+currDate);
			LOGGER.debug("End Date Long "+expDate);
		} catch (java.text.ParseException e) {
			LOGGER.debug("Exception",e);
		}
		
	}
	
	public void removeNode(String taxPath,DocumentUtils documentUtils, String country, String language,ArrayList<String> parentNodeList,ArrayList<String> urlsToFind,ArrayList<String> allURLNodeList) {
	//	File taxFile = new File(taxPath);   
		
	
		
		for(String url : urlsToFind) {
		//	url = url.replace(File.separator, "/");
			LOGGER.debug("Url values = "+ url);
			 try {
			 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			
				dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
				dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
			
				org.dom4j.Document taxonomyDoc = documentUtils.retrieveDocument(taxPath);
			
			    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					 org.w3c.dom.Document doc = dBuilder.parse(new InputSource(new StringReader(taxonomyDoc.asXML())));
					 
					 doc.getDocumentElement().normalize();
					 
	//				 NodeList nList = doc.getElementsByTagName("fr_ca_offers_discounts");
					 
					 LOGGER.debug("----------------------------");
					 if (doc.hasChildNodes()) {

					        taxReadNote(doc.getChildNodes(),url,documentUtils,country,language,parentNodeList,urlsToFind,allURLNodeList);

					    }
					 
				} catch (ParserConfigurationException e) {
					LOGGER.debug("Exception",e);
				} catch (SAXException e) {
					LOGGER.debug("Exception",e);
				} catch (IOException e) {
					LOGGER.debug("Exception",e);
				} catch (CSException e) {
					LOGGER.debug("Exception",e);
				} 
			   
		//	taxonomyDeleteVal(url);
		}
	}
	
	public void taxReadNote(NodeList nodeList, String url, DocumentUtils documentUtils, String country, String language,ArrayList<String> parentNodeList,ArrayList<String> urlsToFind,ArrayList<String> allURLNodeList) throws CSException {
		//String language = task.getVariable("language");
		try {
		for (int count = 0; count < nodeList.getLength(); count++) {
			String[] finalUrlArray = url.split("/"+language+"/");
			if(finalUrlArray.length > 0) {
			String finalUrl = "/"+language+"/"+finalUrlArray[1];
			Node tempNode = nodeList.item(count);
			 if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

			        // get node name and value
			       
			       
			       if(tempNode.getNodeName().contentEquals("path") && tempNode.getTextContent().equals(finalUrl)) {
			    	   LOGGER.debug("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
			    	   LOGGER.debug("\nParent Node Name =" + tempNode.getParentNode().getNodeName() + " [Parent Node]");
				       LOGGER.debug("Node Value =" + tempNode.getTextContent());
			    	   allURLNodeList.add(tempNode.getTextContent());
			    	   parentNodeList.add(tempNode.getParentNode().getNodeName());
			    	   LOGGER.debug("Parent Node Value = "+ parentNodeList);
			    	   LOGGER.debug("All url Value = "+ allURLNodeList);
			    	   LOGGER.debug("executed............");
			       }
			    }
			
			 if (tempNode.hasChildNodes()) {

		            // loop again if has child nodes
				 taxReadNote(tempNode.getChildNodes(),url,documentUtils,country,language,parentNodeList,urlsToFind,allURLNodeList);

		        }
			}
	}
	}catch(Exception e){
		 LOGGER.debug("Execption",e);
	}
	}
	
	
}
