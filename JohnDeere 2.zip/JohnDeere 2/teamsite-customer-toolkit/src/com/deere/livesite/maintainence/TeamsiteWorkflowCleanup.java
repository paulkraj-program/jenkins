package com.deere.livesite.maintainence;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.cssdk.workflow.CSWorkflow;

public class TeamsiteWorkflowCleanup implements CSURLExternalTask {
	final static String logConfig ="/iwmnt/iwadmin/main/deere/syndication/WORKAREA/shared/templatedata/LogRotation/teamsite/data/logconfig.xml";
	private static final Logger LOGGER = Logger.getLogger(TeamsiteWorkflowCleanup.class.getName());
	List<String> emailRcr;
	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		 Date currentDate = new Date();
		 int i=0;
		CSWorkflow jobs[] = client.getWorkflowEngine().getWorkflowsByQuery("<wfquery><active/></wfquery>");
		String daysOld=task.getVariable("days");
		emailRcr = TeamsiteLogsComonUtils.getEmailRcv(logConfig);
		if(daysOld != null) {
		for(CSWorkflow job:jobs) {
			Date jobDate = job.getActivationDate();
			LOGGER.debug("==================================");
			
			long diff = currentDate.getTime() - jobDate.getTime();
			long diffDays = diff / (24 * 60 * 60 * 1000);
			LOGGER.debug("Days old is " +diffDays);
			
			if(diffDays >= Integer.parseInt(daysOld)) {
				i=i+1;
				LOGGER.debug("Terminating Wf "+job.getId()+" "+job.getDescription()+" wf Date is "+currentDate);
				job.terminate();
			}
			
			}
		
		}
		int noOfDeletedJobs = i;
		int totalNoOfjobs=jobs.length;
		
		TeamsiteLogsComonUtils.notify(emailRcr,noOfDeletedJobs,totalNoOfjobs,daysOld);
	
		task.chooseTransition(task.getTransitions()[0], "TeamSite workflow jobs are cleared");
	}

}
