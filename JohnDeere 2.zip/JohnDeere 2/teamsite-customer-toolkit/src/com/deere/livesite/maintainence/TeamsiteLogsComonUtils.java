package com.deere.livesite.maintainence;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.CopyOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class TeamsiteLogsComonUtils {
    
	final static String pathConfig ="/opentext/TeamSite/local/config/logconfiguration.config";
	private static final Logger LOGGER = Logger.getLogger(TeamsiteLogsComonUtils.class.getName());
	public static List<TeamsiteLogConfigurations> getConfigurations(String logConfig) {
     
		List<TeamsiteLogConfigurations> iConfigurations = new ArrayList<TeamsiteLogConfigurations>() ;
		String mPath = new String();
	    try {

		File fXmlFile = new File(logConfig);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);

		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
        doc.getDocumentElement().normalize();
        String patternString = new String();
              
		System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

		NodeList nList = doc.getElementsByTagName("target");

		for (int temp = 0; temp < nList.getLength(); temp++) {
			TeamsiteLogConfigurations Config = new TeamsiteLogConfigurations();
			List<String>patterns = new ArrayList<>();
			Node nNode = nList.item(temp);

			System.out.println("\nCurrent Element :" + nNode.getNodeName());

			if (nNode.getNodeType() == Node.ELEMENT_NODE) {

				Element eElement = (Element) nNode;
                

				if(!eElement.getElementsByTagName("name").item(0).getTextContent().equalsIgnoreCase("")) {
				Config.setApplicationName(eElement.getElementsByTagName("name").item(0).getTextContent());
				
				}
				if(!eElement.getElementsByTagName("logpath").item(0).getTextContent().equalsIgnoreCase("")) {

					Config.setLogPath(eElement.getElementsByTagName("logpath").item(0).getTextContent().toString());
					mPath = eElement.getElementsByTagName("logpath").item(0).getTextContent();
					if(ifValid(mPath)){
						Config.setIsValid(true);
					}else {
					Config.setIsValid(false);
					}
				}
                
				
				if(eElement.getElementsByTagName("action").item(0).getTextContent().equalsIgnoreCase("Delete")) {
					Config.setAction(eElement.getElementsByTagName("action").item(0).getTextContent().toString());
					Config.setDays(Integer.parseInt(eElement.getElementsByTagName("days").item(0).getTextContent()));
					}
				else if(eElement.getElementsByTagName("action").item(0).getTextContent().equalsIgnoreCase("Archive")) {
					Config.setAction(eElement.getElementsByTagName("action").item(0).getTextContent().toString());
					Config.setDays(Integer.parseInt(eElement.getElementsByTagName("days").item(0).getTextContent()));
					Config.setArchivepath(eElement.getElementsByTagName("archivepath").item(0).getTextContent().toString());
				}

				
				NodeList patternList = eElement.getElementsByTagName("pattern");
				for (int i = 0; i < patternList.getLength(); i++) {
					Node pNode = patternList.item(i);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element patternElement = (Element) pNode;
						patternString = patternElement.getElementsByTagName("regexpattern").item(0).getTextContent();
						if((patternString.equalsIgnoreCase("*.*"))||(patternString.equalsIgnoreCase(".*"))||(patternString.equalsIgnoreCase("*."))){}
						else {
							if((!patternString.equalsIgnoreCase(""))&&(patternString != null)) {

						patterns.add(patternElement.getElementsByTagName("regexpattern").item(0).getTextContent());
							}
						}
					//System.out.println("Regex Pattern : " + patternElement.getElementsByTagName("regexpattern").item(0).getTextContent());
					}
				}
				Config.setPatternAdded(patterns);
				
				
				
				
			}
			
			iConfigurations.add(Config);
		}
		
	    } catch (Exception e) {
	    	
		LOGGER.error("Error occuered in the method getConfigurations",e);
	    }
		return iConfigurations;
	}
	private static boolean ifValid(String mPath) {
		// TODO Auto-generated method stub
		Boolean r = false;
		ArrayList<String> result = new ArrayList<>();
		 
		try (FileReader f = new FileReader(pathConfig)) {
		    StringBuffer sb = new StringBuffer();
		    while (f.ready()) {
		        char c = (char) f.read();
		        if (c == '\n') {
		            result.add(sb.toString());
		            sb = new StringBuffer();
		        } else {
		            sb.append(c);
		        }
		    }
		    if (sb.length() > 0) {
		        result.add(sb.toString());
		    }
		} catch (IOException e) {

			LOGGER.error("Error occuered in the method ifValid",e);
		}   
		r = result.contains(mPath);
		
		return r;
	}
	public static List<String> getAlllogFiles(String mPath) {
	// TODO Auto-generated method stub
	List<String>mlogFiles = new ArrayList<String>();
	try {
	    Path startPath = Paths.get(mPath);
	    Files.walkFileTree(startPath, new SimpleFileVisitor<Path>() {
	        @Override
	        public FileVisitResult preVisitDirectory(Path dir,
	                BasicFileAttributes attrs) {
	            return FileVisitResult.CONTINUE;
	        }

	        @Override
	        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
	             mlogFiles.add(file.toString());
	            return FileVisitResult.CONTINUE;
	        }

	        @Override
	        public FileVisitResult visitFileFailed(Path file, IOException e) {
	            return FileVisitResult.CONTINUE;
	        }
	    });
	} catch (IOException e) {
		LOGGER.error("Error occuered in the method getAlllogFiles",e);
	}
	return mlogFiles;
}
	public static List<String> getApplicationLogs(TeamsiteLogConfigurations Configuration){
		List<String> logfiles = new ArrayList<String>();
		List<String> applicationLogFiles = new ArrayList<String>();
		
		
		logfiles = getAlllogFiles(Configuration.getLogPath());
		for(String logFile:logfiles) {
			Path path = Paths.get(logFile); 
			Path fileName = path.getFileName(); 
	        List<String> patterns =Configuration.getPatternAdded();
	        for(String patternCheck:patterns) {
	        	Pattern pattern = Pattern.compile(patternCheck);
	    	    
		        Matcher match = pattern.matcher(fileName.toString());
		        if(match.matches()) {
		          Boolean Older = isLogFileOlder(logFile, Configuration.getDays());
		        	 if(Older) {
		        	    applicationLogFiles.add(logFile);
		        	 }
		        }else {
		        	 }
	        }
		}
		   
	return applicationLogFiles;
    }
	
	public static String getLogsSize(List<String> pTeamsitelogs) {
		// TODO Auto-generated method stub
		long sizeOfLogs = 0;
		for(String filepath :pTeamsitelogs) {
			File file = new File(filepath);
			sizeOfLogs += file.length();
		}
		String pSize = getSizeValue(sizeOfLogs);

		return pSize;
	}

	public static String getSizeValue(long size) {
		
		String hrSize = null;
		double b = size;
	    double k = size/1024.0;
	    double m = ((size/1024.0)/1024.0);
	    double g = (((size/1024.0)/1024.0)/1024.0);
	    double t = ((((size/1024.0)/1024.0)/1024.0)/1024.0);

	    DecimalFormat dec = new DecimalFormat("0.00");

	    if ( t>1 ) {
	        hrSize = dec.format(t).concat(" TB");
	    } else if ( g>1 ) {
	        hrSize = dec.format(g).concat(" GB");
	    } else if ( m>1 ) {
	        hrSize = dec.format(m).concat(" MB");
	    } else if ( k>1 ) {
	        hrSize = dec.format(k).concat(" KB");
	    } else {
	        hrSize = dec.format(b).concat(" Bytes");
	    }
		return hrSize;
		}
	
	public static String getLogFolderSize(TeamsiteLogConfigurations Configuration) {
	   
		long size = FileUtils.sizeOfDirectory(new File(Configuration.getLogPath()));
		
		String sizeValue = getSizeValue(size);

	    

	    return sizeValue;
	}
	public static void logInformation(TeamsiteLogConfigurations configuration) {
		// TODO Auto-generated method stub
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		
		try {
			File folder = new File(configuration.getLogDir());
			folder.mkdirs();
			String logInfo = configuration.getApplicationName();
			logInfo = logInfo.replaceAll("\\s","");

			File file = new File(configuration.getLogDir()+"/"+logInfo+".log");
			System.out.println("Log File is >>>"+file.getPath());
			if (file.createNewFile()) {
			    System.out.println("File created: " + file.getName());
			  } else {
			    System.out.println("File already exists.");
			  }

		       fos = new FileOutputStream(file);

		       bw = new BufferedWriter(new OutputStreamWriter(fos));

		      


		      if(configuration.getAction().equalsIgnoreCase("delete")) {
		    	  
		      for (String text : configuration.getTeamsiteDeletedLogs()) {
		    	bw.write("DELETION SUCCESS =====>>"+text);

		        bw.newLine();
		      }
		      for (String text1 : configuration.getTeamsiteDeletionFailedLogs()) {
			        bw.write("DELETION FAILED =====>>"+text1);
			        bw.newLine();
			      }
		      }


		      if(configuration.getAction().equalsIgnoreCase("archive")) {

		      for (String text : configuration.getTeamsiteDeletedLogs()) {
		        bw.write("ARCHIVE SUCCESS =====>>"+text);
		        bw.newLine();
		      }
		      for (String text1 : configuration.getTeamsiteDeletionFailedLogs()) {
			        bw.write("ARCHIVE FAILED =====>>"+text1);
			        bw.newLine();
			      }
		      }
		      bw.close();
		} catch (IOException e) {

			LOGGER.error("Error occuered in the method logInformation",e);
		}
		finally {

			if(fos != null) {
	            try {
					fos.close();
				} catch (IOException e) {
					LOGGER.error("Error occuered while closing FileOutputStream in the method getConfigurations",e);
				}
			}

			if(bw != null) {
	            try {
	            	bw.close();
				} catch (IOException e) {
					LOGGER.error("Error occuered while closing BufferWriter in the method getConfigurations",e);
				}
			
			
		}
		}
		
	}
	public static TeamsiteLogConfigurations executeDelete(TeamsiteLogConfigurations configuration) {
		// TODO Auto-generated method stub
		List<String> deleted = new ArrayList<String>();
		List<String> failed = new ArrayList<String>();
		
		List<String> l = configuration.getTeamsitelogsdetails();
		long purgeTime = System.currentTimeMillis() - ((long)configuration.getDays() * 24 * 60 * 60 * 1000);
		for(String listFile : l) {
			
			File f = new File(listFile);
			if(f.lastModified() < purgeTime) {
				if(!f.delete()) {
					failed.add(listFile);
	            }
				else {
					deleted.add(listFile);
				}
			  }
			else{
				
				//System.out.println("No need to Delete"+listFile);
			}
			}
		configuration.setTeamsiteDeletedLogs(deleted);
		configuration.setTeamsiteDeletionFailedLogs(failed);
		return configuration;
		
		}

	public static boolean isLogFileOlder(String fileToCheck ,int daysToCheck) {
		Boolean check = false;
		File f = new File(fileToCheck);
		long diff = new Date().getTime() - f.lastModified();
		long cutoff = ((long)daysToCheck * (24 * 60 * 60 * 1000));
		if(diff > cutoff) {
			check=true;
		}
		return check;
		}	  
	
	public static TeamsiteLogConfigurations executeArchive(TeamsiteLogConfigurations configuration) {
		// TODO Auto-generated method stub
		List<String> deleted = new ArrayList<String>();
		List<String> j = new ArrayList<String>();
		List<String> failed = new ArrayList<String>();
				
				try {
					
					String archivePath = configuration.getArchivepath();
					List<String> l = configuration.getTeamsitelogsdetails();
					for(String listFile : l) {
						
						File f = new File(listFile);
						long diff = new Date().getTime() - f.lastModified();
						
	                    long cutoff = ((long)configuration.getDays() * (24 * 60 * 60 * 1000));
	                    CopyOption[] options = new CopyOption[]{StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.COPY_ATTRIBUTES}; 
						if(diff > cutoff) {
					    Files.copy(f.toPath(), new File(archivePath+"/Archive/"+f.getName()).toPath(),options);
					    j.add(listFile);
					}
				else {
					
					}
				}
                   for(String g :j) {
                	   File h = new File(g);
                	   if(!h.delete()) {
       					failed.add(g);
       	            }
       				else {
       					deleted.add(g);
       				}
                	   
                   }
                   } catch (IOException e) {
                	   LOGGER.error("Error occuered in the method executeArchive",e); 
					
				}
				configuration.setTeamsiteDeletedLogs(deleted);
				configuration.setTeamsiteDeletionFailedLogs(failed);
				return configuration;
				
	}
	
	/*public static void writeZipFile(File directoryToZip, List<File> fileList) {

		try {
			FileOutputStream fos = new FileOutputStream(directoryToZip.getName() + ".zip");
			ZipOutputStream zos = new ZipOutputStream(fos);

			for (File file : fileList) {
				if (!file.isDirectory()) { // we only zip files, not directories
					addToZip(directoryToZip, file, zos);
				}
			}

			zos.close();
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/
	
	/*public static void addToZip(File directoryToZip, File file, ZipOutputStream zos) {

		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			String zipFilePath = file.getCanonicalPath().substring(directoryToZip.getCanonicalPath().length() + 1,file.getCanonicalPath().length());
			System.out.println("Writing '" + zipFilePath + "' to zip file");
			ZipEntry zipEntry = new ZipEntry(zipFilePath);
			zos.putNextEntry(zipEntry);
			
			byte[] bytes = new byte[1024];
			int length;
			while ((length = fis.read(bytes)) >= 0) {
				zos.write(bytes, 0, length);
			}
			
			zos.closeEntry();
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		}*/
	public static void notify(List<String> emails, int noOfDeletedJobs, int totalNoOfjobs, String daysOld) {
		
		String from = "TSAdmin@johndeere.com";
       
        String subject = "TeamSite workflow cleanup is completed";
        Properties properties = System.getProperties();
        
		 
		  properties.put("mail.smtp.host","localhost");
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  try
		  {
			   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
			   LocalDateTime now = LocalDateTime.now();
			   
			  MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress[] address = new InternetAddress[emails.size()];
		      for(int i=0; i< emails.size();i++) {
		    	  System.out.println("Sending emails to ......"+emails.get(i));
		    	  address[i]= new InternetAddress(emails.get(i));
		      }
		      
		      msg.setRecipients(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();
		      
		      String headerMessage="<p><strong><span style=\"font-size: 18px; font-family: Calibri, sans-serif;\">Teamsite workflow clean up activity.</span></strong></p>\r\n"
		      		+ "<table style=\"width: 55%; margin-right: calc(45%);\">\r\n"
		      		+ "    <tbody>\r\n"
		      		+ "        <tr>\r\n"
		      		+ "            <td style=\"width: 67.0913%;\"><span style='font-size:15px;font-family:\"Calibri\",sans-serif;'>No of days considered as old jobs&nbsp;</span><br></td>\r\n"
		      		+ "            <td style=\"width: 32.6964%;\">"+daysOld+" days</td>\r\n"
		      		+ "        </tr>\r\n"
		      		+ "        <tr>\r\n"
		      		+ "            <td style=\"width: 67.0913%;\"><span style='font-size:15px;font-family:\"Calibri\",sans-serif;'>No of workflow Jobs terminated</span><br></td>\r\n"
		      		+ "            <td style=\"width: 32.6964%;\">"+noOfDeletedJobs+"</td>\r\n"
		      		+ "        </tr>\r\n"
		      		+ "        <tr>\r\n"
		      		+ "            <td style=\"width: 67.0913%;\"><span style='font-size:15px;font-family:\"Calibri\",sans-serif;'>No of workflow Jobs in Teamsite</span><br></td>\r\n"
		      		+ "            <td style=\"width: 32.6964%;\">"+(totalNoOfjobs - noOfDeletedJobs)+"</td>\r\n"
		      		+ "        </tr>\r\n"
		      		+ "    </tbody>\r\n"
		      		+ "</table>\r\n"
		      		+ "<p><br></p>";

		      
              String bodyMessage = headerMessage;
              mbp1.setContent(bodyMessage,"text/html");
              mp.addBodyPart(mbp1); 
		      msg.setContent(mp);
              Transport.send(msg);
           }
		  
		  catch (MessagingException mex) 
		  {
			  LOGGER.error("Error occuered in the method notify",mex);
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    	  LOGGER.error("Having the next Messaging Exception  in the method notify",ex);
		      }
		  } 
	}
	public static void notify(List<TeamsiteLogConfigurations> configurations,List<String> emails,String logPath) {

		String messageSet =new String();
		String from = "TSAdmin@johndeere.com";
        String to = "rajpaul@johndeere.com";
        String subject = "TeamSite log cleanup is completed";
        Properties properties = System.getProperties();
        String mlogPath = logPath;
		 
		  properties.put("mail.smtp.host","localhost");
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  try
		  {
			   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
			   LocalDateTime now = LocalDateTime.now();
			   
			  MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress[] address = new InternetAddress[emails.size()];
		      for(int i=0; i< emails.size();i++) {
		    	  System.out.println("Sending emails to ......"+emails.get(i));
		    	  address[i]= new InternetAddress(emails.get(i));
		      }
		      
		      msg.setRecipients(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();
		      
		      String headerMessage="<p>Log Cleanup Notification.</p>\r\n" + 
		      		"<p>Date:"+dtf.format(now)+"</p>\r\n" + 
		      		"<p></p>\r\n" + 
		      		"<table border=\"1\" style=\"border-collapse: collapse; width: 100%;\">\r\n" + 
		      		"<tbody>\r\n" + 
		      		"<tr>\r\n" + 
		      		"<td style=\"width: 13.6847%; text-align: center;\">\r\n" + 
		      		"<p><strong>Application Name</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"<td style=\"width: 19.3338%; text-align: center;\">\r\n" + 
		      		"<p><strong>Log Path</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"<td style=\"width: 12.7232%; text-align: center;\">\r\n" + 
		      		"<p><strong>Size of the Log Path Folder</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"<td style=\"width: 13.4444%; text-align: center;\">\r\n" + 
		      		"<p><strong>Action Taken</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"<td style=\"width: 12.3626%; text-align: center;\">\r\n" + 
		      		"<p><strong>No: of days old to be considered</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"<td style=\"width: 11.6415%; text-align: center;\">\r\n" + 
		      		"<p><strong>No: of files</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"<td style=\"width: 16.8097%; text-align: center;\">\r\n" + 
		      		"<p><strong>Updated Size of the Log Path Folder</strong></p>\r\n" + 
		      		"</td>\r\n" + 
		      		"</tr>";
		      messageSet="";
		      for(TeamsiteLogConfigurations Config:configurations) {
		    	  if(Config.getIsValid()) {
		    	  messageSet += "<tr>\r\n" + 
		    	  		"<td style=\"width: 13.6847%; text-align: center;\">"+Config.getApplicationName()+"</td>\r\n" + 
		    	  		"<td style=\"width: 19.3338%; text-align: center;\">"+Config.getLogPath()+"</td>\r\n" + 
		    	  		"<td style=\"width: 12.7232%; text-align: center;\">"+Config.getLogFolderSize()+"</td>\r\n" + 
		    	  		"<td style=\"width: 13.4444%; text-align: center;\">"+Config.getAction()+"</td>\r\n" + 
		    	  		"<td style=\"width: 12.3626%; text-align: center;\">"+Config.getDays()+"</td>\r\n" + 
		    	  		"<td style=\"width: 11.6415%; text-align: center;\">"+(Config.getTeamsitelogsdetails()).size()+"</td>\r\n" + 
		    	  		"<td style=\"width: 16.8097%; text-align: center;\">"+Config.getModifiedlogFolderSize()+"</td>\r\n" + 
		    	  		"</tr>";
		      }
		      else {
		    	  messageSet += "<tr>\r\n" + 
			    	  		"<td style=\"width: 13.6847%; text-align: center;\">"+Config.getApplicationName()+"</td>\r\n" + 
			    	  		"<td style=\"width: 19.3338%; text-align: center;\">"+Config.getLogPath()+"</td>\r\n" + 
			    	  		"<td style=\"width: 12.7232%; text-align: center;\"></td>\r\n" + 
			    	  		"<td style=\"width: 13.4444%; text-align: center;\">"+Config.getAction()+"</td>\r\n" + 
			    	  		"<td style=\"width: 12.3626%; text-align: center;\"></td>\r\n" + 
			    	  		"<td style=\"width: 11.6415%; text-align: center;\"></td>\r\n" + 
			    	  		"<td style=\"width: 16.8097%; text-align: center;\"></td>\r\n" + 
			    	  		"</tr>";
		    	  
		      }
		      
		      
		      }
		      


		      List<String>g = getAlllogFiles(mlogPath);
		      if(g.size()>0) {
		    	  
		    	  for(String lgFilePath:g) {
		    		  MimeBodyPart mbp2 = new MimeBodyPart();
				      FileDataSource fds = new FileDataSource(lgFilePath);
				      mbp2.setDataHandler(new DataHandler(fds));
				      mbp2.setFileName(fds.getName());
				      mp.addBodyPart(mbp2);
		    	  }
		      }
		      
		      
             String bodyMessage = headerMessage + messageSet;
              mbp1.setContent(bodyMessage,"text/html");


			  mp.addBodyPart(mbp1); 
		      msg.setContent(mp);

		      
		      Transport.send(msg);
		      
			  }
		  
		  catch (MessagingException mex) 
		  {
			  LOGGER.error("Error occuered in the method notify",mex);
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    	  LOGGER.error("Error occuered in Messaging for  the method notify",ex);
		      }
		  } 
		
	}
	public static void notifyTaxonomy(List<String> emails,ArrayList<String> parentNodeList, ArrayList<String> urlsToFind, String country, String language,ArrayList<String> allURLNodeList) {
		String messageSet =new String();
		String from = "TSAdmin@johndeere.com";
        String to = "bhalsodhardik@johndeere.com";
        String subject = "Taxonomy Cleanup for expired offers for Locale "+country+"-"+language;
        Properties properties = System.getProperties();
        		 
		  properties.put("mail.smtp.host","localhost");
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  try
		  {
			   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
			   LocalDateTime now = LocalDateTime.now();
			   
			  MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress[] address = new InternetAddress[emails.size()];
		      for(int i=0; i< emails.size();i++) {
		    	  
		    	  address[i]= new InternetAddress(emails.get(i));
		      }
		      
		      msg.setRecipients(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();
		      String headerMessage="<p>Taxonomy Cleanup for expired offers Notification for "+country+"-"+language+".</p>\r\n" + 
			      		"<p>Date:"+dtf.format(now)+"</p>\r\n" + 
			      		"<p></p>\r\n" + 
			      		"<table border=\"1\" style=\"border-collapse: collapse; width: 100%;\">\r\n" + 
			      		"<tbody>\r\n" + 
			      		"<tr>\r\n" + 
			      		"<td style=\"width: 13.6847%; text-align: center;\">\r\n" + 
			      		"<p><strong>Parent Node List</strong></p>\r\n" + 
			      		"</td>\r\n" + 
			      		"<td style=\"width: 19.3338%; text-align: center;\">\r\n" + 
			      		"<p><strong>URL Paths</strong></p>\r\n" + 
			      		"</td>\r\n"+
			      		"<td style=\"width: 19.3338%; text-align: center;\">\r\n" + 
			      		"<p><strong>Path in taxonomy</strong></p>\r\n" + 
			      		"</td>\r\n"+
			      		"</tr>";
		      messageSet="";
		      messageSet += "<tr>\r\n" + 
		    	  		"<td style=\"width: 13.6847%; text-align: center;\">"+parentNodeList+"</td>\r\n" + 
		    	  		"<td style=\"width: 19.3338%; text-align: center;\">"+urlsToFind+"</td>\r\n" + 
		    	  		"<td style=\"width: 19.3338%; text-align: center;\">"+allURLNodeList+"</td>\r\n" + 
		    	  		"</tr>";
		      String bodyMessage = headerMessage + messageSet;
		      mbp1.setContent(bodyMessage,"text/html");
		      mp.addBodyPart(mbp1); 
		      msg.setContent(mp);
		      Transport.send(msg);
		  }
		  catch (MessagingException mex) 
		  {
			  LOGGER.error("Error occuered in the method notify",mex);
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    	  LOGGER.error("Error occuered in Messaging for  the method notify",ex);
		      }
		  } 
	}
	
	public static void notifyInvalidPathDeleteworkflow(List<String> invalidPath, int jobId, String emails, String userName) {
		String messageSet =new String();
		String from = "TSAdmin@johndeere.com";
        String to = "bhalsodhardik@johndeere.com";
        String subject = "Delete Workflow - Review Files for Deletion "+jobId;
        Properties properties = System.getProperties();
        		 
		  properties.put("mail.smtp.host","localhost");
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  try
		  {
			   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
			   LocalDateTime now = LocalDateTime.now();
			   
			  MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress address = new InternetAddress(emails);
		     
		      
		      msg.setRecipient(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();
		      String headerMessage= "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n" + 
			      		"<tbody>\r\n" + 
			      		"<tr>\r\n" + 
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"<p><strong>Task Description</strong></p>\r\n" + 
			      		"</td>\r\n" +
						"</tr>\r\n" +	
						"<tr>\r\n" +						
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"<p>This email is generated from Delete Workflow</p>\r\n" + 
			      		"</td>\r\n"+
			      		"</tr>\r\n"+
						"<tr>\r\n" + 
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"</td>\r\n" +
						"</tr>\r\n" +
						"<tr>\r\n" + 
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"<p><strong>Job Description</strong></p>\r\n" + 
			      		"</td>\r\n" +
						"</tr>\r\n" +
						"<tr>\r\n" + 
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"<p>Delete Workflow - This workflow contains only invalid file paths hence workflow job has ended.</p>\r\n" + 
			      		"</td>\r\n" +
						"</tr>\r\n" +
						"<tr>\r\n" + 
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"</td>\r\n" +
						"</tr>\r\n" +
						"<tr>\r\n" + 
			      		"<td style=\"text-align: left;\">\r\n" + 
			      		"<p><strong>Files which are not included in workflow</strong></p>\r\n" + 
			      		"</td>\r\n" +
						"</tr>" ;
		      messageSet="";
		      for(String invalidURL : invalidPath) {
		      messageSet += "<tr>\r\n" + 
		    	  		"<td style=\"text-align: left;\">"+invalidURL+"</td>\r\n" +
		    	  		"</tr>\r\n";
		      }
		      String bodyMessage = headerMessage + messageSet;
		      mbp1.setContent(bodyMessage,"text/html");
		      mp.addBodyPart(mbp1); 
		      msg.setContent(mp);
		      Transport.send(msg);
		  }
		  catch (MessagingException mex) 
		  {
			  LOGGER.error("Error occuered in the method notify",mex);
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    	  LOGGER.error("Error occuered in Messaging for  the method notify",ex);
		      }
		  } 
	}
	public static List<String> getEmailRcv(String logconfig) {

		File fXmlFile = new File(logconfig);

		List<String>emails = new ArrayList<>();
try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			
			dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		    dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
			String emailAddresses = "";
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
		        doc.getDocumentElement().normalize();
		        NodeList nList = doc.getElementsByTagName("email");
		        for (int temp = 0; temp < nList.getLength(); temp++) {
		            Node nNode = nList.item(temp);
		            
		            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
		                Element eElement = (Element) nNode;
		                
		                emailAddresses = eElement.getTextContent();
		                
		            }
		        }
		        if (emailAddresses.contains(",")) {
		        	String [] multipleemails = emailAddresses.split(",");
		        	for(String email:multipleemails ) {
		        		emails.add(email);
		        	}
		        	
		        }else {
		        	emails.add(emailAddresses);
		        }

	        
		} catch (ParserConfigurationException | SAXException | IOException e) {
			LOGGER.error("Error occuered in the method getEmailRcv",e);
		}
		
		return emails;
	}
	public static void notifyOpenDeployFailure(List<String> emails,String env) {
		String messageSet ="";
		String from = "TSAdmin@johndeere.com";
        String subject = "OpenDeploy Base Server is down in "+env;
        Properties properties = System.getProperties();
        		 
		  properties.put("mail.smtp.host","localhost");
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  try
		  {
				   
			  MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress[] address = new InternetAddress[emails.size()];
		      for(int i=0; i< emails.size();i++) {
     	    	  address[i]= new InternetAddress(emails.get(i));
		      }
		      
		      msg.setRecipients(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();

		      messageSet=subject;

		      String bodyMessage = messageSet;
		      mbp1.setContent(bodyMessage,"text/html");
		      mp.addBodyPart(mbp1); 
		      msg.setContent(mp);
		      Transport.send(msg);
		  }
		  catch (MessagingException mex) 
		  {
			  LOGGER.error("Error occuered in the method notifyOpenDeployFailure about OpenDeploy failure",mex);
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    	  LOGGER.error("Error occuered in Messaging for  the method notifyOpenDeployFailure",ex);
		      }
		  } 
		
	}
}
