package com.deere.livesite.maintainence;


import java.util.Hashtable;
import java.util.List;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.deployapi.deploy.IWDeployService;
import com.interwoven.deployapi.service.IWODService;
import com.interwoven.ui.teamsite.workflow.task.urltask.DeployURLExternalTask;
import org.apache.log4j.Logger;


public class OpenDeployDebugger extends DeployURLExternalTask implements CSURLExternalTask{

	private static final Logger LOGGER = Logger.getLogger (OpenDeployDebugger.class);
	final static String logConfig ="/iwmnt/iwadmin/main/deere/syndication/WORKAREA/shared/templatedata/LogRotation/teamsite/data/logconfig.xml";
	@SuppressWarnings("rawtypes")
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		String defaultTransition= "";
		String transitionComment ="";
		String env = task.getVariable("env");
		TestDeployHelper start = new TestDeployHelper();
		 
		String version = start.checkODVersion(task.getVariable("odhost"), Integer.parseInt(task.getVariable("odport")));
		if (version != null &&  !"".equalsIgnoreCase(version)) {
			LOGGER.debug("OpenDeploy Version is >> "+version);
			defaultTransition = task.getVariable("success");
			transitionComment  = "OpenDeploy is working , Retrying the Data Deployment";
		}
		else {
			LOGGER.debug("Error in Connecting to OD");
			defaultTransition = task.getVariable("error");
			transitionComment  = "OpenDeploy is not working , initating notification task";
			List<String> emailRcr = TeamsiteLogsComonUtils.getEmailRcv(logConfig);
			TeamsiteLogsComonUtils.notifyOpenDeployFailure(emailRcr,env);
			}
		task.chooseTransition(defaultTransition, transitionComment);
		
	}
	protected class TestDeployHelper extends StartDeploy {

		String iwodVersion = "";
		String checkODVersion (String fOdHost, int fOdPort) {
		
			
			try {
                String serviceName = "";
				if ((fOdHost == null) || (fOdHost.length () <= 0)) {
					fOdHost = "localhost";
					fOdPort = 9173;
				} else if (fOdPort <= 0) {
					fOdPort = 9173;
				}
				serviceName = "//" + fOdHost + ":" + fOdPort + "/IWDeployService";
				LOGGER.debug ("Service Name " + serviceName);
				IWDeployService deployService = (IWDeployService) IWODService.locate (serviceName);
               
                LOGGER.debug("deployService from TestDeployHelper is >> "+ deployService.toString());
                
			      iwodVersion = deployService.getInterfaceVersion();
			      LOGGER.debug("iwodVersion from deployService is >> "+iwodVersion);
				
				
			} catch (Exception eVers) {
				LOGGER.debug (eVers.getMessage ());
				LOGGER.error("Error occuered in the method CustomStartDeployHelper "+eVers); 
				iwodVersion = "";
			} 

			return iwodVersion;
		}

	}
	
}
