var o = {};
var checkdates=[];
var arrayOfDates = [];
var showdone = false;
o.iwInitialised = false;
o.loadedScripts = 0;
o.stylesheets = new Array('/iw/jquery/jqdatetime/jquery.datetimepicker.css');
o.scripts = new Array('/iw/jquery/jqdatetime/jquery.js','/iw/jquery/jqdatetime/jquery.datetimepicker.full.js');   

$().ready(function() {
    o.waitForIwInitialise();
});

o.waitForIwInitialise = function() {
    if(!o.iwInitialised) {
        setTimeout('o.waitForIwInitialise()', 100);
    } else {
      
        o.ready();
    }
}

o.iwInitalise = function() {
  
  IWDatacapture.getItem("/Config/TimeZones").setVisible(false);
	IWDatacapture.getItem("/Config/DeployDate").setVisible(false);
	IWDatacapture.getItem("/Config/TimeZones").setRequired(false);
	IWDatacapture.getItem("/Config/DeployDate").setRequired(false);
	IWDatacapture.getItem("/Config/PublishTime").setVisible(false);
	IWEventRegistry.addItemHandler("/Config/PreviewOnly", "onItemChange", scheduleWorkflow);
	scheduleWorkflow();
 wfContainsFiles();
 o.iwInitialised = true;

}
function scheduleWorkflow(){
	
	var index = IWDatacapture.getItem("/Config/PreviewOnly").getValue();
	var option = IWDatacapture.getItem("/Config/PreviewOnly").getOptions();
	var value = option[index].value;
 if(value == 'true'){
 		IWDatacapture.getItem("/Config/TimeZones").setVisible(false);
		IWDatacapture.getItem("/Config/DeployDate").setVisible(false);
    IWDatacapture.getItem("/Config/TimeZones").setValue("");
		IWDatacapture.getItem("/Config/DeployDate").setValue("");
 }
	var groups = IWDatacapture.getGroups();
		//if(groups.includes("PowerUserGroup")){
		if(groups.includes("dce-cms-cpw-schedule")){
			if(value == 'false'){
				IWDatacapture.getItem("/Config/PublishTime").setVisible(true);
           showOrHideItems();
				
				
				return true;
			}
			else{
				IWDatacapture.getItem("/Config/PublishTime").setVisible(false);
        
			}
		}
   
}

function containsAny(str, substrings) {
var YES = false;   
 for (var i = 0; i != substrings.length; i++) {
       var substring = substrings[i];
       
       if (str.includes(substring)) {
         YES=true;
       }
    }
    return YES; 
}
	function wfContainsFiles() {
	var show = false;
	var Filelist = IWDatacapture.getItem("/Config/").getChildren();

	 var selectedFiles = [];
	 for(var i=0; i<Filelist.length; i++) {              
		if (Filelist[i].getName().indexOf("/Config/File")>-1) {
		

	selectedFiles.push(Filelist[i].getLabel());
		}
	 }

  
	for(var j=0; j<selectedFiles.length; j++) {
	 
	var result = containsAny(selectedFiles[j], ["sites/deere/us/en/website/includes"]);
		if (result) {
			show=true;
			}
			
		}
	if(show && !showdone){

	showdone=true;
	IWDatacapture.postFormInfoMessage("\u201cATTENTION: Publishing of Menu DCR is selected, any change in Menu DCR will be updated affecting the header on all the LIVE pages.Please confirm you are aware of the site impact before proceeding.\u201d");
	}
	else{


	}
}


function showOrHideItems() {
	
	var index = IWDatacapture.getItem("/Config/PublishTime").getValue();
	var option = IWDatacapture.getItem("/Config/PublishTime").getOptions();
 
	var value = option[index].value;
	if (value == 'publishNow'){
		IWDatacapture.getItem("/Config/TimeZones").setVisible(false);
		IWDatacapture.getItem("/Config/DeployDate").setVisible(false);
		IWDatacapture.getItem("/Config/TimeZones").setRequired(false);
		IWDatacapture.getItem("/Config/DeployDate").setRequired(false);
		IWDatacapture.getItem("/Config/TimeZones").setValue("");
		IWDatacapture.getItem("/Config/DeployDate").setValue("");
	}
	if (value == 'publishLater'){
 
		IWDatacapture.getItem("/Config/TimeZones").setVisible(true);
		IWDatacapture.getItem("/Config/DeployDate").setVisible(true);
		IWDatacapture.getItem("/Config/TimeZones").setRequired(true);
		IWDatacapture.getItem("/Config/DeployDate").setRequired(true);
    IWDatacapture.getItem("/Config/DeployDate").setReadOnly(true);
	}
}
o.ready = function() {

    o.loadStylesheets();            
}
function validateDate(){
var dateSet = IWDatacapture.getItem("/Config/DeployDate").getValue();
alert("dateSet >> "+dateSet);

}
 
o.loadStylesheets = function() {
    
    var f = window.top.formframe.document;
    var head = f.getElementsByTagName('head')[0];     
    $(o.stylesheets).each(function() {
        var script = f.createElement("link");
        script.setAttribute("rel", "stylesheet");
        script.setAttribute("type", "text/css");
        script.setAttribute("href", this);
        head.appendChild(script);
        var meta = f.createElement("meta");
        meta.setAttribute("http-equiv", "X-UA-Compatible");
        meta.setAttribute("content", "IE=edge");
       
        head.appendChild(meta);
    });         
    o.loadScripts();
}
o.loadScripts = function() {                
    var f = window.top.formframe.document;
    if(o.loadedScripts < o.scripts.length) {
          
        var head = f.getElementsByTagName('head')[0];
        var src = o.scripts[o.loadedScripts];
        var script = f.createElement('script');          
        script.setAttribute('src', src);
        script.setAttribute('type', 'text/javascript');
        o.loadedScripts++;
        script.onreadystatechange= function () {
            if (this.readyState == 'loaded') o.loadScripts();
        }
        script.onload = o.loadScripts;
        head.appendChild(script);
    } else {
        
        o.topFrameLoaded();
    }
}  
    
    function pad(d){
       return(d<10) ? '0' + d : d;
    }
    
  setDates=function(){
        var f = window.top.formframe;
        var d = new Date();
        var days = 30;
        arrayOfDates = [];
        checkdates =[];
        for (i = 0; i <= days; i++) {
        var d = new Date();
        d.setDate(d.getDate() + i);
        datestring = '';
        datestring = d.getFullYear() + '-' + (d.getMonth()) + '-' + d.getDate(); 
        
        var checkdateString = pad(d.getMonth()+1) + '/' + pad(d.getDate()) + '/' + d.getFullYear();
        checkdates.push(checkdateString);
        arrayOfDates.push(datestring); 
        } 
        
        f.$.each(arrayOfDates, function(index, date) {
   
         var getDateinfo = date.split("-");
         var getYear = getDateinfo[0];
         var getMonth = getDateinfo[1];
         var getday = getDateinfo[2];
         
         f.$("td[data-date="+getday+"][data-month="+getMonth+"][data-year="+getYear+"]").removeClass("xdsoft_disabled");
        });
        
    
    }
    setInterval(function(){ 
      var f = window.top.formframe; 
       if (f.$('.xdsoft_datetimepicker').css('display') == 'block')
              {
              setDates();
              }
              else{}
    }, 100);
o.topFrameLoaded = function() {     
var f = window.top.formframe; 

f.$("input[name*='DeployDate']").datetimepicker({
      format: 'm/d/Y H:i:s',
      formatDate:'Y/m/d',
      defaultTime:'10:00',
      step:1,
      showSecond:true,
      openOnFocus:true,
      onGenerate:function(ct){
        f.$(this).find('.xdsoft_date').toggleClass('xdsoft_disabled');
        //f.$('div.xdsoft_time_variant .xdsoft_time').toggleClass('xdsoft_disabled');
        //f.$(this).find('.xdsoft_time_box').css("display","none"); 
        
          
      } ,
      onSelectDate:function () {},

      onClose: function( selectedDate, inst ) {
        //f.$( this ).datetimepicker( "option", 'formatDate', 'Y/m/d' );
        
        var date2 = f.$(this).datetimepicker('getDate');
       // alert("date2>>> "+date2);
        var mm = selectedDate.getMonth();
        var dd = selectedDate.getDate();
        var yy = selectedDate.getFullYear();
        var hh = selectedDate.getHours();
        var ii = selectedDate.getMinutes();
        var selectedDate  = yy + '-' + mm + '-' + dd;
        //alert("Selected Date is >> "+selectedDate);
        //alert("Array of Dates>> "+arrayOfDates);
        var x;
        var decision = 0;
        for(x of arrayOfDates){
          if (selectedDate == x){
          decision =1;
          }
          else{}
        }
        if(decision == 0){
        f.$("input[name*='DeployDate']").val("");
        }
        else{
        f.$("input[name*='DeployDate']").val(pad(mm+1) + "/" + pad(dd) + "/" + yy + " " + pad(hh) + ":" + pad(ii) + ":" + '00');
        }
        f.$( this ).datetimepicker( "option", 'format', 'm/d/Y H:i:s' );
        
      }
    });


    f.$('button.ui-datepicker-current').on('click', function() {
    
        f.$.datetimepicker._curInst.input.datetimepicker('setDate', new Date()).datetimepicker('hide').blur();
        
    });
    

    f.$('button.ui-datepicker-close').on('click', function() {
        //f.$.datepicker._curInst.input.datepicker('setDate','12/31/9999').datepicker('hide').blur();
    });

}   
IWEventRegistry.addFormHandler("onFormInit", o.iwInitalise);
IWEventRegistry.addItemHandler('/Config/TimeZones', 'onItemChange', o.ready);
IWEventRegistry.addItemHandler("/Config/PublishTime", "onItemChange", showOrHideItems);

