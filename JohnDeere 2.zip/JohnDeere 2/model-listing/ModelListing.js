"use strict";

var ModelListing = (function () {

    var initModelListing = function() {

        IWEventRegistry.addItemHandler(CMSItem.getItem("ImageLarge").getName(), 'onCallout', doBrowse);
        IWDatacapture.getItem("/ModelListingContainer/CategoryList").setVisible(false);
       var index = IWDatacapture.getItem("/ModelListingContainer/populate").getValue();
      
      if(index == null){
             IWDatacapture.getItem("/ModelListingContainer/populate").setValue(0);

      }

    }

    CMSItem.addInitHandler(initModelListing);

    return {
        init : initModelListing
    };

})();

IWEventRegistry.addItemHandler("/ModelListingContainer/populate", "onItemChange", setVisibleData);
		IWEventRegistry.addItemHandler("/ModelListingContainer/CategoryList", "onItemChange", setData);
   function setVisibleData(){
       var index = IWDatacapture.getItem("/ModelListingContainer/populate").getValue();
	    var option = IWDatacapture.getItem("/ModelListingContainer/populate").getOptions();
	    var value = option[index].value;
        if(value == 'true'){
          IWDatacapture.getItem("/ModelListingContainer/CategoryList").setVisible(true);
        }
        else{
        IWDatacapture.getItem("/ModelListingContainer/CategoryList").setVisible(false);
        }
}
		function setData(){
		
        var index = IWDatacapture.getItem("/ModelListingContainer/populate").getValue();
	    var option = IWDatacapture.getItem("/ModelListingContainer/populate").getOptions();
	    var value = option[index].value;
        if(value == 'true'){
          //IWDatacapture.getItem("/ModelListingContainer/CategoryList").setVisible(true);
         // alert("Data Changed "+value);
          var cat = IWDatacapture.getItem("/ModelListingContainer/CategoryList");
        
           if (cat.getValue() != undefined && cat.getValue() != null){
            var catVal = cat.getOptions()[cat.getValue()].value;
             //alert(catVal);
             catVal = catVal+"_product_information";
             var modelNumber = IWDatacapture.getItem("/ModelListingContainer/ProductModelNumber").getValue();
             
               //alert(modelNumber);
               if(modelNumber != ""){
                 var datasourceObj = new IWDatasource();
               var dsParams = new IWMap();
                  var returnParams = new IWMap();
                 dsParams.put("configAttr", "GETPRODUCT");
                 dsParams.put("listingType", catVal);
                 dsParams.put("model",modelNumber);
                 returnParams.put("selectItemVpath", "selectItemVpath");
                 datasourceObj.executeDatasource("setDatasourceValueCallback", "GetCatTables", dsParams, returnParams);
               }
               else{
             alert("Product Model number is Empty!! Kindly do enter the Product Model Number");
                 IWDatacapture.getItem("/ModelListingContainer/CategoryList").setVisible(false);
               }
           }
           else{
             //alert("null for cat");
           }
        }
        
          
		}
   function setDatasourceValueCallback(resultObj, ctxParams){
                 console.dir(resultObj);
                 if (IWMap.prototype.isPrototypeOf(resultObj)) {
                   var keysArr = resultObj.keys();
                   var replicantInstance = keysArr.length;
                   addReplicants(replicantInstance);
                   var ObjArray = resultObj.array;
                   var iReplicant=1;
                   Object.keys(ObjArray).forEach(function (key) {
                    var Objval = ObjArray[key];
                    var key = Objval.key;
					var value = Objval.value;
                    setValuesinReplicants(iReplicant,key,value); 
                    iReplicant++;
                    // console.log(key+"=>"+value);
                   });
                  }
                  
                 
              }

function addReplicants(replicantInstance){

                  var replicantCount = IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer").getChildren().length;
                  for(let i=replicantCount; i < replicantInstance; i++){
                    IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer").addInstance(i,"and");
                  }
                 }

function setValuesinReplicants(iReplicant,key,value){

  if(key.includes("[")){
                      key = key.substring(key.lastIndexOf("[") + 1,key.lastIndexOf("]"));
                       }
  if(!value.includes("|")){
  IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterSystemId").setValue(key);
      
  if(value.length > 1){  
   var last2 = value.slice(-2);
    if(last2 == ".0"){
   
      value = value.replace(".0","");
    }
  }
  IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterValue[1]").setValue(value);
  }
  else{
  IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterSystemId").setValue(key);
  var multipleFilterValues = value.split("|");
  var k = multipleFilterValues.length;
  // console.log(value);
   for(var h =0; h < k; h++){
   //console.log(multipleFilterValues[h]);
      var replicantCountValue = IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterValue").getChildren().length;
       for(let j=replicantCountValue; j < k; j++){
              IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterValue").addInstance(j,"and");
          }  
     
     var p = h+1;
     
  IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterValue["+p+"]").setValue(multipleFilterValues[h]);
     
   }
    var replicantCountValue = IWDatacapture.getItem("/ModelListingContainer/ManualFilterAttrContainer["+iReplicant+"]/FilterValue").getChildren().length;
    //console.log(replicantCountValue);
  }
}
