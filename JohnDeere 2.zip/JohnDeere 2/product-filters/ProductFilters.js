"use strict";

var ProductFilters = (function () {

    var initProductFilters = function() {
        
      IWDatacapture.getItem("/ProductFilters/CategoryList").setVisible(false);
      
      var index = IWDatacapture.getItem("/ProductFilters/populate").getValue();
      
      if(index == null){
             IWDatacapture.getItem("/ProductFilters/populate").setValue(0);

      }
      
        var filterContainerParent = CMSItem.getItem("FilterGroupContainer");
        IWEventRegistry.addItemHandler(filterContainerParent.getName(), "onReplicantAdded", addedFilterContainer);

        var containers = filterContainerParent.getChildren();
        if (containers) {
            containers.forEach(addedFilterContainer);
        }

    };

    var addedFilterContainer = function(filterContainer) {
        var filterTypeItem = CMSItem.getChildByName(filterContainer.getName(), "FilterType");
        changedFilterType(filterTypeItem);
        IWEventRegistry.addItemHandler(filterTypeItem.getName(), "onItemChange", changedFilterType);
    };

    var changedFilterType = function(filterTypeItem) {

        var filterContainer = CMSItem.getParent(filterTypeItem.getName());

        var rangeFieldsVisible = false;
        if (CMSItem.isValueSelected(filterTypeItem, "range")) {
            rangeFieldsVisible = true;
        } 

        var minValueItem = CMSItem.getChildByName(filterContainer.getName(), "FilterMinValueLabel");
        CMSItem.setVisible(minValueItem.getName(), rangeFieldsVisible);
        var maxValueItem = CMSItem.getChildByName(filterContainer.getName(), "FilterMaxValueLabel");
        CMSItem.setVisible(maxValueItem.getName(), rangeFieldsVisible);
        var dataPrefixItem = CMSItem.getChildByName(filterContainer.getName(), "FilterDataPrefix");
        CMSItem.setVisible(dataPrefixItem.getName(), rangeFieldsVisible);
        var dataSuffixItem = CMSItem.getChildByName(filterContainer.getName(), "FilterDataSuffix");
        CMSItem.setVisible(dataSuffixItem.getName(), rangeFieldsVisible);

        var optionContainerParent = CMSItem.getChildByName(filterContainer.getName(), "FilterOptionContainer");
        CMSItem.setVisible(optionContainerParent.getName(), !rangeFieldsVisible);

    };

    CMSItem.addInitHandler(initProductFilters);

    return {
        init : initProductFilters
    };

})();
       
 IWEventRegistry.addItemHandler("/ProductFilters/CategoryList", "onItemChange", setReplicants);
 IWEventRegistry.addItemHandler("/ProductFilters/populate", "onItemChange", setData);

var valueCategoryList="";

function setData(){
  
var indexCategoryList = IWDatacapture.getItem("/ProductFilters/CategoryList").getValue();
var optionCategoryList =IWDatacapture.getItem("/ProductFilters/CategoryList").getOptions();
var index = IWDatacapture.getItem("/ProductFilters/populate").getValue();
	    var option = IWDatacapture.getItem("/ProductFilters/populate").getOptions();
	    var value = option[index].value;
		//alert(value);
        if(value == 'true'){
          IWDatacapture.getItem("/ProductFilters/CategoryList").setVisible(true);
        }else{
        
          IWDatacapture.getItem("/ProductFilters/CategoryList").setVisible(false);
          //clearReplicants("/ProductFilters/FilterGroupContainer","FilterOptionContainer");
        }
  
}
					
var rangeObject = new Map();
function setReplicants(){
 
 // alert(valueCategoryList);  
  if(valueCategoryList != ""){
  clearReplicants("/ProductFilters/FilterGroupContainer","FilterOptionContainer");
  }
  var cat = IWDatacapture.getItem("/ProductFilters/CategoryList");
  var catVal = cat.getOptions()[cat.getValue()].value;

  valueCategoryList = catVal;
  if (catVal != ""){
    catVal = catVal+"_product_information";
    // alert(catVal);
    var datasourceObj = new IWDatasource();
    var datasourceRangeObj = new IWDatasource();
    var dsParams = new IWMap();
    var returnParams = new IWMap();
    var dsRangeParams = new IWMap();
    dsRangeParams.put("configAttr", "GETPRODUCTRANGE");
    dsRangeParams.put("listingType", catVal);
    returnParams.put("selectItemVpath", "selectItemVpath");
    datasourceRangeObj.executeDatasource("getRangeValueCallback", "GetCatTables", dsRangeParams, returnParams);
    dsParams.put("configAttr", "GETPRODUCTCATEGORY");
    dsParams.put("listingType", catVal);
    datasourceObj.executeDatasource("setDatasourceValueCallback", "GetCatTables", dsParams, returnParams);
    return;
    //IWDatacapture.getItem("/ProductFilters/FilterGroupContainer").addInstance(0,"and");
  }
  else{
  
   clearReplicants("/ProductFilters/FilterGroupContainer","FilterOptionContainer");
  
  }
}

function clearReplicants(FilterGroupContainerValue,FilterOptionContainerValue){
var replicantTOClear = IWDatacapture.getItem(FilterGroupContainerValue).getChildren().length;
//alert(replicantTOClear);
  for(let crep=replicantTOClear; crep > 0; crep--){
     var getItemPath= FilterGroupContainerValue+"["+crep+"]/"+FilterOptionContainerValue;
    var getFilterType=FilterGroupContainerValue+"["+crep+"]/"+"FilterType";
    var replicantFilValueOptionsToClear = IWDatacapture.getItem(getFilterType);
    var replicantFilValueToClear = replicantFilValueOptionsToClear.getOptions()[replicantFilValueOptionsToClear.getValue()].value;
    
    
   
     // alert(replicantFilValueToClear);
    var filterReplicantContainerCountToClear = IWDatacapture.getItem(getItemPath).getChildren().length;
   
     for(var crepsub=filterReplicantContainerCountToClear; crepsub >= 0; crepsub--){
       // alert("Deleting "+ getItemPath + " of instance " + crepsub);
        IWDatacapture.getItem(getItemPath).deleteInstance(crepsub);
       
      }
    IWDatacapture.getItem(FilterGroupContainerValue).deleteInstance(crep);
    
  }
  
  
  IWDatacapture.getItem("/ProductFilters/FilterGroupContainer[1]/FilterHeaderNameLabel").setValue("");
  IWDatacapture.getItem("/ProductFilters/FilterGroupContainer[1]/FilterSystemValue").setValue("");
  IWDatacapture.getItem("/ProductFilters/FilterGroupContainer[1]/FilterOptionContainer[1]/FilterOptionText").setValue("");
  IWDatacapture.getItem("/ProductFilters/FilterGroupContainer[1]/FilterOptionContainer[1]/FilterOptionValue").setValue("");
  
  
  
}



function getRangeValueCallback(resultRangeObj, ctxParams){
  console.dir(resultRangeObj);
  if (IWMap.prototype.isPrototypeOf(resultRangeObj)) {
    var keysArr = resultRangeObj.keys();
    for (var u = 0; u < keysArr.length; u++) {
      var KeyVal = keysArr[u];
      var displayVal = resultRangeObj.get(keysArr[u]);
      KeyVal = cleanString(KeyVal);
      rangeObject.set(KeyVal,displayVal);
    }
  }
}
function setDatasourceValueCallback(resultObj, ctxParams){
  if (IWMap.prototype.isPrototypeOf(resultObj)) {
    console.dir(resultObj);
    var keysArr = resultObj.keys();
    var replicantInstance = keysArr.length;
    addReplicants(replicantInstance);
    var ObjArray = resultObj.array;
    var iReplicant=1;
    Object.keys(ObjArray).forEach(function (key) {
      var Objval = ObjArray[key];
      var key = Objval.key;
      var value = Objval.value;
      setValuesinReplicants(iReplicant,key,value);
      //alert(iReplicant); 
      iReplicant++;
      // console.log(key+"=>"+value);
    }
    );
  }
  var replicantCountHandle = IWDatacapture.getItem("/ProductFilters/FilterGroupContainer").getChildren().length;
  //alert(replicantCountHandle);
  for(let b=1; b <= replicantCountHandle; b++){
    var replicantFilValueOptions = IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+b+"]/FilterType");
    var replicantFilValue = replicantFilValueOptions.getOptions()[replicantFilValueOptions.getValue()].value;
    if(replicantFilValue =="range"){
      var filterReplicantContainer = IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+b+"]/FilterOptionContainer");
      var filterReplicantContainerCount = filterReplicantContainer.getChildren().length;
      if(filterReplicantContainerCount == 1){
        // alert(filterReplicantContainerCount);
        IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+b+"]/FilterOptionContainer").setVisible(false);
      }
    }
  }
}
function addReplicants(replicantInstance){
  var replicantCount = IWDatacapture.getItem("/ProductFilters/FilterGroupContainer").getChildren().length;
  for(let i=replicantCount; i < replicantInstance; i++){
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer").addInstance(i,"and");
  }
}
function setValuesinReplicants(iReplicant,key,value){
  //console.log(iReplicant + "=>" + key + "=>" + value);
  var filterIWItem = IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterType").getOptions();
  var filter="";
  if(key.includes("^")){
    var filterNameArray = key.split("^");
    key =  filterNameArray[0];
    filter = filterNameArray[1];
  }
  if(!key.includes("|")){
    //alert("doesnt contain | " + key);
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterHeaderNameLabel").setValue(key);
    if(value.includes("[")){
      value = value.substring(value.lastIndexOf("[") + 1,value.lastIndexOf("]"));
    }
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterSystemValue").setValue(value);
    // alert("filter is >> "+filter);
    for(var h =0; h < filterIWItem.length; h++){
      //console.log("Checking if "+filterIWItem[h].value + " is equal to " + filter);
      if(filterIWItem[h].value == filter){
        filterIWItem[h].selected=true;
      }
    }
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterType").setOptions(filterIWItem);
    setRange("/ProductFilters/FilterGroupContainer["+iReplicant+"]",filter)
  }
  if(key.includes("|")){
    //alert(" contain | " + key);
    var multipleFilterValues = key.split("|");
    var NameLabel = cleanString(multipleFilterValues[0]);
    if(NameLabel.includes("[")){
      NameLabel = NameLabel.substring(NameLabel.lastIndexOf("[") + 1,NameLabel.lastIndexOf("]"));
    }
    var SystemValue = cleanString(multipleFilterValues[1]);
    if(SystemValue.includes("[")){
      SystemValue = SystemValue.substring(SystemValue.lastIndexOf("[") + 1,SystemValue.lastIndexOf("]"));
    }
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterHeaderNameLabel").setValue(NameLabel);
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterSystemValue").setValue(SystemValue);
    //alert("filter is >> "+filter)
    for(var h =0; h < filterIWItem.length; h++){
      if(filterIWItem[h].value == filter){
        filterIWItem[h].selected=true;
      }
    }
    setRange("/ProductFilters/FilterGroupContainer["+iReplicant+"]",filter)
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterType").setOptions(filterIWItem);
    if(key.includes("|")){
      var filterOptValues = value.split("|");
      var filterReplicantInstance = filterOptValues.length;
      var filterReplicantCount = IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterOptionContainer").getChildren().length;
      for(let k=0; k < filterReplicantInstance-1; k++)
      {
        IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterOptionContainer").addInstance(k,"and");
        //console.log("Added"+k);
      }
      setFilterOptionValues(filterOptValues,iReplicant);
    }
  }
}
function  setFilterOptionValues(filterOptValues,iReplicant){
  for(var n =0 ; n <filterOptValues.length; n++){
    //console.log(filterOptValues[n]);
    var textToFilter = filterOptValues[n];
    var filterOptionValue = textToFilter.substring(textToFilter.lastIndexOf("[") + 1,textToFilter.lastIndexOf("]"));
    var filterOptionText = textToFilter.replace(/\s*\[.*?\]\s*/g, '');
    var y =n+1;
    //console.log("setting filterOptionValue "+filterOptionValue+ " and setting filterOptionText "+textToFilter);
    //console.log(IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterOptionContainer["+y+"]/FilterOptionText"));
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterOptionContainer["+y+"]/FilterOptionText").setValue(filterOptionText);
    IWDatacapture.getItem("/ProductFilters/FilterGroupContainer["+iReplicant+"]/FilterOptionContainer["+y+"]/FilterOptionValue").setValue(filterOptionValue);
  }
}
function cleanString(str){
  return str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
}
function setRange(replicant ,fil){
  if(fil == "range"){
    IWDatacapture.getItem(replicant+"/FilterMinValueLabel").setVisible(true);
    IWDatacapture.getItem(replicant+"/FilterMaxValueLabel").setVisible(true);
    IWDatacapture.getItem(replicant+"/FilterDataPrefix").setVisible(true);
    IWDatacapture.getItem(replicant+"/FilterDataSuffix").setVisible(true);
    var fsv = IWDatacapture.getItem(replicant+"/FilterSystemValue").getValue()
    var minmax =rangeObject.get(fsv);
    if(minmax !== null && minmax !== "" && minmax !== undefined){
      var minmaxArray = minmax.split("|");
      var min = minmaxArray[0];
      var max = minmaxArray[1];
      IWDatacapture.getItem(replicant+"/FilterMinValueLabel").setValue(min);
      IWDatacapture.getItem(replicant+"/FilterMaxValueLabel").setValue(max);
    }
  }
}


